import java.applet.*;
import java.awt.*;
import EvalExpr;

//Ser vivo
class cSerVivo extends Applet
{
	//Instancia del evaluador de expresiones
	EvalExpr eEvalua;

	//Expresion o ADN del ser vivo
	String sExpresion;
	
	//Adaptacion del ser vivo al medio ambiente (entre mas se aproxime a cero mejor)
	float fAproxima;

	//Energia acumulada del ser vivo
	double dEnergia;
	double dRecursovsAdaptacion;

	
	//El ambiente
	int m_iSerieNum[] = new int[50]; //El ambiente en numeros enteros
	double m_dSerieNum[] = new double [50]; //El ambiente en numeros double
	int m_iContSerie;	//Numero de elementos en la serie
	int m_iCodAmbiente; // Codigo del Ambiente


	public cSerVivo()
	{
		eEvalua = new EvalExpr();
		dEnergia = 0.0;
		fAproxima = 0;
		dRecursovsAdaptacion = 0.0;
		m_iContSerie = 0;
		m_iCodAmbiente = 0;
	}

	public void vAmbiente(String m_sSerieNum)
	{
		int iCont;
		String sAcum="";
		m_iContSerie=0;

		// Ahora deshace la expresion en un arreglo de enteros
		for(iCont=0; iCont<=m_sSerieNum.length()-1; iCont++)
		{
			if (m_sSerieNum.charAt(iCont) != ',' )
				sAcum += m_sSerieNum.charAt(iCont);
			else
			{
				if (sAcum.length()>0)
				{
					m_iSerieNum[m_iContSerie]=Integer.parseInt(sAcum);
					m_iContSerie++;
					sAcum="";
				}
			}
		}
	}
	
	public int iAdaptarse01()  //Chequea su sintaxis
	{
		if (sExpresion.length() > 0)
			return eEvalua.iChequeaSintaxis(sExpresion,1);
		else
			return -1;
	}

	public double dAdaptarse02() //Chequea su adaptacion a la serie (ambiente)
	{
		double dDiferenc; // La diferencia entre la serie y el valor que deduce la expresion
		double dTotDifer=0; //La sumatoria de diferencias
		double dX=0; //Variable X
		int iCont;

		double dResult = eEvalua.dCapturaecuacion(sExpresion, 0, 0);

		for(iCont=0; iCont<m_iContSerie; iCont++)
		{
		   dX++;
		   dDiferenc=m_iSerieNum[iCont]-eEvalua.CicloEvalua(dX, 0);
		   if (eEvalua.m_iERROR==1) return 99999999;
		   if (dDiferenc<0) dDiferenc*=-1;
		   dTotDifer+=dDiferenc;
		}
		return dTotDifer;
	}

	public void vAdaptarse03() //Chequea su adaptacion y los recursos
	{
		double dDiferenc; // La diferencia entre la serie y el valor que deduce la expresion
		double dTotDifer=0; //La sumatoria de diferencias
		double dX=0; //Variable X
		int iCont;
		double dRecurso=0;

		double dResult = eEvalua.dCapturaecuacion(sExpresion, 0, 0);

		for(iCont=0; iCont<m_iContSerie; iCont++)
		{
		   dX++;
		   dDiferenc=m_dSerieNum[iCont]-eEvalua.CicloEvalua(dX, 0);
		   dRecurso+=Math.abs(m_dSerieNum[iCont]);
		   if (eEvalua.m_iERROR==1) break;
		   if (dDiferenc<0) dDiferenc*=-1;
		   dTotDifer+=dDiferenc;
		}
		dRecursovsAdaptacion = dRecurso - dTotDifer;
	}
}
