//------------------------------------------------------------------------------
// frmAlifeSim6.java:
//		Implementation for container control initialization class frmAlifeSim6
//
// WARNING: Do not modify this file.  This file is recreated each time its
//          associated .rct/.res file is sent through the Java Resource Wizard!
//
// This class can be use to create controls within any container, however, the
// following describes how to use this class with an Applet.  For addtional
// information on using Java Resource Wizard generated classes, refer to the
// Visual J++ 1.1 documention.
//
// 1) Import this class in the .java file for the Applet that will use it:
//
//      import frmAlifeSim6;
//
// 2) Create an instance of this class in your Applet's 'init' member, and call
//    CreateControls() through this object:
//
//      frmAlifeSim6 ctrls = new frmAlifeSim6 (this);
//      ctrls.CreateControls();
//
// 3) To process events generated from user action on these controls, implement
//    the 'handleEvent' member for your applet:
//
//      public boolean handleEvent (Event evt)
//      {
//
//      }
//
//------------------------------------------------------------------------------
import java.awt.*;
import DialogLayout;

public class frmAlifeSim6
{
	Container    m_Parent       = null;
	boolean      m_fInitialized = false;
	DialogLayout m_Layout;

	// Control definitions
	//--------------------------------------------------------------------------
	Button        cmdOK;
	Button        cmdStop;
	Label         lblExprAmb01;
	TextField     txtExpr1;
	Label         lblExprAmb02;
	TextField     txtExpr2;
	Label         lblExprAmb03;
	TextField     txtExpr3;
	Label         lblSerVivo4;
	TextField     txtSerVivo1;
	Label         lblEnergia;
	Label         lblAmbiente;
	TextField     txtEnergia1;
	TextField     txtVivoAmb1;
	Label         lblIntento1;
	TextField     txtIntento1;
	Label         lblPosX;
	Label         lblPosN;
	Label         lblParentesis;
	TextField     txtPosX;
	TextField     txtPosN;
	TextField     txtPosP;
	Label         lblExplica;
	Label         lblLongADN;
	TextField     txtLongADN;
	Label         lblNivelMax;
	TextField     txtMaxEnergia;
	Label         lblEnerInic;
	TextField     txtEnergInic;
	Label         lblLongAmb;
	TextField     txtNumSerAmb;
	Label         lblAcumSerMasDura;
	Label         lblAcumVidaEterna;
	TextField     txtMortal;
	TextField     txtInmortal;


	// Constructor
	//--------------------------------------------------------------------------
	public frmAlifeSim6 (Container parent)
	{
		m_Parent = parent;
	}

	// Initialization.
	//--------------------------------------------------------------------------
	public boolean CreateControls()
	{
		// Can only init controls once
		//----------------------------------------------------------------------
		if (m_fInitialized || m_Parent == null)
			return false;

		// Parent must be a derivation of the Container class
		//----------------------------------------------------------------------
		if (!(m_Parent instanceof Container))
			return false;

		// Since there is no way to know if a given font is supported from
		// platform to platform, we only change the size of the font, and not
		// type face name.  And, we only change the font if the dialog resource
		// specified a font.
		//----------------------------------------------------------------------
		Font OldFnt = m_Parent.getFont();
		
		if (OldFnt != null)
		{
			Font NewFnt = new Font(OldFnt.getName(), OldFnt.getStyle(), 8);

			m_Parent.setFont(NewFnt);
		}

		// All position and sizes are in Dialog Units, so, we use the
		// DialogLayout manager.
		//----------------------------------------------------------------------
		m_Layout = new DialogLayout(m_Parent, 419, 186);
		m_Parent.setLayout(m_Layout);
		m_Parent.addNotify();

		Dimension size   = m_Layout.getDialogSize();
		Insets    insets = m_Parent.insets();
		
		m_Parent.resize(insets.left + size.width  + insets.right,
                        insets.top  + size.height + insets.bottom);

		// Control creation
		//----------------------------------------------------------------------
		cmdOK = new Button ("Simule");
		m_Parent.add(cmdOK);
		m_Layout.setShape(cmdOK, 365, 41, 40, 12);

		cmdStop = new Button ("Detener");
		m_Parent.add(cmdStop);
		m_Layout.setShape(cmdStop, 365, 58, 40, 13);

		lblExprAmb01 = new Label ("Ambiente 1:", Label.LEFT);
		m_Parent.add(lblExprAmb01);
		m_Layout.setShape(lblExprAmb01, 21, 41, 40, 11);

		txtExpr1 = new TextField ("");
		m_Parent.add(txtExpr1);
		m_Layout.setShape(txtExpr1, 65, 39, 260, 13);

		lblExprAmb02 = new Label ("Ambiente 2:", Label.LEFT);
		m_Parent.add(lblExprAmb02);
		m_Layout.setShape(lblExprAmb02, 21, 56, 40, 11);

		txtExpr2 = new TextField ("");
		m_Parent.add(txtExpr2);
		m_Layout.setShape(txtExpr2, 65, 52, 260, 13);

		lblExprAmb03 = new Label ("Ambiente 3:", Label.LEFT);
		m_Parent.add(lblExprAmb03);
		m_Layout.setShape(lblExprAmb03, 21, 69, 39, 11);

		txtExpr3 = new TextField ("");
		m_Parent.add(txtExpr3);
		m_Layout.setShape(txtExpr3, 65, 65, 260, 13);

		lblSerVivo4 = new Label ("Ser Vivo", Label.LEFT);
		m_Parent.add(lblSerVivo4);
		m_Layout.setShape(lblSerVivo4, 21, 113, 37, 10);

		txtSerVivo1 = new TextField ("");
		m_Parent.add(txtSerVivo1);
		m_Layout.setShape(txtSerVivo1, 21, 124, 168, 13);

		lblEnergia = new Label ("Energia", Label.LEFT);
		m_Parent.add(lblEnergia);
		m_Layout.setShape(lblEnergia, 203, 114, 28, 10);

		lblAmbiente = new Label ("Ambiente Actual", Label.LEFT);
		m_Parent.add(lblAmbiente);
		m_Layout.setShape(lblAmbiente, 251, 114, 56, 10);

		txtEnergia1 = new TextField ("");
		m_Parent.add(txtEnergia1);
		m_Layout.setShape(txtEnergia1, 195, 124, 48, 13);

		txtVivoAmb1 = new TextField ("");
		m_Parent.add(txtVivoAmb1);
		m_Layout.setShape(txtVivoAmb1, 259, 124, 41, 12);

		lblIntento1 = new Label ("Intento", Label.LEFT);
		m_Parent.add(lblIntento1);
		m_Layout.setShape(lblIntento1, 323, 116, 30, 9);

		txtIntento1 = new TextField ("");
		m_Parent.add(txtIntento1);
		m_Layout.setShape(txtIntento1, 319, 126, 33, 12);

		lblPosX = new Label ("Posibilidad.  X=", Label.LEFT);
		m_Parent.add(lblPosX);
		m_Layout.setShape(lblPosX, 22, 19, 49, 10);

		lblPosN = new Label ("1..9:", Label.LEFT);
		m_Parent.add(lblPosN);
		m_Layout.setShape(lblPosN, 109, 18, 15, 11);

		lblParentesis = new Label ("(, ) :", Label.LEFT);
		m_Parent.add(lblParentesis);
		m_Layout.setShape(lblParentesis, 163, 20, 13, 10);

		txtPosX = new TextField ("");
		m_Parent.add(txtPosX);
		m_Layout.setShape(txtPosX, 73, 17, 25, 15);

		txtPosN = new TextField ("");
		m_Parent.add(txtPosN);
		m_Layout.setShape(txtPosN, 125, 17, 26, 14);

		txtPosP = new TextField ("");
		m_Parent.add(txtPosP);
		m_Layout.setShape(txtPosP, 177, 16, 26, 16);

		lblExplica = new Label ("Posibilidades para generar ambientes y seres vivos", Label.LEFT);
		m_Parent.add(lblExplica);
		m_Layout.setShape(lblExplica, 213, 18, 167, 8);

		lblLongADN = new Label ("Longitud del Ser Vivo:", Label.LEFT);
		m_Parent.add(lblLongADN);
		m_Layout.setShape(lblLongADN, 22, 100, 72, 10);

		txtLongADN = new TextField ("");
		m_Parent.add(txtLongADN);
		m_Layout.setShape(txtLongADN, 95, 98, 22, 12);

		lblNivelMax = new Label ("Maxima Energia:", Label.LEFT);
		m_Parent.add(lblNivelMax);
		m_Layout.setShape(lblNivelMax, 126, 99, 52, 9);

		txtMaxEnergia = new TextField ("");
		m_Parent.add(txtMaxEnergia);
		m_Layout.setShape(txtMaxEnergia, 181, 97, 35, 13);

		lblEnerInic = new Label ("Energia Inicio:", Label.LEFT);
		m_Parent.add(lblEnerInic);
		m_Layout.setShape(lblEnerInic, 233, 99, 47, 10);

		txtEnergInic = new TextField ("");
		m_Parent.add(txtEnergInic);
		m_Layout.setShape(txtEnergInic, 282, 97, 23, 12);

		lblLongAmb = new Label ("# Elementos de la serie para ambiente:", Label.LEFT);
		m_Parent.add(lblLongAmb);
		m_Layout.setShape(lblLongAmb, 21, 82, 123, 11);

		txtNumSerAmb = new TextField ("");
		m_Parent.add(txtNumSerAmb);
		m_Layout.setShape(txtNumSerAmb, 147, 81, 34, 12);

		lblAcumSerMasDura = new Label ("# de Seres Vivos que duraron finito (hasta que su energia llego a cero):", Label.LEFT);
		m_Parent.add(lblAcumSerMasDura);
		m_Layout.setShape(lblAcumSerMasDura, 21, 146, 228, 9);

		lblAcumVidaEterna = new Label ("# de Seres Vivos que tuvieron adaptaci�n total (siempre con energia):", Label.LEFT);
		m_Parent.add(lblAcumVidaEterna);
		m_Layout.setShape(lblAcumVidaEterna, 21, 156, 222, 9);

		txtMortal = new TextField ("");
		m_Parent.add(txtMortal);
		m_Layout.setShape(txtMortal, 250, 143, 41, 12);

		txtInmortal = new TextField ("");
		m_Parent.add(txtInmortal);
		m_Layout.setShape(txtInmortal, 250, 157, 42, 12);

		m_fInitialized = true;
		return true;
	}
}
