/* *****************************************************************************
 Propiedad Intelectual
 Nombre:	Rafael Alberto Moreno Parra
 C.C.:		16.832.929 Jdi/Valle
 
 Programa: Applet Java de graficaci�n lineal

 Descripcion:	Dado unos tres ambientes ciclicos (con expresiones sinusoidales)
			se evalua los seres vivos, los cuales ya tienen ciertas caracter�sticas
			como Energia acumulada (si es mas de cero aun vive, si es cero muere),
			adptaci�n y recursos (dados por el ambiente).
			La energia de cada ser vivo seria la ecuacion:
			Energia = Energia + Recursos - Adaptacion
			Significa que entre mas adaptado (tiende a cero), mas Energia conservar�.

 Fecha:			Febrero 28 de 1999

****************************************************************************** */
import java.applet.*;
import java.awt.*;
import java.util.*;
import EvalExpr; // Evaluador de expresiones
import frmAlifeSim6; //Cuadro de di�logo
import cMutacion; // Para generar expresiones F(x) aleatorias

//Applet
public class EvolSim6 extends Applet implements Runnable
{
	//Trabajar con hilos
	private Thread	 m_thRunner = null;

	//Variables globales
	String m_sSerieNum = new String();  //El ambiente en cadena
	
	//Cuadro de dialogo
	frmAlifeSim6 m_frmDlg6;

	//Mutacion
	cMutacion objMutacion;

	//Contador de #intentos o seres generados
	int m_iContIntento;

	//Numeros generados por los ambientes
	int m_iNumAmb;

	//Probabilidades
	int m_iProbX, m_iProbP, m_iProbN;

	//Caracteristicas del ser vivo
	int m_iLongADN, m_iMaxEner, m_iEnerIni;

	//Contadores de criaturas mortales e inmortales
	int m_iInmortales;
	int m_iMortales;


	public EvolSim6()
	{
		// TODO: Add constructor code here
	}

	public String getAppletInfo()
	{
		return "Name: EvolSim6\r\n" +
		       "Author: Rafael Alberto Moreno Parra\r\n" +
		       "Created with Microsoft Visual J++ Version 1.1\r\n" +
		       "\r\n" +
		       "A-Life: Vida Artificial\r\n" +
		       "Simulacion VI: Criatura en ambientes c�clicos" +
		       "\r\n" +
		       "\r\n" +
		       "\r\n" +
		       "";
	}


	public void init()
	{
    	int iCont;
		String sAcum="";
		
		resize(640, 240);

		// Llama el cuadro de dialogo con valores por defecto
		m_frmDlg6 = new frmAlifeSim6(this);
		m_frmDlg6.CreateControls();

		//Mutacion
		objMutacion = new cMutacion();

		//Valores por defecto
		m_frmDlg6.txtPosX.setText("30");
		m_frmDlg6.txtPosP.setText("25");
		m_frmDlg6.txtPosN.setText("45");
		m_frmDlg6.txtLongADN.setText("10");
		m_frmDlg6.txtMaxEnergia.setText("1000");
		m_frmDlg6.txtEnergInic.setText("100");
		m_frmDlg6.txtNumSerAmb.setText("7");
				
		IniciarValores();
	}

	public void destroy()
	{
		// TODO: Place applet cleanup code here
	}

	public void paint(Graphics g)
	{
	}

	public void start()
	{
		if (m_thRunner == null)
		{
			m_thRunner = new Thread(this);
			m_thRunner.start();
		}
	}
	
	public void stop()
	{
		if (m_thRunner != null)
		{
			m_thRunner.stop();
			m_thRunner=null;
		}	

	}

	public void run()
	{
		//Los objetos evaluador de expresiones
		EvalExpr objEvalua01 = new EvalExpr();
		EvalExpr objEvalua02 = new EvalExpr();
		EvalExpr objEvalua03 = new EvalExpr();
		cMutacion objMutacion = new cMutacion();

		//Los ambientes
		String sEcuacion01, sEcuacion02, sEcuacion03;
		int iCont; // Genera la serie
	
		//Seres vivos
		cSerVivo objSerVivo1 = new cSerVivo();
	
		//Variables para decidir ambiente donde vivir
		int iDecide=0;
		
		//Contador de ciclos 
		int iNumIntentos=0;
		
		//Trae dato aleaotrio
		char cElem;

		//Evaluando los ambientes
		double fValX=0, fValY=0, PI=3.1415926537, dResult;

		//Flag de ser vivo o no
		boolean iNaceSerVivo=true;

		//Energia 
		objSerVivo1.dEnergia=1;
		
		//Crea los (tres) ambientes primero

		//Ambiente 01
		objMutacion.vCrearExpresion(15, m_iProbX, m_iProbP, m_iProbN);
		sEcuacion01= "sin(y)*(" + objMutacion.sAcum + ")";
		m_frmDlg6.txtExpr1.setText(sEcuacion01);
		System.out.println(sEcuacion01);
		dResult = objEvalua01.dCapturaecuacion(sEcuacion01, 0, 0);

		
		//Ambiente 02
		objMutacion.vCrearExpresion(15, m_iProbX, m_iProbP, m_iProbN);
		sEcuacion02= "cos(y)*(" + objMutacion.sAcum + ")";
		m_frmDlg6.txtExpr2.setText(sEcuacion02);
		System.out.println(sEcuacion02);
		dResult = objEvalua02.dCapturaecuacion(sEcuacion02, 0, 0);

		//Ambiente 03
		objMutacion.vCrearExpresion(15, m_iProbX, m_iProbP, m_iProbN);
		sEcuacion03= "cos(y)*(" + objMutacion.sAcum + ")";
		m_frmDlg6.txtExpr3.setText(sEcuacion03);
		System.out.println(sEcuacion03);
		dResult = objEvalua03.dCapturaecuacion(sEcuacion03, 0, 0);


		//Los ciclos de los ambientes
		while (true)
		{
			for (fValY=0; fValY<=2*PI; fValY+=PI/8) //cambio ciclico del ambiente
			{
				iNumIntentos++;
				m_frmDlg6.txtIntento1.setText(String.valueOf(iNumIntentos));
				

			    //Muere el ser si su su energia esta en cero o menos
				if (objSerVivo1.dEnergia < 0 || (objSerVivo1.dEnergia == m_iEnerIni && iNumIntentos > 1000))
				{
					m_iMortales++;
				    m_frmDlg6.txtMortal.setText(String.valueOf(m_iMortales));
					iNaceSerVivo=true;
				}

				//o entra al salon de la fama al superar el limite de energia
				if (objSerVivo1.dEnergia > m_iMaxEner)
				{
					m_iInmortales++;
					m_frmDlg6.txtInmortal.setText(String.valueOf(m_iInmortales));
					iNaceSerVivo=true;
				}
				
				if (iNaceSerVivo)
				{
					objMutacion.vCrearExpresion(m_iLongADN, m_iProbX, m_iProbP, m_iProbN);
					m_frmDlg6.txtSerVivo1.setText(objMutacion.sAcum);
					objSerVivo1.sExpresion = objMutacion.sAcum;
					objSerVivo1.dEnergia = m_iEnerIni;  //Energia por defecto
					objSerVivo1.m_iCodAmbiente=0; //Nace en ningun ambiente
					iNaceSerVivo=false;
					iDecide=0;
					iNumIntentos = 0;
				}
			
				//Valida adaptacion si ya esta en un ambiente
				if (iDecide!=0)
				{
					objSerVivo1.vAdaptarse03();
					objSerVivo1.dEnergia += objSerVivo1.dRecursovsAdaptacion;
					if (objSerVivo1.dRecursovsAdaptacion <= 0) iDecide=0;
				}
				

				//Decide entre los tres ambientes
				while (iDecide==0)
				{
					cElem='N';
					while ( cElem!='+' && cElem!='-' && cElem!='*' )
						cElem = objMutacion.cRandomElem(0, 0, 100, 0);
					switch (cElem)
					{
						case '+':	if (objSerVivo1.m_iCodAmbiente!=1)
									{
										objSerVivo1.m_iCodAmbiente = 1;
										iDecide = 1;
									}
									break;

						case '-': 	if (objSerVivo1.m_iCodAmbiente!=2)
									{
										objSerVivo1.m_iCodAmbiente = 2;
										iDecide = 1;
									}
									break;

						case '*':	if (objSerVivo1.m_iCodAmbiente!=3)
									{
										objSerVivo1.m_iCodAmbiente = 3;
										iDecide = 1;
									}
									break;
					}  //Fin Switch
				} // Fin While
				m_frmDlg6.txtVivoAmb1.setText(String.valueOf(objSerVivo1.m_iCodAmbiente));
				m_frmDlg6.txtEnergia1.setText(String.valueOf(objSerVivo1.dEnergia));

				//Cambia ciclicamente los ambientes
				switch(objSerVivo1.m_iCodAmbiente)
				{
					case 1:
								fValX=0;
								for (iCont=0; iCont<=m_iNumAmb; iCont++)
								{					
									objSerVivo1.m_dSerieNum[iCont] = Math.abs(objEvalua01.CicloEvalua(fValX, fValY));
									fValX++;
								}
								objSerVivo1.m_iContSerie = iCont - 1;
								break;
					case 2:
								fValX=0;
								for (iCont=0; iCont<=m_iNumAmb; iCont++)
								{					
									objSerVivo1.m_dSerieNum[iCont] = Math.abs(objEvalua02.CicloEvalua(fValX, fValY));
									fValX++;
								}
								objSerVivo1.m_iContSerie = iCont - 1;
								break;
					case 3:
								fValX=0;
								for (iCont=0; iCont<=m_iNumAmb; iCont++)
								{					
									objSerVivo1.m_dSerieNum[iCont] = Math.abs(objEvalua03.CicloEvalua(fValX, fValY));
									fValX++;
								}
								objSerVivo1.m_iContSerie = iCont - 1;
								break;
				} //Fin switch
			} // Fin For (ciclos de ambiente)
		} // Fin while(true)
	} // Fin run


	// Manejador de eventos
    public boolean handleEvent( Event e )
    {
        boolean bReturn = false;

        if (e.target == m_frmDlg6.cmdOK)
		{
            bReturn = routeEvent_cmdOK(e);
			start();
		}

		if (e.target == m_frmDlg6.cmdStop)
			stop();
 
		if (bReturn == true)
            return true;
        else
            return super.handleEvent(e);
    }

	
	// Este es el evento de dar click sobre el boton
	private boolean routeEvent_cmdOK(Event e)
    {
        boolean bReturn = false;
		int iCont;
		String sAcum="";
		
        if (e.id == Event.ACTION_EVENT)
			IniciarValores();
	
       return bReturn;
	}

	void IniciarValores()
	{
		//Probabilidades de creacion de expresiones
		m_iProbX = Integer.parseInt(m_frmDlg6.txtPosX.getText());
		m_iProbP = Integer.parseInt(m_frmDlg6.txtPosP.getText());
		m_iProbN = Integer.parseInt(m_frmDlg6.txtPosN.getText());

		//Contador de Intentos
		m_iContIntento = 0;
		m_iInmortales = 0;
		m_iMortales = 0;
		m_iNumAmb = Integer.parseInt(m_frmDlg6.txtNumSerAmb.getText());

		//Longitud del Ser Vivo, Maxima Energia
		m_iLongADN = Integer.parseInt(m_frmDlg6.txtLongADN.getText());
		m_iMaxEner = Integer.parseInt(m_frmDlg6.txtMaxEnergia.getText());
		m_iEnerIni = Integer.parseInt(m_frmDlg6.txtEnergInic.getText());
	}

}
