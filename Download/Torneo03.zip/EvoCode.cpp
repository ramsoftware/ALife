/* Torneo de Organismos
   Inspirado en el programa Robocode de IBM, esta simulaci�n consiste en generar N tanques
   en un tablero (un plano), cada tanque puede girar, desplazarse hacia adelante o hacia atr�s,
   tiene un radar y disparar. Mientras dura el torneo, en cada ciclo, el tanque va perdiendo
   un punto de vida, pierde tres puntos de vida si es impactado por un proyectil de otro tanque
   y gana tres puntos de vida si al disparar acierta a otro tanque.

   El tanque tiene cuatro(4) eventos que se activan cuando:
   1. Es alcanzado por un disparo.
   2. Acierta su disparo en otro tanque.
   3. Choca contra otro tanque.
   4. Detecta otro tanque con el radar.

   Cada evento dispara una serie de instrucciones que han sido previamente generadas al azar.

   En esas instrucciones, t�picas de un lenguaje muy simple de programaci�n se manejan:
   1. Diez(10) variables.
   2. Las instrucciones IF y SET (asignaci�n)
   3. Nueve(9) funciones:
			a: Avanzar_Tanque();
			b: Retroceder_Tanque();
			c: Girar_Tanque(1-8);
			d: Girar_Radar(1-8);
			e: Disparar();  disminuye vida en un punto
			f: GetPosX();
			g: GetPosY();
			h: GetVida();
			i: Reproducirse();
 

  Observaciones:  Este programa se crea como base de desarrollos futuros para probar conceptos
    sobre la evoluci�n: macroorganismos, reproducci�n, sensores, emociones, etc..
    Fue dise�ado para ser lo m�s r�pido posible.
    

  Versi�n: 3.0
  Fecha: 13 de Enero de 2004
  
  Autor: Rafael Alberto Moreno Parra
  E-mail: enginelife@hotmail.com
  WebPage: http://www.geocities.com/krousky


  En esta nueva simulaci�n hay estos cambios
	Un ciclo generar� tanques al azar y solo sobrevivir� uno.
	El que sobrevive engrosar� el podium de los mejores.

    Cuando el podium de los mejores este lleno, entonces
	se mostrar� en estad�stica que pauetes de instrucciones fueron mas usados
	y en que eventos.
*/

#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#include "Tanque.h"
#include "Instruccion.h"
#include "Inicializa.h"
#include "MejorTanque.h"

#define MAXTANQUES 4000 // 49bytes  * 4000 = 196000 => 200Kb
#define MAXINSTR 200 //    522bytes *  200 = 104400 => 110Kb
#define NUMEVENTOS 5


Inicializa objIni;
Tanque objTanque[MAXTANQUES];
MejorTanque objMejor[MAXTANQUES];
Instruccion objInst[MAXINSTR];
int objRelacion[MAXTANQUES][NUMEVENTOS];


void vSimulacion();
void vGeneraTanques(void);
void vCreaTanque(unsigned int);
void vGeneraInstrucciones(void);
void vCreaInstruccion(unsigned int);
bool bChequeaColision(unsigned int);

bool bImpactado(unsigned int);
bool bAciertaDisparo(unsigned int);
bool bChequeaColision(unsigned int);
bool bDetectaRadar(unsigned int);

void vEjecutaInstrucciones(unsigned int, unsigned int);
void vAvance(unsigned int, signed int *, signed int *);
void vInforme(unsigned int);
void vMuestraInstrucciones(unsigned int);


void main()
{
	unsigned int iTanque; /* Para ir de tanque en tanque */
	unsigned int iEvento; /* Para crear la relaci�n tanque-evento-bloque */
	unsigned int iCopiaRel; /* Copia la relaci�n tanque-evento-bloque en el podium de los mejores */
	unsigned int iInstr; /* Sirve para contabilizar que bloque de instrucciones on usadas por los tanques exitosos */
	unsigned int iAcumula;

	/* Lee el archivo plano de par�metros de simulaciones */
	objIni.vPantallaIni();
	objIni.vLeeArchivoIni();
	objIni.vInforme();

	/* Inicializa la semilla de numeros aleatorios */
	time_t ltime2;
	time(&ltime2);
	srand( ltime2 );
	
	/* Crea las instrucciones. Permanecen inalterables. */
	vGeneraInstrucciones();

	/* Ejecuta la simulaci�n con los tanques aleatorios */
	for (unsigned int iSimula=0; iSimula < objIni.stDatVA.iTorneos; iSimula++)
	{
		/* Coloca los tanques en posiciones, radar, direcci�n al azar con determinada energ�a */
		vGeneraTanques();

		/* Crea la relaci�n Tanque + Evento + Instruccion */
		for(iTanque=0; iTanque < objIni.stDatVA.iNumTanques; iTanque++)
			for (iEvento=0; iEvento < NUMEVENTOS; iEvento++)
				objRelacion[iTanque][iEvento] = abs(rand()%objIni.stDatVA.iBloqueInstr);

		/* Ejecuta la simulaci�n */
		vSimulacion();
		
		/* Guarda el mejor tanque en el Podium */
		for (iTanque=0; iTanque < objIni.stDatVA.iNumTanques; iTanque++)
			if (objTanque[iTanque].iVida > 0) break;

		objMejor[iSimula].iCodigo = iTanque;
		for (iCopiaRel = 0; iCopiaRel < NUMEVENTOS; iCopiaRel++)
		{
			iInstr = objMejor[iSimula].iEvento[iCopiaRel] = objRelacion[iTanque][iCopiaRel];
			objInst[iInstr].iParticipa[iCopiaRel]++; //El bloque aumenta en calificaci�n por ser usado */
		}
		
		if (iSimula%30==0)
		{
			time(&ltime2);
			srand( ltime2 );
			printf("Torneo: %d\n", iSimula);
		}
	//	vInforme(iTanque);
	//	printf("Numero de veces que Acerto: %d\n", objTanque[iTanque].iAcerto);
	//	printf("Numero de veces alcanzado: %d\n", objTanque[iTanque].iAlcanzado);
	//	printf("Numero de veces que se reprodujo: %d\n", objTanque[iTanque].iReproduce);
	}

	/* Muestra cuanto se uso cada instrucci�n */
	iAcumula = 0;
	for (unsigned int iInforme=0; iInforme < objIni.stDatVA.iBloqueInstr; iInforme++)
		iAcumula = iAcumula + objInst[iInforme].iParticipa[0] + objInst[iInforme].iParticipa[1] + objInst[iInforme].iParticipa[2] + objInst[iInforme].iParticipa[3] + objInst[iInforme].iParticipa[4];

	printf("iAcumula: %d\n", iAcumula);
	for (iInforme=0; iInforme < objIni.stDatVA.iBloqueInstr; iInforme++)
	{
		unsigned int iTotal = objInst[iInforme].iParticipa[0] + objInst[iInforme].iParticipa[1] + objInst[iInforme].iParticipa[2] + objInst[iInforme].iParticipa[3] + objInst[iInforme].iParticipa[4];
		printf("Bloque: %d, veces usado: %d  %3.2f%%\n", iInforme, iTotal, (float) ((float)iTotal/iAcumula)*100);
		printf("   Uso: Lo impactaron?: %d\n", objInst[iInforme].iParticipa[0]);
		printf("   Uso: La bala impacto tanque enemigo?: %d\n", objInst[iInforme].iParticipa[1]);
		printf("   Uso: Choco con otro tanque?: %d\n", objInst[iInforme].iParticipa[2]);
		printf("   Uso: Detecto otro tanque con el radar?: %d\n", objInst[iInforme].iParticipa[3]);
		printf("   Uso: Sin eventos: %d\n\n", objInst[iInforme].iParticipa[4]);
	}
}		

void vSimulacion()
{	
	signed int iBalaX, iBalaY; /* Para mover la bala disparada por el tanque */
	unsigned int iTanque; /* Para ir de tanque en tanque */
	unsigned int iTanquesVivos; /* Que tanques estan vivitos y coleando */

	/* Ciclo de vida de los Tanques */
	iTanque = 0;
	while (true) /* Si solo queda un tanque vivo termina la simulaci�n */
	{
		/* Chequea cuantos tanques vivos quedaron */
		iTanquesVivos = 0;
		for (register unsigned int iCont=0; iCont < objIni.stDatVA.iNumTanques; iCont++)
			if (objTanque[iCont].iVida > 0) iTanquesVivos++;
		if (iTanquesVivos <= 1) break;

		/* Evalua cada tanque, cuando llegue al ultimo vuelve y arranca de cero */
		iTanque++;
		if (iTanque >= objIni.stDatVA.iNumTanques) iTanque = 0;

		/* Solo evalua al tanque vivo */
		if (objTanque[iTanque].iVida <= 0) continue;


		/* �Lo impactaron? quita un punto de vida */
		if (bImpactado(iTanque))
		{
			objTanque[iTanque].iVida-=3;
			objTanque[iTanque].iAlcanzado++;

			//Ejecuta las instrucciones
			vEjecutaInstrucciones(iTanque, 0);
		}

		/* Instrucciones que hace el tanque sin necesidad de emociones */
		{		
			if (objTanque[iTanque].bEstadoBala)
			{
				vAvance(objTanque[iTanque].iDirBala, &iBalaX, &iBalaY);
				objTanque[iTanque].iPosBalaX += iBalaX;
				objTanque[iTanque].iPosBalaY += iBalaY;
			}	

			if (objTanque[iTanque].iPosBalaX < 0 || objTanque[iTanque].iPosBalaX >= objIni.stDatVA.iTableroX) objTanque[iTanque].bEstadoBala = false;
			if (objTanque[iTanque].iPosBalaY < 0 || objTanque[iTanque].iPosBalaY >= objIni.stDatVA.iTableroY) objTanque[iTanque].bEstadoBala = false;

			//Ejecuta instrucciones del Tanque
			vEjecutaInstrucciones(iTanque, 4);

			//Disminuye vida
			objTanque[iTanque].iVida--;
		}

		
		/* �La bala disparada impact� a un tanque enemigo? da tres puntos de vida */
		if (bAciertaDisparo(iTanque))
		{
			objTanque[iTanque].iVida+=3;
			objTanque[iTanque].iAcerto++;
			
			//Ejecuta las instrucciones
			vEjecutaInstrucciones(iTanque, 1);
		}

		/* �Choc� con otro tanque? */
		if (bChequeaColision(iTanque))
		{
			//Ejecuta las instrucciones
			vEjecutaInstrucciones(iTanque, 2);
		}

		/* �Detect� otro tanque con el radar? */
		if (bDetectaRadar(iTanque))
		{
			//Ejecuta las instrucciones
			vEjecutaInstrucciones(iTanque, 3);
		}

	}
}


/* Genera todos los tanques */
void vGeneraTanques()
{
	for (unsigned int iCont = 0; iCont < objIni.stDatVA.iNumTanques; iCont++)
		vCreaTanque(iCont);
}

/* Genera un tanque en particular */
void vCreaTanque(unsigned int iTanque)
{
	objTanque[iTanque].iCodigo = iTanque;

	do
	{
		objTanque[iTanque].iPosX = abs(rand() % objIni.stDatVA.iTableroX);
		objTanque[iTanque].iPosY = abs(rand() % objIni.stDatVA.iTableroY);
	} while (bChequeaColision(iTanque));

	objTanque[iTanque].iDireccion = abs(rand() % 8);
	objTanque[iTanque].iRadar = abs(rand() % 8 );
	objTanque[iTanque].bEstadoBala = false;
	objTanque[iTanque].iVida = objIni.stDatVA.iConstVida;

	objTanque[iTanque].iAcerto = 0;
	objTanque[iTanque].iAlcanzado = 0;
	objTanque[iTanque].iReproduce = 0;

}

/* Genera todos los juegos de instrucciones */
void vGeneraInstrucciones()
{
	for (unsigned int iCont = 0; iCont < objIni.stDatVA.iBloqueInstr; iCont++)
		vCreaInstruccion(iCont);
}

/* Genera un juego de instrucciones en particular */
void vCreaInstruccion(unsigned int iInstr)
{
	objInst[iInstr].iParticipa[0] = 0;
	objInst[iInstr].iParticipa[1] = 0;
	objInst[iInstr].iParticipa[2] = 0;
	objInst[iInstr].iParticipa[3] = 0;
	objInst[iInstr].iParticipa[4] = 0;

	for (unsigned int iCont=0; iCont < TRIPLETES; iCont++)
	{
		/* 
			0:  IF >
			1:  IF <
			2:  IF =
			3:  IF <>
			4:  SET
			5:  Avanzar_Tanque();
			6:  Retroceder_Tanque();
			7:  Girar_Tanque(1-8);
			8:  Girar_Radar(1-8);
			9:  Disparar();  disminuye vida en un punto
			10: GetPosX();
			11: GetPosY();
			12: GetVida();
			13: Reproducirse();
        */
		objInst[iInstr].m_oTriplete[iCont].iInstruccion = abs(rand()%14);
		
		/* Variable que recibe el resultado de la funci�n */
		objInst[iInstr].m_oTriplete[iCont].iRecibe = abs(rand()%VARIABLES);

		/* Chequea si el primer operando es variable o un n�mero */
		if (abs(rand()%2) == 0 )
			objInst[iInstr].m_oTriplete[iCont].bEsNumero1 = true;
		else
			objInst[iInstr].m_oTriplete[iCont].bEsNumero1 = false;

		/* Chequea si el segundo operando es variable o un n�mero */
		if (abs(rand()%2) == 0 )
			objInst[iInstr].m_oTriplete[iCont].bEsNumero2 = true;
		else
			objInst[iInstr].m_oTriplete[iCont].bEsNumero2 = false;

		/* Variable o n�mero... decide cual, si es un n�mero va de 0 a 9 */
		objInst[iInstr].m_oTriplete[iCont].iVariable1 = abs(rand()%VARIABLES);
		objInst[iInstr].m_oTriplete[iCont].iVariable2 = abs(rand()%VARIABLES);

		/* Decide operador */
		switch (abs(rand()%4))
		{
		case 0: objInst[iInstr].m_oTriplete[iCont].cOperador = '+'; break;
		case 1: objInst[iInstr].m_oTriplete[iCont].cOperador = '-'; break;
		case 2: objInst[iInstr].m_oTriplete[iCont].cOperador = '*'; break;
		case 3: objInst[iInstr].m_oTriplete[iCont].cOperador = '/'; break;
		}
		
		/* Salta a si hay una condicion IF */
		objInst[iInstr].m_oTriplete[iCont].iGotoLabel = abs(rand()%TRIPLETES);
	}
}


/* ************************************************************************************ */
/*                            SECCION DE EVENTOS O EMOCIONES                            */ 
/* ************************************************************************************ */

/* Chequea si al tanque lo impactaron */
bool bImpactado (unsigned int iTanque)
{
	for (unsigned int iCont = 0; iCont < objIni.stDatVA.iNumTanques; iCont++)
	{
		if (iCont != iTanque && objTanque[iCont].iVida > 0 && objTanque[iCont].bEstadoBala == true )
			if ( objTanque[iTanque].iPosX == objTanque[iCont].iPosBalaX &&
				 objTanque[iTanque].iPosY == objTanque[iCont].iPosBalaY )
			{
				objTanque[iCont].bEstadoBala = false; /* Puede disparar de nuevo el tanque que le acert� primero */
				return true;
			}
	}

	return false;
}

/* Chequea si la bala disparada acert� en un tanque enemigo */
bool bAciertaDisparo (unsigned int iTanque)
{
	if (objTanque[iTanque].bEstadoBala == false) return false;

	for (unsigned int iCont = 0; iCont < objIni.stDatVA.iNumTanques; iCont++)
	{
		if (iCont != iTanque && objTanque[iCont].iVida > 0)
			if ( objTanque[iTanque].iPosBalaX == objTanque[iCont].iPosX &&
				 objTanque[iTanque].iPosBalaY == objTanque[iCont].iPosY )
					return true;
	}

	return false;
}

/* Chequea si el tanque esta colisionando con otro tanque vivo */
bool bChequeaColision (unsigned int iTanque)
{
	for (unsigned int iCont = 0; iCont < objIni.stDatVA.iNumTanques; iCont++)
	{
		if (iCont != iTanque && objTanque[iCont].iVida > 0 )
			if ( objTanque[iTanque].iPosX == objTanque[iCont].iPosX &&
				 objTanque[iTanque].iPosY == objTanque[iCont].iPosY )
					return true;
	}

	return false;
}
		
/* �Detect� otro tanque con el radar? */
bool bDetectaRadar (unsigned int iTanque)
{
	signed int iRastreoX, iRastreoY;
	unsigned int iPosRadarX, iPosRadarY;

	/* Depende de la posici�n que tiene el radar */
	vAvance(objTanque[iTanque].iRadar, &iRastreoX, &iRastreoY);

	/* Desde la posici�n del tanque hasta los l�mites del tablero */
	iPosRadarX = objTanque[iTanque].iPosX;
	iPosRadarY = objTanque[iTanque].iPosY;

	while (iPosRadarX >= 0 && iPosRadarX < objIni.stDatVA.iTableroX && iPosRadarY >= 0 && iPosRadarY < objIni.stDatVA.iTableroY)
	{
		iPosRadarX += iRastreoX;
		iPosRadarY += iRastreoY;
		
		for (unsigned int iCont = 0; iCont < objIni.stDatVA.iNumTanques; iCont++)
		{
			if (iCont != iTanque && objTanque[iCont].iVida > 0 )
				if ( objTanque[iCont].iPosX == iPosRadarX &&
					 objTanque[iCont].iPosY == iPosRadarY )
						return true;
		}
	}
    return false;
}

/* ***************************************************************************************** */
/* EJECUTAR INSTRUCCIONES DEL TANQUE 
/* ***************************************************************************************** */
void vEjecutaInstrucciones(unsigned int iTanque, unsigned int iEvento)
{
	unsigned int iInstr, iCont=0, iVarRecibe, iCiclo=0;
	signed int iIncX, iIncY, iValor1, iValor2, iValorT;
	bool bCiclo = true;

	iInstr = objRelacion[iTanque][iEvento]; //Trae las instrucciones para este tanque y evento (cruce)

	while(iCont<TRIPLETES && bCiclo)
	{
		/* Evita que se quede en un ciclo infinito */
		iCiclo++;
		if (iCiclo > objIni.stDatVA.iMaxCiclos) bCiclo = false;

		/* Variable que recibe el resultado de la funci�n */
		iVarRecibe = objInst[iInstr].m_oTriplete[iCont].iRecibe;

		/* Las intrucciones IF se interpretan as�:
			IF varRecibe > var1  + var2 THEN Goto Etiqueta 
			IF varRecibe > 6557  - var2 THEN Goto Etiqueta
	    */
	    if (objInst[iInstr].m_oTriplete[iCont].bEsNumero1)
			iValor1 = objInst[iInstr].m_oTriplete[iCont].iVariable1;
		else
			iValor1 = objInst[iInstr].iVariable[objInst[iInstr].m_oTriplete[iCont].iVariable1];
			
		if (objInst[iInstr].m_oTriplete[iCont].bEsNumero2)
			iValor2 = objInst[iInstr].m_oTriplete[iCont].iVariable2;
		else
			iValor2 = objInst[iInstr].iVariable[objInst[iInstr].m_oTriplete[iCont].iVariable2];

		switch (objInst[iInstr].m_oTriplete[iCont].cOperador)
		{
			 case '+': iValorT = iValor1 + iValor2; break;
			 case '-': iValorT = iValor1 - iValor2; break;
			 case '*': iValorT = iValor1 * iValor2; break;
			 case '/': if (iValor2!=0)
						   iValorT = iValor1 / iValor2;
					   else
						   iValorT = 0;
					   break;
		}

		switch (objInst[iInstr].m_oTriplete[iCont].iInstruccion)
		{
		case 0:  //printf("IF > \n");
				 if (objInst[iInstr].iVariable[objInst[iInstr].m_oTriplete[iCont].iVariable1] > iValorT)
					 iCont = objInst[iInstr].m_oTriplete[iCont].iGotoLabel;
				 break; /* IF > */

		case 1:  //printf("IF < \n");
				 if (objInst[iInstr].iVariable[objInst[iInstr].m_oTriplete[iCont].iVariable1] < iValorT)
					 iCont = objInst[iInstr].m_oTriplete[iCont].iGotoLabel;
				 break; /* IF < */

		case 2:  //printf("IF ==  \n");
				 if (objInst[iInstr].iVariable[objInst[iInstr].m_oTriplete[iCont].iVariable1] == iValorT)
					 iCont = objInst[iInstr].m_oTriplete[iCont].iGotoLabel;
				 break; /* IF == */

		case 3:  //printf("IF <>  \n");
				 if (objInst[iInstr].iVariable[objInst[iInstr].m_oTriplete[iCont].iVariable1] != iValorT)
					 iCont = objInst[iInstr].m_oTriplete[iCont].iGotoLabel;
				 break; /* IF <> */

		case 4:  //printf("SET  \n");
				 objInst[iInstr].iVariable[iVarRecibe] = iValorT;
				 break; /* SET */

		case 5:  //printf("Avanzar Tanque \n");
				 vAvance(objTanque[iTanque].iDireccion, &iIncX, &iIncY);
				 objTanque[iTanque].iPosX += iIncX;
				 objTanque[iTanque].iPosY += iIncY;
				 if (objTanque[iTanque].iPosX < 0) objTanque[iTanque].iPosX = 0;
				 if (objTanque[iTanque].iPosX >= objIni.stDatVA.iTableroX) objTanque[iTanque].iPosX = objIni.stDatVA.iTableroX - 1;
				 if (objTanque[iTanque].iPosY < 0) objTanque[iTanque].iPosY = 0;
				 if (objTanque[iTanque].iPosY >= objIni.stDatVA.iTableroY) objTanque[iTanque].iPosY = objIni.stDatVA.iTableroY - 1;
				 break; /* Avanzar_Tanque */

		case 6:  //printf("Retroceder Tanque \n");
				 vAvance(objTanque[iTanque].iDireccion, &iIncX, &iIncY);
				 objTanque[iTanque].iPosX -= iIncX;
				 objTanque[iTanque].iPosY -= iIncY;
				 if (objTanque[iTanque].iPosX < 0) objTanque[iTanque].iPosX = 0;
				 if (objTanque[iTanque].iPosX >= objIni.stDatVA.iTableroX) objTanque[iTanque].iPosX = objIni.stDatVA.iTableroX - 1;
				 if (objTanque[iTanque].iPosY < 0) objTanque[iTanque].iPosY = 0;
				 if (objTanque[iTanque].iPosY >= objIni.stDatVA.iTableroY) objTanque[iTanque].iPosY = objIni.stDatVA.iTableroY - 1;
				 break; /* Retroceder Tanque */

		case 7:  //printf("Girar Tanque \n");
			     objTanque[iTanque].iDireccion = objInst[iInstr].iVariable[iVarRecibe];
				 break; /* Girar_Tanque(variable_recibe) */

		case 8:  //printf("Girar Radar \n");
				 objTanque[iTanque].iRadar = objInst[iInstr].iVariable[iVarRecibe];
				 break; /* Girar_Radar(variable_recibe) */

		case 9:	 //printf("Disparar \n");
			     if (objTanque[iTanque].bEstadoBala == false)
				 {
					objTanque[iTanque].bEstadoBala = true;
					objTanque[iTanque].iPosBalaX = objTanque[iTanque].iPosX;
					objTanque[iTanque].iPosBalaY = objTanque[iTanque].iPosY;
					objTanque[iTanque].iDirBala  = objTanque[iTanque].iDireccion;
					objTanque[iTanque].iVida--; /* Penaliza con un punto el disparar */
				 } 
				 break; /* Disparar */

		case 10: //printf("GetPosX \n");
			     objInst[iInstr].iVariable[iVarRecibe] = objTanque[iTanque].iPosX;
			     break; /* GetPosX */

		case 11: //printf("GetPosY \n");
			     objInst[iInstr].iVariable[iVarRecibe] = objTanque[iTanque].iPosY;
			     break; /* GetPosY */

		case 12: //printf("GetVida \n");
				 objInst[iInstr].iVariable[iVarRecibe] = objTanque[iTanque].iVida;
			     break; /* GetVida */

		case 13: // printf("Reproducirse \n");
				if (objTanque[iTanque].iVida >= objIni.stDatVA.iLimReproduce)
				{
					for (unsigned int iReprod = 0; iReprod < objIni.stDatVA.iNumTanques; iReprod++)
					{
						if (objTanque[iReprod].iVida <= 0) //sobreescribe un tanque muerto
						{
							objTanque[iTanque].iReproduce++;

							vCreaTanque(iReprod);
							objTanque[iReprod].iVida = objTanque[iTanque].iVida / 2;
							objTanque[iTanque].iVida /= 2;

							//Copia los eventos
							for ( unsigned int iEvento=0; iEvento < NUMEVENTOS; iEvento++)
								objRelacion[iReprod][iEvento] = objRelacion[iTanque][iEvento];


							if (objIni.stDatVA.bMutacion)
							{
								unsigned int iMuta = abs(rand() % NUMEVENTOS);
								objRelacion[iReprod][iMuta] = abs(rand()%objIni.stDatVA.iBloqueInstr);
							}

							break;
						}
					}
				}
				break; /* Reproducirse */
		}
		iCont++;
	}

}


/* Retorna que valores debe adicionar en X y Y para avanzar en la Matriz */
void vAvance(unsigned int iDireccion, signed int *iIncX, signed int *iIncY)
{
	switch(iDireccion)
	{
	case 0: *iIncX =  0; *iIncY = -1; break; /* Vertical hacia arriba */
	case 1: *iIncX =  1; *iIncY = -1; break; /* Diagonal derecha hacia arriba */
	case 2: *iIncX =  1; *iIncY =  0; break; /* Horizontal derecha */
	case 3: *iIncX =  1; *iIncY =  1; break; /* Diagonal derecha hacia abajo */
	case 4: *iIncX =  0; *iIncY =  1; break; /* Vertical hacia abajo */
	case 5: *iIncX = -1; *iIncY =  1; break; /* Diagonal izquierda hacia abajo */
	case 6: *iIncX = -1; *iIncY =  0; break; /* Horizontal izquierda */
	default: *iIncX = -1; *iIncY = -1; break; /* Diagonal izquierda hacia arriba */
	}
}


/* Informe sobre energ�a e instrucciones del Tanque */
void vInforme(unsigned int iTanque)
{
	printf("iTanque: %d, iPosX: %d, iPosY: %d, iVida: %d\n", iTanque, objTanque[iTanque].iPosX, objTanque[iTanque].iPosY, objTanque[iTanque].iVida);
	
	printf("\nFue Impactado entonces ejecuta bloque: [%d]\n", objRelacion[iTanque][0]);
	vMuestraInstrucciones(objRelacion[iTanque][0]);

	printf("\nLe acerto a otro tanque entonces ejecuta bloque: [%d]\n", objRelacion[iTanque][1]);
	vMuestraInstrucciones(objRelacion[iTanque][1]);

	printf("\nChoco con un tanque entonces ejecuta bloque: [%d]\n", objRelacion[iTanque][2]);
	vMuestraInstrucciones(objRelacion[iTanque][2]);

	printf("\nDetecto el Radar entonces ejecuta bloque: [%d]\n", objRelacion[iTanque][3]);
	vMuestraInstrucciones(objRelacion[iTanque][3]);

	printf("\nVida Normal entonces ejecuta bloque: [%d]\n", objRelacion[iTanque][4]);
	vMuestraInstrucciones(objRelacion[iTanque][4]);
}

/* Muestra las instrucciones formateadas (creadas al azar) */
void vMuestraInstrucciones(unsigned int iInstr)
{
	char sbADN[1000], sExprTemp1[250], sExprTemp2[250]="";
	char cEnter[4];
    cEnter[0]= '\n';
    cEnter[1]= '\0';

	strcpy(sbADN,"#include <stdio.h>");
	strcat(sbADN,cEnter);
	strcat(sbADN,"void main()");
	strcat(sbADN,cEnter);
	strcat(sbADN,"{");
	strcat(sbADN,cEnter);
	strcat(sbADN,"  int V0=0, V1=0, V2=0, V3=0, V4=0, V5=0, V6=0, V7=0, V8=0, V9=0;");
	strcat(sbADN,cEnter);

	for (unsigned int iCont=1; iCont < TRIPLETES; iCont++)
    {
		sprintf(sExprTemp1, "  L%d: ", iCont);
		strcat(sbADN, sExprTemp1);

		if (objInst[iInstr].m_oTriplete[iCont].iInstruccion >= 5 ) //Es una funcion
		{
			switch(objInst[iInstr].m_oTriplete[iCont].iInstruccion)
			{
			case 5: sprintf(sExprTemp1, "Avanzar_Tanque();" ); break;
			case 6: sprintf(sExprTemp1, "Retroceder_Tanque();" ); break;
			case 7: sprintf(sExprTemp1, "Girar_Tanque(V%d);", objInst[iInstr].m_oTriplete[iCont].iRecibe ); break;
			case 8: sprintf(sExprTemp1, "Girar_Radar(V%d);", objInst[iInstr].m_oTriplete[iCont].iRecibe ); break;
			case 9: sprintf(sExprTemp1, "Disparar();" ); break;
			case 10: sprintf(sExprTemp1, "V%d = GetPosX();", objInst[iInstr].m_oTriplete[iCont].iRecibe); break;
			case 11: sprintf(sExprTemp1, "V%d = GetPosY();", objInst[iInstr].m_oTriplete[iCont].iRecibe); break;
			case 12: sprintf(sExprTemp1, "V%d = GetVida();", objInst[iInstr].m_oTriplete[iCont].iRecibe); break;
			case 13: sprintf(sExprTemp1, "Reproducirse();" ); break;
			}
		
			strcat(sbADN, sExprTemp1);
			strcat(sbADN, cEnter);
			continue;
		}
                 
        //Organiza los if y asignaciones
		if (objInst[iInstr].m_oTriplete[iCont].iInstruccion >=0 && objInst[iInstr].m_oTriplete[iCont].iInstruccion <= 3)
			strcat(sbADN, "if (");

		sprintf(sExprTemp1, "V%d ", objInst[iInstr].m_oTriplete[iCont].iRecibe);
		strcat(sbADN, sExprTemp1);

		switch (objInst[iInstr].m_oTriplete[iCont].iInstruccion)
		{
			case 0:	strcat(sbADN, "> ("); break;
			case 1:	strcat(sbADN, "< ("); break;
			case 2:	strcat(sbADN, "== ("); break;
			case 3:	strcat(sbADN, "!= ("); break;
			case 4:	strcat(sbADN, "= ("); break;
		}

		if (objInst[iInstr].m_oTriplete[iCont].bEsNumero1 == false)
			sprintf(sExprTemp1, "V%d", objInst[iInstr].m_oTriplete[iCont].iVariable1);
		else
			sprintf(sExprTemp1,  "%d", objInst[iInstr].m_oTriplete[iCont].iVariable1);

		strcat(sbADN, sExprTemp1);
		sprintf(sExprTemp1, " %c ", objInst[iInstr].m_oTriplete[iCont].cOperador);
		strcat(sbADN, sExprTemp1);

		if (objInst[iInstr].m_oTriplete[iCont].bEsNumero2 == false)
			sprintf(sExprTemp1, "V%d)", objInst[iInstr].m_oTriplete[iCont].iVariable2);
		else
			sprintf(sExprTemp1,  "%d)", objInst[iInstr].m_oTriplete[iCont].iVariable2);
		strcat(sbADN, sExprTemp1);

		if (objInst[iInstr].m_oTriplete[iCont].iInstruccion>=0 && objInst[iInstr].m_oTriplete[iCont].iInstruccion <= 3)
		{
			sprintf(sExprTemp1, ") goto L%d;", objInst[iInstr].m_oTriplete[iCont].iGotoLabel);
			strcat(sbADN, sExprTemp1);
		}
		else
			strcat(sbADN, ";");

		strcat(sbADN, cEnter);
	}
	strcat(sbADN, "  L0: ");
	strcat(sbADN, cEnter);
	strcat(sbADN, "}");
	strcat(sbADN, cEnter);
	printf(sbADN);
}
