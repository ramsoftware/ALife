/* Este es un microorganismo */
#define TRIPLETES 20
#define VARIABLES 10

//Consume 6*4*20+2+10*4 = 522bytes
class Instruccion
{
public:
	struct stTriplete
	{
		unsigned int iInstruccion; /* C�digo de la Instrucci�n IF_Mayor, IF_Menor, SET o una funcion */
		unsigned int iRecibe; /* Variable para asignarse o para comparaci�n */
		bool bEsNumero1; /* �es una variable o un numero? */
		unsigned int iVariable1; /* Variable o Numero */
		unsigned char cOperador; /* + - * / */
		bool bEsNumero2; /* �es una variable o un numero? */
		unsigned int iVariable2; /* Variable o Numero */
		unsigned int iGotoLabel; /* Hacia que instrucci�n ir� */
	};

	int iVariable[VARIABLES];
	struct stTriplete m_oTriplete[TRIPLETES];

	int iParticipa[5]; /* Participa[0] se incrementa cada vez que es usado por un organismo exitoso en el evento 0  */
					   /* Participa[1] se incrementa cada vez que es usado por un organismo exitoso en el evento 1  */
};
