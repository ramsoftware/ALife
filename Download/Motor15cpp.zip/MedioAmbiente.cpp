/*
Autor:		Rafael Alberto Moreno Parra
URL:		http://www.geocities.com/krousky
Clase:		MedioAmbiente
Lenguaje:	C++

Prop�sito:
Clase de administraci�n del medio ambiente (serie num�rica de entrada y
salida)

M�todos:
vDeshaceIO: Toma la serie de entrada y salida en cadena (string) y la lleva
            a un vector de enteros.

*/
#include <string.h>
#include <stdlib.h>
#include "MedioAmbiente.h"

void MedioAmbiente::vDeshaceIO(char *m_sSerieNum)
{
		char sAcum[30];
		unsigned int iProgreso=0, iCont;
		
		// Ahora deshace la expresion en un arreglo de enteros
		m_iContador = 0;
		for(iCont=0; iCont<=strlen(m_sSerieNum); iCont++)
		{
			if(m_sSerieNum[iCont] != ',')
			{
				sAcum[iProgreso++] = m_sSerieNum[iCont];
				sAcum[iProgreso]='\0';
			}
			else
				if(strlen(sAcum)>0)
				{
			        m_fAmbiente[m_iContador++]= (float) atof(sAcum);
					iProgreso=0;
				}
		} // Fin For
}; // Fin DeshaceIO
