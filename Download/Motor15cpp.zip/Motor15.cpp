/* Autor: Rafael Alberto Moreno Parra
   Fecha: 26 de Junio de 2000

MOTOR15. Escrito en C++ (Compilado en Visual C++ 6.0)
Ambientes y Organismos (simples expresiones, algoritmos y mutaci�n)

El ser vivo capta informaci�n de su medio ambiente mediante sus sentidos
(vista, olfato, gusto, ...), cada sentido (sensor) envia una determinada
informaci�n al organismo. Dependiendo de esta informaci�n, el organismo
reacciona (o evoluciona).

Entre mas especializado este un sensor, de mejor calidad ser� la informaci�n,
entre mas sentidos tenga un ser vivo mas informaci�n habr� del medio
ambiente.

M�ltiples ambientes, el organismo selecciona uno de entrada y otro de salida.
En esta simulaci�n se resuelve un problema que presenta la simulaci�n 14:
	M�ltiples organismos con el mismo ambiente de entrada y salida.
	Esto se debe a que cuando se genera un organismo por debajo del valor de error
	es aceptado. Como este tambi�n muta, puede que la mutaci�n no lo afecte y logre
	un resultado satisfactorio por lo cual tambi�n es aceptado y as� sucesivamente.

En esta simulaci�n el usuario deber� entrar cuantos organismos se generar�n y cuantos
compartir�n la misma entrada y salida. Solo los mejores quedar�n.

*/

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>

#include "Organismo.h"
#include "MasApto.h"
#include "MedioAmbiente.h"
#include "Inicializa.h"
#include "CoxGenAmb.h"

void Simular(void);
void vQuitaEspacios(char *sCadena);
void vLeft(char *cad1, char *cad2, char num_letras);
void vRight(char *cad1, char *cad2, char num_letras);
void vMid(char *cad1, char *cad2, char desde, char hasta);

#define MAXORGANISMOS 30
#define MAXAMBIENTES 10


//Programa Principal
int main()
{
	Inicializa objInicializa; //Inicializa la simulaci�n
    MedioAmbiente objAmbiente[MAXAMBIENTES+1]; //Todos los ambientes
	MasApto objMasApto[MAXORGANISMOS+1]; //Los mejores organismos
	CoxGenAmb objCoxGenAmb[MAXORGANISMOS+1]; //Todas las conexiones
	Organismo objOrganismo;

    //Presentaci�n
	objInicializa.vPantallaIni();
	
	//Lee los parametros de simulaci�n
	int iLeeDatos = objInicializa.vLeeArchivoIni();
	if (iLeeDatos == -1) return 1;

    //Deduce el ambiente
	unsigned int iContAmb1; // Contador de Ambientes
	for (iContAmb1=0; iContAmb1<objInicializa.stDatVA.iNumAmbiente; iContAmb1++)
		objAmbiente[iContAmb1].vDeshaceIO(objInicializa.stDatVA.sAmbiente[iContAmb1]);

    //Inicializa el comportamiento aleatorio
	objOrganismo.IniciaSemillaT();
	objOrganismo.cMuta.vIniLista(	objInicializa.stDatVA.iPosibN,
									objInicializa.stDatVA.iPosibX,
									objInicializa.stDatVA.iPosibP);
	objOrganismo.m_iMaxiCiclos =  objInicializa.stDatVA.iNumCiclos;
	objOrganismo.vCreaADN(false, 65,
					objInicializa.stDatVA.iPosibIf,
					objInicializa.stDatVA.iPosibSet,
					objInicializa.stDatVA.iPosW,
					objInicializa.stDatVA.iPosX,
					objInicializa.stDatVA.iPosY,
					objInicializa.stDatVA.iPosZ,
					objInicializa.stDatVA.iPosIg,
					objInicializa.stDatVA.iPosMay,
					objInicializa.stDatVA.iPosMen,
					objInicializa.stDatVA.iPosDif,
					objInicializa.stDatVA.iLongExpr,
					objInicializa.stDatVA.iPosibX,
					objInicializa.stDatVA.iPosibP,
					objInicializa.stDatVA.iPosibN);

    //Informaci�n Inicial de la simulaci�n para simple expresi�n
	objOrganismo.m_oGen[1].bEjecuta = false;
	objOrganismo.m_oGen[1].cTipInst = 'S';
	objOrganismo.m_oGen[1].cVarActiva = 'X';
	objOrganismo.m_oGen[1].cVariable = 'Y';
	objOrganismo.m_oGen[1].iGotoLabel = 0;
	objOrganismo.m_iMaxGenOrg = 1;


	unsigned int iContAmbE=0; //Contador de ambientes de Entrada
	unsigned int iContAmbS=0; //Contador de ambientes de Salida
	unsigned int iConAprox=0; //Contador de aproximaci�n.
	unsigned int iContMasApto=0; //Contador de Organismos
	float fResult[40]; //Resultados del organismo con el ambiente de entrada
    float fAcumError=0; //Acumula el error (adaptaci�n) a todos los ambientes
    float fErrOrg=0; //Acumula el error (adaptacion) de un ambiente en particular
    unsigned int iMejorAmbE=0; //Mejor Ambiente de Entrada
    unsigned int iMejorAmbS=0; //Mejor Ambiente de Salida
	unsigned int iGeneracion=0; //Que estrat�gia usar� para generar organismos
	unsigned int iOrgSelecci=0; //Decide con que organismo jugar
	unsigned int iCopia=0; //Para copiar de MasAptos a Organismo
	unsigned int iNumGenes=0;  //Contador de genes(instrucciones a generar)
	unsigned int iMutar=1; //Que gen mutara
	unsigned int iMutables=0; //N�mero de instrucciones realmente ejecutadas

        //Para reemplazar organismos que comparten una misma entrada y salida.
	unsigned int iBusca = 0;
	unsigned int iGrabar = 0;

	objInicializa.vArchResult(); //Encabezado

	/* En esta simulaci�n multi-ambiente, se tendr� en cuenta la generaci�n
	   de organismos simples (una l�nea) y tipo algoritmo. Proceso de mutaci�n
	   fuerte y sutil */
	while(true)
	{
		//Si ya ha habido organismos generados puede mutarlos
		if (iContMasApto > 0 )
		{
			iOrgSelecci = rand()%iContMasApto; //Decide con que organismo jugar
            if (objMasApto[iOrgSelecci].m_iMaxGenOrg > 1 )
        		iGeneracion = rand()%5 + 1; //Decide entre las 5 estrat�gias
            else
      			iGeneracion = rand()%3 + 1; //Decide entre las 3 estrat�gias
			switch(iGeneracion)
			{
				case 1:
					objOrganismo.cMuta.vCrearExpresion(9, objInicializa.stDatVA.iPosibX, objInicializa.stDatVA.iPosibP, objInicializa.stDatVA.iPosibN);
					strcpy(objOrganismo.m_oGen[1].sbExpresion,objOrganismo.cMuta.sExpresion);
					break;
				case 2: //Muta la simple expresion
					strcpy(objOrganismo.cMuta.sExpresion, objMasApto[iOrgSelecci].m_oGen[1].sbExpresion);
					objOrganismo.cMuta.vMutarPartes(objInicializa.stDatVA.iPosibX, objInicializa.stDatVA.iPosibN);
					strcpy(objOrganismo.m_oGen[1].sbExpresion,objOrganismo.cMuta.sExpresion);
					break;
				case 3: //Genera Aleatoriamente los Algoritmos
					iNumGenes = rand() % (objInicializa.stDatVA.iNumInstMax - objInicializa.stDatVA.iNumInstMin) + objInicializa.stDatVA.iNumInstMin;
					objOrganismo.vCreaADN(false, iNumGenes,
							objInicializa.stDatVA.iPosibIf,
							objInicializa.stDatVA.iPosibSet,
							objInicializa.stDatVA.iPosW,
							objInicializa.stDatVA.iPosX,
							objInicializa.stDatVA.iPosY,
							objInicializa.stDatVA.iPosZ,
							objInicializa.stDatVA.iPosIg,
							objInicializa.stDatVA.iPosMay,
							objInicializa.stDatVA.iPosMen,
							objInicializa.stDatVA.iPosDif,
							objInicializa.stDatVA.iLongExpr,
							objInicializa.stDatVA.iPosibX,
							objInicializa.stDatVA.iPosibP,
							objInicializa.stDatVA.iPosibN);

					//Restaura la primera instruccion
					objOrganismo.m_oGen[1].cOperacion = objMasApto[iOrgSelecci].m_oGen[1].cOperacion;
					objOrganismo.m_oGen[1].cTipInst = objMasApto[iOrgSelecci].m_oGen[1].cTipInst;
					objOrganismo.m_oGen[1].cVarActiva = objMasApto[iOrgSelecci].m_oGen[1].cVarActiva;
					objOrganismo.m_oGen[1].cVariable = objMasApto[iOrgSelecci].m_oGen[1].cVariable;
					objOrganismo.m_oGen[1].iGotoLabel = objMasApto[iOrgSelecci].m_oGen[1].iGotoLabel;
					strcpy(objOrganismo.m_oGen[1].sbExpresion,objMasApto[iOrgSelecci].m_oGen[1].sbExpresion);
					break;

				case 4: //Muta todo un Gen
					iMutables=0;
					for (iCopia=1; iCopia <= objMasApto[iOrgSelecci].m_iMaxGenOrg; iCopia++)
					{
						if (objMasApto[iOrgSelecci].m_oGen[iCopia].bEjecuta == true) iMutables++;
						objOrganismo.m_oGen[iCopia].bEjecuta = false;
						objOrganismo.m_oGen[iCopia].cOperacion = objMasApto[iOrgSelecci].m_oGen[iCopia].cOperacion;
						objOrganismo.m_oGen[iCopia].cTipInst = objMasApto[iOrgSelecci].m_oGen[iCopia].cTipInst;
						objOrganismo.m_oGen[iCopia].cVarActiva = objMasApto[iOrgSelecci].m_oGen[iCopia].cVarActiva;
						objOrganismo.m_oGen[iCopia].cVariable = objMasApto[iOrgSelecci].m_oGen[iCopia].cVariable;
						objOrganismo.m_oGen[iCopia].iGotoLabel = objMasApto[iOrgSelecci].m_oGen[iCopia].iGotoLabel;
						strcpy(objOrganismo.m_oGen[iCopia].sbExpresion,objMasApto[iOrgSelecci].m_oGen[iCopia].sbExpresion);
					}
					objOrganismo.m_iMaxGenOrg = objMasApto[iOrgSelecci].m_iMaxGenOrg;

					//Escoge que Gen mutar�, muta los que se ejecutaron
					iMutar = rand() % (iMutables-1) + 2;
					for (iCopia=1; iCopia <= objMasApto[iOrgSelecci].m_iMaxGenOrg; iCopia++)
					{
						if (objMasApto[iOrgSelecci].m_oGen[iCopia].bEjecuta == true) iMutar--;
						if (iMutar==0) break;
					}
					iMutar = iCopia; //La posici�n real a mutar


					//Muta el Gen
					objOrganismo.vHaceGen(iMutar, objOrganismo.m_iMaxGenOrg,
							objInicializa.stDatVA.iPosibIf,
							objInicializa.stDatVA.iPosibSet,
							objInicializa.stDatVA.iPosW,
							objInicializa.stDatVA.iPosX,
							objInicializa.stDatVA.iPosY,
							objInicializa.stDatVA.iPosZ,
							objInicializa.stDatVA.iPosIg,
							objInicializa.stDatVA.iPosMay,
							objInicializa.stDatVA.iPosMen,
							objInicializa.stDatVA.iPosDif,
							objInicializa.stDatVA.iLongExpr,
							objInicializa.stDatVA.iPosibX,
							objInicializa.stDatVA.iPosibP,
							objInicializa.stDatVA.iPosibN);
					break;

				case 5: //Muta un Gen pero de forma sutil
						iMutables=0;
						for (iCopia=1; iCopia <= objMasApto[iOrgSelecci].m_iMaxGenOrg; iCopia++)
						{
							if (objMasApto[iOrgSelecci].m_oGen[iCopia].bEjecuta == true) iMutables++;
							objOrganismo.m_oGen[iCopia].bEjecuta = false;
							objOrganismo.m_oGen[iCopia].cOperacion = objMasApto[iOrgSelecci].m_oGen[iCopia].cOperacion;
							objOrganismo.m_oGen[iCopia].cTipInst = objMasApto[iOrgSelecci].m_oGen[iCopia].cTipInst;
							objOrganismo.m_oGen[iCopia].cVarActiva = objMasApto[iOrgSelecci].m_oGen[iCopia].cVarActiva;
							objOrganismo.m_oGen[iCopia].cVariable = objMasApto[iOrgSelecci].m_oGen[iCopia].cVariable;
							objOrganismo.m_oGen[iCopia].iGotoLabel = objMasApto[iOrgSelecci].m_oGen[iCopia].iGotoLabel;
							strcpy(objOrganismo.m_oGen[iCopia].sbExpresion,objMasApto[iOrgSelecci].m_oGen[iCopia].sbExpresion);
						}
						objOrganismo.m_iMaxGenOrg = objMasApto[iOrgSelecci].m_iMaxGenOrg;

						//Escoge que Gen mutar�, muta los que se ejecutaron
						iMutar = rand() % (iMutables - 1) + 2;
						for (iCopia=1; iCopia <= objMasApto[iOrgSelecci].m_iMaxGenOrg; iCopia++)
						{
							if (objMasApto[iOrgSelecci].m_oGen[iCopia].bEjecuta == true) iMutar--;
							if (iMutar==0) break;
						}
						iMutar = iCopia; //La posici�n real a mutar

						//Muta el Gen en forma sutil
						objOrganismo.vMutaGen(iMutar, objOrganismo.m_iMaxGenOrg,
										objInicializa.stDatVA.iLongExpr,
										objInicializa.stDatVA.iPosibX,
										objInicializa.stDatVA.iPosibP,
										objInicializa.stDatVA.iPosibN);
						break;
			} //Fin switch()
		}
		else //Nunca se ha creado un organismo
		{
		    objOrganismo.cMuta.vCrearExpresion(9, objInicializa.stDatVA.iPosibX, objInicializa.stDatVA.iPosibP, objInicializa.stDatVA.iPosibN);
		    strcpy(objOrganismo.m_oGen[1].sbExpresion,objOrganismo.cMuta.sExpresion);
		}

        //Evalua previamente el organismo
		objOrganismo.vEvaluaPrevio();


		//Toma cada ambiente, lo trata como Entrada y compara con alguno que de Salida
        fAcumError = 9999999;
		for (iContAmbE=0; iContAmbE<objInicializa.stDatVA.iNumAmbiente; iContAmbE++)
		{
			//Evalua previamente el Organismo con el ambiente de Entrada
       		for (iConAprox=0; iConAprox<objAmbiente[iContAmbE].m_iContador; iConAprox++)
				fResult[iConAprox] = objOrganismo.fEvalOrganismo(objAmbiente[iContAmbE].m_fAmbiente[iConAprox]);

			//Ahora viene la comparaci�n con el ambiente de Salida
			for (iContAmbS=0; iContAmbS<objInicializa.stDatVA.iNumAmbiente; iContAmbS++)
			{
				if (iContAmbE!=iContAmbS) //Evita que el ambiente de entrada sea el mismo de salida
				{
					fErrOrg=0;
					for (iConAprox=0; iConAprox<objAmbiente[iContAmbS].m_iContador; iConAprox++)
						fErrOrg += (float) fabs(fResult[iConAprox] - objAmbiente[iContAmbS].m_fAmbiente[iConAprox]);

					//Deduce cual es el mejor ambiente de salida
                    if (fErrOrg < fAcumError)
					{
						iMejorAmbE = iContAmbE;
						iMejorAmbS = iContAmbS;
						fAcumError = fErrOrg;
                   	    objOrganismo.IniciaSemillaR(); //Inicializa la semilla
					}
				}
			}
		}

		//Ahora bien, ya sabe donde se adapta el organismo.
		//Se valida entonces si esta adaptacion es la que se espera.
		//y almacena los resultados.
		if (fAcumError < objInicializa.stDatVA.fMaximoError)
		{
        	//Busca si hay otro Organismo con la misma entrada y salida
			int iExiste=0;
        	for (iBusca=0; iBusca <= iContMasApto; iBusca++)
				if (objCoxGenAmb[iBusca].iCodAmbEntr == iMejorAmbE && objCoxGenAmb[iBusca].iCodAmbSali == iMejorAmbS)
				{
					iExiste = 1;
					break;
				}

			if (iExiste)		
				if (fAcumError < objCoxGenAmb[iBusca].fError)
					iGrabar = iBusca;
				else
					iGrabar = -1;
			else
			{
	            iGrabar = iContMasApto;
	            iContMasApto++;
			}

			if (iGrabar != -1)
			{
				objOrganismo.sDisplayADN(objMasApto[iGrabar].sTextOrg);
				for (iCopia=1; iCopia <= objOrganismo.m_iMaxGenOrg; iCopia++)
				{
					objMasApto[iGrabar].m_oGen[iCopia].bEjecuta = objOrganismo.m_oGen[iCopia].bEjecuta;
					objMasApto[iGrabar].m_oGen[iCopia].cOperacion = objOrganismo.m_oGen[iCopia].cOperacion;
					objMasApto[iGrabar].m_oGen[iCopia].cTipInst = objOrganismo.m_oGen[iCopia].cTipInst;
					objMasApto[iGrabar].m_oGen[iCopia].cVarActiva = objOrganismo.m_oGen[iCopia].cVarActiva;
					objMasApto[iGrabar].m_oGen[iCopia].cVariable = objOrganismo.m_oGen[iCopia].cVariable;
					objMasApto[iGrabar].m_oGen[iCopia].iGotoLabel = objOrganismo.m_oGen[iCopia].iGotoLabel;
					strcpy(objMasApto[iGrabar].m_oGen[iCopia].sbExpresion, objOrganismo.m_oGen[iCopia].sbExpresion);
				}
				objMasApto[iGrabar].iCodMasApto = iGrabar;
				objMasApto[iGrabar].m_iMaxGenOrg = objOrganismo.m_iMaxGenOrg;

				objCoxGenAmb[iGrabar].iCodMasApto = iGrabar;
				objCoxGenAmb[iGrabar].iCodAmbEntr = iMejorAmbE;
				objCoxGenAmb[iGrabar].iCodAmbSali = iMejorAmbS;
				objCoxGenAmb[iGrabar].fError = fAcumError;
				objOrganismo.IniciaSemillaT(); //Inicializa la semilla
			}
		}

		if (iContMasApto > objInicializa.stDatVA.iNumOrganismos) break;
	}

	//Imprime los resultados
	for (iBusca=0; iBusca < iContMasApto; iBusca++)
		objInicializa.vImprRelac(objMasApto[iBusca].sTextOrg, objCoxGenAmb[iBusca].iCodAmbEntr, objCoxGenAmb[iBusca].iCodAmbSali, objCoxGenAmb[iBusca].fError);

	return 1;
}

