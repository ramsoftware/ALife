/*
* @(#)Motor de Vida Artificial
* 
* Es un conjunto de subrutinas que simulando la Evoluci�n de las Especies,
* puedan crear programas (codigo fuente) que se adapten a un ambiente en particular.
* Todo software tiene entradas y salidas. Las entradas son procesadas y se emite un resultado
* que son las salidas. Este proceso es implementado por un Dise�ador/Programador.
* Ahora bien, si usamos un sistema que usa principios evolutivos, este proceso puede nacer
* por si solo, esto tiene sus ventajas:
* 1. No se requiere de personal humano (programadores) para crear el proceso.
* 2. Puede disminuirse o anularse la posiblidad de errores en el proceso.
* 3. Ante nuevos requerimientos (nuevas entradas o formatos de salida) el proceso se adaptara.
* 4. Capaz de encontrar o acercarse a soluciones de problemas muy complejos.
* 
* El obst�culo:
*  Conseguir un proceso que ofrezca salidas esperadas a unas entradas, usando principios evolutivos
*  puede tardar un tiempo considerablemente alto. Con los nuevos procesadores a mayores velocidades y
*  un buen algoritmo evolutivo, el tiempo puede ser disminuido, de tal manera que podria entrar a
*  competir con programadores humanos.
*/

import java.util.*;
import java.lang.*;

public class Organismo
{
    public Gen m_oGen[] = new Gen[80]; //Genes del ser vivo
    EvalExpr m_eEvalua[] = new EvalExpr[80]; //Expresiones de asignacion evaluadas previamente
    int m_iMaxGenOrg; //Maximo numero de genes para el organismo
    int m_iMaxiCiclos; //Maximo numero de ciclos que se gastaran para evaluar el organismo
 
    cMutacion cMuta = new cMutacion();  //Clase que maneja los valores aleatorios
    
    Organismo()
    {
        //Crea los genes, crea al maximo.
        int iCont;
        for (iCont=1; iCont< 80; iCont++)
        {
            m_oGen[iCont] = new Gen();
            m_eEvalua[iCont] = new EvalExpr();
        }
    }
        

    public String sDisplayADN()
    {
        char cEnter = '\n';
        String sbADN="float fSerVivo(float X)" + cEnter + "{" + cEnter + "float W=0, Y=0, Z=0;" + cEnter + cEnter;
        for (int iCont=1; iCont<=m_iMaxGenOrg; iCont++)
        {
            sbADN += String.valueOf(iCont) + ": ";

            //Reemplaza la expresion por la variable activa
            String sbTmp = "";
            int iLongExpr = m_oGen[iCont].sbExpresion.length();
            for (int iChar=0; iChar < iLongExpr; iChar++)
            {
                char cCharAt = m_oGen[iCont].sbExpresion.charAt(iChar);
                if (cCharAt=='X')
                    sbTmp += m_oGen[iCont].cVarActiva;
                else
                    sbTmp += cCharAt;
            }
                    
            //Organiza los if y asignaciones
            if (m_oGen[iCont].cTipInst == 'I')
                sbADN += "if( " + m_oGen[iCont].cVariable + " " + m_oGen[iCont].cOperacion + " " + sbTmp + " ) goto " + String.valueOf(m_oGen[iCont].iGotoLabel) + ";";
            else                
                sbADN += m_oGen[iCont].cVariable + " = " + sbTmp + ";";
            sbADN += cEnter;
        }    
        //Finaliza la expresion
        sbADN += "return Y;" + cEnter + "}";
                
        return sbADN;
    }

    public void vCreaADN (boolean bGenRandom, int iMaxGenes, int iMaxCicl,
                   int iPosibIf, int iPosibSet,
                   int iPosW,  int iPosX, int iPosY, int iPosZ,
                   int iPosIg, int iPosMay, int iPosMen, int iPosDif,
                   int iLongExpr, int iPosibX, int iPosibP, int iPosibN)
    {
        int iCont, iCont1, iCont2, iCont3, iCont4;
     
        if(bGenRandom)
        {
            //Crea organismos entre 1 y iMaxGenes instrucciones
		    long iSemilla= (long) System.currentTimeMillis();
		    Random mAleat= new Random(iSemilla);
		    m_iMaxGenOrg = Math.abs(mAleat.nextInt() % iMaxGenes ) + 1;
		}
		else
            m_iMaxGenOrg = iMaxGenes;        
     
        //M�ximo n�mero de ciclos que se evaluar�n del organismo, si el
        //organimso supera este n�mero de ciclos sin dar con un resultado
        //es desechado.
        m_iMaxiCiclos = iMaxCicl;
  
        for (iCont=1; iCont<=m_iMaxGenOrg; iCont++)
           vHaceGen ( iCont, m_iMaxGenOrg,
                      iPosibIf, iPosibSet,
                      iPosW,  iPosX, iPosY, iPosZ,
                      iPosIg, iPosMay, iPosMen, iPosDif,
                      iLongExpr, iPosibX, iPosibP, iPosibN);
    }
    
    public void vEvaluaPrevio()
    {
        double dResultado;
        for (int iCont=1; iCont<=m_iMaxGenOrg; iCont++)
           dResultado = m_eEvalua[iCont].dCapturaecuacion(m_oGen[iCont].sbExpresion, 0, 0);
    }
        
    
    public float fEvalOrganismo (float fValX)
    {                   
        /* Viene la interpretacion, los valores X se disparan de 1 a n y se comparan con el ambiente Y */
        float fValW=0, fValY=0, fValZ=0, fValor=0, fResultado=0, fCompara=0;
        int iGenOrg=1; //# de Instrucci�n de inicio
        int iNumCiclos=0; //Contador de Ciclos
       
        while (iGenOrg!=0 && iGenOrg<=m_iMaxGenOrg)
        {
             //Coloca a TRUE la instruci�n porque se ejecuta
             m_oGen[iGenOrg].bEjecuta = true;
            
             //Aumenta el # de Ciclos
             iNumCiclos++;
             if (iNumCiclos > m_iMaxiCiclos)
             {
                fValY = 9999999;
                break;
             }
            
             //Que variable esta jugando dentro de la expresion
             switch (m_oGen[iGenOrg].cVarActiva)
             {
                case 'W': fValor = fValW; break;
                case 'X': fValor = fValX; break;
                case 'Y': fValor = fValY; break;
                case 'Z': fValor = fValZ; break;
             }
            
             //Evalua la expresion
             //double dResultado = m_eEvalua.dCapturaecuacion(m_oGen[iGenOrg].sbExpresion, dValor, 0);
		     fResultado = m_eEvalua[iGenOrg].CicloEvalua(fValor, 0);

		     //Si es un SET asigna el valor a la variable del Gen
		     if (m_oGen[iGenOrg].cTipInst == 'S')
		     {
		        m_oGen[iGenOrg].bIFtrue = true; //No es instruccion IF
		        switch(m_oGen[iGenOrg].cVariable)
		        {
		            case 'W': if ( fValW != fResultado)
		                      {
		                        m_oGen[iGenOrg].bCambiacVariable = true;
		                        fValW = fResultado;
		                      }
		                      break;
                    case 'X': if ( fValX != fResultado)
		                      {
		                        m_oGen[iGenOrg].bCambiacVariable = true;
		                        fValX = fResultado;
		                      }
		                      break;
		            case 'Y': if ( fValY != fResultado)
		                      {
		                        m_oGen[iGenOrg].bCambiacVariable = true;
		                        fValY = fResultado;
		                      }
		                      break;
		            case 'Z': if ( fValZ != fResultado)
		                      {
		                        m_oGen[iGenOrg].bCambiacVariable = true;
		                        fValZ = fResultado;
		                      }
		                      break;
		        }
		        iGenOrg++; //Ignora el salto en un SET
             }
             else //Es un If condicional
             {
                m_oGen[iGenOrg].bCambiacVariable = true; //En un IF siempre se coloca esta variable a TRUE
                switch(m_oGen[iGenOrg].cVariable)
		        {
		            case 'W': fCompara = fValW; break;
		            case 'X': fCompara = fValX; break;
		            case 'Y': fCompara = fValY; break;
		            case 'Z': fCompara = fValZ; break;
		        }
                
                switch(m_oGen[iGenOrg].cOperacion)
                {
                    case '>': if (fCompara > fResultado) 
		                      {
		                        m_oGen[iGenOrg].bIFtrue = true;
		                        iGenOrg=m_oGen[iGenOrg].iGotoLabel;
		                      }
		                      else
		                        iGenOrg++;
		                      break;
                    case '<': if (fCompara < fResultado) 
		                      {
		                        m_oGen[iGenOrg].bIFtrue = true;
		                        iGenOrg=m_oGen[iGenOrg].iGotoLabel;
		                      }
		                      else
		                        iGenOrg++;
		                      break;
		            case '=': if (fCompara == fResultado) 
		                      {
		                        m_oGen[iGenOrg].bIFtrue = true;
		                        iGenOrg=m_oGen[iGenOrg].iGotoLabel;
		                      }
		                      else
		                        iGenOrg++;
		                      break;
                    case '!': if (fCompara != fResultado) 
		                      {
		                        m_oGen[iGenOrg].bIFtrue = true;
		                        iGenOrg=m_oGen[iGenOrg].iGotoLabel;
		                      }
		                      else
		                        iGenOrg++;
		                      break;
		        }
		     }
		} //Fin de la evaluacion del ser vivo
		return fValY;
     }
     
     /* Crea una linea de codigo fuente (la llam� Gen). El formato es:
        label, [, IF/SET, Variable, =/>/</!, (, expresion, ), Goto, Label, ]
        para mayor velocidad, se ubica en una clase el Gen */
     public void vHaceGen(int iLabel, int iMaxGenes,
                   int iPosibIf, int iPosibSet,
                   int iPosW,  int iPosX, int iPosY, int iPosZ,
                   int iPosIg, int iPosMay, int iPosMen, int iPosDif,
                   int iLongExpr, int iPosibX, int iPosibP, int iPosibN)
     {
        char cVar, cOper;

        cMuta.vIniSemilla();
        
        //Por defecto, nunca se ha ejecutado esta instruccion
        m_oGen[iLabel].bEjecuta = false;
        
        //Por defecto, siempre los if dan falso
        m_oGen[iLabel].bIFtrue = false;
        
        //Por defecto, las asignaciones nunca cambian el valor de la variable activa
        m_oGen[iLabel].bCambiacVariable = false;
        
        //Por defecto, las asignaciones son anuladas por instrucciones de asignacion siguientes
        m_oGen[iLabel].bMantenerInst = false;

        //Decide si es una asignaci�n(Set) o un If condicional
        cOper = cMuta.cRandomElem(iPosibIf, iPosibSet, 0, 0);
        if (cOper == 'X') m_oGen[iLabel].cTipInst = 'I';
        else m_oGen[iLabel].cTipInst = 'S';
       
        //Decide que variable usar W, X, Y, Z
        cVar = cMuta.cRandomElem(iPosW, iPosX, iPosY, iPosZ);
        if (cVar == 'X') m_oGen[iLabel].cVariable = 'W';
        else if (cVar == '(') m_oGen[iLabel].cVariable = 'X';
        else if (Character.isDigit(cVar)) m_oGen[iLabel].cVariable = 'Z';
        else m_oGen[iLabel].cVariable = 'Y';
        
        //Decide si usa =, >, <, ! Estos son tenidos en cuenta si es un IF condicional
        cVar = cMuta.cRandomElem(iPosIg, iPosMay, iPosMen, iPosDif);
        if (cVar == 'X') m_oGen[iLabel].cOperacion = '=';
        else if (cVar == '(') m_oGen[iLabel].cOperacion = '>';
        else if (Character.isDigit(cVar)) m_oGen[iLabel].cOperacion = '!';
        else m_oGen[iLabel].cOperacion = '<';
        
        //Trae la expresion
        cMuta.vCrearExpresion(iLongExpr, iPosibX, iPosibP, iPosibN);
        m_oGen[iLabel].sbExpresion = cMuta.sAcum;
        
        //Como la trae para X, aqui la cambio a W, X, Y, Z
        char cCambia;
        cVar = cMuta.cRandomElem(iPosW, iPosX, iPosY, iPosZ);
        if (cVar == 'X') m_oGen[iLabel].cVarActiva = 'W';
        else if (cVar == '(') m_oGen[iLabel].cVarActiva = 'X';
        else if (Character.isDigit(cVar)) m_oGen[iLabel].cVarActiva = 'Z';
        else m_oGen[iLabel].cVarActiva = 'Y';
        
        
        //Decide hacia que label va (entre 1 y MaxGenes) o si es el FIN, el resultado siempre sera Y
		Random mAleat = new Random();
        int iNumCiclo = Math.abs(mAleat.nextInt() % iMaxGenes);
        m_oGen[iLabel].iGotoLabel = iNumCiclo; //Retorna 0 para FINalizar
     }
     
     public void Muta(int iLabel, int iMaxGenes,
                   int iPosibIf, int iPosibSet,
                   int iPosW,  int iPosX, int iPosY, int iPosZ,
                   int iPosIg, int iPosMay, int iPosMen, int iPosDif,
                   int iLongExpr, int iPosibX, int iPosibP, int iPosibN)
     {
        vHaceGen ( iLabel, iMaxGenes,
                      iPosibIf, iPosibSet,
                      iPosW,  iPosX, iPosY, iPosZ,
                      iPosIg, iPosMay, iPosMen, iPosDif,
                      iLongExpr, iPosibX, iPosibP, iPosibN);

        //Evalua la expresion previamente
        double dResultado = m_eEvalua[iLabel].dCapturaecuacion(m_oGen[iLabel].sbExpresion, 0, 0);            
     }

    //Esta subrutina retira los Genes (instrucciones) que no se ejecutaron durante la 
    //validaci�n del ambiente
    public void Optimiza()
    {
      int iContGen = 0, iContGen2 = 0;

      while (iContGen < m_iMaxGenOrg)
      {
        iContGen++;
      
        //Busca la instruccion sobrante
        if (m_oGen[iContGen].bEjecuta == false)
        {
            iContGen2 = iContGen;
            
            //Borra la instruccion sobrante moviendo el resto de instrucciones
            while (iContGen2 < m_iMaxGenOrg)
            {
                m_oGen[iContGen2].bEjecuta = m_oGen[iContGen2+1].bEjecuta;
                m_oGen[iContGen2].bIFtrue = m_oGen[iContGen2+1].bIFtrue;
                m_oGen[iContGen2].bCambiacVariable = m_oGen[iContGen2+1].bCambiacVariable;
                m_oGen[iContGen2].cOperacion = m_oGen[iContGen2+1].cOperacion;
                m_oGen[iContGen2].cTipInst = m_oGen[iContGen2+1].cTipInst;
                m_oGen[iContGen2].cVarActiva = m_oGen[iContGen2+1].cVarActiva;
                m_oGen[iContGen2].cVariable = m_oGen[iContGen2+1].cVariable;
                m_oGen[iContGen2].sbExpresion = m_oGen[iContGen2+1].sbExpresion;
                m_oGen[iContGen2].iGotoLabel = m_oGen[iContGen2+1].iGotoLabel;
                iContGen2++;
            }
            m_iMaxGenOrg--;
            
            //Actualiza los "Gotos".
            for (int iCont=1; iCont<=m_iMaxGenOrg; iCont++)
                    if (m_oGen[iCont].iGotoLabel >= iContGen )
                        m_oGen[iCont].iGotoLabel--;
            iContGen = 0; //Vuelve y arranca de nuevo 
        } // Fin If
      } //Fin While
      
      /* Coloca el indicador para no ejecutado en FALSE para que se comporte como
         si recien se generara el ser vivo */
      for (iContGen=1; iContGen<=m_iMaxGenOrg; iContGen++)
        m_oGen[iContGen].bEjecuta = false;
    }
}