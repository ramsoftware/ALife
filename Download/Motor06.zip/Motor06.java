/*
* @(#)Motor de Vida Artificial. Motor 06
*
* Autor: Rafael Alberto Moreno Parra
* Pais: Colombia
* E-mail: krousky@uniweb.net.co
* 
* Investigaci�n: Vida Artificial
* Fecha: 06 de Febrero del 2000
* 
* Es un conjunto de subrutinas que simulando la Evoluci�n de las Especies,
* puedan crear programas (codigo fuente) que se adapten a un ambiente en particular.
* Todo software tiene entradas y salidas. Las entradas son procesadas y se emite un resultado
* que son las salidas. Este proceso es implementado por un Dise�ador/Programador.
* Ahora bien, si usamos un sistema que usa principios evolutivos, este proceso puede nacer
* por si solo, esto tiene sus ventajas:
* 1. No se requiere de personal humano (programadores) para crear el proceso.
* 2. Puede disminuirse o anularse la posibilidad de errores en el proceso.
* 3. Ante nuevos requerimientos (nuevas entradas o formatos de salida) el proceso se adaptara.
* 4. Capaz de encontrar o acercarse a soluciones de problemas muy complejos.
* 
* Lo nuevo en MOTOR06
* Durante las pruebas que se realizaron en la generaci�n aleatoria de algoritmos not� varios problemas:
* 1. Varias instrucciones de los algoritmos generados nunca son ejecutadas, son instrucciones de sobra.
* 2. Las instrucciones de sobra son da�inas porque durante el proceso de mutaci�n, si se llegara a mutar una
*    instrucci�n sobrante no tendria efecto alguno en el resultado del algoritmo y si se pierde un ciclo de evaluaci�n.
* 3. Hay instrucciones que de por si son in�tiles por ejemplo X = X, o X = X + 1 + X - 1 - X.
* 4. Otras instruciones borran lo hecho por una anterior, por ejemplo:
*	10: Y = W + 5 -3 * W
*       11: Y = X + 7 + X * X
* 5. Existen IF que siempre dan falso (no hacen el salto).
* Observe que la instrucci�n 10, que es ejecutada, pierde todo efecto cuando se ejecuta la 11.
*
* En la secci�n de articulos, en: La gran decisi�n: �Cabeza o Cola?, cient�ficos que estudiaron al topo Spalax,
* observaron en acci�n el proceso llamado Atrofia: aquella estructura que consume energia y su aporte no equivale
* a lo consumido, entra en proceso de atrofia (desaparici�n). Este proceso puede aplicarse a los algoritmos generados:
* 1. Las instrucciones tendr�n un estado que se activa si son ejecutadas, si despues de evaluar el algoritmo en un 
*    ambiente finito (serie num�rica de entrada), y algunas instrucciones nunca fueron ejecutadas entonces estas son
*    eliminadas y el algoritmo es optimizado.
* 2. Las cuatro variables (W, X, Y, Z) tendran estados por instrucci�n, si las instrucciones son de asignaci�n y despu�s de
*    la evaluaci�n en el ambiente finito, las variables no presentaron cambios entonces tambi�n estas instrucciones son marcadas
*    para ser mutadas.
* 3. Las sentencias IF que siempre dan falso son marcadas para ser mutadas.
*
* Estas modificaciones buscan hacer que la mutaci�n sea m�s efectiva con los algoritmos mas aptos.
*
* El obst�culo:
*  Conseguir un proceso que ofrezca salidas esperadas a unas entradas, usando principios evolutivos
*  puede tardar un tiempo considerablemente alto. Con los nuevos procesadores a mayores velocidades y
*  un buen algoritmo evolutivo, el tiempo puede ser disminuido, de tal manera que podria entrar a
*  competir con programadores humanos.
*/



import java.lang.*;
import java.applet.*;
import java.util.*;
import java.awt.*;

public class Motor06 extends Applet implements Runnable
{
    //Trabajar con hilos
	private Thread m_thRunner = null;
	boolean m_bDetieneHilo; //Variable que evita que el hilo sea detenido por otro programa
	
	//Ambiente (series de entrada y salida)
	String m_sEntra = new String();
	String m_sSale = new String();
	
	//Ambiente y ser vivo
	MedioAmbiente objAmbiente = new MedioAmbiente();
	int m_iNumGenes;
	int m_iNumCiclos;
	boolean m_bEvaluaCiclo; //Variable que almacena si se cumplio todo el ciclo de evaluacion de un organismo
	int m_iContIntentos;
    float m_fPuesto1;

	//Los mejores organismos con diferentes n�meros de instrucciones
	String m_Org05Gen = new String();
	String m_Org10Gen = new String();
	String m_Org15Gen = new String();
	String m_Org20Gen = new String();
	String m_Org25Gen = new String();
	String m_Org30Gen = new String();
	String m_Org35Gen = new String();
	String m_Org40Gen = new String();
	String m_Org45Gen = new String();
	String m_Org50Gen = new String();
	String m_Org55Gen = new String();
	String m_Org60Gen = new String();
	float m_fOrg05Gen;
	float m_fOrg10Gen;
	float m_fOrg15Gen;
	float m_fOrg20Gen;
	float m_fOrg25Gen;
	float m_fOrg30Gen;
	float m_fOrg35Gen;
	float m_fOrg40Gen;
	float m_fOrg45Gen;
	float m_fOrg50Gen;
	float m_fOrg55Gen;
	float m_fOrg60Gen;
	
	//Probabilidades para construir los genes
    int m_iPosibIf;
    int m_iPosibSet;
    int m_iPosW;
    int m_iPosX;
    int m_iPosY;
    int m_iPosZ;
    int m_iPosIg;
    int m_iPosMay;
    int m_iPosMen;
    int m_iPosDif;
    int m_iLongExpr;
    int m_iPosibX;
    int m_iPosibP;
    int m_iPosibN;
    
    //Si se crea de 1 a n genes: true, si se crean solo n genes: false
    boolean m_bGenRandom;
	
/*	public static void main ( String args[])
	{
	    Motor06 eApp4 = new Motor06();
	    Frame frame = new Frame();
        frame.setTitle("Motor de Vida Artificial. Motor 06");
        frame.add(eApp4, BorderLayout.CENTER);
        eApp4.init();
        frame.setSize(735,450);
        Dimension d = Toolkit.getDefaultToolkit().getScreenSize();
        frame.setLocation((d.width - frame.getSize().width) / 2, (d.height - frame.getSize().height) / 2);
        frame.setVisible(true);
        eApp4.start();
    } 
  */  
	public void init()
	{
		// This code is automatically generated by Visual Cafe when you add
		// components to the visual environment. It instantiates and initializes
		// the components. To modify the code, only use code syntax that matches
		// what Visual Cafe can generate, or Visual Cafe may be unable to back
		// parse your Java file into its visual environment.
		//{{INIT_CONTROLS
		setLayout(null);
		setBackground(java.awt.Color.lightGray);
		setSize(735,428);
		lblTitulo.setText("Motor de Vida Artificial. Motor 06. Generaci�n Aleatoria y Mutaci�n. Proceso de Atrofia.");
		add(lblTitulo);
		lblTitulo.setBackground(java.awt.Color.black);
		lblTitulo.setForeground(java.awt.Color.white);
		lblTitulo.setFont(new Font("Dialog", Font.BOLD, 16));
		lblTitulo.setBounds(12,12,708,24);
		lblEntrada.setText("Valores de Entrada:");
		add(lblEntrada);
		lblEntrada.setBounds(12,48,132,24);
		lblSalida.setText("Valores de Salida esperados:");
		add(lblSalida);
		lblSalida.setBounds(12,72,168,24);
		cmdIniciar.setLabel("Iniciar");
		add(cmdIniciar);
		cmdIniciar.setBounds(12,144,81,22);
		cmdDetener.setLabel("Detener");
		add(cmdDetener);
		cmdDetener.setBounds(240,144,80,22);
		txt05Gen.setEditable(false);
		add(txt05Gen);
		txt05Gen.setFont(new Font("MonoSpaced", Font.PLAIN, 12));
		txt05Gen.setBounds(120,180,87,21);
		txt10Gen.setEditable(false);
		add(txt10Gen);
		txt10Gen.setFont(new Font("MonoSpaced", Font.PLAIN, 12));
		txt10Gen.setBounds(120,204,87,21);
		add(txt10Gen);
		txt15Gen.setEditable(false);
		add(txt15Gen);
		txt15Gen.setFont(new Font("MonoSpaced", Font.PLAIN, 12));
		txt15Gen.setBounds(120,228,87,21);
		txtEntra.setText("1,2,3,4,5,6,7,8,9,10,11,12,13,");
		add(txtEntra);
		txtEntra.setFont(new Font("MonoSpaced", Font.PLAIN, 12));
		txtEntra.setBounds(180,48,540,24);
		txtSale.setText("1,-2,3,-4,5,-6,7,-8,9,-10,11,-12,13,");
		add(txtSale);
		txtSale.setFont(new Font("MonoSpaced", Font.PLAIN, 12));
		txtSale.setBounds(180,72,540,24);
		add(txtCodFuente);
		txtCodFuente.setFont(new Font("MonoSpaced", Font.PLAIN, 12));
		txtCodFuente.setBounds(420,120,300,216);
		lblSerVivoCodFu.setText("Ser Vivo");
		add(lblSerVivoCodFu);
		lblSerVivoCodFu.setBounds(420,96,48,24);
		lblIntento.setText("# M�ximo de intentos:");
		add(lblIntento);
		lblIntento.setBounds(12,120,120,24);
		txtIntento.setText("30000");
		add(txtIntento);
		txtIntento.setFont(new Font("MonoSpaced", Font.PLAIN, 12));
		txtIntento.setBounds(144,120,48,24);
		lblCiclosSerVivo.setText("# M�ximo de Ciclos CPU para el Ser Vivo:");
		add(lblCiclosSerVivo);
		lblCiclosSerVivo.setBounds(12,96,240,24);
		txtCiclos.setText("130");
		add(txtCiclos);
		txtCiclos.setFont(new Font("MonoSpaced", Font.PLAIN, 12));
		txtCiclos.setBounds(252,96,36,19);
		txtPuesto.setEditable(false);
		add(txtPuesto);
		txtPuesto.setFont(new Font("MonoSpaced", Font.PLAIN, 12));
		txtPuesto.setBounds(480,96,240,24);
		lblAvanzado.setText("Propiedades Avanzadas");
		add(lblAvanzado);
		lblAvanzado.setBackground(java.awt.Color.black);
		lblAvanzado.setForeground(java.awt.Color.white);
		lblAvanzado.setFont(new Font("Dialog", Font.BOLD, 12));
		lblAvanzado.setBounds(12,324,144,24);
		label1.setText("Probabilidad de IF:");
		add(label1);
		label1.setBounds(12,348,108,24);
		lblProbAsig.setText("Asignaci�n:");
		add(lblProbAsig);
		lblProbAsig.setBounds(180,348,72,24);
		lblVarActivaW.setText(" Variable Activa. W=");
		add(lblVarActivaW);
		lblVarActivaW.setBounds(336,348,108,24);
		lblVarActivaX.setText("+ X=");
		add(lblVarActivaX);
		lblVarActivaX.setBounds(480,348,24,24);
		lblVarActivaY.setText("+ Y=");
		add(lblVarActivaY);
		lblVarActivaY.setBounds(552,348,24,24);
		lblVarActivaZ.setText("+ Z=");
		add(lblVarActivaZ);
		lblVarActivaZ.setBounds(624,348,24,24);
		lblOperacion1.setText("Oper = Igual");
		add(lblOperacion1);
		lblOperacion1.setBounds(12,372,72,24);
		lblOperac2.setText("> Mayor");
		add(lblOperac2);
		lblOperac2.setBounds(120,372,48,24);
		lblPosMenor.setText("< Menor");
		add(lblPosMenor);
		lblPosMenor.setBounds(204,372,48,24);
		lblPosDif.setText("! Difer.");
		add(lblPosDif);
		lblPosDif.setBounds(300,372,36,24);
		lblPosX.setText("X=");
		add(lblPosX);
		lblPosX.setBounds(12,396,17,24);
		lblPosParent.setText("Par�ntesis =");
		add(lblPosParent);
		lblPosParent.setBounds(72,396,72,24);
		lblPosNumer.setText("Numero=");
		add(lblPosNumer);
		lblPosNumer.setBounds(192,396,48,24);
		txtProbIF.setText("50");
		add(txtProbIF);
		txtProbIF.setFont(new Font("MonoSpaced", Font.PLAIN, 12));
		txtProbIF.setBounds(120,348,36,24);
		cmd05Gen.setLabel("5 Instrucciones");
		add(cmd05Gen);
		cmd05Gen.setBounds(12,180,106,19);
		cmd10Gen.setLabel("10 Instrucciones");
		add(cmd10Gen);
		cmd10Gen.setBounds(12,204,106,19);
		cmd15Gen.setLabel("15 Instrucciones");
		add(cmd15Gen);
		cmd15Gen.setBounds(12,228,106,19);
		cmd20Gen.setLabel("20 Instrucciones");
		add(cmd20Gen);
		cmd20Gen.setBounds(12,252,106,19);
		cmd25Gen.setLabel("25 Instrucciones");
		add(cmd25Gen);
		cmd25Gen.setBounds(12,276,106,19);
		cmd30Gen.setLabel("30 Instrucciones");
		add(cmd30Gen);
		cmd30Gen.setBounds(12,300,106,19);
		txt20Gen.setEditable(false);
		add(txt20Gen);
		txt20Gen.setFont(new Font("MonoSpaced", Font.PLAIN, 12));
		txt20Gen.setBounds(120,252,87,21);
		txt25Gen.setEditable(false);
		add(txt25Gen);
		txt25Gen.setFont(new Font("MonoSpaced", Font.PLAIN, 12));
		txt25Gen.setBounds(120,276,87,21);
		txt30Gen.setEditable(false);
		add(txt30Gen);
		txt30Gen.setFont(new Font("MonoSpaced", Font.PLAIN, 12));
		txt30Gen.setBounds(120,300,87,21);
		cmd35Gen.setLabel("35 Instrucciones");
		add(cmd35Gen);
		cmd35Gen.setBounds(216,180,106,19);
		cmd40Gen.setLabel("40 Instrucciones");
		add(cmd40Gen);
		cmd40Gen.setBounds(216,204,106,19);
		cmd45Gen.setLabel("45 Instrucciones");
		add(cmd45Gen);
		cmd45Gen.setBounds(216,228,106,19);
		cmd50Gen.setLabel("50 Instrucciones");
		add(cmd50Gen);
		cmd50Gen.setBounds(216,252,106,19);
		cmd55Gen.setLabel("55 Instrucciones");
		add(cmd55Gen);
		cmd55Gen.setBounds(216,276,106,19);
		cmd60Gen.setLabel("60 Instrucciones");
		add(cmd60Gen);
		cmd60Gen.setBounds(216,300,106,19);
		txt35Gen.setEditable(false);
		add(txt35Gen);
		txt35Gen.setFont(new Font("MonoSpaced", Font.PLAIN, 12));
		txt35Gen.setBounds(324,180,87,21);
		txt40Gen.setEditable(false);
		add(txt40Gen);
		txt40Gen.setFont(new Font("MonoSpaced", Font.PLAIN, 12));
		txt40Gen.setBounds(324,204,87,21);
		txt45Gen.setEditable(false);
		add(txt45Gen);
		txt45Gen.setFont(new Font("MonoSpaced", Font.PLAIN, 12));
		txt45Gen.setBounds(324,228,87,21);
		txt50Gen.setEditable(false);
		add(txt50Gen);
		txt50Gen.setFont(new Font("MonoSpaced", Font.PLAIN, 12));
		txt50Gen.setBounds(324,252,87,21);
		txt55Gen.setEditable(false);
		add(txt55Gen);
		txt55Gen.setFont(new Font("MonoSpaced", Font.PLAIN, 12));
		txt55Gen.setBounds(324,276,87,21);
		txt60Gen.setEditable(false);
		add(txt60Gen);
		txt60Gen.setFont(new Font("MonoSpaced", Font.PLAIN, 12));
		txt60Gen.setBounds(324,300,87,21);
		lblTotal.setText("= 100%");
		add(lblTotal);
		lblTotal.setBounds(684,348,43,27);
		label2.setText("= 100%");
		add(label2);
		label2.setBounds(288,348,43,27);
		label3.setText("= 100%");
		add(label3);
		label3.setBounds(384,372,43,27);
		label4.setText("= 100%");
		add(label4);
		label4.setBounds(300,396,43,27);
		txtNumIntento.setEditable(false);
		add(txtNumIntento);
		txtNumIntento.setFont(new Font("MonoSpaced", Font.PLAIN, 12));
		txtNumIntento.setBounds(336,144,72,24);
		lblLongExpr.setText("Longitud Expresiones Asignaci�n y Comparaci�n");
		add(lblLongExpr);
		lblLongExpr.setBounds(360,396,276,24);
		chkRandGen.setState(true);
		chkRandGen.setLabel("�De 0 a N instrucciones?");
		add(chkRandGen);
		chkRandGen.setBounds(240,120,168,27);
		cmdContinua.setLabel("Continuar");
		add(cmdContinua);
		cmdContinua.setBounds(132,144,77,22);
		txtLongExpr.setText("2");
		add(txtLongExpr);
		txtLongExpr.setFont(new Font("MonoSpaced", Font.PLAIN, 12));
		txtLongExpr.setBounds(636,396,24,24);
		txtProbSET.setText("50");
		add(txtProbSET);
		txtProbSET.setFont(new Font("MonoSpaced", Font.PLAIN, 12));
		txtProbSET.setBounds(252,348,36,24);
		txtProbW.setText("25");
		add(txtProbW);
		txtProbW.setFont(new Font("MonoSpaced", Font.PLAIN, 12));
		txtProbW.setBounds(444,348,27,24);
		txtProbX.setText("25");
		add(txtProbX);
		txtProbX.setFont(new Font("MonoSpaced", Font.PLAIN, 12));
		txtProbX.setBounds(504,348,39,24);
		add(txtProbExpX);
		txtProbExpX.setFont(new Font("MonoSpaced", Font.PLAIN, 12));
		txtProbExpX.setBounds(36,396,24,24);
		txtProbParen.setText("10");
		txtProbY.setText("25");
		add(txtProbY);
		txtProbY.setFont(new Font("MonoSpaced", Font.PLAIN, 12));
		txtProbY.setBounds(576,348,34,24);
		txtProbZ.setText("25");
		add(txtProbZ);
		txtProbZ.setFont(new Font("MonoSpaced", Font.PLAIN, 12));
		txtProbZ.setBounds(648,348,30,24);
		txtProbIgual.setText("25");
		add(txtProbIgual);
		txtProbIgual.setFont(new Font("MonoSpaced", Font.PLAIN, 12));
		txtProbIgual.setBounds(84,372,24,24);
		txtProbMay.setText("25");
		add(txtProbMay);
		txtProbMay.setFont(new Font("MonoSpaced", Font.PLAIN, 12));
		txtProbMay.setBounds(168,372,28,24);
		txtProbMen.setText("25");
		add(txtProbMen);
		txtProbMen.setFont(new Font("MonoSpaced", Font.PLAIN, 12));
		txtProbMen.setBounds(264,372,25,24);
		txtProbDif.setText("25");
		add(txtProbDif);
		txtProbDif.setFont(new Font("MonoSpaced", Font.PLAIN, 12));
		txtProbDif.setBounds(348,372,29,24);
		txtProbExpX.setText("40");
		add(txtProbExpX);
		add(txtProbParen);
		txtProbParen.setFont(new Font("MonoSpaced", Font.PLAIN, 12));
		txtProbParen.setBounds(144,396,36,24);
		txtProbNum.setText("50");
		add(txtProbNum);
		txtProbNum.setFont(new Font("MonoSpaced", Font.PLAIN, 12));
		txtProbNum.setBounds(252,396,37,24);
		add(lblLongExpr);
		add(lblLongExpr);
		//}}
	
		//{{REGISTER_LISTENERS
		SymAction lSymAction = new SymAction();
		cmdIniciar.addActionListener(lSymAction);
		cmdDetener.addActionListener(lSymAction);
		cmd05Gen.addActionListener(lSymAction);
		cmd10Gen.addActionListener(lSymAction);
		cmd15Gen.addActionListener(lSymAction);
		cmd20Gen.addActionListener(lSymAction);
		cmd25Gen.addActionListener(lSymAction);
		cmd30Gen.addActionListener(lSymAction);
		cmd35Gen.addActionListener(lSymAction);
		cmd40Gen.addActionListener(lSymAction);
		cmd45Gen.addActionListener(lSymAction);
		cmd50Gen.addActionListener(lSymAction);
		cmd55Gen.addActionListener(lSymAction);
		cmd60Gen.addActionListener(lSymAction);
		cmdContinua.addActionListener(lSymAction);
		txtLongExpr.addActionListener(lSymAction);
		//}}

    	IniciarValores();
	
	}
	
	//{{DECLARE_CONTROLS
	java.awt.Label lblTitulo = new java.awt.Label();
	java.awt.Label lblEntrada = new java.awt.Label();
	java.awt.Label lblSalida = new java.awt.Label();
	java.awt.Button cmdIniciar = new java.awt.Button();
	java.awt.Button cmdDetener = new java.awt.Button();
	java.awt.TextField txt05Gen = new java.awt.TextField();
	java.awt.TextField txt10Gen = new java.awt.TextField();
	java.awt.TextField txt15Gen = new java.awt.TextField();
	java.awt.TextField txtEntra = new java.awt.TextField();
	java.awt.TextField txtSale = new java.awt.TextField();
	java.awt.TextArea txtCodFuente = new java.awt.TextArea();
	java.awt.Label lblSerVivoCodFu = new java.awt.Label();
	java.awt.Label lblIntento = new java.awt.Label();
	java.awt.TextField txtIntento = new java.awt.TextField();
	java.awt.Label lblCiclosSerVivo = new java.awt.Label();
	java.awt.TextField txtCiclos = new java.awt.TextField();
	java.awt.TextField txtPuesto = new java.awt.TextField();
	java.awt.Label lblAvanzado = new java.awt.Label();
	java.awt.Label label1 = new java.awt.Label();
	java.awt.Label lblProbAsig = new java.awt.Label();
	java.awt.Label lblVarActivaW = new java.awt.Label();
	java.awt.Label lblVarActivaX = new java.awt.Label();
	java.awt.Label lblVarActivaY = new java.awt.Label();
	java.awt.Label lblVarActivaZ = new java.awt.Label();
	java.awt.Label lblOperacion1 = new java.awt.Label();
	java.awt.Label lblOperac2 = new java.awt.Label();
	java.awt.Label lblPosMenor = new java.awt.Label();
	java.awt.Label lblPosDif = new java.awt.Label();
	java.awt.Label lblPosX = new java.awt.Label();
	java.awt.Label lblPosParent = new java.awt.Label();
	java.awt.Label lblPosNumer = new java.awt.Label();
	java.awt.TextField txtProbIF = new java.awt.TextField();
	java.awt.Button cmd05Gen = new java.awt.Button();
	java.awt.Button cmd10Gen = new java.awt.Button();
	java.awt.Button cmd15Gen = new java.awt.Button();
	java.awt.Button cmd20Gen = new java.awt.Button();
	java.awt.Button cmd25Gen = new java.awt.Button();
	java.awt.Button cmd30Gen = new java.awt.Button();
	java.awt.TextField txt20Gen = new java.awt.TextField();
	java.awt.TextField txt25Gen = new java.awt.TextField();
	java.awt.TextField txt30Gen = new java.awt.TextField();
	java.awt.Button cmd35Gen = new java.awt.Button();
	java.awt.Button cmd40Gen = new java.awt.Button();
	java.awt.Button cmd45Gen = new java.awt.Button();
	java.awt.Button cmd50Gen = new java.awt.Button();
	java.awt.Button cmd55Gen = new java.awt.Button();
	java.awt.Button cmd60Gen = new java.awt.Button();
	java.awt.TextField txt35Gen = new java.awt.TextField();
	java.awt.TextField txt40Gen = new java.awt.TextField();
	java.awt.TextField txt45Gen = new java.awt.TextField();
	java.awt.TextField txt50Gen = new java.awt.TextField();
	java.awt.TextField txt55Gen = new java.awt.TextField();
	java.awt.TextField txt60Gen = new java.awt.TextField();
	java.awt.Label lblTotal = new java.awt.Label();
	java.awt.Label label2 = new java.awt.Label();
	java.awt.Label label3 = new java.awt.Label();
	java.awt.Label label4 = new java.awt.Label();
	java.awt.TextField txtNumIntento = new java.awt.TextField();
	java.awt.Checkbox chkRandGen = new java.awt.Checkbox();
	java.awt.Button cmdContinua = new java.awt.Button();
	java.awt.TextField txtLongExpr = new java.awt.TextField();
	java.awt.TextField txtProbSET = new java.awt.TextField();
	java.awt.TextField txtProbW = new java.awt.TextField();
	java.awt.TextField txtProbX = new java.awt.TextField();
	java.awt.TextField txtProbY = new java.awt.TextField();
	java.awt.TextField txtProbZ = new java.awt.TextField();
	java.awt.TextField txtProbIgual = new java.awt.TextField();
	java.awt.TextField txtProbMay = new java.awt.TextField();
	java.awt.TextField txtProbMen = new java.awt.TextField();
	java.awt.TextField txtProbDif = new java.awt.TextField();
	java.awt.TextField txtProbExpX = new java.awt.TextField();
	java.awt.TextField txtProbParen = new java.awt.TextField();
	java.awt.TextField txtProbNum = new java.awt.TextField();
	java.awt.Label lblLongExpr = new java.awt.Label();
	//}}

	class SymAction implements java.awt.event.ActionListener
	{
		public void actionPerformed(java.awt.event.ActionEvent event)
		{
			Object object = event.getSource();
			if (object == cmdIniciar)
				cmdIniciar_ActionPerformed(event);
			else if (object == cmdDetener)
				cmdDetener_ActionPerformed(event);
			if (object == cmd05Gen)
				cmd05Gen_ActionPerformed(event);
			else if (object == cmd10Gen)
				cmd10Gen_ActionPerformed(event);
			else if (object == cmd15Gen)
				cmd15Gen_ActionPerformed(event);
			else if (object == cmd20Gen)
				cmd20Gen_ActionPerformed(event);
			else if (object == cmd25Gen)
				cmd25Gen_ActionPerformed(event);
			else if (object == cmd30Gen)
				cmd30Gen_ActionPerformed(event);
			else if (object == cmd35Gen)
				cmd35Gen_ActionPerformed(event);
			else if (object == cmd40Gen)
				cmd40Gen_ActionPerformed(event);
			else if (object == cmd45Gen)
				cmd45Gen_ActionPerformed(event);
			else if (object == cmd50Gen)
				cmd50Gen_ActionPerformed(event);
			else if (object == cmd55Gen)
				cmd55Gen_ActionPerformed(event);
			else if (object == cmd60Gen)
				cmd60Gen_ActionPerformed(event);
			else if (object == cmdContinua)
				cmdContinua_ActionPerformed(event);
			else if (object == txtLongExpr)
				txtLongExpr_ActionPerformed(event);
			
		}
	}

	void cmdIniciar_ActionPerformed(java.awt.event.ActionEvent event)
	{
	    m_bDetieneHilo=true;
	    stop();
	    IniciarValores();
		start();
	}

	void cmdDetener_ActionPerformed(java.awt.event.ActionEvent event)
	{
	    m_bDetieneHilo = true;
        stop();			 
	}
	
	public void start()
	{
		if (m_thRunner == null)
		{
			m_thRunner = new Thread(this);
			m_thRunner.start();
		}
	}
	
	public void stop()
	{
	    if (m_bDetieneHilo)
		    if (m_thRunner != null)
		    {
			    m_thRunner.stop();
			    m_thRunner=null;
		    }	
	}
	
	static void main(String args[])
	{
	    Organismo OrgPuesto1 = new Organismo();
	    
	    OrgPuesto1.vCreaADN(false, 6, 130,
                    50, 50,
                    25, 25, 25, 25, 
                    25, 25, 25, 25,
                    4, 33, 33, 34);
                    
        for(int iCont=1; iCont<=OrgPuesto1.m_iMaxGenOrg; iCont++)
                OrgPuesto1.m_oGen[iCont].bEjecuta = false;
                
        OrgPuesto1.vEvaluaPrevio();
        float fResult = OrgPuesto1.fEvalOrganismo((float)3);
        
        String sADN = new String();
        sADN = OrgPuesto1.sDisplayADN();
        System.out.println("Ser Vivo sin optimizar es:");
        System.out.println(sADN);
        
        OrgPuesto1.Optimiza();
        System.out.println("Ser Vivo optimizado es:");
        sADN = OrgPuesto1.sDisplayADN();
        System.out.println(sADN);
    }
	    

	public void run()
	{
		float fResult, fErrOrg;
		Organismo oSerVivo = new Organismo();
		int iCont, iMutar=1, iNumCiclo, iGen;
		Random mAleat = new Random();

		//Objeto que guarda el mejor objeto organismo 
	    Organismo OrgPuesto1 = new Organismo();
		
	    //Genera seres vivos aleatoriamente, luego comienza a mutarlos.
		OrgPuesto1.vCreaADN(false, 65, m_iNumCiclos,
                    m_iPosibIf, m_iPosibSet,
                    m_iPosW, m_iPosX, m_iPosY, m_iPosZ, 
                    m_iPosIg, m_iPosMay, m_iPosMen, m_iPosDif,
                    m_iLongExpr, m_iPosibX, m_iPosibP, m_iPosibN);
        oSerVivo.vCreaADN(false, 65, m_iNumCiclos,
                    m_iPosibIf, m_iPosibSet,
                    m_iPosW, m_iPosX, m_iPosY, m_iPosZ, 
                    m_iPosIg, m_iPosMay, m_iPosMen, m_iPosDif,
                    m_iLongExpr, m_iPosibX, m_iPosibP, m_iPosibN);                    
		
		while(true) 
		{
		    if (m_bEvaluaCiclo)
		    {
		        m_iNumGenes += 5; // Aumenta de 5 en 5 las instrucciones
		        m_bEvaluaCiclo = false;
		        m_iContIntentos = 0;
		        m_fPuesto1 = (float) 999999;
		        iMutar = 1;

   		        OrgPuesto1.vCreaADN(false, m_iNumGenes, m_iNumCiclos,
                                   m_iPosibIf, m_iPosibSet,
                                   m_iPosW, m_iPosX, m_iPosY, m_iPosZ, 
                                   m_iPosIg, m_iPosMay, m_iPosMen, m_iPosDif,
                                   m_iLongExpr, m_iPosibX, m_iPosibP, m_iPosibN);
		    }

		    if (m_iNumGenes >= 65 ) break; //Hace hasta 65 instrucciones (genes)
		    while (m_iContIntentos < Integer.parseInt(txtIntento.getText()))
		    {
		        m_iContIntentos++; // Intentos de generaci�n
                txtNumIntento.setText(String.valueOf(m_iContIntentos));

                //Genera una vez, Muta la siguiente y asi sucesivamente
	            switch(iMutar)
                {
                    case 1: //Genera aleatoriamente el ser vivo
	                        oSerVivo.vCreaADN(m_bGenRandom, m_iNumGenes, m_iNumCiclos,
                                  m_iPosibIf, m_iPosibSet,
                                  m_iPosW, m_iPosX, m_iPosY, m_iPosZ, 
                                  m_iPosIg, m_iPosMay, m_iPosMen, m_iPosDif,
                                  m_iLongExpr, m_iPosibX, m_iPosibP, m_iPosibN);
                            iMutar = 2;
                            break;
                    case 2: /* Muta el mejor de su especie */
                            for (int iCopia=1; iCopia <= OrgPuesto1.m_iMaxGenOrg; iCopia++)
                            {
                                oSerVivo.m_oGen[iCopia].bIFtrue = OrgPuesto1.m_oGen[iCopia].bIFtrue;
                                oSerVivo.m_oGen[iCopia].bCambiacVariable = OrgPuesto1.m_oGen[iCopia].bCambiacVariable;
                                oSerVivo.m_oGen[iCopia].cOperacion = OrgPuesto1.m_oGen[iCopia].cOperacion;
                                oSerVivo.m_oGen[iCopia].cTipInst = OrgPuesto1.m_oGen[iCopia].cTipInst;
                                oSerVivo.m_oGen[iCopia].cVarActiva = OrgPuesto1.m_oGen[iCopia].cVarActiva;
                                oSerVivo.m_oGen[iCopia].cVariable = OrgPuesto1.m_oGen[iCopia].cVariable;
                                oSerVivo.m_oGen[iCopia].iGotoLabel = OrgPuesto1.m_oGen[iCopia].iGotoLabel;
                                oSerVivo.m_oGen[iCopia].sbExpresion = OrgPuesto1.m_oGen[iCopia].sbExpresion;
                            }
                            oSerVivo.m_iMaxGenOrg = OrgPuesto1.m_iMaxGenOrg;
                            oSerVivo.m_iMaxiCiclos = OrgPuesto1.m_iMaxiCiclos;

                            /* Muta todas aquellas instrucciones inutiles */
                            for(iGen=1; iGen<=oSerVivo.m_iMaxGenOrg; iGen++)
                                if (oSerVivo.m_oGen[iGen].bIFtrue == false || oSerVivo.m_oGen[iGen].bCambiacVariable == false )
                                    oSerVivo.Muta(iGen, oSerVivo.m_iMaxGenOrg,
                                            m_iPosibIf, m_iPosibSet,
                                            m_iPosW, m_iPosX, m_iPosY, m_iPosZ, 
                                            m_iPosIg, m_iPosMay, m_iPosMen, m_iPosDif,
                                            m_iLongExpr, m_iPosibX, m_iPosibP, m_iPosibN);

                            /* Muta una al azar... */
                            iNumCiclo = Math.abs(mAleat.nextInt() % oSerVivo.m_iMaxGenOrg ) + 1;
                            oSerVivo.Muta(iNumCiclo, oSerVivo.m_iMaxGenOrg,
                                            m_iPosibIf, m_iPosibSet,
                                            m_iPosW, m_iPosX, m_iPosY, m_iPosZ, 
                                            m_iPosIg, m_iPosMay, m_iPosMen, m_iPosDif,
                                            m_iLongExpr, m_iPosibX, m_iPosibP, m_iPosibN);
                            
                            iMutar = 1;
                            break;
                }     
                oSerVivo.vEvaluaPrevio();
    
	            /* Compara la cadena de salida del organismo con la requerida */
                fErrOrg=0;
	            for (iCont=0; iCont<objAmbiente.m_iContEntra; iCont++)
	            {
	                fResult = oSerVivo.fEvalOrganismo((float)objAmbiente.m_iEntradas[iCont]);
	                fErrOrg += Math.abs(fResult-(float)objAmbiente.m_iSalidas[iCont]);
	            }
	        
	            /* Compara con el puesto anterior y si la aproximaci�n es menor reemplaza */
	            if (fErrOrg < m_fPuesto1)
	            {
	                m_fPuesto1 = fErrOrg;

                    oSerVivo.Optimiza(); //Nuevo. Motor06. Quita instrucciones de sobra.
	                
                    //Almacena el mejor objeto organismo
                    for (int iCopia=1; iCopia <= oSerVivo.m_iMaxGenOrg; iCopia++)
                    {
                        OrgPuesto1.m_oGen[iCopia].bIFtrue = oSerVivo.m_oGen[iCopia].bIFtrue;
                        OrgPuesto1.m_oGen[iCopia].bCambiacVariable = oSerVivo.m_oGen[iCopia].bCambiacVariable;
                        OrgPuesto1.m_oGen[iCopia].cOperacion = oSerVivo.m_oGen[iCopia].cOperacion;
                        OrgPuesto1.m_oGen[iCopia].cTipInst = oSerVivo.m_oGen[iCopia].cTipInst;
                        OrgPuesto1.m_oGen[iCopia].cVarActiva = oSerVivo.m_oGen[iCopia].cVarActiva;
                        OrgPuesto1.m_oGen[iCopia].cVariable = oSerVivo.m_oGen[iCopia].cVariable;
                        OrgPuesto1.m_oGen[iCopia].iGotoLabel = oSerVivo.m_oGen[iCopia].iGotoLabel;
                        OrgPuesto1.m_oGen[iCopia].sbExpresion = oSerVivo.m_oGen[iCopia].sbExpresion;
                    }
                    OrgPuesto1.m_iMaxGenOrg = oSerVivo.m_iMaxGenOrg;
                    OrgPuesto1.m_iMaxiCiclos = oSerVivo.m_iMaxiCiclos;
	                
    	            switch (m_iNumGenes)
	                {
	                    case 5: txt05Gen.setText(String.valueOf(fErrOrg));
	                    	    m_fOrg05Gen = fErrOrg;
	                            m_Org05Gen = oSerVivo.sDisplayADN();
        	                    break;
	                    case 10: txt10Gen.setText(String.valueOf(fErrOrg));
	                    	    m_fOrg10Gen = fErrOrg;
	                            m_Org10Gen = oSerVivo.sDisplayADN();
        	                    break;
	                    case 15: txt15Gen.setText(String.valueOf(fErrOrg));
	                    	    m_fOrg15Gen = fErrOrg;	                    
	                            m_Org15Gen = oSerVivo.sDisplayADN();
	                            break;
	                    case 20: txt20Gen.setText(String.valueOf(fErrOrg));
	                    	    m_fOrg20Gen = fErrOrg;	                    
	                            m_Org20Gen = oSerVivo.sDisplayADN();
	                            break;
	                    case 25: txt25Gen.setText(String.valueOf(fErrOrg));
	                    	    m_fOrg25Gen = fErrOrg;	                    
	                            m_Org25Gen = oSerVivo.sDisplayADN();
	                            break;
	                    case 30: txt30Gen.setText(String.valueOf(fErrOrg));
	                    	    m_fOrg30Gen = fErrOrg;	                    
	                            m_Org30Gen = oSerVivo.sDisplayADN();
	                            break;
	                    case 35: txt35Gen.setText(String.valueOf(fErrOrg));
	                    	    m_fOrg35Gen = fErrOrg;
	                            m_Org35Gen = oSerVivo.sDisplayADN();
	                            break;
	                    case 40: txt40Gen.setText(String.valueOf(fErrOrg));
	                    	    m_fOrg40Gen = fErrOrg;	                    
	                            m_Org40Gen = oSerVivo.sDisplayADN();
                                break;
	                    case 45: txt45Gen.setText(String.valueOf(fErrOrg));
	                    	    m_fOrg45Gen = fErrOrg;	                    
	                            m_Org45Gen = oSerVivo.sDisplayADN();
	                            break;
	                    case 50: txt50Gen.setText(String.valueOf(fErrOrg));
	                    	    m_fOrg50Gen = fErrOrg;
	                            m_Org50Gen = oSerVivo.sDisplayADN();
        	                    break;
	                    case 55: txt55Gen.setText(String.valueOf(fErrOrg));
	                    	    m_fOrg55Gen = fErrOrg;	                    
	                            m_Org55Gen = oSerVivo.sDisplayADN();
	                            break;
	                    case 60: txt60Gen.setText(String.valueOf(fErrOrg));
	                    	    m_fOrg60Gen = fErrOrg;	                    
	                            m_Org60Gen = oSerVivo.sDisplayADN();
        	                    break;
	                } //Switch
	            } // End If
	        } // End While
	        m_bEvaluaCiclo = true;
	    } // End While(true)
	}
	
    void IniciarValores()
	{
	    //Impide que el hilo de ejecuci�n sea detenido
   	    m_bDetieneHilo=false;
	    
        //Posibilidades para creaci�n de genes:
        m_iPosibIf= Integer.parseInt(txtProbIF.getText());
        m_iPosibSet= Integer.parseInt(txtProbSET.getText());
        m_iPosW= Integer.parseInt(txtProbW.getText());
        m_iPosX= Integer.parseInt(txtProbX.getText());
        m_iPosY= Integer.parseInt(txtProbY.getText());
        m_iPosZ= Integer.parseInt(txtProbZ.getText());
        m_iPosIg= Integer.parseInt(txtProbIgual.getText());
        m_iPosMay= Integer.parseInt(txtProbMay.getText());
        m_iPosMen= Integer.parseInt(txtProbMen.getText());
        m_iPosDif= Integer.parseInt(txtProbDif.getText());
        m_iLongExpr= Integer.parseInt(txtLongExpr.getText());
        m_iPosibX= Integer.parseInt(txtProbExpX.getText());
        m_iPosibP= Integer.parseInt(txtProbParen.getText());
        m_iPosibN= Integer.parseInt(txtProbNum.getText());
		
	    //El ambiente
		m_sEntra = txtEntra.getText();
		m_sSale = txtSale.getText();
	    objAmbiente.vDeshaceIO(m_sEntra, 1);
	    objAmbiente.vDeshaceIO(m_sSale, 2);
		
		//Inicializa los genes y el numero de ciclos CPU requeridos para evaluar ser vivo
		m_iNumCiclos = Integer.parseInt(txtCiclos.getText());
		m_iNumGenes = 0;
		m_bEvaluaCiclo = true;
		
		//Inicializa las aproximaciones en pantalla
		txt05Gen.setText(String.valueOf((float)99999));
		txt10Gen.setText(String.valueOf((float)99999));
		txt15Gen.setText(String.valueOf((float)99999));
		txt20Gen.setText(String.valueOf((float)99999));
		txt25Gen.setText(String.valueOf((float)99999));
		txt30Gen.setText(String.valueOf((float)99999));
		txt35Gen.setText(String.valueOf((float)99999));
		txt40Gen.setText(String.valueOf((float)99999));
    	txt45Gen.setText(String.valueOf((float)99999));
        txt50Gen.setText(String.valueOf((float)99999));
        txt55Gen.setText(String.valueOf((float)99999));
        txt60Gen.setText(String.valueOf((float)99999));
        
        //Genera organismos de 0 a N instrucciones: true, de lo contraro: false
        m_bGenRandom = chkRandGen.getState();
	}	

	void cmd05Gen_ActionPerformed(java.awt.event.ActionEvent event)
	{
	    txtPuesto.setText("5 Instrucciones: " + m_fOrg05Gen);
        txtCodFuente.setText(m_Org05Gen);
	}

	void cmd10Gen_ActionPerformed(java.awt.event.ActionEvent event)
	{
	    txtPuesto.setText("10 Instrucciones: " + m_fOrg10Gen);
        txtCodFuente.setText(m_Org10Gen);
	}

	void cmd15Gen_ActionPerformed(java.awt.event.ActionEvent event)
	{
	    txtPuesto.setText("15 Instrucciones: " + m_fOrg15Gen);
        txtCodFuente.setText(m_Org15Gen);
	}

	void cmd20Gen_ActionPerformed(java.awt.event.ActionEvent event)
	{
	    txtPuesto.setText("20 Instrucciones: " + m_fOrg20Gen);
        txtCodFuente.setText(m_Org20Gen);
	}

	void cmd25Gen_ActionPerformed(java.awt.event.ActionEvent event)
	{
   	    txtPuesto.setText("25 Instrucciones: " + m_fOrg25Gen);
        txtCodFuente.setText(m_Org25Gen);
	}

	void cmd30Gen_ActionPerformed(java.awt.event.ActionEvent event)
	{
   	    txtPuesto.setText("30 Instrucciones: " + m_fOrg30Gen);
        txtCodFuente.setText(m_Org30Gen);
	}

	void cmd35Gen_ActionPerformed(java.awt.event.ActionEvent event)
	{
   	    txtPuesto.setText("35 Instrucciones: " + m_fOrg35Gen);
        txtCodFuente.setText(m_Org35Gen);
	}

	void cmd40Gen_ActionPerformed(java.awt.event.ActionEvent event)
	{
   	    txtPuesto.setText("40 Instrucciones: " + m_fOrg40Gen);
        txtCodFuente.setText(m_Org40Gen);
	}

	void cmd45Gen_ActionPerformed(java.awt.event.ActionEvent event)
	{
   	    txtPuesto.setText("45 Instrucciones: " + m_fOrg45Gen);
        txtCodFuente.setText(m_Org45Gen);
	}

	void cmd50Gen_ActionPerformed(java.awt.event.ActionEvent event)
	{
	    txtPuesto.setText("50 Instrucciones: " + m_fOrg50Gen);
        txtCodFuente.setText(m_Org50Gen);
	}

	void cmd55Gen_ActionPerformed(java.awt.event.ActionEvent event)
	{
   	    txtPuesto.setText("55 Instrucciones: " + m_fOrg55Gen);
        txtCodFuente.setText(m_Org55Gen);
	}

	void cmd60Gen_ActionPerformed(java.awt.event.ActionEvent event)
	{
	    txtPuesto.setText("60 Instrucciones: " + m_fOrg60Gen);
        txtCodFuente.setText(m_Org60Gen);
	}

	void cmdContinua_ActionPerformed(java.awt.event.ActionEvent event)
	{
	    stop();
		start();
	}

	void txtLongExpr_ActionPerformed(java.awt.event.ActionEvent event)
	{
		if (Integer.parseInt(txtLongExpr.getText())< 2)
		    txtLongExpr.setText("2");
	}
}
