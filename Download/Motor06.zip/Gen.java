/*
* @(#)Motor de Vida Artificial
* 
* Es un conjunto de subrutinas que simulando la Evoluci�n de las Especies,
* puedan crear programas (codigo fuente) que se adapten a un ambiente en particular.
* Todo software tiene entradas y salidas. Las entradas son procesadas y se emite un resultado
* que son las salidas. Este proceso es implementado por un Dise�ador/Programador.
* Ahora bien, si usamos un sistema que usa principios evolutivos, este proceso puede nacer
* por si solo, esto tiene sus ventajas:
* 1. No se requiere de personal humano (programadores) para crear el proceso.
* 2. Puede disminuirse o anularse la posiblidad de errores en el proceso.
* 3. Ante nuevos requerimientos (nuevas entradas o formatos de salida) el proceso se adaptara.
* 4. Capaz de encontrar o acercarse a soluciones deporblemas muy complejos.
* 
* El obst�culo:
*  Conseguir un proceso que ofrezca salidas esperadas a unas entradas, usando principios evolutivos
*  puede tardar un tiempo considerablemente alto. Con los nuevos procesadores a mayores velocidades y
*  un buen algoritmo evolutivo, el tiempo puede ser disminuido, de tal manera que podria entrar a
*  competir con programadores humanos.
*/

import java.util.*;

public class Gen
{
    /* ============ Variables para el proceso de ATROFIA ===============
       Las instrucciones que se crean en el algoritmo pero no sirven porque no son ejecutadas, 
       o no cambian valores, que son sobra, son eliminadas. Esto eleva ampliamente la
       posibilidad de que las sucesivas mutaciones del organismo si afecten su desempe�o para bien
       (adaptaci�n mejor) o para mal (pobre adaptaci�n). */
   
    public boolean bEjecuta; // MOTOR06 Nuevo. Se coloca a TRUE si la instruccion es ejecutada
    
    //La variable es inicializada a FALSE, si en el curso de la simulaci�n
    //siempre da falso la instrucci�n sobra.
    public boolean bIFtrue; // MOTOR06 Nuevo. Se coloca a TRUE si la instrucci�n da verdadero
    
    //Si es una asignaci�n, el valor de la cVariable debe cambiar sino la instrucci�n sobra.
    public boolean bCambiacVariable;
    
    /* Mas complejo:
    Si hay dos asignaciones continuas con la misma cVariable y diferente cVarActiva, por ejemplo:
    10: Z = 12 - Y * Y + Y
    11: Z =  X - 4 * X * X
    entonces solo es valida la instrucci�n �ltima. Esta variable se activa a TRUE si la 
    instrucci�n de asignaci�n es anulada por una siguiente. */
    public boolean bMantenerInst;
    
    /* ======================================================================= */
    
    public char cTipInst; /* Operacion IF o SET */
    public char cVariable; /* Variable a la que van a asignarle un valor o a compararla */
    public char cOperacion; /* Que operacion >,<,=,! se hara si es un IF condicional */
    public char cVarActiva; /* Variable activa en la expresion */
    public String sbExpresion; /* Expresion en X */
    public int iGotoLabel; /* Hacia que gen ir� */
}