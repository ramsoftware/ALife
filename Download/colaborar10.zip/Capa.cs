﻿/* Autor: Rafael Alberto Moreno Parra
 * Fecha: 26 de junio de 2022
 * 
 * Dada una serie de datos del tipo X,Y,Z donde X,Y son las entradas y Z es la salida.
 * El programa genera una ecuación al azar Z=F(X,Y) y da valores a X entre 0 y 1, Y entre 0 y 1. Así se
 * obtiene el dataset.
 *
 * Se busca la curva que mejor se ajuste a esa serie de datos.
 * La mejor curva permitiría hacer operaciones de interpolación.
 * Se prueban dos técnicas para buscar esa curva:
 * 1. Algoritmos evolutivos.
 * 2. Red neuronal, tipo perceptrón multicapa (algoritmos ya definidos)
 * 
 * La investigación se concentra en los algoritmos evolutivos, NO en la red neuronal.
 * Se comparan ambas técnicas, sobre cuál logra encontrar la curva con mejor ajuste con el mismo tiempo de procesamiento
 *
 * En este proyecto en particular "Colaborar10", en algoritmos evolutivos, se prueba a generar dos curvas,
 * la primera curva cubre la primera mitad de los datos y la segunda curva la segunda mitad de los datos. Luego la
 * expresión sería:
 *      Z = f(X,Y) si Y está entre 0 y 0.5
 *      Z = g(X,Y) si Y está entre 0.5 y 1
 *
 * Colaborar10 trae como novedad el uso de arreglos estáticos, en vez de listas dinámicas para hacer más rápidos los algoritmos.
*/

using System;

namespace Colaborar10{
    class Capa {
		private int TOTALNEURONAS;
		public Neurona[] Neuronas; //Las neuronas que tendrá la capa
		public double[] Salidas; //Almacena las salidas de cada neurona

		public Capa(Random Azar, int TotalNeuronas, int TotalEntradas) {
			TOTALNEURONAS = TotalNeuronas;
			Neuronas = new Neurona[TOTALNEURONAS];
			Salidas = new double[TOTALNEURONAS];

			//Genera las neuronas de eesa capa
			for (int Contador = 0; Contador < TotalNeuronas; Contador++) 
				Neuronas[Contador] = new Neurona(Azar, TotalEntradas);
		}

		//Calcula las salidas de cada neurona de la capa
		public void CalculaCapa(double[] Entradas) {
			for (int Contador = 0; Contador < TOTALNEURONAS; Contador++) 
				Salidas[Contador] = Neuronas[Contador].CalculaSalida(Entradas);
		}

		//Actualiza los pesos y umbrales de las neuronas
		public void Actualiza() {
			for (int Contador = 0; Contador < TOTALNEURONAS; Contador++) 
				Neuronas[Contador].Actualiza();
		}
	}
}
