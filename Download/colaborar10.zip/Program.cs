﻿/* Autor: Rafael Alberto Moreno Parra
 * Fecha: 26 de junio de 2022
 * 
 * Dada una serie de datos del tipo X,Y,Z donde X,Y son las entradas y Z es la salida.
 * El programa genera una ecuación al azar Z=F(X,Y) y da valores a X entre 0 y 1, Y entre 0 y 1. Así se
 * obtiene el dataset.
 *
 * Se busca la curva que mejor se ajuste a esa serie de datos.
 * La mejor curva permitiría hacer operaciones de interpolación.
 * Se prueban dos técnicas para buscar esa curva:
 * 1. Algoritmos evolutivos.
 * 2. Red neuronal, tipo perceptrón multicapa (algoritmos ya definidos)
 * 
 * La investigación se concentra en los algoritmos evolutivos, NO en la red neuronal.
 * Se comparan ambas técnicas, sobre cuál logra encontrar la curva con mejor ajuste con el mismo tiempo de procesamiento
 *
 * En este proyecto en particular "Colaborar10", en algoritmos evolutivos, se prueba a generar dos curvas,
 * la primera curva cubre la primera mitad de los datos y la segunda curva la segunda mitad de los datos. Luego la
 * expresión sería:
 *      Z = f(X,Y) si Y está entre 0 y 0.5
 *      Z = g(X,Y) si Y está entre 0.5 y 1
 *
 * Colaborar10 trae como novedad el uso de arreglos estáticos, en vez de listas dinámicas para hacer más rápidos los algoritmos.
*/
using System;
using System.Diagnostics;

namespace Colaborar10 {
    internal class Program {
        static void Main(string[] args) {
			Random AzarEcuacion = new Random(1000);
			Random Azar = new Random(); //Generador único

			int TotalPruebas = 10; //Número de veces que se generará un dataset con ecuación aleatoria para probar ambos algoritmos
			long MilisegundosParaOperar = 10000; //Cuántos milisegundos dará a cada tipo de algoritmo genético para operar
			int NumPiezasEcuacionGeneraDataset = 5; //Número de piezas que compondrá la ecuación que genera el dataset

			//Configuración del algoritmo genético
			int IndividuosPorPoblacion = 1000;

			//Configuración del perceptrón multicapa
			int TotalNeuronasCapaOculta1 = 5; //Total neuronas en la capa 0
			int TotalNeuronasCapaOculta2 = 5; //Total neuronas en la capa 1

			Console.WriteLine("COLABORAR 10");
			Console.WriteLine("Fecha: " + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"));
			Console.WriteLine("Total Pruebas: " + TotalPruebas.ToString());
			Console.WriteLine("Tiempo en milisegundos para cada algoritmo: " + MilisegundosParaOperar.ToString());
			Console.WriteLine("Número de piezas que compondrá la ecuación que genera el dataset: " + NumPiezasEcuacionGeneraDataset.ToString());

			Console.WriteLine("\r\n\r\nALGORITMO GENETICO: MEJORA LOS INDIVIDUOS Y LUEGO COMPITEN");
			Console.WriteLine("Número de individuos en la población: " + IndividuosPorPoblacion.ToString());

			Console.WriteLine("\r\n\r\nPERCEPTRON MULTICAPA");
			Console.WriteLine("Número de neuronas Primera Capa Oculta: " + TotalNeuronasCapaOculta1.ToString());
			Console.WriteLine("Número de neuronas Segunda Capa Oculta: " + TotalNeuronasCapaOculta2.ToString() + "\r\n");

			//Prepara el generador de datos
			GeneradorDatos ConjuntoDatos = new GeneradorDatos();

			for (int Pruebas = 1; Pruebas <= TotalPruebas; Pruebas++) {

				//Genera el dataset en forma aleatoria
				ConjuntoDatos.GeneraEcuacion(AzarEcuacion, NumPiezasEcuacionGeneraDataset);

				//Llama al algoritmo genético que mejora primero los individuos
				Genetico(Azar, ConjuntoDatos.Entrada1, ConjuntoDatos.Entrada2, ConjuntoDatos.Salidas, MilisegundosParaOperar, IndividuosPorPoblacion);

				//Llama a la red neuronal
				Perceptron(Azar, ConjuntoDatos.Entrada1, ConjuntoDatos.Entrada2, ConjuntoDatos.Salidas, MilisegundosParaOperar, TotalNeuronasCapaOculta1, TotalNeuronasCapaOculta2);
			}

			Console.WriteLine("\r\nFINAL\r\n");
			Console.ReadKey();
		}


		//El algoritmo genético
		public static void Genetico(Random Azar, double[] Entrada1, double[] Entrada2, double[][] Salidas, long TiempoParaOperar, int IndividuosPorPoblacion) {
			//La primera mitad del dataset es atendida por esta población
			PoblacionB Poblacion1 = new PoblacionB(Azar, IndividuosPorPoblacion);

			//La segunda mitad del dataset es atendida por esta población
			PoblacionB Poblacion2 = new PoblacionB(Azar, IndividuosPorPoblacion);

			Poblacion1.Proceso(Azar, Entrada1, Entrada2, Salidas, 0, Entrada2.Length / 2 - 1, TiempoParaOperar / 2);
			Poblacion2.Proceso(Azar, Entrada1, Entrada2, Salidas, Entrada2.Length / 2, Entrada2.Length - 1, TiempoParaOperar / 2);

			//El promedio de las dos aproximaciones se considera como la aproximación del algoritmo genético al dataset
			double Aproxima = (Poblacion1.MejorAproximacion() + Poblacion2.MejorAproximacion()) / 2;
			Console.Write("AGM;" + Aproxima.ToString());
		}

		//La red neuronal
		public static void Perceptron(Random Azar, double[] Entrada1, double[] Entrada2, double[][] Salidas, long TiempoParaOperar, int TotalNeuronasCapaOculta1, int TotalNeuronasCapaOculta2) {
			//Medidor de tiempos
			Stopwatch Cronometro = new Stopwatch();
			Cronometro.Reset();
			Cronometro.Start();

			int NumeroEntradas = 2; //Número de entradas
			int TotalNeuronasCapaSalida = 1; //Total neuronas en la capa de salida
			Perceptron RedNeuronal = new Perceptron(Azar, NumeroEntradas, TotalNeuronasCapaOculta1, TotalNeuronasCapaOculta2, TotalNeuronasCapaSalida);

			//Estas serán las entradas y salidas externas al perceptrón
			double[] Entradas = new double[2];
			double[] SalidaEsperada = new double[1];

			//Ciclo que entrena la red neuronal
			while (Cronometro.ElapsedMilliseconds < TiempoParaOperar) {

				//Por cada ciclo, se entrena el perceptrón con todos los valores
				for (int X = 0; X < Salidas.Length; X++)
					for (int Y = 0; Y < Salidas[X].Length; Y++) {
						//Entradas y salidas esperadas
						Entradas[0] = Entrada1[X];
						Entradas[1] = Entrada2[Y];
						SalidaEsperada[0] = Salidas[X][Y];

						//Primero calcula la salida del perceptrón con esas entradas
						RedNeuronal.CalculaSalidaRed(Entradas);

						//Luego entrena el perceptrón para ajustar los pesos y umbrales
						RedNeuronal.Entrena(Entradas, SalidaEsperada);
					}
			}

			//Calcula la aproximación
			double Aproxima = 0;
			for (int X = 0; X < Salidas.Length; X++)
				for (int Y = 0; Y < Salidas[X].Length; Y++) {
					//Entradas y salidas esperadas
					Entradas[0] = Entrada1[X];
					Entradas[1] = Entrada2[Y];
					SalidaEsperada[0] = Salidas[X][Y];

					//Calcula la salida del perceptrón con esas entradas
					RedNeuronal.CalculaSalidaRed(Entradas);
					Aproxima += (RedNeuronal.Capas[2].Salidas[0] - SalidaEsperada[0]) * (RedNeuronal.Capas[2].Salidas[0] - SalidaEsperada[0]);
				}
			Console.WriteLine(";RN;" + Aproxima.ToString());
		}
	}
}
