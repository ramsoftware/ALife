﻿/* Autor: Rafael Alberto Moreno Parra
 * Fecha: 26 de junio de 2022
 * 
 * Dada una serie de datos del tipo X,Y,Z donde X,Y son las entradas y Z es la salida.
 * El programa genera una ecuación al azar Z=F(X,Y) y da valores a X entre 0 y 1, Y entre 0 y 1. Así se
 * obtiene el dataset.
 *
 * Se busca la curva que mejor se ajuste a esa serie de datos.
 * La mejor curva permitiría hacer operaciones de interpolación.
 * Se prueban dos técnicas para buscar esa curva:
 * 1. Algoritmos evolutivos.
 * 2. Red neuronal, tipo perceptrón multicapa (algoritmos ya definidos)
 * 
 * La investigación se concentra en los algoritmos evolutivos, NO en la red neuronal.
 * Se comparan ambas técnicas, sobre cuál logra encontrar la curva con mejor ajuste con el mismo tiempo de procesamiento
 *
 * En este proyecto en particular "Colaborar10", en algoritmos evolutivos, se prueba a generar dos curvas,
 * la primera curva cubre la primera mitad de los datos y la segunda curva la segunda mitad de los datos. Luego la
 * expresión sería:
 *      Z = f(X,Y) si Y está entre 0 y 0.5
 *      Z = g(X,Y) si Y está entre 0.5 y 1
 *
 * Colaborar10 trae como novedad el uso de arreglos estáticos, en vez de listas dinámicas para hacer más rápidos los algoritmos.
*/
using System;

namespace Colaborar10 {
	internal class IndividuoB {
		public double[] Coef = new double[18];

		//Guarda en "caché" el ajuste para no tener que calcularlo continuamente
		public double Ajuste;

		//Inicializa el individuo con las Piezas, Modificadores y Operadores al azar
		public IndividuoB(Random Azar) {
			for (int Contador = 0; Contador < Coef.Length; Contador++) 
				Coef[Contador] = Azar.NextDouble();
			Ajuste = -1;
		}

		//Mejora el individuo antes de entrar a la arena de la competición, cambiando los coeficientes 
		public void MejoraIndividuo(Random Azar, double[] Entrada1, double[] Entrada2, double[][] Salidas, int MinimoY, int MaximoY) {
			int Cambiar = Azar.Next(0, Coef.Length);
			double Antes = Coef[Cambiar];
			Coef[Cambiar] += Azar.NextDouble() * 2 - 1;

			//El cálculo del ajuste es la sumatoria de (valor esperado - valor calculado por el individuo)^2
			//Prueba el individuo con los datos
			double NuevoAjuste = 0;
			for (int X = 0; X < Salidas.Length; X++) {
				double x = Entrada1[X];
				for (int Y = MinimoY; Y <= MaximoY; Y++) {
					double y = Entrada2[Y];
					double valorP1 = Coef[0] * (1 - x) * (1 - x) * (1 - x) * (1 - x) + Coef[1] * (1 - x) * (1 - x) * (1 - x) + Coef[2] * (1 - x) * (1 - x) + Coef[3] * (1 - x) + Coef[4] + Coef[5] * x + Coef[6] * x * x + Coef[7] * x * x * x + Coef[8] * x * x * x * x;
					double valorP2 = Coef[9] * (1 - y) * (1 - y) * (1 - y) * (1 - y) + Coef[10] * (1 - y) * (1 - y) * (1 - y) + Coef[11] * (1 - y) * (1 - y) + Coef[12] * (1 - x) + Coef[13] + Coef[14] * y + Coef[15] * y * y + Coef[16] * y * y * y + Coef[17] * y * y * y * y;
					double Diferencia = (Math.Sin(valorP1 + valorP2) + 1) / 2 - Salidas[X][Y];
					NuevoAjuste += Diferencia * Diferencia;
					if (NuevoAjuste > Ajuste && Ajuste != -1) { //Si el cambio perjudica el ajuste anterior, retorna el valor anterior del coeficiente cambiado
						Coef[Cambiar] = Antes;
						return;
					}
				}
			}

			Ajuste = NuevoAjuste;
		}

		//Calcula el ajuste del individuo con los valores de salida esperados
		public void AjusteIndividuo(double[] Entrada1, double[] Entrada2, double[][] Salidas, int MinimoY, int MaximoY) {
			//Si ya había sido calculado entonces evita calcularlo de nuevo
			if (Ajuste != -1) return;

			//El cálculo del ajuste es la sumatoria de (valor esperado - valor calculado por el individuo)^2
			Ajuste = 0;
			for (int X = 0; X < Salidas.Length; X++) {
				double x = Entrada1[X];
				for (int Y = MinimoY; Y <= MaximoY; Y++) {
					double y = Entrada2[Y];
					double valorP1 = Coef[0] * (1 - x) * (1 - x) * (1 - x) * (1 - x) + Coef[1] * (1 - x) * (1 - x) * (1 - x) + Coef[2] * (1 - x) * (1 - x) + Coef[3] * (1 - x) + Coef[4] + Coef[5] * x + Coef[6] * x * x + Coef[7] * x * x * x + Coef[8] * x * x * x * x;
					double valorP2 = Coef[9] * (1 - y) * (1 - y) * (1 - y) * (1 - y) + Coef[10] * (1 - y) * (1 - y) * (1 - y) + Coef[11] * (1 - y) * (1 - y) + Coef[12] * (1 - x) + Coef[13] + Coef[14] * y + Coef[15] * y * y + Coef[16] * y * y * y + Coef[17] * y * y * y * y;
					double Diferencia = (Math.Sin(valorP1 + valorP2) + 1) / 2 - Salidas[X][Y];
					Ajuste += Diferencia * Diferencia;
				}
			}
		}
	}
}
