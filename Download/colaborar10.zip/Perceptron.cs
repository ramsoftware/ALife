﻿/* Autor: Rafael Alberto Moreno Parra
 * Fecha: 26 de junio de 2022
 * 
 * Dada una serie de datos del tipo X,Y,Z donde X,Y son las entradas y Z es la salida.
 * El programa genera una ecuación al azar Z=F(X,Y) y da valores a X entre 0 y 1, Y entre 0 y 1. Así se
 * obtiene el dataset.
 *
 * Se busca la curva que mejor se ajuste a esa serie de datos.
 * La mejor curva permitiría hacer operaciones de interpolación.
 * Se prueban dos técnicas para buscar esa curva:
 * 1. Algoritmos evolutivos.
 * 2. Red neuronal, tipo perceptrón multicapa (algoritmos ya definidos)
 * 
 * La investigación se concentra en los algoritmos evolutivos, NO en la red neuronal.
 * Se comparan ambas técnicas, sobre cuál logra encontrar la curva con mejor ajuste con el mismo tiempo de procesamiento
 *
 * En este proyecto en particular "Colaborar10", en algoritmos evolutivos, se prueba a generar dos curvas,
 * la primera curva cubre la primera mitad de los datos y la segunda curva la segunda mitad de los datos. Luego la
 * expresión sería:
 *      Z = f(X,Y) si Y está entre 0 y 0.5
 *      Z = g(X,Y) si Y está entre 0.5 y 1
 *
 * Colaborar10 trae como novedad el uso de arreglos estáticos, en vez de listas dinámicas para hacer más rápidos los algoritmos.
*/
using System;

namespace Colaborar10 {
	class Perceptron {
		public Capa[] Capas;

		//Crea las diversas capas
		public Perceptron(Random Azar, int TotalEntradas, int TotalNeuronasCapa0, int TotalNeuronasCapa1, int TotalNeuronasCapa2) {
			Capas = new Capa[3];
            Capas[0] = new Capa(Azar, TotalNeuronasCapa0, TotalEntradas); //Crea la capa 0
            Capas[1] = new Capa(Azar, TotalNeuronasCapa1, TotalNeuronasCapa0); //Crea la capa 1
            Capas[2] = new Capa(Azar, TotalNeuronasCapa2, TotalNeuronasCapa1); //Crea la capa 2
		}

		//Imprime los datos de las diferentes capas
		public void SalidaPerceptron(double[] Entradas, double[] SalidasEsperadas) {
			for (int cont = 0; cont < Entradas.Length; cont++) {
				Console.Write(Entradas[cont].ToString() + " ");
			}
			Console.Write(" | ");
			for (int cont = 0; cont < SalidasEsperadas.Length; cont++) {
				Console.Write(SalidasEsperadas[cont].ToString() + " ");
			}
			Console.Write(" | ");
			for (int cont = 0; cont < Capas[2].Salidas.Length; cont++) {
				Console.Write(Capas[2].Salidas[cont].ToString());
			}
			Console.WriteLine(" ");
		}


		//Dada las entradas al perceptrón, se calcula la salida de cada capa.
		//Con eso se sabrá que salidas se obtienen con los pesos y umbrales actuales.
		//Esas salidas son requeridas para el algoritmo de entrenamiento.
		public void CalculaSalidaRed(double[] Entradas) {
			Capas[0].CalculaCapa(Entradas);
			Capas[1].CalculaCapa(Capas[0].Salidas);
			Capas[2].CalculaCapa(Capas[1].Salidas);
		}

		//Con las salidas previamente calculadas con unas determinadas entradas
		//se ejecuta el algoritmo de entrenamiento "Backpropagation"  
		public void Entrena(double[] Entradas, double[] SalidasEsperadas) {
			int Capa0 = Capas[0].Neuronas.Length;
			int Capa1 = Capas[1].Neuronas.Length;
			int Capa2 = Capas[2].Neuronas.Length;

			//Factor de aprendizaje
			double alpha = 0.4;

			//Procesa pesos capa 2
			for (int j = 0; j < Capa1; j++) //Va de neurona en neurona de la capa 1
				for (int i = 0; i < Capa2; i++) { //Va de neurona en neurona de la capa de salida (capa 2)
					double Yi = Capas[2].Salidas[i]; //Salida de la neurona de la capa de salida
					double Si = SalidasEsperadas[i]; //Salida esperada
					double a1j = Capas[1].Salidas[j]; //Salida de la capa 1
					double dE2 = a1j * (Yi - Si) * Yi * (1 - Yi); //La fórmula del error
					Capas[2].Neuronas[i].NuevosPesos[j] = Capas[2].Neuronas[i].Pesos[j] - alpha * dE2; //Ajusta el nuevo peso
				}

			//Procesa pesos capa 1
			for (int j = 0; j < Capa0; j++) //Va de neurona en neurona de la capa 0
				for (int k = 0; k < Capa1; k++) { //Va de neurona en neurona de la capa 1
					double acumula = 0;
					for (int i = 0; i < Capa2; i++) { //Va de neurona en neurona de la capa 2
						double Yi = Capas[2].Salidas[i]; //Salida de la capa 2
						double Si = SalidasEsperadas[i]; //Salida esperada
						double W2ki = Capas[2].Neuronas[i].Pesos[k];
						acumula += W2ki * (Yi - Si) * Yi * (1 - Yi); //Sumatoria
					}
					double a0j = Capas[0].Salidas[j];
					double a1k = Capas[1].Salidas[k];
					double dE1 = a0j * a1k * (1 - a1k) * acumula;
					Capas[1].Neuronas[k].NuevosPesos[j] = Capas[1].Neuronas[k].Pesos[j] - alpha * dE1;
				}

			//Procesa pesos capa 0
			for (int j = 0; j < Entradas.Length; j++) //Va de entrada en entrada
				for (int k = 0; k < Capa0; k++) { //Va de neurona en neurona de la capa 0
					double AcumulaA = 0;
					for (int p = 0; p < Capa1; p++) { //Va de neurona en neurona de la capa 1
						double AcumulaB = 0;
						for (int i = 0; i < Capa2; i++) { //Va de neurona en neurona de la capa 2
							double Yi = Capas[2].Salidas[i];
							double Si = SalidasEsperadas[i]; //Salida esperada
							double W2pi = Capas[2].Neuronas[i].Pesos[p];
							AcumulaB += W2pi * (Yi - Si) * Yi * (1 - Yi); //Sumatoria interna
						}
						double W1kp = Capas[1].Neuronas[p].Pesos[k];
						double a1p = Capas[1].Salidas[p];
						AcumulaA += W1kp * a1p * (1 - a1p) * AcumulaB; //Sumatoria externa
					}
					double xj = Entradas[j];
					double a0k = Capas[0].Salidas[k];
					double dE0 = xj * a0k * (1 - a0k) * AcumulaA;
					double W0jk = Capas[0].Neuronas[k].Pesos[j];
					Capas[0].Neuronas[k].NuevosPesos[j] = W0jk - alpha * dE0;
				}


			//Procesa umbrales capa 2
			for (int i = 0; i < Capa2; i++) { //Va de neurona en neurona de la capa de salida (capa 2)
				double Yi = Capas[2].Salidas[i]; //Salida de la neurona de la capa de salida
				double Si = SalidasEsperadas[i]; //Salida esperada
				double dE2 = (Yi - Si) * Yi * (1 - Yi);
				Capas[2].Neuronas[i].NuevoUmbral = Capas[2].Neuronas[i].Umbral - alpha * dE2;
			}

			//Procesa umbrales capa 1
			for (int k = 0; k < Capa1; k++) { //Va de neurona en neurona de la capa 1
				double Acumula = 0;
				for (int i = 0; i < Capa2; i++) { //Va de neurona en neurona de la capa 2
					double Yi = Capas[2].Salidas[i]; //Salida de la capa 2
					double Si = SalidasEsperadas[i];
					double W2ki = Capas[2].Neuronas[i].Pesos[k];
					Acumula += W2ki * (Yi - Si) * Yi * (1 - Yi);
				}
				double a1k = Capas[1].Salidas[k];
				double dE1 = a1k * (1 - a1k) * Acumula;
				Capas[1].Neuronas[k].NuevoUmbral = Capas[1].Neuronas[k].Umbral - alpha * dE1;
			}

			//Procesa umbrales capa 0
			for (int k = 0; k < Capa0; k++) { //Va de neurona en neurona de la capa 0
				double AcumulaA = 0;
				for (int p = 0; p < Capa1; p++) { //Va de neurona en neurona de la capa 1
					double AcumulaB = 0;
					for (int i = 0; i < Capa2; i++) { //Va de neurona en neurona de la capa 2
						double Yi = Capas[2].Salidas[i];
						double Si = SalidasEsperadas[i];
						double W2pi = Capas[2].Neuronas[i].Pesos[p];
						AcumulaB += W2pi * (Yi - Si) * Yi * (1 - Yi);
					}
					double W1kp = Capas[1].Neuronas[p].Pesos[k];
					double a1p = Capas[1].Salidas[p];
					AcumulaA += W1kp * a1p * (1 - a1p) * AcumulaB;
				}
				double a0k = Capas[0].Salidas[k];
				double dE0 = a0k * (1 - a0k) * AcumulaA;
				Capas[0].Neuronas[k].NuevoUmbral = Capas[0].Neuronas[k].Umbral - alpha * dE0;
			}

			//Actualiza los pesos
			Capas[0].Actualiza();
			Capas[1].Actualiza();
			Capas[2].Actualiza();
		}
	}
}
