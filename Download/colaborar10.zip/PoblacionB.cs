﻿/* Autor: Rafael Alberto Moreno Parra
 * Fecha: 26 de junio de 2022
 * 
 * Dada una serie de datos del tipo X,Y,Z donde X,Y son las entradas y Z es la salida.
 * El programa genera una ecuación al azar Z=F(X,Y) y da valores a X entre 0 y 1, Y entre 0 y 1. Así se
 * obtiene el dataset.
 *
 * Se busca la curva que mejor se ajuste a esa serie de datos.
 * La mejor curva permitiría hacer operaciones de interpolación.
 * Se prueban dos técnicas para buscar esa curva:
 * 1. Algoritmos evolutivos.
 * 2. Red neuronal, tipo perceptrón multicapa (algoritmos ya definidos)
 * 
 * La investigación se concentra en los algoritmos evolutivos, NO en la red neuronal.
 * Se comparan ambas técnicas, sobre cuál logra encontrar la curva con mejor ajuste con el mismo tiempo de procesamiento
 *
 * En este proyecto en particular "Colaborar10", en algoritmos evolutivos, se prueba a generar dos curvas,
 * la primera curva cubre la primera mitad de los datos y la segunda curva la segunda mitad de los datos. Luego la
 * expresión sería:
 *      Z = f(X,Y) si Y está entre 0 y 0.5
 *      Z = g(X,Y) si Y está entre 0.5 y 1
 *
 * Colaborar10 trae como novedad el uso de arreglos estáticos, en vez de listas dinámicas para hacer más rápidos los algoritmos.
*/
using System;
using System.Diagnostics;

namespace Colaborar10 {
	internal class PoblacionB {
		//Almacena los individuos de la población
		IndividuoB[] Individuos;

		//Inicializa la población con un número de individuos
		public PoblacionB(Random Azar, int numIndividuos) {
			Individuos = new IndividuoB[numIndividuos];
			for (int Contador = 0; Contador < numIndividuos; Contador++)
                Individuos[Contador] = new IndividuoB(Azar);
		}

		public void Proceso(Random Azar, double[] Entrada1, double[] Entrada2, double[][] Salidas, int MinimoY, int MaximoY, long TiempoParaOperar) {
			IndividuoB Ganador, Perdedor;

			//Medidor de tiempos
			Stopwatch Cronometro = new Stopwatch();
			Cronometro.Reset();
			Cronometro.Start();

			//Llama al que mejora cada individuo
			int Contador = 0;
			while (Cronometro.ElapsedMilliseconds < TiempoParaOperar / 2) {
				Individuos[Contador++].MejoraIndividuo(Azar, Entrada1, Entrada2, Salidas, MinimoY, MaximoY);
				if (Contador >= Individuos.Length) Contador = 0;
			}

			//Veces que se repetirá el proceso evolutivo
			while (Cronometro.ElapsedMilliseconds < TiempoParaOperar) {

				//Escoge dos individuos al azar
				int IndividuoA = Azar.Next(Individuos.Length);
				int IndividuoB;
				do {
					IndividuoB = Azar.Next(Individuos.Length);
				} while (IndividuoB == IndividuoA);

				//Evalúa cada individuo con respecto a las entradas y salidas esperadas
				Individuos[IndividuoA].AjusteIndividuo(Entrada1, Entrada2, Salidas, MinimoY, MaximoY);
				Individuos[IndividuoB].AjusteIndividuo(Entrada1, Entrada2, Salidas, MinimoY, MaximoY);

				//El mejor individuo genera una copia que sobreescribe al peor y la copia se muta
				if (Individuos[IndividuoA].Ajuste < Individuos[IndividuoB].Ajuste) {
					Ganador = Individuos[IndividuoA];
					Perdedor = Individuos[IndividuoB];
				}
				else {
					Ganador = Individuos[IndividuoB];
					Perdedor = Individuos[IndividuoA];
				}

				//Copia el individuo ganador sobre el perdedor
				for (int Copia = 0; Copia < Ganador.Coef.Length; Copia++) 
					Perdedor.Coef[Copia] = Ganador.Coef[Copia];

				//Muta la copia
				Perdedor.Coef[Azar.Next(0, Perdedor.Coef.Length)] += Azar.NextDouble() * 2 - 1;
				Perdedor.Ajuste = -1;
			}
		}

		public double MejorAproximacion() {
			double MejorAjuste = double.MaxValue;
			for (int cont = 0; cont < Individuos.Length; cont++)
				if (Individuos[cont].Ajuste != -1 && Individuos[cont].Ajuste < MejorAjuste)
					MejorAjuste = Individuos[cont].Ajuste;
			return MejorAjuste;
		}
	}
}
