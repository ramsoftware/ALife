/* Esta nueva simulaci�n trabaja dependiendo de los datos
que se obitenen por los sensores y las acciones.

Para crear un organismo, se debe identificar a la libreria
cuantos sensores existen y cuantas acciones son posibles de hacer.

Luego se crean los organismos normalmente teniendo en cuenta
que los sensores hacen parte de la expresi�n y no son asignables.
*/

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "Inicializa.h"
#include "Organismo.h"

#define NUMEROFUNCIONES 3
#define TOTALSENSORES 6
#define TOTALACCIONES 4

#define INISEMILLA 200  //Con cuantos organismos se refresca la semilla de aleatorios
#define LONGLISTA 40  //Tamano de la lista
#define MENORNUMERO 9999 //Numero de casillas tablero

void main()
{
	//Inicializa lista de mejores organismos
	Mejores objMejor[LONGLISTA];
	for (unsigned int iCont=0; iCont<LONGLISTA; iCont++)
		objMejor[iCont].iPuntAdapta = 0;

	//Valores de la simulacion
	Inicializa objIni;
	objIni.vPantallaIni();
	if (objIni.vLeeArchivoIni() < 0 ) exit(1);
	objIni.vArchResult();
	
	//Variables para el organismo
	char sbADN[4000];

	//Inicializa tablero de Juego (un ambiente)
	unsigned int iTablero[80][80];
	unsigned int iCont1, iCont2, iCasillaLlena, iLista, iCopia, iMenor=0, iPosMenor=0;

	//Comienza el juego
	unsigned int iPuntInstr1 = 1;
	unsigned int iCuentaJuegos=0;
	unsigned int iAccion=0;
	unsigned int iFuncion=0;
	unsigned int iCuentaOrg=0, iCasillaLlenaOrg=0;
	
	unsigned int iVecesJuega;
	iVecesJuega = objIni.stDatVA.iAnchoTabl * objIni.stDatVA.iLargoTabl*2;

	//Objeto Organismo
	Organismo objOrg;
	objOrg.IniciaSemillaT();
	objOrg.vInicio(true, objIni.stDatVA.iNumInstMax, objIni.stDatVA.iNumCiclos,
						objIni.stDatVA.iPosibIf, objIni.stDatVA.iPosibSet,
						objIni.stDatVA.iPosIg, objIni.stDatVA.iPosMay,
						objIni.stDatVA.iPosMen, objIni.stDatVA.iPosDif,
						objIni.stDatVA.iLongExpr, objIni.stDatVA.iPosibX, objIni.stDatVA.iPosibY,
						objIni.stDatVA.iPosibP,	objIni.stDatVA.iPosibN,
						NUMEROFUNCIONES, TOTALSENSORES, TOTALACCIONES);
    objOrg.objGenExpr.vIniLista
	(objIni.stDatVA.iPosibN,
	 objIni.stDatVA.iPosibX,
	 objIni.stDatVA.iPosibY,
	 objIni.stDatVA.iPosibP);

	//Primer Grupo. Se llena la lista de los mejores organismos
	do //Ciclo de juego
	{
		//Inicializar la semilla de numeros aleatorios
		iCuentaOrg++;
		if (iCuentaOrg>INISEMILLA)
		{
			objOrg.IniciaSemillaT();
			objOrg.objGenExpr.vIniLista(
				objIni.stDatVA.iPosibN,
				objIni.stDatVA.iPosibX,
				objIni.stDatVA.iPosibY,
				objIni.stDatVA.iPosibP);

			iCuentaOrg=0;
			iCasillaLlenaOrg++;
			printf("Organismos: %d\n", iCasillaLlenaOrg*INISEMILLA);
			if (iCasillaLlenaOrg*INISEMILLA>=objIni.stDatVA.iTotalOrg) break;
		}

		//Inicializa el tablero a cero
		for (iCont1=0; iCont1<objIni.stDatVA.iAnchoTabl; iCont1++)
			for (iCont2=0; iCont2<objIni.stDatVA.iLargoTabl; iCont2++)
 				iTablero[iCont1][iCont2]=0;

		//Inicializa los sensores y acciones
		for (iCont1=0; iCont1<=TOTALSENSORES; iCont1++)
			objOrg.fSensor[iCont1] = 0;
		
		for (iCont1=0; iCont1<=TOTALACCIONES; iCont1++)
			objOrg.fAccion[iCont1] = 0;

		//Crea Organismo
		objOrg.vCreaADN();

		//Por donde va el algoritmo
		iPuntInstr1 = 1;

		//Cuantas veces es llamado el algoritmo a jugar
		iCuentaJuegos=0;
		iCasillaLlena=0;
		do
		{
			iCuentaJuegos++;
			iAccion = objOrg.fEvalOrganismo( &iPuntInstr1, &iFuncion);
			if (iAccion==1) //Llamando una funcion
			{
				switch(iFuncion)
				{
				case 1: //Sensor de Posici�n 1, Accion 1-2
					if ((objOrg.fAccion[1]<objIni.stDatVA.iAnchoTabl && objOrg.fAccion[1]>=0) && (objOrg.fAccion[2]<objIni.stDatVA.iLargoTabl && objOrg.fAccion[2]>=0))
					{
						iCont1 = (int) objOrg.fAccion[1];
						iCont2 = (int) objOrg.fAccion[2];
						objOrg.fSensor[1] = (float) iTablero[iCont1][iCont2];
					}
					else
						objOrg.fSensor[1] = -1;
					break;
				case 2: //Sensor de l�mites 2-5
					objOrg.fSensor[2] = 0;
					objOrg.fSensor[3] = 0;
					objOrg.fSensor[4] = (float) objIni.stDatVA.iAnchoTabl;
					objOrg.fSensor[5] = (float) objIni.stDatVA.iLargoTabl;
					break;
				case 3: //Accion: Colocar una ficha, Sensor 6
					if ((objOrg.fAccion[3]<objIni.stDatVA.iAnchoTabl && objOrg.fAccion[3]>=0) && (objOrg.fAccion[4]<objIni.stDatVA.iLargoTabl && objOrg.fAccion[4]>=0))
					{
						iCont1 = (int) objOrg.fAccion[3];
						iCont2 = (int) objOrg.fAccion[4];
						if (iTablero[iCont1][iCont2]==0)
						{
							iTablero[iCont1][iCont2]=1;
							objOrg.fSensor[6]=1;
							iCasillaLlena++;
						}
						else
							objOrg.fSensor[6]=2;
					}
					else
						objOrg.fSensor[6]=-1;
					break;
				}
			}

		} while (iCuentaJuegos<=iVecesJuega && iAccion!=0 && iAccion!=-1);

		//Segun el iCasillaLlena lo guarda en la lista de los mejores
		if (iCasillaLlena>iMenor)
		{
			//Queda el organismo en la lista de los mejores
			for (iCopia=1; iCopia<=objOrg.m_iMaxGenOrg; iCopia++)
			{
				objMejor[iPosMenor].m_oGen[iCopia].cTipInst = objOrg.m_oGen[iCopia].cTipInst;
				objMejor[iPosMenor].m_oGen[iCopia].iVarSensor = objOrg.m_oGen[iCopia].iVarSensor;
				objMejor[iPosMenor].m_oGen[iCopia].iVarAccion = objOrg.m_oGen[iCopia].iVarAccion;
				objMejor[iPosMenor].m_oGen[iCopia].cOperacion = objOrg.m_oGen[iCopia].cOperacion;
				objMejor[iPosMenor].m_oGen[iCopia].iVarExpr1 = objOrg.m_oGen[iCopia].iVarExpr1;
				objMejor[iPosMenor].m_oGen[iCopia].iVarExpr2 = objOrg.m_oGen[iCopia].iVarExpr2;
				strcpy(objMejor[iPosMenor].m_oGen[iCopia].sbExpresion, objOrg.m_oGen[iCopia].sbExpresion);
				objMejor[iPosMenor].m_oGen[iCopia].iGotoLabel = objOrg.m_oGen[iCopia].iGotoLabel;
				objMejor[iPosMenor].m_oGen[iCopia].iCodFunc = objOrg.m_oGen[iCopia].iCodFunc;
			}
			objMejor[iPosMenor].m_iMaxGenOrg = objOrg.m_iMaxGenOrg;
			objMejor[iPosMenor].iPuntAdapta = iCasillaLlena;

			//Busca una siguiente posicion menor
			iMenor = MENORNUMERO;
			for (iLista=0; iLista<LONGLISTA; iLista++)
				if (objMejor[iLista].iPuntAdapta < iMenor)
				{
					iMenor = objMejor[iLista].iPuntAdapta;
					iPosMenor = iLista;
				}
		}

	} while (true);

	//Graba a archivo los LONGLISTA mejores organismos
	float iTotAcum=0;
	for (iLista=0; iLista<LONGLISTA; iLista++)
	{
		for (iCopia=1; iCopia<=objMejor[iLista].m_iMaxGenOrg; iCopia++)
		{
			objOrg.m_oGen[iCopia].cTipInst = objMejor[iLista].m_oGen[iCopia].cTipInst;
			objOrg.m_oGen[iCopia].iVarSensor = objMejor[iLista].m_oGen[iCopia].iVarSensor;
			objOrg.m_oGen[iCopia].iVarAccion = objMejor[iLista].m_oGen[iCopia].iVarAccion;
			objOrg.m_oGen[iCopia].cOperacion = objMejor[iLista].m_oGen[iCopia].cOperacion;
			objOrg.m_oGen[iCopia].iVarExpr1 = objMejor[iLista].m_oGen[iCopia].iVarExpr1;
			objOrg.m_oGen[iCopia].iVarExpr2 = objMejor[iLista].m_oGen[iCopia].iVarExpr2;
			strcpy(objOrg.m_oGen[iCopia].sbExpresion, objMejor[iLista].m_oGen[iCopia].sbExpresion);
			objOrg.m_oGen[iCopia].iGotoLabel = objMejor[iLista].m_oGen[iCopia].iGotoLabel;
			objOrg.m_oGen[iCopia].iCodFunc = objMejor[iLista].m_oGen[iCopia].iCodFunc;
		}
		objOrg.m_iMaxGenOrg = objMejor[iLista].m_iMaxGenOrg;
		objOrg.sDisplayADN(sbADN);
		objIni.vGrabaOrganismos(objMejor[iLista].iPuntAdapta, sbADN);
		iTotAcum += objMejor[iLista].iPuntAdapta;
	}
	objIni.vFinalSimulacion();
	sprintf(sbADN, "Promedio es: %f\n", iTotAcum / LONGLISTA);
	objIni.vGrabaOrganismos(0, sbADN);
}