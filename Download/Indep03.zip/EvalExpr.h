/* ARTIFICIAL LIFE ENGINE. EVALUADOR DE EXPRESIONES OPTIMIZADO.

   AUTOR: RAFAEL ABERTO MORENO PARRA

   EvalExpr de expresiones en Visual C++.	Enero 30 del 2000.

   Sus caracteristicas principales son:
   - Evaluador NO recursivo.
   - Optimizado para Artificial Life Engine 
   - Evalua m_sFuncion trigonometricas en radianes.

   Forma de uso:

	 float dCapturaEcuacion(char *expresion, float valor_x, float valor_y);

		 Donde *expresion es una cadena donde reposa la expresion a evaluar,
		 por ejemplo: "4*2-x+y*3".
		 valor_x y valor_y son los valores con que va las variables 'x' y 'y'
		 en la expresi�n.
		 Esta subrutina retorna el valor de la expresi�n.

		 Ej:
			 void main()
			 {
			  float resultado;
			   char funcion[]="3*4+y-21*x";
			  float x=10.4, y=23.5;

			  resultado=dCapturaEcuacion(funcion, x, y);

			  printf("el resultado es %f", resultado);
			 }


	 float dCicloEvalua(float valor_x, float valor_y);

		 retorna los valores de una expresion anteriormente evaluada,
		 es muy veloz para ciclos.

		 Ej:

			 void main()
			 {
			  float resultado;
			   char funcion[]="3*4+y-21*x";
			  float x=10.4, y=23.5;
			   int contador;

			  resultado=dCapturaEcuacion(funcion, x, y);

			  printf("el resultado es %f\n", resultado);

			  for(i=1; i<=60; i++)
			  {
			   x*=i; y+=i;
			   resultado=dCicloEvalua(x, y);
			   printf("resultados parciales %f\n", resultado);
			  }
			 }



	  int iChequeaSintaxis( char *expresion)

	 retorna 0 si NO hay errores en la expresi�n.
	 retorna
		 1:  Dobles operandos. Ej: 5*+3
		 2:  Parentesis desbalanceados  Ej: 4-(3*4
		 3:  Numero seguido de (      Ej: 7-4(3*2)
		 4:  Operando(+,-,*,/) seguido de )   Ej: 3-(4*)+2
		 5:  Letra seguida de )     Ej: 7-(5-a)
		 6:  Mandato Desconocido  Ej: flow(3*4)

*/


/* COMO FUE PROGRAMADO:

   Supongamos una cadena de expresi�n as�:
	3-4*(3+x)+8-(2+x*x)

   la expresi�n se desintegra en acums:

   m_sAcum[0]="2+x*x"             => 3-4*(3+x)+8-@A;
   m_sAcum[1]="3x+8"               => 3-4*@B+8-@A;
   m_sAcum[2]="3-4*@B+8-@A"

   cada '@?' es evaluado como una expresi�n simple.
   m_sAcum[0]="2+x*y"
   => m_sVectorNumeros[0][0]="2"  m_sVectorOperador[0][0]='+';
	  m_sVectorNumeros[0][1]="x"   m_sVectorOperador[0][1]='*';
	  m_sVectorNumeros[0][2]="y"   m_sVectorOperador[0][2]='F';
*/

class EvalExpr {
public:
	float dCapturaEcuacion(char *p, float x, float y);
	float dCicloEvalua(float x, float y);
	char ERRORMATEMATICO;
	int _matherr(struct exception *a);

private:
// Variables requeridas para el EvalExpr de expresiones.
	 char m_sAcum[30][50];
	 unsigned char m_iNumAcums; // variable que cuenta el numero de acums
	 char m_sVectorNumeros[27][20][10];
	 char m_sVectorOperador[27][27];
 	 float m_AcumFloat[30];
	 char m_sFuncion[19][16];
	 	
// m_sFuncion privadas del optimizador	
	void vExprAcums(char *p);
	void vReemplazarExpr( char *p, char *sReemplazo,
		      unsigned char desde, unsigned char hasta);
	void vDesintegraAcumn( char *expresion,  char indicadorp);
	float dEvaluaExpresion(unsigned char indicadorp, float x, float y);
};