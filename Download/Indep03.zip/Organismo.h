/*
Autor:		Rafael Alberto Moreno Parra
URL:		http://www.geocities.com/krousky
Clase:		Organismo
Lenguaje:	C++

Prop�sito:
Clase de administraci�n del medio ambiente (serie num�rica de entrada y
salida)

M�todos:
IniciaSemillaT: Inicializa la semilla dependiendo del tiempo
IniciaSemillaR: Inicializa la semilla aleatoriamente
sDisplayADN: Despliega el organismo como si fuera c�digo Java
vCreaADN: Crea el organismo, llamando la funci�n que hace sus genes
vHaceGen: Crea una linea de codigo fuente (la llam� Gen). El formato es:
          label, [, IF/SET, Variable, =/>/</!, (, expresion, ), Goto, Label, ]
          para mayor velocidad, se ubica en una clase el Gen
vEvaluaPrevio: Optimiza la velocidad de evaluaci�n del organismo en un
               ambiente.
fEvalOrganismo: Evalua el organismo en el ambiente
vMutaGen: Mutaci�n suave de un gen del organismo

*/

#include <time.h>
#include "EvalExpr.h"
#include "GenExpr.h"

class Organismo
{
private:
	EvalExpr m_eEvalua; //Evaluador de expresiones
    time_t ltime1; //Variable tiempo para regenerar la semilla de aleatorios

	struct stProbabilidades
	{
		bool bGenRandom; //N�mero de Genes fijos o aleatorio
		unsigned int iMaxGenes; //M�ximo n�mero de genes
		unsigned int iMaxiCiclos; //Maximo numero de ciclos que se gastaran para evaluar el organismo
        unsigned int iPosibIf; //Posibilidad de If
		unsigned int iPosibSet; //Posibilidad de Asignaci�n
        unsigned int iPosIg; //Posibilidad de = en el IF
		unsigned int iPosMay; //Posibilidad de > en el IF
		unsigned int iPosMen; //Posibilidad de < en el IF
		unsigned int iPosDif; //Posibilidad de <> en el IF
		unsigned int iLongExpr; //Longitud maxima de la expresi�n
		unsigned int iPosibV1; //Posibilidad de variable 1 en la expresion 
		unsigned int iPosibV2; //Posibilidad de variable 2 en la expresion 
		unsigned int iPosibP; //Posibilidad de parentesis en la expresion 
		unsigned int iPosibN; //Posibilidad de numero en la expresion
	};
	

	struct stGen
	{
		bool bEjecuta; /* Se coloca a TRUE si la instruccion es ejecutada */
		char cTipInst; /* Operacion IF o SET o FUNCION */
		unsigned int iVarSensor; /* Variable Sensor para comparacion */
		unsigned int iVarAccion; /* Variable Sensor para asignacion */
		char cOperacion; /* Que operacion >,<,=,! se hara si es un IF condicional */
		unsigned int iVarExpr1; /* Variable 1 activa en la expresion */
		unsigned int iVarExpr2; /* Variable 2 activa en la expresion */
		char sbExpresion[60]; /* Expresion en X y Y */
		unsigned int iGotoLabel; /* Hacia que gen ir� */
		unsigned int iCodFunc; /* Codigo de la funcion */
	};


public:
	//Probabilidades
	struct stProbabilidades stProbOrg;

	//Para generaci�n de expresiones
	GenExpr objGenExpr;
	unsigned int m_iMaxGenOrg; //Maximo numero de genes para el organismo

	//Genes
	struct stGen m_oGen[100];

    //Constructor
	Organismo();

	//Inicia la semilla de los n�meros aleatorios (tiempo)
	void IniciaSemillaT();
	void IniciaSemillaR();
    
	//Fija las probabilidades en la estructura
	void vInicio (bool bGenRandom, unsigned int iMaxGenes, unsigned int iMaxiCiclos,
                   unsigned int iPosibIf, unsigned int iPosibSet,
                   unsigned int iPosIg, unsigned int iPosMay, unsigned int iPosMen, unsigned int iPosDif,
                   unsigned int iLongExpr, unsigned int iPosibV1, unsigned int iPosibV2, unsigned int iPosibP, unsigned int iPosibN,
				   unsigned int iTotalFuncion, unsigned int iTotalSensor, unsigned int iTotalAccion);


	//Crea el Organismo
    void vCreaADN ();

    /* Crea una linea de codigo fuente (la llam� Gen). El formato es:
    label, [, IF/SET, Variable, =/>/</!, (, expresion, ), Goto, Label, ]
    para mayor velocidad, se ubica en una clase el Gen */
    void vHaceGen(unsigned int iLabel);

	//Evalua el organismo en el ambiente
	unsigned int m_iTotalFuncion;
	unsigned int m_iTotalSensor;
	unsigned int m_iTotalAccion;
	float fSensor[50]; // Hasta 50 sensores
	float fAccion[50]; // Hasta 50 acciones
	int fEvalOrganismo (unsigned int *iOrgGenInst, unsigned int *iFuncion);

	void sDisplayADN(char *sbADN);
};

//Mejores Organismos (sin los m�todos)
class Mejores
{

private:
	struct stGen
	{
		char cTipInst; /* Operacion IF o SET o FUNCION */
		unsigned int iVarSensor; /* Variable Sensor para comparacion */
		unsigned int iVarAccion; /* Variable Accion para asignacion */
		char cOperacion; /* Que operacion >,<,=,! se hara si es un IF condicional */
		unsigned int iVarExpr1; /* Variable 1 activa en la expresion */
		unsigned int iVarExpr2; /* Variable 2 activa en la expresion */
		char sbExpresion[60]; /* Expresion en X y Y */
		unsigned int iGotoLabel; /* Hacia que gen ir� */
		unsigned int iCodFunc; /* Codigo de la funcion */
	};

public:
	struct stGen m_oGen[100];
	unsigned int m_iMaxGenOrg; //Maximo numero de genes para el organismo
	unsigned int iPuntAdapta; //Adaptacion ser vivo	
};