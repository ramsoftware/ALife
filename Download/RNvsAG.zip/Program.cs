﻿using System;
using System.Diagnostics;

namespace RNvsAG {
    //La clase que implementa el perceptrón multicapa
    class Perceptron {
        private double[,,] W; //Los pesos serán arreglos multidimensionales. Así: W[capa, neurona inicial, neurona final]
        private double[,] U; //Los umbrales de cada neurona serán arreglos bidimensionales. Así: U[capa, neurona que produce la salida]
        double[,] A; //Las salidas de cada neurona serán arreglos bidimensionales. Así: A[capa, neurona que produce la salida]

        private double[,,] WN; //Los nuevos pesos serán arreglos multidimensionales. Así: W[capa, neurona inicial, neurona final]
        private double[,] UN; //Los nuevos umbrales de cada neurona serán arreglos bidimensionales. Así: U[capa, neurona que produce la salida]

        private int TotalCapas; //El total de capas que tendrá el perceptrón incluyendo la capa de entrada
        private int[] neuronasporcapa; //Cuantas neuronas habrá en cada capa
        private int TotalEntradas; //Total de entradas externas del perceptrón
        private int TotalSalidas; //Total salidas externas del perceptrón
        private double TasaAprende; //Tasa de aprendizaje

        public Perceptron(Random azar, double TasaAprende, int TotalEntradas, int TotalSalidas, int TotalCapas, int[] neuronasporcapa) {
            this.TotalEntradas = TotalEntradas;
            this.TotalSalidas = TotalSalidas;
            this.TotalCapas = TotalCapas;
            this.TasaAprende = TasaAprende;
            int maxNeuronas = 0; //Detecta el máximo número de neuronas por capa para dimensionar los arreglos
            this.neuronasporcapa = new int[TotalCapas + 1];
            for (int capa = 1; capa <= TotalCapas; capa++) {
                this.neuronasporcapa[capa] = neuronasporcapa[capa];
                if (neuronasporcapa[capa] > maxNeuronas) maxNeuronas = neuronasporcapa[capa];
            }

            //Dimensiona con el máximo valor
            W = new double[TotalCapas + 1, maxNeuronas + 1, maxNeuronas + 1];
            U = new double[TotalCapas + 1, maxNeuronas + 1];
            WN = new double[TotalCapas + 1, maxNeuronas + 1, maxNeuronas + 1];
            UN = new double[TotalCapas + 1, maxNeuronas + 1];
            A = new double[TotalCapas + 1, maxNeuronas + 1];

            IniciaPesosAzar(azar);
        }

        public void IniciaPesosAzar(Random azar) {
            //Da valores aleatorios a pesos y umbrales
            for (int capa = 2; capa <= TotalCapas; capa++)
                for (int i = 1; i <= neuronasporcapa[capa]; i++)
                    U[capa, i] = azar.NextDouble();

            for (int capa = 1; capa < TotalCapas; capa++)
                for (int i = 1; i <= neuronasporcapa[capa]; i++)
                    for (int j = 1; j <= neuronasporcapa[capa + 1]; j++)
                        W[capa, i, j] = azar.NextDouble();
        }

        public double Procesa(double[] E) {
            //Entradas externas del perceptrón pasan a la salida de la primera capa
            for (int copia = 1; copia <= TotalEntradas; copia++) A[1, copia] = E[copia];

            //Proceso del perceptrón
            for (int capa = 2; capa <= TotalCapas; capa++)
                for (int neurona = 1; neurona <= neuronasporcapa[capa]; neurona++) {
                    A[capa, neurona] = 0;
                    for (int entra = 1; entra <= neuronasporcapa[capa - 1]; entra++)
                        A[capa, neurona] += A[capa - 1, entra] * W[capa - 1, entra, neurona];
                    A[capa, neurona] += U[capa, neurona];
                    A[capa, neurona] = 1 / (1 + Math.Exp(-A[capa, neurona]));
                }

            return A[TotalCapas, 1];
        }

        //Retorna la diferencia absoluta entre la salida esperada y la salida calculada por el perceptrón
        public double Diferencia(double[] S) {
            return Math.Abs(S[1] - A[TotalCapas, 1]);
        }

        public void Entrena(double[] E, double[] S) {
            //Ajusta pesos capa3 ==> capa4
            for (int j = 1; j <= neuronasporcapa[3]; j++)
                for (int i = 1; i <= neuronasporcapa[4]; i++) {
                    double Yi = A[4, i];
                    double dE3 = A[3, j] * (Yi - S[i]) * Yi * (1 - Yi);
                    WN[3, j, i] = W[3, j, i] - TasaAprende * dE3; //Nuevo peso se guarda temporalmente
                }

            //Ajusta pesos capa2 ==> capa3
            for (int j = 1; j <= neuronasporcapa[2]; j++)
                for (int k = 1; k <= neuronasporcapa[3]; k++) {
                    double acum = 0;
                    for (int i = 1; i <= neuronasporcapa[4]; i++) {
                        double Yi = A[4, i];
                        acum += W[3, k, i] * (Yi - S[i]) * Yi * (1 - Yi);
                    }
                    double dE2 = A[2, j] * A[3, k] * (1 - A[3, k]) * acum;
                    WN[2, j, k] = W[2, j, k] - TasaAprende * dE2; //Nuevo peso se guarda temporalmente
                }

            //Ajusta pesos capa1 ==> capa2
            for (int j = 1; j <= neuronasporcapa[1]; j++)
                for (int k = 1; k <= neuronasporcapa[2]; k++) {
                    double acumular = 0;
                    for (int p = 1; p <= neuronasporcapa[3]; p++) {
                        double acum = 0;
                        for (int i = 1; i <= neuronasporcapa[4]; i++) {
                            double Yi = A[4, i];
                            acum += W[3, p, i] * (Yi - S[i]) * Yi * (1 - Yi);
                        }
                        acumular += W[2, k, p] * A[3, p] * (1 - A[3, p]) * acum;
                    }
                    double dE1 = E[j] * A[2, k] * (1 - A[2, k]) * acumular;
                    WN[1, j, k] = W[1, j, k] - TasaAprende * dE1; //Nuevo peso se guarda temporalmente
                }

            //Ajusta umbrales de neuronas de la capa 4
            for (int i = 1; i <= neuronasporcapa[4]; i++) {
                double Yi = A[4, i];
                double dE4 = (Yi - S[i]) * Yi * (1 - Yi);
                UN[4, i] = U[4, i] - TasaAprende * dE4; //Nuevo umbral se guarda temporalmente
            }

            //Ajusta umbrales de neuronas de la capa 3
            for (int k = 1; k <= neuronasporcapa[3]; k++) {
                double acum = 0;
                for (int i = 1; i <= neuronasporcapa[4]; i++) {
                    double Yi = A[4, i];
                    acum += W[3, k, i] * (Yi - S[i]) * Yi * (1 - Yi);
                }
                double dE3 = A[3, k] * (1 - A[3, k]) * acum;
                UN[3, k] = U[3, k] - TasaAprende * dE3; //Nuevo umbral se guarda temporalmente
            }

            //Ajusta umbrales de neuronas de la capa 2
            for (int k = 1; k <= neuronasporcapa[2]; k++) {
                double acumular = 0;
                for (int p = 1; p <= neuronasporcapa[3]; p++) {
                    double acum = 0;
                    for (int i = 1; i <= neuronasporcapa[4]; i++) {
                        double Yi = A[4, i];
                        acum += W[3, p, i] * (Yi - S[i]) * Yi * (1 - Yi);
                    }
                    acumular += W[2, k, p] * A[3, p] * (1 - A[3, p]) * acum;
                }
                double dE2 = A[2, k] * (1 - A[2, k]) * acumular;
                UN[2, k] = U[2, k] - TasaAprende * dE2; //Nuevo umbral se guarda temporalmente
            }

            //Copia los nuevos pesos y umbrales a los pesos y umbrales respectivos del perceptrón
            for (int capa = 2; capa <= TotalCapas; capa++)
                for (int i = 1; i <= neuronasporcapa[capa]; i++)
                    U[capa, i] = UN[capa, i];

            for (int capa = 1; capa < TotalCapas; capa++)
                for (int i = 1; i <= neuronasporcapa[capa]; i++)
                    for (int j = 1; j <= neuronasporcapa[capa + 1]; j++)
                        W[capa, i, j] = WN[capa, i, j];
        }
    }

    //Las clases que implementan el algoritmo genético (población, individuos, instrucciones por individuo)

    //Piezas que estarán en el arreglo bidimensional 
    class Pieza {
        public int Funcion;  //¿Se va a hacer uso de una función? 0 es no, 1 es seno, 2 es coseno, ....
        public int VarA; //Cuál variable de la primera parte
        public double Constante; //Constante
        public int Operador; // +, -, *, /
        public int VarB;  //Cuál variable de la segunda parte
        public int Tipo; // 0 es variable operador variable; 1 es variable operador constante; 2 es constante operador variable

        public Pieza(Random Azar, int fila) {
            Funcion = Azar.Next() % 3; //Las 3 funciones posibles
            VarA = Azar.Next() % fila; // Hacia donde apunta la primera variable
            Constante = Azar.NextDouble();
            Operador = Azar.Next() % 4;  //+  -  * /
            VarB = Azar.Next() % fila;
            Tipo = Azar.Next() % 3;
        }
    }

    class Individuo {
        public int[] Genotipo; //Almacena que piezas tiene el individuo
        public double Aproximacion; //Almacena su aproximación

        public Individuo(int Maxpiezasindiv) {
            Aproximacion = -1;
            Genotipo = new int[Maxpiezasindiv + 1];
            for (int cont = 0; cont < Genotipo.Length; cont++) Genotipo[cont] = 0;
        }

        public void GeneraIndividuo(Random Azar, int Piezasporcapa) {
            for (int pos = 1; pos < Genotipo.Length; pos++) Genotipo[pos] = Azar.Next() % Piezasporcapa + 1;
        }
    }

    class Genetico {
        int TamanoPoblacion; //Tamaño de la población
        Individuo[] Individuos; //Individuos de la población
        public int MejorIndividuo; //Almacena el mejor individuo
        public double MejorAproximacion; //Almacena la aproximación del mejor individuo (entre más cercano a cero es mejor)

        //Arreglo bidimensional que tendrá las piezas que formarán a los individuos
        int Piezasporcapa; //Número de piezas por capa
        int NumPiezasIndividuo; //Número de piezas que tendrá cada individuo
        Pieza[,] Arreglo;

        double[] valorX; //Valor X dado por el usuario final
        double[] valorYesperado; //Valor Y esperado por el usuario final
        int NumeroValores;  //Número de valores a encontrar tendencia

        //Copia las entradas y salidas esperadas
        public Genetico(int NumeroValores, double[][] E, double[][] S) {
            this.NumeroValores = NumeroValores;
            valorX = new double[NumeroValores + 1];
            valorYesperado = new double[NumeroValores + 1];

            for (int cont = 1; cont <= NumeroValores; cont++) {
                valorX[cont] = E[cont][1];
                valorYesperado[cont] = S[cont][1];
            }
        }

        //Inicia el proceso de cero: Población y arreglo bidimensional de piezas
        public void Iniciar(Random Azar, int TamanoPoblacion, int Piezasporcapa, int NumPiezasIndividuo) {
            //Tamaño de la población, arreglo bidimensional de piezas (Piezasporcapa*NumPiezasIndividuo)
            this.TamanoPoblacion = TamanoPoblacion;
            Individuos = new Individuo[TamanoPoblacion + 1];
            this.Piezasporcapa = Piezasporcapa;
            this.NumPiezasIndividuo = NumPiezasIndividuo;
            Arreglo = new Pieza[NumPiezasIndividuo + 1, Piezasporcapa + 1];

            MejorIndividuo = -1;
            MejorAproximacion = -1;

            //Genera los individuos
            for (int cont = 1; cont <= TamanoPoblacion; cont++) Individuos[cont] = new Individuo(NumPiezasIndividuo);

            //El arreglo bidimensional de las piezas
            for (int fila = 1; fila <= NumPiezasIndividuo; fila++)
                for (int columna = 1; columna <= Piezasporcapa; columna++)
                    Arreglo[fila, columna] = new Pieza(Azar, fila);
        }

        public void MutaMejorIndividuo(int quien, Random azar, int NumeroCiclos) {
            Individuo individuo = Individuos[quien];
            double AnteriorAprox = individuo.Aproximacion;
            double acumulaIndividuo;

            for (int cont = 1; cont <= NumeroCiclos; cont++) {
                int fila = azar.Next() % NumPiezasIndividuo + 1;
                int columna = individuo.Genotipo[fila];
                double valorAnterior = Arreglo[fila, columna].Constante;
                Arreglo[fila, columna].Constante = azar.NextDouble();

                acumulaIndividuo = 0;
                for (int valorEvalua = 1; valorEvalua <= NumeroValores; valorEvalua++) {
                    double salida = EvaluaIndividuo(quien, valorX[valorEvalua]);
                    acumulaIndividuo += (valorYesperado[valorEvalua] - salida) * (valorYesperado[valorEvalua] - salida);
                }

                if (AnteriorAprox <= acumulaIndividuo)
                    Arreglo[fila, columna].Constante = valorAnterior;
                else {
                    individuo.Aproximacion = acumulaIndividuo;
                    AnteriorAprox = acumulaIndividuo;
                    MejorAproximacion = acumulaIndividuo;
                }
            }
        }

        //Evalúa el individuo yendo de instrucción en instrucción que lo compone y retorna la aproximación
        public double EvaluaIndividuo(int quien, double Entrada) {
            double valorPieza = 0, parte1, parte2;
            Individuo individuo = Individuos[quien];
            double[] VariablesIndiv = new double[NumPiezasIndividuo + 1];
            VariablesIndiv[0] = Entrada;

            for (int fila = 1; fila <= NumPiezasIndividuo; fila++) {
                int columna = individuo.Genotipo[fila];
                switch (Arreglo[fila, columna].Tipo) {
                    case 0: //Variable operador variable
                    parte1 = VariablesIndiv[Arreglo[fila, columna].VarA];
                    parte2 = VariablesIndiv[Arreglo[fila, columna].VarB];
                    break;
                    case 1: //Variable operador constante
                    parte1 = VariablesIndiv[Arreglo[fila, columna].VarA];
                    parte2 = Arreglo[fila, columna].Constante;
                    break;
                    default: //Constante operador variable
                    parte1 = Arreglo[fila, columna].Constante;
                    parte2 = VariablesIndiv[Arreglo[fila, columna].VarB];
                    break;
                }
                if (double.IsInfinity(parte1) || double.IsInfinity(parte2) || double.IsNaN(parte1) || double.IsNaN(parte2)) return -1;

                switch (Arreglo[fila, columna].Operador) {
                    case 0: valorPieza = parte1 + parte2; break; //Sumar
                    case 1: valorPieza = Math.Abs(parte1 - parte2); break; //Restar
                    case 2: valorPieza = parte1 * parte2; break; //Multiplicar
                    case 3: valorPieza = parte1 / parte2; break; //Dividir
                }
                if (double.IsInfinity(valorPieza) || double.IsNaN(valorPieza)) return -1;

                switch (Arreglo[fila, columna].Funcion) {
                    case 0: VariablesIndiv[fila] = valorPieza; break;
                    case 1: VariablesIndiv[fila] = Math.Abs(Math.Sin(valorPieza)); break;
                    case 2: VariablesIndiv[fila] = Math.Abs(Math.Cos(valorPieza)); break;
                }
            }
            return VariablesIndiv[NumPiezasIndividuo];
        }

        public double CalculaAproximacion(int quien) {
            double acumulaIndividuo = 0, salida, saleAntes = -1;

            //Técnica de mínimos cuadrados
            for (int valorEvalua = 1; valorEvalua <= NumeroValores; valorEvalua++) {
                salida = EvaluaIndividuo(quien, valorX[valorEvalua]);
                if (salida == -1) return -1;
                if (saleAntes == -1)
                    saleAntes = salida;
                else {
                    if (Math.Abs(saleAntes - salida) < 0.00000001)
                        return -1;
                    else
                        saleAntes = salida;
                }
                acumulaIndividuo += (valorYesperado[valorEvalua] - salida) * (valorYesperado[valorEvalua] - salida);
            }

            if (double.IsInfinity(acumulaIndividuo) || double.IsNaN(acumulaIndividuo)) return -1;
            return acumulaIndividuo;
        }

        /* Proceso del algoritmo genético:
           1. Seleccionar dos individuos de la población al azar: A y B
           2. Comparar sus aproximaciones
           3. El que mejor se aproxima sobreescribe su código en el peor
           4. El individuo sobre-escrito muta una parte al azar
           5. Volver al punto 1
        */
        public void Proceso(Random Azar) {
            //Seleccionar dos individuos al azar
            int indivA, indivB;
            indivA = Azar.Next() % TamanoPoblacion + 1;
            do indivB = Azar.Next() % TamanoPoblacion + 1; while (indivB == indivA);

            Individuo individuoA = Individuos[indivA];
            Individuo individuoB = Individuos[indivB];

            if (individuoA.Aproximacion == -1) { //Si no se ha generado
                do {
                    individuoA.GeneraIndividuo(Azar, Piezasporcapa); //Genera el individuo
                    individuoA.Aproximacion = CalculaAproximacion(indivA);
                } while (individuoA.Aproximacion == -1);
            }

            if (individuoB.Aproximacion == -1) { //Si no se ha generado
                do {
                    individuoB.GeneraIndividuo(Azar, Piezasporcapa); //Genera el individuo
                    individuoB.Aproximacion = CalculaAproximacion(indivB);
                } while (individuoB.Aproximacion == -1);
            }

            //El que mejor se aproxima sobreescribe su código en el peor
            if ((individuoA.Aproximacion < individuoB.Aproximacion) || (individuoA.Aproximacion == individuoB.Aproximacion && MejorIndividuo == indivA)) {
                //Detecta si es el mejor individuo generado en la simulación
                if (individuoA.Aproximacion < this.MejorAproximacion || MejorAproximacion == -1) {
                    this.MejorAproximacion = individuoA.Aproximacion;
                    this.MejorIndividuo = indivA;
                }

                do {
                    //IndividuoA sobreescribe al IndividuoB
                    for (int pos = 1; pos <= NumPiezasIndividuo; pos++) individuoB.Genotipo[pos] = individuoA.Genotipo[pos];

                    //Muta el nuevo IndividuoB y calcula su aproximación
                    int seleccionada = Azar.Next() % NumPiezasIndividuo + 1;
                    individuoB.Genotipo[seleccionada] = Azar.Next() % Piezasporcapa + 1;
                    individuoB.Aproximacion = CalculaAproximacion(indivB);
                } while (individuoB.Aproximacion == -1);
            }
            else {
                //Detecta si es el mejor individuo generado en la simulación
                if (individuoB.Aproximacion < this.MejorAproximacion || MejorAproximacion == -1) {
                    this.MejorAproximacion = individuoB.Aproximacion;
                    this.MejorIndividuo = indivB;
                }

                do {
                    //IndividuoB sobreescribe al IndividuoA
                    for (int pos = 1; pos <= NumPiezasIndividuo; pos++) individuoA.Genotipo[pos] = individuoB.Genotipo[pos];

                    //Muta el nuevo IndividuoA y calcula su aproximación
                    int seleccionada = Azar.Next() % NumPiezasIndividuo + 1;
                    individuoA.Genotipo[seleccionada] = Azar.Next() % Piezasporcapa + 1;
                    individuoA.Aproximacion = CalculaAproximacion(indivA);
                } while (individuoA.Aproximacion == -1);
            }
        }
    }

    class Program {
        static double[] AproxRed;
        static double[] AproxGen;
        static double[] TiempoRed;
        static double[] TiempoGen;
        static int prueba;

        static void Main(string[] args) {
            Console.OutputEncoding = System.Text.Encoding.UTF8;
            Console.WriteLine("Ajuste de curvas: Perceptrón Multicapa vs Regresión simbólica");

            const string urlArchivo = "Dolar2015.tendencia"; //Nombre del archivo plano
            int Ciclos = 10000; // Convert.ToInt32(args[0]); //Cuantas veces el perceptrón o algoritmo genético serán entrenados con los datos de entrada y salidas esperados
            Random azar = new Random(); //Generador único de números pseudo-aleatorios

            // Lee los datos del archivo plano
            double[][] entrada = new double[2001][];
            double[][] salidas = new double[2001][];
            int TotalRegistros = LeeDatosArchivo(urlArchivo, entrada, salidas);

            Console.WriteLine("Archivo de datos: " + urlArchivo);
            Console.WriteLine("Total de registros: " + TotalRegistros.ToString());
            //Console.WriteLine("Registros leídos");

            // Con los datos leídos, normaliza esos valores entre 0 y 1
            double minimoX = entrada[1][1], maximoX = entrada[1][1];
            double minimoY = salidas[1][1], maximoY = salidas[1][1];
            for (int cont = 1; cont <= TotalRegistros; cont++) {
                if (entrada[cont][1] > maximoX) maximoX = entrada[cont][1];
                if (salidas[cont][1] > maximoY) maximoY = salidas[cont][1];
                if (entrada[cont][1] < minimoX) minimoX = entrada[cont][1];
                if (salidas[cont][1] < minimoY) minimoY = salidas[cont][1];
                //Console.WriteLine("X= " + entrada[cont][1].ToString() + "  Y= " + salidas[cont][1].ToString());
            }

            for (int cont = 1; cont <= TotalRegistros; cont++) {
                entrada[cont][1] = (entrada[cont][1] - minimoX) / (maximoX - minimoX);
                salidas[cont][1] = (salidas[cont][1] - minimoY) / (maximoY - minimoY);
            }

            Console.WriteLine("Mínimo X: " + minimoX.ToString() + " Máximo X: " + maximoX.ToString());
            Console.WriteLine("Mínimo Y: " + minimoY.ToString() + " Máximo Y: " + maximoY.ToString());

            AproxGen = new double[11];
            AproxRed = new double[11];
            TiempoRed = new double[11];
            TiempoGen = new double[11];
            for (prueba = 1; prueba <= 10; prueba++) {

                // Inicia el proceso de aprendizaje de la red neuronal: Perceptrón multicapa
                RedNeuronal(azar, TotalRegistros, Ciclos, entrada, salidas, minimoX, maximoX, minimoY, maximoY);

                // Inicia el proceso de adaptación del algoritmo genético: Regresión simbólica
                AlgoritmoGenetico(azar, TotalRegistros, Ciclos, entrada, salidas, minimoX, maximoX, minimoY, maximoY);

                Console.WriteLine(" ");
                Console.WriteLine(" ");
            }

            Console.WriteLine("Datos para Excel");
            for (prueba = 1; prueba <= 10; prueba++)
                Console.WriteLine(AproxGen[prueba].ToString() + " " + TiempoGen[prueba].ToString());
                //Console.WriteLine(AproxRed[prueba].ToString() + " " + AproxGen[prueba].ToString() + " " + TiempoRed[prueba].ToString() + " " + TiempoGen[prueba].ToString());

            Console.WriteLine("FIN");
        }

        //Algoritmo genético. Regresión simbólica
        private static void AlgoritmoGenetico(Random azar, int totalRegistros, int numeroCiclos, double[][] entrada, double[][] salidas, double minimoX, double maximoX, double minimoY, double maximoY) {
            Console.WriteLine("\n=====================  Algoritmo Genético. Regresión Simbólica =====================");
            Console.WriteLine("Número de veces en que se tomará dos individuos, se da con el mejor y se reproducirá: " + numeroCiclos.ToString());

            Genetico objG = new Genetico(totalRegistros, entrada, salidas);
            int Poblacion = 1000;
            int Piezasporcapa = 10000; //Cuantas piezas por capa tendrá el arreglo bidimensional de piezas
            int NumPiezasIndividuo = 10; //Número de piezas que compondrá el individuo
            Console.WriteLine("Población: " + Poblacion.ToString());
            Console.WriteLine("Número de piezas generadas por capa: " + Piezasporcapa.ToString());
            Console.WriteLine("Número de piezas que tendrá cada individuo: " + NumPiezasIndividuo.ToString());

            // Calcula tiempo que toma hacer todas las pruebas
            Stopwatch temporizador = Stopwatch.StartNew();

            //Inicializa todo el proceso
            objG.Iniciar(azar, Poblacion, Piezasporcapa, NumPiezasIndividuo);

            //Ejecuta el proceso de seleccionar dos individuos, escoger el mejor y reproducirlo
            for (int numciclos = 1; numciclos <= numeroCiclos; numciclos++) objG.Proceso(azar);
            //objG.MutaMejorIndividuo(objG.MejorIndividuo, azar, numeroCiclos);
            TimeSpan tiempoTotal = temporizador.Elapsed;
            Console.WriteLine("Tiempo tomado por el proceso de algoritmo genético: {0}", tiempoTotal.TotalSeconds);
            Console.WriteLine("Error (datos normalizados): " + objG.MejorAproximacion.ToString());

            /*for (int mostrar = 1; mostrar <= totalRegistros; mostrar++) {
                double entradaUsuario = entrada[mostrar][1] * (maximoX - minimoX) + minimoX;
                double salidasUsuario = salidas[mostrar][1] * (maximoY - minimoY) + minimoY;
                double salida = objG.EvaluaIndividuo(objG.MejorIndividuo, entrada[mostrar][1]) * (maximoY - minimoY) + minimoY;
                Console.Write(entradaUsuario.ToString() + "; ");
                Console.Write(salidasUsuario.ToString() + "; ");
                Console.WriteLine(salida.ToString());
            }*/
            AproxGen[prueba] = objG.MejorAproximacion;
            TiempoGen[prueba] = tiempoTotal.TotalSeconds;
        }

        //Entrenamiento de una red neuronal tipo perceptrón multicapa
        private static void RedNeuronal(Random azar, int totalRegistros, int numeroCiclos, double[][] entrada, double[][] salidas, double minimoX, double maximoX, double minimoY, double maximoY) {
            double alpha = 0.4; //Tasa de aprendizaje
            int TotalEntradas = 1; //Número de entradas externas del perceptrón
            int TotalSalidas = 1; //Número de salidas externas del perceptrón
            int TotalCapas = 4; //Total capas que tendrá el perceptrón (máximo 4)
            int[] neuronasporcapa = new int[TotalCapas + 1]; //Los índices iniciarán en 1 en esta implementación
            neuronasporcapa[1] = TotalEntradas; //Entradas externas del perceptrón
            neuronasporcapa[2] = 5; //Capa oculta con 5 neuronas
            neuronasporcapa[3] = 5; //Capa oculta con 5 neuronas
            neuronasporcapa[4] = TotalSalidas; //Capa de salida con 1 neurona
            Perceptron objP = new Perceptron(azar, alpha, TotalEntradas, TotalSalidas, TotalCapas, neuronasporcapa);

            Console.WriteLine("\n===================== Perceptrón multicapa =====================");
            Console.WriteLine("Factor de aprendizaje: " + alpha.ToString());
            Console.WriteLine("Total de capas: " + TotalCapas.ToString());
            Console.WriteLine("Neuronas capa 1 (entrada): " + neuronasporcapa[1].ToString());
            Console.WriteLine("Neuronas capa 2 (oculta): " + neuronasporcapa[2].ToString());
            Console.WriteLine("Neuronas capa 3 (oculta): " + neuronasporcapa[3].ToString());
            Console.WriteLine("Neuronas capa 4 (salida): " + neuronasporcapa[4].ToString());
            Console.WriteLine("Número de veces que se entrenará el perceptrón: " + numeroCiclos.ToString());

            // Calcula tiempo que toma hacer el entrenamiento
            Stopwatch temporizador = Stopwatch.StartNew();

            double TotalError = 0; //Acumula el error del perceptrón en cada prueba
            objP.IniciaPesosAzar(azar); //Inicializa los pesos al azar. Aprendizaje se reinicia.

            //Entrena al perceptrón multicapa
            for (int numciclos = 1; numciclos <= numeroCiclos; numciclos++) {
                for (int num = 1; num <= totalRegistros; num++) {
                    objP.Procesa(entrada[num]);
                    objP.Entrena(entrada[num], salidas[num]);
                }
            }

            //Técnica de mínimos cuadrados: salida esperada y la salida calculada por el perceptrón
            for (int num = 1; num <= totalRegistros; num++)
                TotalError += (salidas[num][1] - objP.Procesa(entrada[num])) * (salidas[num][1] - objP.Procesa(entrada[num]));

            TimeSpan tiempoTotal = temporizador.Elapsed;
            Console.WriteLine("Tiempo tomado por el entrenamiento: {0}", tiempoTotal.TotalSeconds);
            Console.WriteLine("Error (datos normalizados): " + TotalError.ToString());

            /*for (int mostrar = 1; mostrar <= totalRegistros; mostrar++) {
                double entradaUsuario = entrada[mostrar][1] * (maximoX - minimoX) + minimoX;
                double salidasUsuario = salidas[mostrar][1] * (maximoY - minimoY) + minimoY;
                double salida = objP.Procesa(entrada[mostrar]) * (maximoY - minimoY) + minimoY;
                Console.Write(entradaUsuario.ToString() + "; ");
                Console.Write(salidasUsuario.ToString() + "; ");
                Console.WriteLine(salida.ToString());
            }*/
            AproxRed[prueba] = TotalError;
            TiempoRed[prueba] = tiempoTotal.TotalSeconds;
        }

        //Lee los datos de un archivo plano
        private static int LeeDatosArchivo(string urlArchivo, double[][] entrada, double[][] salida) {
            var archivo = new System.IO.StreamReader(urlArchivo);
            archivo.ReadLine(); //La línea de simple serie
            archivo.ReadLine(); //La línea de título de cada columna de datos
            string leelinea;

            int limValores = 0;
            while ((leelinea = archivo.ReadLine()) != null) {
                limValores++;
                double valX = TraerNumeroCadena(leelinea, ';', 1);
                double valY = TraerNumeroCadena(leelinea, ';', 2);
                entrada[limValores] = new double[] { 0, valX };
                salida[limValores] = new double[] { 0, valY };
            }
            archivo.Close();
            return limValores;
        }

        //Dada una cadena con separaciones por delimitador, trae determinado ítem
        private static double TraerNumeroCadena(string linea, char delimitador, int numeroToken) {
            string numero = "";
            int numTrae = 0;
            foreach (char t in linea) {
                if (t != delimitador)
                    numero = numero + t;
                else {
                    numTrae = numTrae + 1;
                    if (numTrae == numeroToken) {
                        numero = numero.Trim();
                        if (numero == "") return 0;
                        return Convert.ToDouble(numero);
                    }
                    numero = "";
                }
            }
            numero = numero.Trim();
            if (numero == "") return 0;
            return Convert.ToDouble(numero);
        }
    }
}
