import java.applet.*;
import java.awt.*;
import java.util.*;

//Aqui nace la mutacion, el ser vivo recibe esta cadena
class cMutacion
{

	String sAcum; //La expresion que se genera
	Random mAleat;
	String sMutacion;
	long iSemilla; // Sirve para comparar la semilla
	
	
	cMutacion() //Constructor
	{
	    iSemilla = (long) 0;
	    vIniSemilla();
	}
	
	public void vIniSemilla()
	{
		while (System.currentTimeMillis()==iSemilla); //garantiza que la semilla sea diferente
		iSemilla=System.currentTimeMillis();
		mAleat= new Random(iSemilla);
	}


	//Esta rutina sirve para seleccionar entre una de las tres estrategias
	//y uno de los tres seres vivos.
	public int iMetodoSer(int iPosibAleat, int iPosibAdic, int iPosibMutac)
	{
		char cElem; //Elemento para armar la expresion
		mAleat= new Random();

		cElem = cRandomElem(iPosibAleat, iPosibAdic, 0, iPosibMutac);
       	if (cElem=='X') return 1; //Aleatorio
		if (cElem=='(') return 2; //Adiciona
		if (cElem>='0' && cElem<='9') return 3; //Muta
		return 1;
	}


	public void vMutarPartes(int iPosibX, int iPosibN)
	{
	/* Recibe una expresion y cambia una parte de ella:
	   Aleatoriamente determina la posici�n a cambiar siempre y cuando no sea parentesis
	   Ahora bien:
	   Si es operador(*,/-,+) la cambia por otro operador
	   Si es numero la cambia por otro o una X
	   Si es X la cambia por numero
	*/
		
		int iNumAleat, iPosExpr=-1;
		String sTemp;
		char cPosic='k', cElem='k';

        vIniSemilla();

		//Calcula alguna posicion
		while (iPosExpr==-1)
		{
            iPosExpr = Math.abs(mAleat.nextInt() % sAcum.length() );
			cPosic = sAcum.charAt(iPosExpr);			
			if (cPosic=='(' || cPosic==')')	iPosExpr=-1;
		}

		//Si es operador lo reemplaza por otro operador
		if (cPosic=='+' || cPosic=='-' || cPosic=='*' || cPosic=='/')
		{
			cElem = cRandomElem(0, 0, 100, 0);
			sTemp = sAcum.substring(0, iPosExpr) + cElem + sAcum.substring(iPosExpr+1);
			sAcum = sTemp;
			return;
		}
	

		//Si es numero lo reemplaza por otro numero o variable X
		if ( cPosic>='0' && cPosic<='9')
		{
			while ( (cElem<'0' || cElem>'9') && cElem!='X' )
				cElem = cRandomElem(iPosibX, 0, 0, iPosibN);

			sTemp = sAcum.substring(0, iPosExpr) + cElem + sAcum.substring(iPosExpr+1);
			sAcum = sTemp;
			return;
		}

		if (cPosic=='X')
		{
			while ( (cElem<'0' || cElem>'9') && cElem!='X' )
				cElem = cRandomElem(iPosibX, 0, 0, iPosibN);

			sTemp = sAcum.substring(0, iPosExpr) + cElem + sAcum.substring(iPosExpr+1);
			sAcum = sTemp;
			return;
		}
	}


	
	public void vAdicMutacion(int iPosibX, int iPosibP, int iPosibN)
	{
		char cElem = '$'; //Elemento para armar la expresion

		vIniSemilla();
		sMutacion="";

		//Trae el operador
		while (cElem!='+' && cElem!='-' && cElem!='/' && cElem!='*')
			cElem = cRandomElem(0, 0, 100, 0);

		sMutacion+=cElem;

		//Trae el operando
		while (cElem=='+' || cElem=='-' || cElem=='/' || cElem=='*' || cElem=='^' || cElem=='(' || cElem==')' || cElem=='.' )
			cElem = cRandomElem(iPosibX, iPosibP, 0, iPosibN);

		sMutacion+=cElem; //Completa la mutacion
		sAcum+=sMutacion; //Adiciona la mutacion
	}

	public void vCrearExpresion(int iLongExpr, int iPosibX, int iPosibP, int iPosibN)
	//iLongExpr es la maxima longitud que tendr� la expresi�n entre operadores y operandos
	{
		int iCont; //Contador de elementos
		int iContP=0; //Contador de Parentesis
		int iValida=0; //Validacion de la sintaxis de la expresion
		int iNacum=0; // Contador de acumulacion de numeros (evita que se acumulen numeros grandes. Por ejemplo: 46564566776453479)
		char cElem; //Elemento para armar la expresion
		char cLast; //El elemento predecesor
		int iTotalParent=0;
		
		vIniSemilla();
		sAcum= "(";
		for (iCont=0; iCont<=iLongExpr; iCont++)
		{
			//Es interesante esta parte: Como sucede con los seres vivos, se valida que la
			//proxima mutacion pueda existir. Aqui no se permite que una expresion se arme
			//como: XX++3.45-)X+/5, ya que dicha expresion tiene errores sintacticos.

			//Agrega operando: una X, un numero o un parentesis
			cLast = sAcum.charAt(sAcum.length()-1);
			cElem = cRandomElem(iPosibX, iPosibP, 0, iPosibN);
			if (cElem=='(') // Si es par�ntesis valida que no se pasa de 20
			{
				iTotalParent++;
				if (iTotalParent<20)
				{
					sAcum += cElem;
					iContP++;
				}
			}
			else
			{
				sAcum += cElem; //Un numero o X
				cElem = cRandomElem(iPosibX, iPosibP, 0, iPosibN);
				if (cElem=='(') //Esto es para colocar el parentesis )
					if (iContP>0)
					{
						sAcum+=')';
						iContP--;
					}
			}


			//Agrega luego un operador: +, -, *, /
			cLast = sAcum.charAt(sAcum.length()-1);
			if (cLast!='(')
			{
				cElem = cRandomElem(0, 0, 100, 0);
				sAcum += cElem;
			}
		}

		//Completa la expresion
		cLast = sAcum.charAt(sAcum.length()-1);
		if (cLast=='+' || cLast=='-' || cLast=='*' || cLast=='/' || cLast=='^' || cLast=='(')
			sAcum+='X';
		
		sAcum = sAcum.substring(1, sAcum.length());
		for (iCont=1; iCont<=iContP; iCont++) sAcum+=')';  //Equilibra parentesis
	}


	// Devuelve una X, numero, operador, parentesis
	char cRandomElem(int iPosibX, int iPosibP, int iPosibO, int iPosibN)
	{
		// Posibilidades de salir una variable, un numero, un operador, un parentesis
		// debe sumar 100
	//	vIniSemilla();
        int iNumAleat = Math.abs(mAleat.nextInt() % 100 )+ 1;

		if (iNumAleat<=iPosibX)
			return 'X';
		else if (iNumAleat<=iPosibX+iPosibN)
			{	
			//Que numero devuelve (quite el cero porque daba problemas)
			if (iNumAleat<=iPosibX+iPosibN*0.2)
				return '1';
			else if (iNumAleat<=iPosibX+iPosibN*0.3)
				return '2';
			else if (iNumAleat<=iPosibX+iPosibN*0.4)
				return '3';
			else if (iNumAleat<=iPosibX+iPosibN*0.5)
				return '4';
			else if (iNumAleat<=iPosibX+iPosibN*0.6)
				return '5';
			else if (iNumAleat<=iPosibX+iPosibN*0.7)
				return '6';
			else if (iNumAleat<=iPosibX+iPosibN*0.8)
				return '7';
		    else if (iNumAleat<=iPosibX+iPosibN*0.9)
				return '8';
			else if (iNumAleat<=iPosibX+iPosibN)
				return '9';
			}
		else if (iNumAleat<=iPosibX+iPosibN+iPosibO)
			{	
			//Que signo devuelve (quite el ^ porque daba problemas)
			if (iNumAleat<=iPosibX+iPosibN+iPosibO*0.2)
				return '+';
			else if (iNumAleat<=iPosibX+iPosibN+iPosibO*0.4)
				return '-';
			else if (iNumAleat<=iPosibX+iPosibN+iPosibO*0.6)
				return '*';
			else if (iNumAleat<=iPosibX+iPosibN+iPosibO*0.8)
				return '/';
			else if (iNumAleat<=iPosibX+iPosibN+iPosibO)
				return '-';
			}
		else if (iNumAleat<=iPosibX+iPosibN+iPosibO+iPosibP)
				return '(';
		return 'F';
	}
}
