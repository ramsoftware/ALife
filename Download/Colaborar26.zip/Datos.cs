﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GeneraEntradaSalida {
    internal class Datos {
        public double EntradaReal, SalidaReal;
        public List<int> Entradas;
        public List<int> Salidas;

        public Datos(double EntradaReal, double SalidaReal) {
            this.EntradaReal = EntradaReal;
            this.SalidaReal = SalidaReal;
        }

        public void VuelveArreglo(int[] Entra, int[] Sale) {
            Entradas = new List<int>();
            Salidas = new List<int>();

            for(int cont=0; cont<Entra.Length; cont++) {
                Entradas.Add(Entra[cont]);
            }

            for (int cont = 0; cont < Sale.Length; cont++) {
                Salidas.Add(Sale[cont]);
            }
        }

        public void Imprime() {
            Console.Write("E=" + String.Format("{0:0.00000000000000000}", EntradaReal) + "; ");
            for (int cont = 0; cont < Entradas.Count; cont++) {
                Console.Write(Entradas[cont].ToString() + " ");
            }

            Console.Write(" S=" + String.Format("{0:0.00000000000000000}", SalidaReal) + "; ");
            for (int cont = 0; cont < Salidas.Count; cont++) {
                Console.Write(Salidas[cont].ToString() + " ");
            }

            Console.WriteLine();
        }
    }
}
