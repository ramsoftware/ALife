﻿/* Tomar una entradas y salidas como 
 * X            Y
 * 0.8157       0.9172
 * 
 * En una sucesión de enteros
 * X                    Y
 * 8,1,5,7              9,1,7,2
 * 
 * Luego volverlos entre 0 y 1
 * X                        Y
 * 0.8, 0.1, 0.5, 0.7       0.9, 0.1, 0.7, 0.2
 * 
 * Y de esa manera hacer uso de un perceptrón multicapa para tratar las 4 entradas y las 4 salidas.
 * Una colaboración
 * 
 * */
using System;
using System.Collections.Generic;

namespace GeneraEntradaSalida {
    internal class Program {
        static void Main(string[] args) {

            //Lee los datos del archivo plano
            List<Datos> MisDatos = new List<Datos>();
            LeeDatosArchivo(args[0], MisDatos);

            //Luego los normaliza
            NormalizaDatos(MisDatos);

            //Posteriormente los convierte a entradas y salidas
            int DigitosHacer = 5;
            for (int cont = 0; cont < MisDatos.Count; cont++) {
                int[] DigitosEntra = ConvierteArreglo(MisDatos[cont].EntradaReal, DigitosHacer);
                int[] DigitosSale = ConvierteArreglo(MisDatos[cont].SalidaReal, DigitosHacer);
                MisDatos[cont].VuelveArreglo(DigitosEntra, DigitosSale);
            }

            //Elimina las entradas repetidas
            //Console.WriteLine("Antes: " + MisDatos.Count.ToString());
            for (int i=0; i<MisDatos.Count-1; i++) {
                for (int j=i+1; j< MisDatos.Count; j++) {
                    bool EsIgual = true;
                    for(int k=0; k < MisDatos[0].Entradas.Count; k++)
                        if (MisDatos[i].Entradas[k] != MisDatos[j].Entradas[k])
                            EsIgual = false;
                    if (EsIgual) { MisDatos.RemoveAt(j); j--; }
                }
            }
            //Console.WriteLine("Después: " + MisDatos.Count.ToString());

            int numEntradas = DigitosHacer; //Número de entradas
            int capa0 = 5; //Total neuronas en la capa 0
            int capa1 = 5; //Total neuronas en la capa 1
            int capa2 = DigitosHacer; //Total neuronas en la capa 2
            Perceptron perceptron = new Perceptron(numEntradas, capa0, capa1, capa2);

            //Estas serán las entradas externas al perceptrón
            List<double> entradas = new List<double>();
            for (int cont = 0; cont < DigitosHacer; cont++) entradas.Add(0);

            //Estas serán las salidas esperadas externas al perceptrón
            List<double> salidasEsperadas = new List<double>();
            for (int cont = 0; cont < DigitosHacer; cont++) salidasEsperadas.Add(0);

            //Ciclo que entrena la red neuronal
            int totalCiclos = 100000; //Ciclos de entrenamiento
            for (int ciclo = 1; ciclo <= totalCiclos; ciclo++) {

                //Por cada ciclo, se entrena el perceptrón con todos los valores
                for (int conjunto = 0; conjunto < MisDatos.Count; conjunto++) {

                    //Entradas y salidas esperadas
                    int Divide = 10;
                    for (int cont = 0; cont < DigitosHacer; cont++) {
                        entradas[cont] = (double) MisDatos[conjunto].Entradas[cont] / Divide;
                        salidasEsperadas[cont] = (double) MisDatos[conjunto].Salidas[cont] / Divide;
                        Divide *= 10;
                    }

                    //Primero calcula la salida del perceptrón con esas entradas
                    perceptron.calculaSalida(entradas);

                    //Luego entrena el perceptrón para ajustar los pesos y umbrales
                    perceptron.Entrena(entradas, salidasEsperadas);
                }
            }

            Console.WriteLine("Entrada normalizada | Salida esperada normalizada | Salida perceptrón normalizada");
            for (int conjunto = 0; conjunto < MisDatos.Count; conjunto++) {

                //Entradas y salidas esperadas
                int Divide = 10;
                for (int cont = 0; cont < DigitosHacer; cont++) {
                    entradas[cont] = (double)MisDatos[conjunto].Entradas[cont] / Divide;
                    salidasEsperadas[cont] = (double)MisDatos[conjunto].Salidas[cont] / Divide;
                    Divide *= 10;
                }

                //Calcula la salida del perceptrón con esas entradas
                perceptron.calculaSalida(entradas);

                //Muestra la salida
                perceptron.SalidaPerceptron(entradas, salidasEsperadas);
            }

            Console.WriteLine("Finaliza");

            //Console.ReadKey();
        }

        //Convierte el número real a una serie de digitos
        public static int[] ConvierteArreglo(double Valor, int Maximo) {
            string Cadena = Valor.ToString();
            int[] Digitos = new int[Maximo];
            for (int i = 2; i < Cadena.Length && i < Maximo + 2; i++) Digitos[i - 2] = int.Parse(Cadena[i].ToString());
            return Digitos;
        }

        //Normaliza
        public static void NormalizaDatos(List<Datos> MisDatos) {
            double MinX, MinY, MaxX, MaxY;
            MinX = MisDatos[0].EntradaReal;
            MaxX = MinX;
            MinY = MisDatos[0].SalidaReal;
            MaxY = MinY;
            for (int cont = 0; cont < MisDatos.Count; cont++) {
                if (MisDatos[cont].EntradaReal < MinX) MinX = MisDatos[cont].EntradaReal;
                if (MisDatos[cont].EntradaReal > MaxX) MaxX = MisDatos[cont].EntradaReal;
                if (MisDatos[cont].SalidaReal < MinY) MinY = MisDatos[cont].SalidaReal;
                if (MisDatos[cont].SalidaReal > MaxY) MaxY = MisDatos[cont].SalidaReal;
            }

            /* Cómo se trabaja con los decimales, hay dos valores que dan problemas, el valor 
             * mínimo que es 0 y el valor máximo que es 1. En ambos, sus decimales son 00000
             * así que se evitan estos valores bajando en un 0.1 el mínimo y subiendo un 0.1 el máximo */
            MinY -= 0.1;
            MaxY += 0.1;

            for (int cont = 0; cont < MisDatos.Count; cont++) {
                MisDatos[cont].EntradaReal = (MisDatos[cont].EntradaReal - MinX) / (MaxX - MinX);
                MisDatos[cont].SalidaReal = (MisDatos[cont].SalidaReal - MinY) / (MaxY - MinY);
            }
        }


        //Lee los datos del archivo plano
        public static void LeeDatosArchivo(string urlArchivo, List<Datos> MisDatos) {
            var archivo = new System.IO.StreamReader(urlArchivo);
            string leelinea;

            while ((leelinea = archivo.ReadLine()) != null) {
                double valX = TraerNumeroCadena(leelinea, ';', 1);
                double valY = TraerNumeroCadena(leelinea, ';', 2);
                MisDatos.Add(new Datos(valX, valY));
            }
            archivo.Close();
        }

        //Dada una cadena con separaciones por delimitador, trae determinado ítem
        private static double TraerNumeroCadena(string linea, char delimitador, int numeroToken) {
            string numero = "";
            int numTrae = 0;
            foreach (char t in linea) {
                if (t != delimitador)
                    numero += t;
                else {
                    numTrae += 1;
                    if (numTrae == numeroToken) {
                        numero = numero.Trim();
                        if (numero == "") return 0;
                        return Convert.ToDouble(numero);
                    }
                    numero = "";
                }
            }
            numero = numero.Trim();
            if (numero == "") return 0;
            return Convert.ToDouble(numero);
        }
    }
}

