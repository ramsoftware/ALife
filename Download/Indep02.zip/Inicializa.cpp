/*
Autor:		Rafael Alberto Moreno Parra
URL:		http://www.geocities.com/krousky
Clase:		Inicializa.
Lenguaje:	C++

Prop�sito:
Inicializa las variables para la simulaci�n

*/

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>
#include "Inicializa.h"
#include "StringUtil.h"

void Inicializa::vPantallaIni()
{
	printf("Motor de Vida Artificial\n\n");
	printf("Juego 02: �En que consiste el juego? Parte 2\n\n");
	printf("Autor: Rafael Alberto Moreno Parra\n");
	printf("Fecha: 06 de Febrero  de 2002\n");
	printf("E-mail: enginelife@hotmail.com\n");
	printf("http://www.geocities.com/krousky\n\n");
};

//Abre y estudia el archivo de inicializaci�n
int Inicializa::vLeeArchivoIni()
{
	FILE *fpInicio;
	char sFrase[600], sVariable[200], sValor[200];
    unsigned int iCar;
	StringUtil StrUtil;

	//Inicializa la estructura
	stDatVA.iPosibIf = 0;
	stDatVA.iPosibSet = 0;
	stDatVA.iPosibFun = 0;
	stDatVA.iPosIg = 0;
	stDatVA.iPosMay = 0;
	stDatVA.iPosMen = 0;
	stDatVA.iPosDif = 0;
	stDatVA.iLongExpr = 0;
	stDatVA.iPosibX = 0;
	stDatVA.iPosibY = 0;
	stDatVA.iPosibP = 0;
	stDatVA.iPosibN = 0;
	stDatVA.iNumCiclos= 0;
	stDatVA.iNumInstMax = 0;
	stDatVA.iAnchoTabl = 0;
	stDatVA.iLargoTabl = 0;
	stDatVA.iTotalOrg = 0;
	strcpy(stDatVA.sArchResult, "Juego01.txt");
	
	
	fpInicio = fopen("Juego02.ini", "r+t");
	if (fpInicio == NULL)
    {
		printf("Error al tratar de abrir archivo de inicializaci�n Juego02.ini\n");
		return -1;
    }
	while(!feof(fpInicio))
	{
		fgets(sFrase, 298, fpInicio);
		StrUtil.vQuitaEspacios(sFrase);

		//Extrae variables y valores
		for (iCar=0; iCar<strlen(sFrase) && sFrase[iCar]!='='; iCar++);
		StrUtil.vLeft(sVariable, sFrase, iCar);
		StrUtil.vMid(sValor, sFrase, iCar+2,strlen(sFrase)-1);

		//Clasifica variables
		if(strcmp(sVariable, "iPosibIf")==0) stDatVA.iPosibIf = atoi(sValor);
		if(strcmp(sVariable, "iPosibSet")==0) stDatVA.iPosibSet = atoi(sValor);
		if(strcmp(sVariable, "iPosibFun")==0) stDatVA.iPosibFun = atoi(sValor);
		if(strcmp(sVariable, "iPosIg")==0) stDatVA.iPosIg = atoi(sValor);
		if(strcmp(sVariable, "iPosMay")==0) stDatVA.iPosMay = atoi(sValor);
		if(strcmp(sVariable, "iPosMen")==0) stDatVA.iPosMen = atoi(sValor);
		if(strcmp(sVariable, "iPosDif")==0) stDatVA.iPosDif = atoi(sValor);
		if(strcmp(sVariable, "iLongExpr")==0) stDatVA.iLongExpr = atoi(sValor);
		if(strcmp(sVariable, "iPosibX")==0) stDatVA.iPosibX = atoi(sValor);
		if(strcmp(sVariable, "iPosibY")==0) stDatVA.iPosibY = atoi(sValor);
		if(strcmp(sVariable, "iPosibP")==0) stDatVA.iPosibP = atoi(sValor);
		if(strcmp(sVariable, "iPosibN")==0) stDatVA.iPosibN = atoi(sValor);
		if(strcmp(sVariable, "iNumCiclos")==0) stDatVA.iNumCiclos= atoi(sValor);
		if(strcmp(sVariable, "iNumInstMax")==0) stDatVA.iNumInstMax = atoi(sValor);
		
		if(strcmp(sVariable, "iAnchoTabl")==0) stDatVA.iAnchoTabl = atoi(sValor);
		if(strcmp(sVariable, "iLargoTabl")==0) stDatVA.iLargoTabl = atoi(sValor);
		if(strcmp(sVariable, "iTotalOrg")==0) stDatVA.iTotalOrg = atoi(sValor);

		if(strcmp(sVariable, "sArchResult")==0)
		{
			if (strlen(sValor) > 15 || strlen(sValor) < 3)
			{
				printf("Mal Nombre de archivo de resultado. sArchResult M�nimo: 3 M�ximo: 15 caracteres\n");
				return -1;
			}
			strcpy(stDatVA.sArchResult, sValor);
		}
	}
	
	//Valida que los valores del archivo de inicializaci�n sean correctos
	if (stDatVA.iPosibIf + stDatVA.iPosibSet + stDatVA.iPosibFun != 100)
	{
		printf("Mal los porcentajes de IF, ASIGNACION, FUNCION (iPosibIf, iPosibSet, iPosibFun)\n");
		return -1;
	}

	if (stDatVA.iPosibN + stDatVA.iPosibP + stDatVA.iPosibX + stDatVA.iPosibY != 100)
	{
		printf("Mal los porcentajes para construcci�n de expresiones (iPosibX, iPosibY, iPosibN, iPosibP)\n");
		return -1;
	}

	if (stDatVA.iLongExpr > 45 || stDatVA.iLongExpr < 4)
	{
		printf("Mal longitud de la expresion (iLongExpr min 4, max 45)\n");
		return -1;
	}

	if (stDatVA.iPosMay + stDatVA.iPosMen + stDatVA.iPosDif + stDatVA.iPosIg != 100)
	{
		printf("Mal los porcentajes para comparacion (iPosMay, iPosMen, iPosDif, iPosIg)\n");
		return -1;
	}

	if (stDatVA.iNumInstMax > 48 || stDatVA.iNumInstMax < 8)
	{
		printf("Mal n�mero de instrucciones (iNumInstMax min 8 max 48)\n");
		return -1;
	}

	if (stDatVA.iAnchoTabl > 78 || stDatVA.iLargoTabl > 78 || stDatVA.iAnchoTabl < 4 || stDatVA.iLargoTabl < 4 )
	{
		printf("Excedi� tama�o de tablero. M�nimo: 4 x 4 M�ximo: 78 x 78\n");
		return -1;
	}

	fclose(fpInicio);
	return 0;
};

//Hace el encabezado del archivo de resultados
void Inicializa::vArchResult()
{
    //Leidos de una vez los par�metros de simulaci�n, comienza a simular
	FILE *fpSimular;
    unlink(stDatVA.sArchResult);
	fpSimular = fopen(stDatVA.sArchResult, "a+t");
	fprintf(fpSimular,"Juego01. �En que consiste el juego?\n");

	fprintf(fpSimular,"\nPosibilidades:\n");
	fprintf(fpSimular,"1. Tipo de Instrucciones. If Condicional: %d, Asignacion: %d\n", stDatVA.iPosibIf, stDatVA.iPosibSet);
	fprintf(fpSimular,"2. En Instrucciones de If Condicional, el operador de comparacion es:  '==':%d, '>':%d, '<':%d, '!=':%d\n", stDatVA.iPosIg, stDatVA.iPosMay, stDatVA.iPosMen, stDatVA.iPosDif);
	fprintf(fpSimular,"3. Longitud de la expresi�n (n�mero de operadores): %d\n\n", stDatVA.iLongExpr);
	fprintf(fpSimular,"4. Construcci�n de las expresiones, posibilidad de salir X=%d, Y=%d, Parentesis=%d, N�meros=%d\n", stDatVA.iPosibX, stDatVA.iPosibY, stDatVA.iPosibP, stDatVA.iPosibN);
	fprintf(fpSimular,"\n");
	fprintf(fpSimular,"N�mero m�ximo de ciclos CPU: %d\n", stDatVA.iNumCiclos);
	fprintf(fpSimular,"N�mero de Instrucciones m�ximas para algoritmo: %d\n", stDatVA.iNumInstMax);
	fprintf(fpSimular,"Numero Organismos: %d\n", stDatVA.iTotalOrg);
	fprintf(fpSimular,"\n\t\tTablero de 0..%d x 0..%d\n\n", stDatVA.iAnchoTabl, stDatVA.iLargoTabl);
	
	time_t ltime;
    time( &ltime );
    fprintf(fpSimular,"Simulaci�n inicia en: %s\n", ctime( &ltime ) );
	fclose(fpSimular);
};

void Inicializa::vGrabaOrganismos(unsigned int iAciertos, char *sMensaje)
{
	FILE *fpSimular;

	fpSimular = fopen(stDatVA.sArchResult, "a+t");
	fprintf(fpSimular,"Casillas Llenas: [%d]\n", iAciertos);
	fprintf(fpSimular,"%s\n", sMensaje);
	fclose(fpSimular);
};

void Inicializa::vFinalSimulacion()
{
	FILE *fpSimular;
	time_t ltime;

	fpSimular = fopen(stDatVA.sArchResult, "a+t");
	time( &ltime );
	fprintf(fpSimular,"Finaliza en: %s\n", ctime( &ltime ) );
	fclose(fpSimular);
};