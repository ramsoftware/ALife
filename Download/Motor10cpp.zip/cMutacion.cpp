/*
* @(#)ArtificialLifeEngine.java
* 
* Es un conjunto de subrutinas que simulando la Evoluci�n de las Especies,
* puedan crear programas (codigo fuente) que se adapten a un ambiente en particular.
* Todo software tiene entradas y salidas. Las entradas son procesadas y se emite un resultado
* que son las salidas. Este proceso es implementado por un Dise�ador/Programador.
* Ahora bien, si usamos un sistema que usa principios evolutivos, este proceso puede nacer
* por si solo, esto tiene sus ventajas:
* 1. No se requiere de personal humano (programadores) para crear el proceso.
* 2. Puede disminuirse o anularse la posiblidad de errores en el proceso.
* 3. Ante nuevos requerimientos (nuevas entradas o formatos de salida) el proceso se adaptara.
* 4. Capaz de encontrar o acercarse a soluciones de problemas muy complejos.
* 
* El obst�culo:
*  Conseguir un proceso que ofrezca salidas esperadas a unas entradas, usando principios evolutivos
*  puede tardar un tiempo considerablemente alto. Con los nuevos procesadores a mayores velocidades y
*  un buen algoritmo evolutivo, el tiempo puede ser disminuido, de tal manera que podria entrar a
*  competir con programadores humanos.
*/

#include <afx.h>
#include "cMutacion.h"

/* Se llena de manera previa a las simulaciones, sirve para
   la construccion r�pida de las expresiones */
int cMutacion::vIniLista(int iProbN, int iProbX, int iProbP)
{
   unsigned int iCont;
   char cCambiaNum='1', cCambiaPar='(';

   if ( (iProbN+iProbX+iProbP) != 100 ) return -1; //Es un error

   vLlenaconNulos(sOperNumPar,101);
   for(iCont=0; iCont<100;iCont++)
   {
       if (iCont<iProbX)
          sOperNumPar[iCont]='x';
       else if(iCont>=iProbX && iCont<(iProbX+iProbN))
       {
          sOperNumPar[iCont]=cCambiaNum;
          cCambiaNum++;
          if (cCambiaNum>'9') cCambiaNum='1';
       }   
       else //Los parentesis
       {
          switch(cCambiaPar)
          {
             case '(': sOperNumPar[iCont]=cCambiaPar;
                       cCambiaPar=')';
                       break;
             case ')': sOperNumPar[iCont]=cCambiaPar;
                       cCambiaPar='(';
                       break;
          }
       }
   }
   //printf("Listado: [%s]\n", sOperNumPar);
   return 1; //Todo OK
}

void cMutacion::vCrearExpresion(int iLongExpr, int iPosibX, int iPosibP, int iPosibN)
	//iLongExpr es la maxima longitud que tendr� la expresi�n entre operadores y operandos
{
		unsigned int iCont=0; //Contador de elementos
		int iContP=0; //Contador de Parentesis
		char cElem='('; //Elemento para armar la expresion
		int iNumAleat;

		vLlenaconNulos(sExpresion,400);
		while (iCont<=iLongExpr)
		{
			//Trae un Numero, X o Parentesis
            do
            {
				iNumAleat = abs(rand() % 100 );
				cElem = sOperNumPar[iNumAleat];

			    if (cElem=='(' || cElem==')') // Si es par�ntesis valida que no se pasa de 20
			    {
					if (iContP<20)
					{
						sExpresion[iCont++]='(';
						iContP++;
					}
					else
					{
						iNumAleat = abs(rand() % (iPosibX+iPosibN));
						cElem = sOperNumPar[iNumAleat];
						sExpresion[iCont]=cElem; //Un numero o X
					}
			    }
                else
					sExpresion[iCont]=cElem; //Un numero o X
            }while(cElem=='(' || cElem==')');

		    //Chequea si cierra los parentesis
            iNumAleat = abs(rand() % 100 );
            cElem = sOperNumPar[iNumAleat];
            if (cElem==')')
            {
				if (iContP>0)
                {
					iCont++;
                    iContP--;
                    sExpresion[iCont]=cElem;
                }
            }
                                
                            
			//Agrega luego un operador: +, -, *, /
            iCont++;
		    iNumAleat = abs(rand() % 4) + 1;
            switch(iNumAleat)
            {
				case 1: sExpresion[iCont]='+'; break;
                case 2: sExpresion[iCont]='-'; break;
                case 3: sExpresion[iCont]='*'; break;
                case 4: sExpresion[iCont]='/'; break;
			}
			iCont++;
		}

		//Completa la expresion
	    iNumAleat = abs(rand() % (iPosibX+iPosibN));
		sExpresion[iCont++]= sOperNumPar[iNumAleat];
	    for (int iParent=1; iParent<=iContP; iParent++) sExpresion[iCont++]=')';  //Equilibra parentesis
};

void cMutacion::vLlenaconNulos(char *sbCadena, int iLong)
{
   unsigned int iCont;

   for(iCont=0; iCont<iLong; iCont++)
      sbCadena[iCont]='\0';
};