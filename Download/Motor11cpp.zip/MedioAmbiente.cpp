/*
* @(#)ArtificialLifeEngine.java
* 
* Es un conjunto de subrutinas que simulando la Evoluci�n de las Especies,
* puedan crear programas (codigo fuente) que se adapten a un ambiente en particular.
* Todo software tiene entradas y salidas. Las entradas son procesadas y se emite un resultado
* que son las salidas. Este proceso es implementado por un Dise�ador/Programador.
* Ahora bien, si usamos un sistema que usa principios evolutivos, este proceso puede nacer
* por si solo, esto tiene sus ventajas:
* 1. No se requiere de personal humano (programadores) para crear el proceso.
* 2. Puede disminuirse o anularse la posiblidad de errores en el proceso.
* 3. Ante nuevos requerimientos (nuevas entradas o formatos de salida) el proceso se adaptara.
* 4. Capaz de encontrar o acercarse a soluciones de problemas muy complejos.
* 
* El obst�culo:
*  Conseguir un proceso que ofrezca salidas esperadas a unas entradas, usando principios evolutivos
*  puede tardar un tiempo considerablemente alto. Con los nuevos procesadores a mayores velocidades y
*  un buen algoritmo evolutivo, el tiempo puede ser disminuido, de tal manera que podria entrar a
*  competir con programadores humanos.
*/
#include <string.h>
#include <stdlib.h>
#include "MedioAmbiente.h"

void MedioAmbiente::vDeshaceIO(char *m_sSerieNum, int iEntraSale)
{
		char sAcum[30];
		unsigned int iProgreso=0, iCont;
		
		switch(iEntraSale)
		{
		    case 1: m_iContEntra=0; break;
		    case 2: m_iContSale=0; break;
		}

		// Ahora deshace la expresion en un arreglo de enteros
		for(iCont=0; iCont<=strlen(m_sSerieNum); iCont++)
		{
			if(m_sSerieNum[iCont] != ',')
			{
				sAcum[iProgreso++] = m_sSerieNum[iCont];
				sAcum[iProgreso]='\0';
			}
			else
				if(strlen(sAcum)>0)
				{
				    switch(iEntraSale)
				    {
				        case 1:
					        m_iEntradas[m_iContEntra++]=atoi(sAcum);
					        break;
					    case 2: 
					        m_iSalidas[m_iContSale++]=atoi(sAcum);
					        break;
					}
					iProgreso=0;
				}
		} // Fin For
}; // Fin DeshaceIO
