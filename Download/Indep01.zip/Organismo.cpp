/*
Autor:		Rafael Alberto Moreno Parra
URL:		http://www.geocities.com/krousky
Clase:		Organismo
Lenguaje:	C++
Fecha:		01 de Enero de 2002

Prop�sito:


M�todos:
IniciaSemillaT: Inicializa la semilla dependiendo del tiempo
IniciaSemillaR: Inicializa la semilla aleatoriamente
sDisplayADN: Despliega el organismo como si fuera c�digo Java
vCreaADN: Crea el organismo, llamando la funci�n que hace sus genes
vHaceGen: Crea una linea de codigo fuente (la llam� Gen). El formato es:
          label, [, IF/SET, Variable, =/>/</!, (, expresion, ), Goto, Label, ]
          para mayor velocidad, se ubica en una clase el Gen
vEvaluaPrevio: Optimiza la velocidad de evaluaci�n del organismo en un
               ambiente.
fEvalOrganismo: Evalua el organismo en el ambiente
vMutaGen: Mutaci�n suave de un gen del organismo

*/

#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <float.h>
#include "Organismo.h"

//Constructor
Organismo::Organismo()
{
	time(&ltime1);
}


//Inicializa la semilla dependiendo del tiempo
void Organismo::IniciaSemillaT()
{
	time_t ltime2;
	do
	{
		time(&ltime2);
	}while(ltime2==ltime1);
	srand( ltime2 );
	ltime1 = ltime2;
}

//Inicializa la semilla aleatoriamente
void Organismo::IniciaSemillaR()
{
	srand(rand());
};

//Despliega el organismo como si fuera c�digo Java
void Organismo::sDisplayADN(char *sbADN)
{
	char sExprTemp1[250], sExprTemp2[250]="";
	char cEnter[4];
	strcpy(sbADN,"float fSerVivo()");
    cEnter[0]= '\n';
    cEnter[1]= '\0';

	strcat(sbADN,cEnter);
	strcat(sbADN, "{");
    strcat(sbADN,cEnter);

    strcat(sbADN,"float X=0, W=0, Y=0, Z=0;");
    strcat(sbADN,cEnter);
    strcat(sbADN,cEnter);

	for (unsigned int iCont=1; iCont<=m_iMaxGenOrg; iCont++)
    {
		sprintf(sExprTemp1, "%d", iCont);
		strcat(sbADN, sExprTemp1);
		strcat(sbADN, ": ");

        //Reemplaza la expresion por la variable activa
		int iLongExpr = strlen(m_oGen[iCont].sbExpresion);
		sExprTemp2[0]='\0';
		sExprTemp1[1]='\0';
        for (int iChar=0; iChar < iLongExpr; iChar++)
        {
			char cCharAt = m_oGen[iCont].sbExpresion[iChar];
            if (cCharAt=='x')
				sExprTemp1[0]=m_oGen[iCont].cVarActiva1;
            else if (cCharAt=='y')
				sExprTemp1[0]=m_oGen[iCont].cVarActiva2;
			else
				sExprTemp1[0]=cCharAt;
   			strcat(sExprTemp2, sExprTemp1);
        }
                    
        //Organiza los if y asignaciones
        if (m_oGen[iCont].cTipInst == 'I')
        {
			sExprTemp1[0]=m_oGen[iCont].cVariable;
			strcat(sbADN, "if( ");  //if(
			strcat(sbADN, sExprTemp1);  //if ( Z
			strcat(sbADN, " ");
			sExprTemp1[0]=m_oGen[iCont].cOperacion; // if ( Z >
			strcat(sbADN, sExprTemp1);
			strcat(sbADN, " ");
			strcat(sbADN, sExprTemp2); // if (Z > 4*X*X
			strcat(sbADN, " ) goto ");
			sprintf(sExprTemp1, "%d", m_oGen[iCont].iGotoLabel);
			strcat(sbADN, sExprTemp1); // if (Z > 4*X*X ) goto 4
			strcat(sbADN, ";");
		}
        else if (m_oGen[iCont].cTipInst == 'S')
		{
			sExprTemp1[0]=m_oGen[iCont].cVariable;
			strcat(sbADN, sExprTemp1);
			strcat(sbADN, " = ");
			strcat(sbADN, sExprTemp2);
			strcat(sbADN, ";");
		}
		else
		{
			sprintf(sExprTemp1, "F:%d;", m_oGen[iCont].iCodFunc);
			strcat(sbADN, sExprTemp1);
		}
        strcat(sbADN, cEnter);
    }    
    //Finaliza la expresion
	strcat(sbADN, "return Y;");
	strcat(sbADN, cEnter);
	strcat(sbADN, "}");
	strcat(sbADN, cEnter);
};

// Crea el organismo, llamando la funci�n que hace sus genes
void Organismo::vCreaADN (bool bGenRandom, unsigned int iMaxGenes,
                   unsigned int iPosibIf, unsigned int iPosibSet,
                   unsigned int iPosW,  unsigned int iPosX, unsigned int iPosY, unsigned int iPosZ,
                   unsigned int iPosIg, unsigned int iPosMay, unsigned int iPosMen, unsigned int iPosDif,
                   unsigned int iLongExpr, unsigned int iPosibX, unsigned int iPosibY, unsigned int iPosibP, unsigned int iPosibN)
{
    unsigned int iCont;

	if(bGenRandom)
		m_iMaxGenOrg = abs(rand() % iMaxGenes ) + 1; //Crea organismos entre 1 y iMaxGenes instrucciones
	else
        m_iMaxGenOrg = iMaxGenes;        
     
    for (iCont=1; iCont<=m_iMaxGenOrg; iCont++)
		vHaceGen (iCont, m_iMaxGenOrg,
                  iPosibIf, iPosibSet,
                  iPosW,  iPosX, iPosY, iPosZ,
                  iPosIg, iPosMay, iPosMen, iPosDif,
                  iLongExpr, iPosibX, iPosibY, iPosibP, iPosibN);
};

/* Crea una linea de codigo fuente (la llam� Gen). El formato es:
   label, [, IF/SET, Variable, =/>/</!, (, expresion, ), Goto, Label, ]
   para mayor velocidad, se ubica en una clase el Gen */
void Organismo::vHaceGen(unsigned int iLabel, unsigned int iMaxGenes,
                   unsigned int iPosibIf, unsigned int iPosibSet,
                   unsigned int iPosW,  unsigned int iPosX, unsigned int iPosY, unsigned int iPosZ,
                   unsigned int iPosIg, unsigned int iPosMay, unsigned int iPosMen, unsigned int iPosDif,
                   unsigned int iLongExpr, unsigned int iPosibX, unsigned int iPosibY, unsigned int iPosibP, unsigned int iPosibN)
{
	unsigned int iAleatorio;

    //Por defecto, nunca se ha ejecutado esta instruccion
    m_oGen[iLabel].bEjecuta = false;
       
  
    //Decide que variable usar W, X, Y, Z (para ser asignada o comparada)
   	iAleatorio = abs(rand() % 100) + 1;
	if (iAleatorio<=iPosW)
		m_oGen[iLabel].cVariable = 'W';
	else if (iAleatorio<=iPosW+iPosX)
		m_oGen[iLabel].cVariable = 'X';
    else if (iAleatorio<=iPosW+iPosX+iPosY)
		m_oGen[iLabel].cVariable = 'Y';
	else
		m_oGen[iLabel].cVariable = 'Z';
        
    //Decide si usa =, >, <, ! Estos son tenidos en cuenta si es un IF condicional
   	iAleatorio = abs(rand() % 100) + 1;
	if (iAleatorio<=iPosIg)
		m_oGen[iLabel].cOperacion = '=';
	else if (iAleatorio<=iPosIg+iPosMay)
		m_oGen[iLabel].cOperacion = '>';
    else if (iAleatorio<=iPosIg+iPosMay+iPosMen)
		m_oGen[iLabel].cOperacion = '<';
	else
		m_oGen[iLabel].cOperacion = '!';

    //Trae la expresion (SET o IF) y los par�metros (FUNCION)
    objGenExpr.vCrearExpresion(iLongExpr, iPosibX, iPosibY, iPosibP, iPosibN);
    strcpy(m_oGen[iLabel].sbExpresion,objGenExpr.sExpresion);

    //Como la trae para X aqui la cambio a W, X, Y, Z
   	iAleatorio = abs(rand() % 100) + 1;
	if (iAleatorio<=iPosW)
		m_oGen[iLabel].cVarActiva1 = 'W';
	else if (iAleatorio<=iPosW+iPosX)
		m_oGen[iLabel].cVarActiva1 = 'X';
    else if (iAleatorio<=iPosW+iPosX+iPosY)
		m_oGen[iLabel].cVarActiva1 = 'Y';
	else
		m_oGen[iLabel].cVarActiva1 = 'Z';

    //Como la trae para Y aqui la cambio a W, X, Y, Z
   	iAleatorio = abs(rand() % 100) + 1;
	if (iAleatorio<=iPosW)
		m_oGen[iLabel].cVarActiva2 = 'W';
	else if (iAleatorio<=iPosW+iPosX)
		m_oGen[iLabel].cVarActiva2 = 'X';
    else if (iAleatorio<=iPosW+iPosX+iPosY)
		m_oGen[iLabel].cVarActiva2 = 'Y';
	else
		m_oGen[iLabel].cVarActiva2 = 'Z';

    //Decide hacia que label va (entre 1 y MaxGenes) o si es el FIN, el resultado siempre sera Y
    unsigned int iNumCiclo;
	do
	{
		iNumCiclo = abs(rand() % (iMaxGenes+1));
	} while (iNumCiclo==iLabel); //Evita el goto hacia la misma instruccion
    m_oGen[iLabel].iGotoLabel = iNumCiclo; //Retorna 0 para FINalizar

	//Decide si es un IF, un SET o una FUNCION
	iAleatorio = abs(rand() % 100) + 1;
	if (iAleatorio<=iPosibIf)
		m_oGen[iLabel].cTipInst = 'I'; //If
	else if (iAleatorio<=iPosibIf+iPosibSet)
		m_oGen[iLabel].cTipInst = 'S'; //Set o Asignacion
	else
	{
		m_oGen[iLabel].cTipInst = 'F'; //Funcion	
		m_oGen[iLabel].iCodFunc = abs(rand() % NUMFUNCIONES) + 1;
	}

	
};

    
/* Evalua el organismo en el ambiente
Retorna:
-1 Si hubo un error
0 Finalizo la ejecucion
1 Si ejecuta alguna funcion
*/
   
int Organismo::fEvalOrganismo (unsigned int *iOrgGenInst,
							   unsigned int *iFuncion,
							   float *fParam01,
							   float *fParam02,
							   float *fParam03,
							   float *fParam04)
{                   
	/* Interpretador de los algoritmos gen�ticos */
    float fValX, fValW, fValY, fValZ, fValor1=0, fValor2=0, fResultado=0, fCompara=0;
    unsigned int iGenOrg; //# de Instrucci�n de inicio
    unsigned int iNumCiclos=0; //Contador de Ciclos
    
	
	//OJO!: Aunque burda (por ahora) esta es la manera en que el
	//organismo interactua con el ambiente (juego)
	iGenOrg = *iOrgGenInst; //Continua por donde estaba
	fValX = *fParam01; // Resultado = Funcion (X, Y);
	fValY = *fParam02;
	fValW = *fParam03;
	fValZ = *fParam04;
	//Fin de la interaccion

    while (iGenOrg!=0 && iGenOrg<=m_iMaxGenOrg)
    {
		//Coloca a TRUE la instruci�n porque se ejecuta
        m_oGen[iGenOrg].bEjecuta = true;
            
        //Aumenta el # de Ciclos
        iNumCiclos++;

		//M�ximo n�mero de ciclos que se evaluar�n del organismo, si el
        //organismo supera este n�mero de ciclos sin dar con un resultado
        //es desechado.
		if (iNumCiclos > m_iMaxiCiclos)
			return -1; //Error ejecutando
            
        //Que variable esta jugando dentro de la expresion
        switch (m_oGen[iGenOrg].cVarActiva1)
        {
		   case 'W': fValor1 = fValW; break;
           case 'X': fValor1 = fValX; break;
           case 'Y': fValor1 = fValY; break;
           case 'Z': fValor1 = fValZ; break;
        }
            
        switch (m_oGen[iGenOrg].cVarActiva2)
        {
		   case 'W': fValor2 = fValW; break;
           case 'X': fValor2 = fValX; break;
           case 'Y': fValor2 = fValY; break;
           case 'Z': fValor2 = fValZ; break;
        }

        //Evalua la expresion
		fResultado = m_eEvalua.dCapturaEcuacion(m_oGen[iGenOrg].sbExpresion, fValor1, fValor2);
		if (m_eEvalua.ERRORMATEMATICO==1 ||
			fResultado >= 9999999 || fResultado <= -9999999 )
			return -1; //Error ejecutando

		
		//Es una funcion
		if (m_oGen[iGenOrg].cTipInst == 'F')
		{
			//Estas son las respuestas del organismo a las funciones
			*fParam01 =	fValX;
			*fParam02 = fValY;
			*fParam03 = fValW;
			*fParam04 = fValZ;
			*iFuncion = m_oGen[iGenOrg].iCodFunc;
			*iOrgGenInst = iGenOrg+1;
			return 1; //Ejecuta una funcion
		}
		else if (m_oGen[iGenOrg].cTipInst == 'S') //Si es un SET asigna el valor a la variable del Gen
		{
		    switch(m_oGen[iGenOrg].cVariable)
		    {
				case 'W': fValW = fResultado; break;
                case 'X': fValX = fResultado; break;
		        case 'Y': fValY = fResultado; break;
		        case 'Z': fValZ = fResultado; break;
		    }
		    iGenOrg++; //Ignora el salto en un SET
        }
        else //Es un If condicional
        {
            switch(m_oGen[iGenOrg].cVariable)
		    {
				case 'W': fCompara = fValW; break;
		        case 'X': fCompara = fValX; break;
		        case 'Y': fCompara = fValY; break;
		        case 'Z': fCompara = fValZ; break;
		    }
                
            switch(m_oGen[iGenOrg].cOperacion)
            {
				case '>': if (fCompara > fResultado) 
		                      iGenOrg=m_oGen[iGenOrg].iGotoLabel;
		                  else
						      iGenOrg++;
		                  break;
                case '<': if (fCompara < fResultado) 
		                      iGenOrg=m_oGen[iGenOrg].iGotoLabel;
		                  else
					         iGenOrg++;
		                  break;
		        case '=': if (fCompara == fResultado) 
		                      iGenOrg=m_oGen[iGenOrg].iGotoLabel;
		                  else
						      iGenOrg++;
		                  break;
                case '!': if (fCompara != fResultado) 
		                      iGenOrg=m_oGen[iGenOrg].iGotoLabel;
		                  else
						      iGenOrg++;
		                  break;
		    }
		}
	 }//Fin de la evaluacion del ser vivo
	 return 0; //Finalizo la ejecucion
};
     

//Muta de forma suave el Gen
void Organismo::vMutaGen(unsigned int iLabel, unsigned int iMaxGenes,
                         unsigned int iLongExpr, unsigned int iPosibX,
						 unsigned int iPosibY, unsigned int iPosibP, unsigned int iPosibN)
{
	unsigned int iAleatorio;
	unsigned int iModif;
	char cVariable;

    //Por defecto, nunca se ha ejecutado esta instruccion
    m_oGen[iLabel].bEjecuta = false;
       
    //Si es una instrucci�n IF que hay que modificar, entonces se puede
	//modificar (y se nota el cambio) en las dos ultimas categorias
	//"Goto Label" y ">,<,!,="
	if (m_oGen[iLabel].cTipInst == 'I')
		iModif = abs(rand() % 7) + 1;
	else
		iModif = abs(rand() % 5) + 1;

	switch (iModif)
	{
	case 1: // Modifica SET, ASIGNA o FUNCION
		iAleatorio = abs(rand() % 2);
		switch(m_oGen[iLabel].cTipInst)
		{
			case 'I': if (iAleatorio==0)
					m_oGen[iLabel].cTipInst = 'S';
				  else
					m_oGen[iLabel].cTipInst = 'F';
				  break;
			case 'S': if (iAleatorio==0)
					m_oGen[iLabel].cTipInst = 'I';
				  else
					m_oGen[iLabel].cTipInst = 'F';
				  break;
			case 'F': if (iAleatorio==0)
					m_oGen[iLabel].cTipInst = 'I';
				  else
					m_oGen[iLabel].cTipInst = 'S';
				  break;
		}
		break;
	case 2: //Cambia la variable
		do
		{
   			iAleatorio = abs(rand() % 4) + 1;
			switch (iAleatorio)
			{
				case 1: cVariable = 'W'; break;
				case 2: cVariable = 'X'; break;
				case 3: cVariable = 'Y'; break;
				case 4: cVariable = 'Z'; break;
			}
		} while (m_oGen[iLabel].cVariable == cVariable);
		m_oGen[iLabel].cVariable = cVariable;
		break;

	case 3: //Cambia la expresion
		objGenExpr.vCrearExpresion(iLongExpr, iPosibX, iPosibY, iPosibP, iPosibN);
		strcpy(m_oGen[iLabel].sbExpresion,objGenExpr.sExpresion);
		break;

	case 4://Cambia la variable activa de la expresion
		do
		{
   			iAleatorio = abs(rand() % 4) + 1;
			switch (iAleatorio)
			{
				case 1: cVariable = 'W'; break;
				case 2: cVariable = 'X'; break;
				case 3: cVariable = 'Y'; break;
				case 4: cVariable = 'Z'; break;
			}
		} while (m_oGen[iLabel].cVarActiva1 == cVariable);
		m_oGen[iLabel].cVarActiva1 = cVariable;
		break;

	case 5://Cambia la variable activa de la expresion
		do
		{
   			iAleatorio = abs(rand() % 4) + 1;
			switch (iAleatorio)
			{
				case 1: cVariable = 'W'; break;
				case 2: cVariable = 'X'; break;
				case 3: cVariable = 'Y'; break;
				case 4: cVariable = 'Z'; break;
			}
		} while (m_oGen[iLabel].cVarActiva2 == cVariable);
		m_oGen[iLabel].cVarActiva2 = cVariable;
		break;

    case 6:
		//Cambia hacia que label va (entre 0 y MaxGenes)
	    unsigned int iNumCiclo;
		do
		{
			iNumCiclo = abs(rand() % (iMaxGenes+1));
		} while (iNumCiclo == m_oGen[iLabel].iGotoLabel && iNumCiclo == iLabel);
		m_oGen[iLabel].iGotoLabel = iNumCiclo;
		break;

	case 7: //Decide si usa =, >, <, ! Estos son tenidos en cuenta si es un IF condicional
   		char cOperacion;
		do
		{
   			iAleatorio = abs(rand() % 4) + 1;
			switch (iAleatorio)
			{
				case 1: cOperacion = '='; break;
				case 2: cOperacion = '>'; break;
				case 3: cOperacion = '<'; break;
				case 4: cOperacion = '!'; break;
			}
		} while (m_oGen[iLabel].cOperacion == cOperacion);
		m_oGen[iLabel].cOperacion = cOperacion;
		break;
	}
};