#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "Inicializa.h"
#include "Organismo.h"

#define INISEMILLA 100
#define LONGLISTA 40
#define MENORNUMERO 9999 //Numero de casillas tablero

void main()
{
	//Inicializa lista de mejores organismos
	Mejores objMejor[LONGLISTA];
	for (unsigned int iCont=0; iCont<LONGLISTA; iCont++)
		objMejor[iCont].iPuntAdapta = 0;

	//Valores de la simulacion
	Inicializa objIni;
	objIni.vPantallaIni();
	if (objIni.vLeeArchivoIni() < 0 ) exit(1);
	objIni.vArchResult();
	
	//Variables para el organismo
	char sbADN[4000];

	//Inicializa tablero de Juego (un ambiente)
	unsigned int iTablero[80][80];
	unsigned int iCont1, iCont2, iAcum, iLista, iCopia, iMenor=0, iPosMenor=0;

	//Comienza el juego
	unsigned int iPuntInstr1 = 1;
	unsigned int iCuentaJuegos=0;
	signed int iAccion=0;
	unsigned int iFuncion=0;
	unsigned int iCuentaOrg=0, iAcumOrg=0;
	float fParam01=0, fParam02=0, fParam03=0, fParam04=0;
	
	unsigned int iVecesJuega;
	iVecesJuega = objIni.stDatVA.iAnchoTabl * objIni.stDatVA.iLargoTabl*2;

	//Objeto Organismo
	Organismo objOrganismo1;
    objOrganismo1.m_iMaxiCiclos = objIni.stDatVA.iNumCiclos;
	objOrganismo1.IniciaSemillaT();
    objOrganismo1.objGenExpr.vIniLista(
		objIni.stDatVA.iPosibN,
		objIni.stDatVA.iPosibX,
		objIni.stDatVA.iPosibY,
		objIni.stDatVA.iPosibP);

	//Primer Grupo. Se llena la lista de los mejores organismos
	do //Ciclo de juego
	{
		//Inicializar la semilla de numeros aleatorios
		iCuentaOrg++;
		if (iCuentaOrg>INISEMILLA)
		{
			objOrganismo1.IniciaSemillaT();
			objOrganismo1.objGenExpr.vIniLista(
				objIni.stDatVA.iPosibN,
				objIni.stDatVA.iPosibX,
				objIni.stDatVA.iPosibY,
				objIni.stDatVA.iPosibP);

			iCuentaOrg=0;
			iAcumOrg++;
			printf("Organismos: %d\n", iAcumOrg*INISEMILLA);
			if (iAcumOrg*INISEMILLA>=objIni.stDatVA.iTotalOrg) break;
		}

		//Inicializa el tablero a cero
		for (iCont1=0; iCont1<objIni.stDatVA.iAnchoTabl; iCont1++)
			for (iCont2=0; iCont2<objIni.stDatVA.iLargoTabl; iCont2++)
 				iTablero[iCont1][iCont2]=0;
			
		//Crea Organismo
		objOrganismo1.vCreaADN(false, 
			objIni.stDatVA.iNumInstMax,
            objIni.stDatVA.iPosibIf, objIni.stDatVA.iPosibSet,
            objIni.stDatVA.iPosW, objIni.stDatVA.iPosX,
			objIni.stDatVA.iPosY, objIni.stDatVA.iPosZ,
            objIni.stDatVA.iPosIg, objIni.stDatVA.iPosMay,
			objIni.stDatVA.iPosMen, objIni.stDatVA.iPosDif,
			objIni.stDatVA.iLongExpr,
			objIni.stDatVA.iPosibX,
			objIni.stDatVA.iPosibY,
			objIni.stDatVA.iPosibP,
			objIni.stDatVA.iPosibN);

		//Por donde va el algoritmo
		iPuntInstr1 = 1;

		//Parametros retornados por los algoritmos geneticos
		fParam01=0; fParam02=0; fParam03=0; fParam04=0;

		//Cuantas veces es llamado el algoritmo a jugar
		iCuentaJuegos=0;
		iAcum=0;
		do
		{
			iCuentaJuegos++;
			iAccion = objOrganismo1.fEvalOrganismo( &iPuntInstr1,
													&iFuncion,
													&fParam01,
													&fParam02,
													&fParam03,
													&fParam04);
			if (iAccion==1) //Llamando una funcion
			{
				switch(iFuncion)
				{
				case 1: //Sensor de Posici�n
					if ((fParam02<objIni.stDatVA.iAnchoTabl && fParam02>=0) && (fParam03<objIni.stDatVA.iLargoTabl && fParam03>=0))
					{
						iCont1 = (int) fParam02;
						iCont2 = (int) fParam03;
						fParam01 = (float) iTablero[iCont1][iCont2];
					}
					else
						fParam01 = -1;
					break;
				case 2: //Sensor de l�mites
					fParam01 = 0;
					fParam02 = 0;
					fParam03 = (float) objIni.stDatVA.iAnchoTabl;
					fParam04 = (float) objIni.stDatVA.iLargoTabl;
					break;
				case 3: //Colocar una ficha
					if ((fParam02<objIni.stDatVA.iAnchoTabl && fParam02>=0) && (fParam03<objIni.stDatVA.iLargoTabl && fParam03>=0))
					{
						iCont1 = (int) fParam02;
						iCont2 = (int) fParam03;
						if (iTablero[iCont1][iCont2]==0)
						{
							fParam01 = 1;
							iTablero[iCont1][iCont2]=1;
							iAcum++;
						}
					}
					else
						fParam01 = -1;
					break;
				}
			}

		} while (iCuentaJuegos<=iVecesJuega && iAccion!=0 && iAccion!=-1);

		//Segun el iAcum lo guarda en la lista de los mejores
		if (iAcum>iMenor)
		{
			//Queda el organismo en la lista de los mejores
			for (iCopia=1; iCopia<=objIni.stDatVA.iNumInstMax; iCopia++)
			{
				objMejor[iPosMenor].m_oGen[iCopia].cTipInst = objOrganismo1.m_oGen[iCopia].cTipInst;
				objMejor[iPosMenor].m_oGen[iCopia].cVariable = objOrganismo1.m_oGen[iCopia].cVariable;
				objMejor[iPosMenor].m_oGen[iCopia].cOperacion = objOrganismo1.m_oGen[iCopia].cOperacion;
				objMejor[iPosMenor].m_oGen[iCopia].cVarActiva1 = objOrganismo1.m_oGen[iCopia].cVarActiva1;
				objMejor[iPosMenor].m_oGen[iCopia].cVarActiva2 = objOrganismo1.m_oGen[iCopia].cVarActiva2;
				strcpy(objMejor[iPosMenor].m_oGen[iCopia].sbExpresion, objOrganismo1.m_oGen[iCopia].sbExpresion);
				objMejor[iPosMenor].m_oGen[iCopia].iGotoLabel = objOrganismo1.m_oGen[iCopia].iGotoLabel;
				objMejor[iPosMenor].m_oGen[iCopia].iCodFunc = objOrganismo1.m_oGen[iCopia].iCodFunc;
			}
			objMejor[iPosMenor].m_iMaxGenOrg = objOrganismo1.m_iMaxGenOrg;
			objMejor[iPosMenor].iPuntAdapta = iAcum;

			//Busca una siguiente posicion menor
			iMenor = MENORNUMERO;
			for (iLista=0; iLista<LONGLISTA; iLista++)
				if (objMejor[iLista].iPuntAdapta < iMenor)
				{
					iMenor = objMejor[iLista].iPuntAdapta;
					iPosMenor = iLista;
				}
		}

	} while (true);

	//Graba a archivo los LONGLISTA mejores organismos
	float iTotAcum=0;
	for (iLista=0; iLista<LONGLISTA; iLista++)
	{
		for (iCopia=1; iCopia<=objIni.stDatVA.iNumInstMax; iCopia++)
		{
			objOrganismo1.m_oGen[iCopia].cTipInst = objMejor[iLista].m_oGen[iCopia].cTipInst;
			objOrganismo1.m_oGen[iCopia].cVariable = objMejor[iLista].m_oGen[iCopia].cVariable;
			objOrganismo1.m_oGen[iCopia].cOperacion = objMejor[iLista].m_oGen[iCopia].cOperacion;
			objOrganismo1.m_oGen[iCopia].cVarActiva1 = objMejor[iLista].m_oGen[iCopia].cVarActiva1;
			objOrganismo1.m_oGen[iCopia].cVarActiva2 = objMejor[iLista].m_oGen[iCopia].cVarActiva2;
			strcpy(objOrganismo1.m_oGen[iCopia].sbExpresion, objMejor[iLista].m_oGen[iCopia].sbExpresion);
			objOrganismo1.m_oGen[iCopia].iGotoLabel = objMejor[iLista].m_oGen[iCopia].iGotoLabel;
			objOrganismo1.m_oGen[iCopia].iCodFunc = objMejor[iLista].m_oGen[iCopia].iCodFunc;
		}
		objOrganismo1.sDisplayADN(sbADN);
		objIni.vGrabaOrganismos(objMejor[iLista].iPuntAdapta, sbADN);
		iTotAcum += objMejor[iLista].iPuntAdapta;
	}
	objIni.vFinalSimulacion();
	sprintf(sbADN, "Promedio es: %f\n", iTotAcum / LONGLISTA);
	objIni.vGrabaOrganismos(0, sbADN);
}