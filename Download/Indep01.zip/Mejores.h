/*
Autor:		Rafael Alberto Moreno Parra
URL:		http://www.geocities.com/krousky
Clase:		Gen
Lenguaje:	C++

Prop�sito:
   Linea de codigo fuente (la llam� Gen). El formato es:
   label, [, IF/SET, Variable, =/>/</!, (, expresion, ), Goto, Label, ]
   para mayor velocidad, se ubica en una clase el Gen

*/
#include "Gen.h"

