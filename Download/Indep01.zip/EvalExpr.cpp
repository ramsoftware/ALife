/* ARTIFICIAL LIFE ENGINE. EVALUADOR DE EXPRESIONES OPTIMIZADO.

   AUTOR: RAFAEL ABERTO MORENO PARRA

   EvalExpr de expresiones en Visual C++.	Diciembre 30 del 2001.

   Sus caracter�sticas principales son:
   - Evaluador NO recursivo.
   - Optimizado para Artificial Life Engine 
   - Evalua m_sFuncion trigonometricas en radianes.

   Forma de uso:

	 float dCapturaEcuacion(char *expresion, float valor_x, float valor_y);

		 Donde *expresion es una cadena donde reposa la expresion a evaluar,
		 por ejemplo: "4*2-x+y*3".
		 valor_x y valor_y son los valores con que va las variables 'x' y 'y'
		 en la expresi�n.
		 Esta subrutina retorna el valor de la expresi�n.

		 Ej:
			 void main()
			 {
			  float resultado;
			   char funcion[]="3*4+y-2*x";
			  float x=10.4, y=23.5;

			  resultado=dCapturaEcuacion(funcion, x, y);

			  printf("el resultado es %f", resultado);
			 }


	 float dCicloEvalua(float valor_x, float valor_y);

		 retorna los valores de una expresion anteriormente evaluada,
		 es muy veloz para ciclos.

		 Ej:

			 void main()
			 {
			  float resultado;
			   char funcion[]="3*4+y-21*x";
			  float x=10.4, y=23.5;
			   int contador;

			  resultado=dCapturaEcuacion(funcion, x, y);

			  printf("el resultado es %f\n", resultado);

			  for(i=1; i<=60; i++)
			  {
			   x*=i; y+=i;
			   resultado=dCicloEvalua(x, y);
			   printf("resultados parciales %f\n", resultado);
			  }
			 }

*/


/* COMO FUE PROGRAMADO:

   Supongamos una cadena de expresi�n as�:
	3-4*(3+x)+8-(2+x*x)

   la expresi�n se desintegra en acums:

   m_sAcum[0]="2+x*x"             => 3-4*(3+x)+8-@A;
   m_sAcum[1]="3x+8"               => 3-4*@B+8-@A;
   m_sAcum[2]="3-4*@B+8-@A"

   cada '@?' es evaluado como una expresi�n simple.
   m_sAcum[0]="2+x*y"
   => m_sVectorNumeros[0][0]="2"  m_sVectorOperador[0][0]='+';
	  m_sVectorNumeros[0][1]="x"   m_sVectorOperador[0][1]='*';
	  m_sVectorNumeros[0][2]="y"   m_sVectorOperador[0][2]='F';
*/


#include <string.h>
#include <ctype.h>
#include <math.h>
#include <stdlib.h>
#include <stdio.h>
#include "EvalExpr.h"

float EvalExpr::dCapturaEcuacion(char *sEcuacion, float dX, float dY)
{
 char sEcuacion2[200];
 float resultado;
 unsigned char iCont;

 strcpy(sEcuacion2, sEcuacion); 

 // Desglosa la cadena(expresion algebraica) en Acums y
 // deduce el numero de Acums
 m_iNumAcums=0;
 vExprAcums(sEcuacion2);
 for(iCont=0; iCont<=m_iNumAcums; iCont++)
	  vDesintegraAcumn(m_sAcum[iCont], iCont);

 resultado=dCicloEvalua(dX, dY);
 if(ERRORMATEMATICO==1){ resultado=0; ERRORMATEMATICO=0; }
 return resultado;
}

// Convierte la expresion algebraica en acums
void EvalExpr::vExprAcums(char *sEcuacion)
{
 unsigned char cCont1, cCont2, cCar1, cCar2;
 char sReemplazo[4];

 sReemplazo[0]='@';
 sReemplazo[2]='\0';

 do{
  for(cCont1=strlen(sEcuacion); cCont1>0; cCont1--)
   if( sEcuacion[cCont1] == '(' ) break; // busca parentesis
  
  if(sEcuacion[cCont1] == '(') // si hay parentesis "(" se debe buscar el ")"
  {
   for(cCont2=cCont1+1;;cCont2++)
    if( sEcuacion[cCont2] == ')')
    {
	  // extrae la expresion entre parentesis
	 for(cCar1=0, cCar2=cCont1+1; cCar2<cCont2; cCar1++, cCar2++)
		m_sAcum[m_iNumAcums][cCar1] = sEcuacion[cCar2];
	 m_sAcum[m_iNumAcums][cCar1]='\0';

     // reemplaza la sSubExpresion entre parentesis por un @A, @B, @C hasta @Z (el l�mite)
	 sReemplazo[1]=m_iNumAcums+65;
     vReemplazarExpr(sEcuacion, sReemplazo, cCont1, cCont2+2);
     m_iNumAcums++;
     break;
    }
  }
 }while(cCont1>0); // para hasta que se acaben los parentesis
 strcpy(m_sAcum[m_iNumAcums], sEcuacion);
}


void EvalExpr::vReemplazarExpr( char *sEcuacion,  char *sReemplazo,
		      unsigned char cDesde, unsigned char cHasta)
{
 char *sTemCad1, *sTemCad2;
 unsigned char iCont1, iCont2;

 sTemCad1=( char *)malloc(strlen(sEcuacion)+2);
 sTemCad2=( char *)malloc(strlen(sEcuacion)+2);

 //Corta a la izquierda de la cadena (Left)
 for(iCont1=0; iCont1<=cDesde-1 && *(sEcuacion+iCont1); iCont1++)
	 sTemCad1[iCont1] = sEcuacion[iCont1];
 sTemCad1[iCont1]='\0';

 strcat(sTemCad1, sReemplazo);
 
 //Corta a la derecha (Right)
 for(iCont2=0, iCont1=cHasta-1; *(sEcuacion+iCont1); iCont2++, iCont1++)
	 sTemCad2[iCont2] = sEcuacion[iCont1];
 sTemCad2[iCont2]='\0';

 strcat(sTemCad1, sTemCad2);
 strcpy(sEcuacion, sTemCad1);

 free(sTemCad1);
 free(sTemCad2);
}


// Desintegra los Acumns en operandos y operadores
void EvalExpr::vDesintegraAcumn(char *sExprSimple, char cIndAcum)
{
	unsigned char cCiclo, cCaract, cContLetr=0;
	char cAcumNumeros[3], iContOper=0;
	cAcumNumeros[1]='\0';

	for(cCiclo=0; cCiclo<=(char)strlen(sExprSimple); cCiclo++)
	switch( cCaract=*(sExprSimple+cCiclo) )
	{
		case 'x': // variable
		case 'y':
			m_sVectorNumeros[cIndAcum][cContLetr][0]=cCaract;
			cContLetr++;
			break;
		case '@': // Es un acumn
			 m_sVectorNumeros[cIndAcum][cContLetr][0]= *(sExprSimple+cCiclo+1);
			 cContLetr++;
			 cCiclo+=1;
			 break;
		case '*':
		case '/':
		case '+':
		case '-':
			m_sVectorOperador[cIndAcum][iContOper++]=cCaract;
			break;
		default: // o sea un numero
			cAcumNumeros[0]=cCaract;
			strcpy(m_sVectorNumeros[cIndAcum][cContLetr++], cAcumNumeros);
			cAcumNumeros[0]='\0';
	   } // switch
   if( cAcumNumeros[0] != '\0') strcpy(m_sVectorNumeros[cIndAcum][cContLetr], cAcumNumeros);
   m_sVectorOperador[cIndAcum][iContOper]='F';
}


float EvalExpr::dCicloEvalua(float dX, float dY)
{
 unsigned char iIndAcum;
  
 ERRORMATEMATICO=0;
 for(iIndAcum=0; iIndAcum<=m_iNumAcums; iIndAcum++)
   m_AcumFloat[iIndAcum]=dEvaluaExpresion(iIndAcum, dX, dY);

  if(ERRORMATEMATICO==0)
	  return(m_AcumFloat[m_iNumAcums]);
  else
	  return 0;
}


float EvalExpr::dEvaluaExpresion(unsigned char cIndiceAcum, float dX, float dY)
{
 char cOperando[20];
 float dNumero[20], dAcumResult=0;
 unsigned char cExplVect, cAjustVect, cExploraAcum, cLimArray=0;

 for(cExploraAcum=0;;cExploraAcum++)
 {
  switch(m_sVectorNumeros[cIndiceAcum][cExploraAcum][0])
  {
   case 'x': dNumero[cExploraAcum]=dX; break;
   case 'y': dNumero[cExploraAcum]=dY; break;
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':
   case '0':
			 dNumero[cExploraAcum]=(float)atof(m_sVectorNumeros[cIndiceAcum][cExploraAcum]);
			 break;
   default:	 dNumero[cExploraAcum]=m_AcumFloat[m_sVectorNumeros[cIndiceAcum][cExploraAcum][0]-65];
  }
  cOperando[cExploraAcum]=m_sVectorOperador[cIndiceAcum][cExploraAcum];
  if(cOperando[cExploraAcum]=='F') break;
 }
 cLimArray=cExploraAcum;

 //Division
 for(cExplVect=0; cExplVect<=cLimArray; cExplVect++)
  while(cOperando[cExplVect]=='/')
  {
   if(dNumero[cExplVect+1]!=0) dNumero[cExplVect]=dNumero[cExplVect]/dNumero[cExplVect+1];
   else { ERRORMATEMATICO=1; dNumero[cExplVect]=0; return 0; }
   for(cAjustVect=cExplVect+2; cAjustVect<=cLimArray+1; cAjustVect++)
   {
	dNumero[cAjustVect-1]=dNumero[cAjustVect];
	cOperando[cAjustVect-2]=cOperando[cAjustVect-1];
   }
   cLimArray--;
  }

 // Multiplicacion	 
 for(cExplVect=0; cExplVect<=cLimArray; cExplVect++)
  while(cOperando[cExplVect]=='*')
  {
   dNumero[cExplVect]=dNumero[cExplVect]*dNumero[cExplVect+1];
   for(cAjustVect=cExplVect+2; cAjustVect<=cLimArray+1; cAjustVect++)
   {
	dNumero[cAjustVect-1]=dNumero[cAjustVect];
	cOperando[cAjustVect-2]=cOperando[cAjustVect-1];
   }
   cLimArray--;
  }

 // Suma y Resta
 dAcumResult=dNumero[0];
 for(cExplVect=0; cExplVect<=cLimArray; cExplVect++)
  if(cOperando[cExplVect]=='+') dAcumResult+=dNumero[cExplVect+1];
  else
   if(cOperando[cExplVect]=='-') dAcumResult-=dNumero[cExplVect+1];

 return dAcumResult;
}

int EvalExpr::_matherr(struct exception *a)
{
	printf("Hubo un error\n");
	ERRORMATEMATICO=1;
    return 1;
}
