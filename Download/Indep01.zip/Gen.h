/*
Autor:		Rafael Alberto Moreno Parra
URL:		http://www.geocities.com/krousky
Clase:		Gen
Lenguaje:	C++

Prop�sito:
   Linea de codigo fuente (la llam� Gen). El formato es:
   label, [, IF/SET, Variable, =/>/</!, (, expresion, ), Goto, Label, ]
   para mayor velocidad, se ubica en una clase el Gen

*/
class Gen
{
public:
    bool bEjecuta; // Se coloca a TRUE si la instruccion es ejecutada

    char cTipInst; /* Operacion IF o SET o FUNCION */

    //Si es una istruccion IF o SET
	char cVariable; /* Variable a la que van a asignarle un valor o a compararla */
    char cOperacion; /* Que operacion >,<,=,! se hara si es un IF condicional */
    char cVarActiva1; /* Variable 1 activa en la expresion */
    char cVarActiva2; /* Variable 2 activa en la expresion */
    char sbExpresion[60]; /* Expresion en X y Y */
    unsigned int iGotoLabel; /* Hacia que gen ir� */

	// Si es una instruccion tipo FUNCION
	unsigned int iCodFunc; /* Codigo de la funcion */
};