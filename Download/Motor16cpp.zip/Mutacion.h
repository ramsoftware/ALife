/*
Autor:		Rafael Alberto Moreno Parra
URL:		http://www.geocities.com/krousky
Clase:		Mutacion
Lenguaje:	C++

Prop�sito:
Clase de generaci�n/modificaci�n de expresiones matem�ticas en forma
aleatoria.

M�todos:
vIniLista: Optimiza la generaci�n/modificaci�n de expresiones
vCrearExpresion: Genera expresi�n
vMutarPartes: Modifica expresi�n

*/
class Mutacion {
public:
    int vIniLista(unsigned int, unsigned int, unsigned int);
	void vCrearExpresion(unsigned int, unsigned int, unsigned int, unsigned int);
	void vMutarPartes(unsigned int, unsigned int);

    char sExpresion[130]; //La expresion que se genera
	unsigned int iSemilla;
    unsigned char sOperNumPar[101]; //Por velocidad: Almacena un listado de Numeros, Operadores, Variables X, Parentesis
                               //para cuando se construyan las expresiones sea muy rapido.
};