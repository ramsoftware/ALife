/*
Autor:		Rafael Alberto Moreno Parra
URL:		http://www.geocities.com/krousky
Clase:		Inicializa.
Lenguaje:	C++

Prop�sito:
Inicializa las variables para la simulaci�n

M�todos:

*/

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>
#include "Inicializa.h"
#include "StringUtil.h"

void Inicializa::vPantallaIni()
{
	printf("Motor de Vida Artificial\n\n");
	printf("Motor 16. MacroOrganismo\n\n");
	printf("Autor: Rafael Alberto Moreno Parra\n");
	printf("Fecha: 04 de Octubre de 2000\n");
	printf("E-mail: enginelife@hotmail.com\n");
	printf("http://www.geocities.com/krousky\n");
};

//Abre y estudia el archivo de inicializaci�n
int Inicializa::vLeeArchivoIni()
{
	FILE *fpInicio;
	char sFrase[600], sVariable[200], sValor[200];
    unsigned int iCar;
	StringUtil StrUtil;

	fpInicio = fopen("Motor16.ini", "r+t");
	if (fpInicio == NULL)
    {
		printf("Error al tratar de abrir archivo de inicializaci�n Motor16.ini\n");
		return -1;
    }
	while(!feof(fpInicio))
	{
		fgets(sFrase, 298, fpInicio);
		StrUtil.vQuitaEspacios(sFrase);

		//Extrae variables y valores
		for (iCar=0; iCar<strlen(sFrase) && sFrase[iCar]!='='; iCar++);
		StrUtil.vLeft(sVariable, sFrase, iCar);
		StrUtil.vMid(sValor, sFrase, iCar+2,strlen(sFrase)-1);

		//Clasifica variables
		if(strcmp(sVariable, "iPosibIf")==0) stDatVA.iPosibIf = atoi(sValor);
		if(strcmp(sVariable, "iPosibSet")==0) stDatVA.iPosibSet = atoi(sValor);
		if(strcmp(sVariable, "iPosW")==0) stDatVA.iPosW = atoi(sValor);
		if(strcmp(sVariable, "iPosX")==0) stDatVA.iPosX = atoi(sValor);
		if(strcmp(sVariable, "iPosY")==0) stDatVA.iPosY = atoi(sValor);
		if(strcmp(sVariable, "iPosZ")==0) stDatVA.iPosZ = atoi(sValor);
		if(strcmp(sVariable, "iPosIg")==0) stDatVA.iPosIg = atoi(sValor);
		if(strcmp(sVariable, "iPosMay")==0) stDatVA.iPosMay = atoi(sValor);
		if(strcmp(sVariable, "iPosMen")==0) stDatVA.iPosMen = atoi(sValor);
		if(strcmp(sVariable, "iPosDif")==0) stDatVA.iPosDif = atoi(sValor);
		if(strcmp(sVariable, "iLongExpr")==0) stDatVA.iLongExpr = atoi(sValor);
		if(strcmp(sVariable, "iPosibX")==0) stDatVA.iPosibX = atoi(sValor);
		if(strcmp(sVariable, "iPosibP")==0) stDatVA.iPosibP = atoi(sValor);
		if(strcmp(sVariable, "iPosibN")==0) stDatVA.iPosibN = atoi(sValor);
		if(strcmp(sVariable, "iNumCiclos")==0) stDatVA.iNumCiclos= atoi(sValor);

		if(strcmp(sVariable, "iNumInstMin")==0) stDatVA.iNumInstMin = atoi(sValor);
		if(strcmp(sVariable, "iNumInstMax")==0) stDatVA.iNumInstMax = atoi(sValor);

		if(strcmp(sVariable, "fMaximoError")==0) stDatVA.fMaximoError = (float) atof(sValor);
		if(strcmp(sVariable, "sAmbiente")==0) strcpy(stDatVA.sAmbiente, sValor);
		if(strcmp(sVariable, "iXini")==0) stDatVA.iXini = (int) atoi(sValor);
		if(strcmp(sVariable, "iXfin")==0) stDatVA.iXfin = (int) atoi(sValor);

		if(strcmp(sVariable, "sArchResult")==0) strcpy(stDatVA.sArchResult, sValor);
	}
	fclose(fpInicio);
	return 0;
};

//Hace el encabezado del archivo de resultados
void Inicializa::vArchResult()
{
    //Leidos de una vez los par�metros de simulaci�n, comienza a simular
	FILE *fpSimular;
    unlink(stDatVA.sArchResult);
	fpSimular = fopen(stDatVA.sArchResult, "a+t");
	fprintf(fpSimular,"MOTOR16. MacroOrganismo \n");

	fprintf(fpSimular,"\nPosibilidades:\n");
	fprintf(fpSimular,"1. Tipo de Instrucciones. If Condicional: %d, Asignacion: %d\n", stDatVA.iPosibIf, stDatVA.iPosibSet);
	fprintf(fpSimular,"2. En Instrucciones de If Condicional, el operador de comparacion es:  '==':%d, '>':%d, '<':%d, '!=':%d\n", stDatVA.iPosIg, stDatVA.iPosMay, stDatVA.iPosMen, stDatVA.iPosDif);
	fprintf(fpSimular,"3. Longitud de la expresi�n (n�mero de operadores): %d\n\n", stDatVA.iLongExpr);
	fprintf(fpSimular,"4. Construcci�n de las expresiones, posibilidad de salir X=%d, Parentesis:%d, N�meros=%d\n", stDatVA.iPosibX, stDatVA.iPosibP, stDatVA.iPosibN);
	fprintf(fpSimular,"5. Variables que se asignar�n, comparar�n o estar�n al interior de las expresiones: W=%d, X=%d, Y=%d, Z=%d\n", stDatVA.iPosW, stDatVA.iPosX, stDatVA.iPosY, stDatVA.iPosZ);
	fprintf(fpSimular,"\n");
	fprintf(fpSimular,"N�mero m�ximo de ciclos CPU: %d\n", stDatVA.iNumCiclos);
	fprintf(fpSimular,"N�mero de Instrucciones m�nimas para algoritmo: %d\n", stDatVA.iNumInstMin);
	fprintf(fpSimular,"N�mero de Instrucciones m�ximas para algoritmo: %d\n", stDatVA.iNumInstMax);
    fprintf(fpSimular,"Error m�ximo de adaptaci�n: %f\n", stDatVA.fMaximoError);
	fprintf(fpSimular,"Ambiente C�clico (0 a PI) es: F(z) = sin(y) * ( %s )\n", stDatVA.sAmbiente);
	fprintf(fpSimular,"Desde X=[%d] hasta [%d]\n\n", stDatVA.iXini, stDatVA.iXfin);
	fclose(fpSimular);
};

void Inicializa::vGrabaResult(int iTipResult, char *sMensaje, unsigned int iContIntentos, float fErrOrg)
{
	FILE *fpSimular;
	time_t ltime;

	fpSimular = fopen(stDatVA.sArchResult, "a+t");

	if (iTipResult==1)
	{
		time( &ltime );
		fprintf(fpSimular,"Fecha: %s", ctime( &ltime ) );
	}
	else
		fprintf(fpSimular,"Intento: [%d]  Aproximaci�n: [%f]\n", iContIntentos, fErrOrg);

	fprintf(fpSimular,"%s\n", sMensaje);
	fclose(fpSimular);
};

void Inicializa::vImprMacroOrg(unsigned int iPosY, char *sOrganismo, float fError)
{
	FILE *fpSimular;

	fpSimular = fopen(stDatVA.sArchResult, "a+t");

    fprintf(fpSimular,"PosY: %d*PI/8, Error: [%f]\n", iPosY, fError);
	fprintf(fpSimular,"Organismo\n%s\n\n", sOrganismo);
	fclose(fpSimular);
};
