/* Autor: Rafael Alberto Moreno Parra
   Fecha: 22 de Septiembre de 2000

MOTOR16. Escrito en C++ (Compilado en Visual C++ 6.0)
Ambientes y Organismos (simples expresiones, algoritmos y mutaci�n)

Aqui se simula el comportamiento c�clico de un ambiente.
Por ejemplo:
		
Ambiente = sin(y) * (4+3*X-X*X)
Genero un valor Y=PI/2 y doy valores de X = 1..10 entonces:
		
sin(PI/2) * (4+3*X-X*X) = 1 * (4+3*X-X*X) = 6,6,4,0,-6,-14,-24,-36,-50,-66
Ahora genero un organismo que se adapte a ese ambiente (6,6,4,0,-6,-14,-24,-36,-50,-66)

Luego cambio el valor de Y=PI/3 y doy valores de X=1..10 entonces obtengo el ambiente
5.1961, 5.1961, 3.4641, 0, -5.1961, -12.1243, -20.7846, -31.1769, -43.30127, -50.1576
Ahora genero otro organismo para dicho ambiente

Y asi sucesivamente de Y=0 hasta 2*PI. Con eso obtengo una serie de organismos que se adaptan
a un determinado ciclo de un ambiente c�clico. Ahora es hacer que logren hacer simbiosis
y se obtiene el macroorganismo.
		
*/

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>

#include "Organismo.h"
#include "MasApto.h"
#include "MedioAmbiente.h"
#include "Inicializa.h"

void Simular(void);
void vQuitaEspacios(char *sCadena);
void vLeft(char *cad1, char *cad2, char num_letras);
void vRight(char *cad1, char *cad2, char num_letras);
void vMid(char *cad1, char *cad2, char desde, char hasta);

#define MAXORGANISMOS 30
#define PI 3.1415926537


//Programa Principal
int main()
{
	//Definici�n de variables
	unsigned int iOrgSelecci=0; //Decide con que organismo jugar
	unsigned int iGeneracion=0; //Que estrat�gia usar� para generar organismos
	unsigned int iNumGenes=0;  //Contador de genes(instrucciones a generar)
	unsigned int iMutables=0; //N�mero de instrucciones realmente ejecutadas
	unsigned int iCopia=0; //Para copiar de MasAptos a Organismo
	unsigned int iMutar=1; //Que gen mutar�
	unsigned int iCicl=0; //En que parte del ciclo es mejor el organismo
	float fY=0; //Valor que tendr� el ciclo en un momento
	float fAcumErr; //Acumula el error de aproximaci�n del organismo al ambiente
	int iX=0; //Valor X de la expresi�n de ambiente
	float fDiferen; //Diferencia entre ambiente y organismo
	float fMinimo; //Buscar la mejor adaptaci�n
	int iMejorLugar; //Posici�n en el ciclo donde se adapta mejor el organismo
	int iLugar; //Contador temporal para averiguar la mejor adpataci�n



	Inicializa objInicializa; //Inicializa la simulaci�n
    MedioAmbiente objAmbiente;
	MasApto objMasApto[MAXORGANISMOS+1]; //Los mejores organismos
	Organismo objOrganismo;

	//Inicializa Organismos Aptos (c�digo -1)
	for (int iCont=0; iCont<MAXORGANISMOS; iCont++)
	{
		objMasApto[iCont].iCodMasApto = -1;
		objMasApto[iCont].fErrAdapta = (float) 99999999;
	}

    //Presentaci�n
	objInicializa.vPantallaIni();
	
	//Lee los parametros de simulaci�n
	int iLeeDatos = objInicializa.vLeeArchivoIni();
	if (iLeeDatos == -1) return 1;
	objAmbiente.iInicio = objInicializa.stDatVA.iXini;
	objAmbiente.iFinal = objInicializa.stDatVA.iXfin;


    //Deduce el ambiente
	objAmbiente.vEvalAmbiente(objInicializa.stDatVA.iXini, objInicializa.stDatVA.iXfin, objInicializa.stDatVA.sAmbiente);


    //Inicializa el comportamiento aleatorio
	objOrganismo.IniciaSemillaT();
	objOrganismo.cMuta.vIniLista(	objInicializa.stDatVA.iPosibN,
									objInicializa.stDatVA.iPosibX,
									objInicializa.stDatVA.iPosibP);
	objOrganismo.m_iMaxiCiclos =  objInicializa.stDatVA.iNumCiclos;
	objOrganismo.vCreaADN(false, 65,
					objInicializa.stDatVA.iPosibIf,
					objInicializa.stDatVA.iPosibSet,
					objInicializa.stDatVA.iPosW,
					objInicializa.stDatVA.iPosX,
					objInicializa.stDatVA.iPosY,
					objInicializa.stDatVA.iPosZ,
					objInicializa.stDatVA.iPosIg,
					objInicializa.stDatVA.iPosMay,
					objInicializa.stDatVA.iPosMen,
					objInicializa.stDatVA.iPosDif,
					objInicializa.stDatVA.iLongExpr,
					objInicializa.stDatVA.iPosibX,
					objInicializa.stDatVA.iPosibP,
					objInicializa.stDatVA.iPosibN);

    //Informaci�n Inicial de la simulaci�n para simple expresi�n
	objOrganismo.m_oGen[1].bEjecuta = false;
	objOrganismo.m_oGen[1].cTipInst = 'S';
	objOrganismo.m_oGen[1].cVarActiva = 'X';
	objOrganismo.m_oGen[1].cVariable = 'Y';
	objOrganismo.m_oGen[1].iGotoLabel = 0;
	objOrganismo.m_iMaxGenOrg = 1;


	//Encabezado archivo de resultados
	objInicializa.vArchResult(); //Encabezado

	/* En esta simulaci�n ambiente c�clico, se tendr� en cuenta la generaci�n
	   de organismos simples (una l�nea) y tipo algoritmo: Proceso de mutaci�n
	   fuerte y sutil */
	while(true)
	{
		//Se va a generar fijo: 2*PI / (PI/8) Organismos = 16 Organismos
		iOrgSelecci = rand()%16; //Decide con que organismo jugar
        
		if (objMasApto[iOrgSelecci].iCodMasApto != -1) //Si ya lo ocupaba alguien
		{
			if (objMasApto[iOrgSelecci].m_iMaxGenOrg > 1 )
        		iGeneracion = rand()%4 + 1; //Decide entre las 4 estrat�gias
			else
      			iGeneracion = rand()%2 + 1; //Decide entre las 2 estrat�gias

			switch(iGeneracion)
			{
				case 1: //Muta la simple expresion
					strcpy(objOrganismo.cMuta.sExpresion, objMasApto[iOrgSelecci].m_oGen[1].sbExpresion);
					objOrganismo.cMuta.vMutarPartes(objInicializa.stDatVA.iPosibX, objInicializa.stDatVA.iPosibN);
					strcpy(objOrganismo.m_oGen[1].sbExpresion,objOrganismo.cMuta.sExpresion);
					break;

				case 2: //Genera Aleatoriamente los Algoritmos
					iNumGenes = rand() % (objInicializa.stDatVA.iNumInstMax - objInicializa.stDatVA.iNumInstMin) + objInicializa.stDatVA.iNumInstMin;
					objOrganismo.vCreaADN(false, iNumGenes,
							objInicializa.stDatVA.iPosibIf,
							objInicializa.stDatVA.iPosibSet,
							objInicializa.stDatVA.iPosW,
							objInicializa.stDatVA.iPosX,
							objInicializa.stDatVA.iPosY,
							objInicializa.stDatVA.iPosZ,
							objInicializa.stDatVA.iPosIg,
							objInicializa.stDatVA.iPosMay,
							objInicializa.stDatVA.iPosMen,
							objInicializa.stDatVA.iPosDif,
							objInicializa.stDatVA.iLongExpr,
							objInicializa.stDatVA.iPosibX,
							objInicializa.stDatVA.iPosibP,
							objInicializa.stDatVA.iPosibN);

					//Restaura la primera instruccion
					objOrganismo.m_oGen[1].cOperacion = objMasApto[iOrgSelecci].m_oGen[1].cOperacion;
					objOrganismo.m_oGen[1].cTipInst = objMasApto[iOrgSelecci].m_oGen[1].cTipInst;
					objOrganismo.m_oGen[1].cVarActiva = objMasApto[iOrgSelecci].m_oGen[1].cVarActiva;
					objOrganismo.m_oGen[1].cVariable = objMasApto[iOrgSelecci].m_oGen[1].cVariable;
					objOrganismo.m_oGen[1].iGotoLabel = objMasApto[iOrgSelecci].m_oGen[1].iGotoLabel;
					strcpy(objOrganismo.m_oGen[1].sbExpresion,objMasApto[iOrgSelecci].m_oGen[1].sbExpresion);
					break;

				case 3: //Muta todo un Gen
					iMutables=0;
					for (iCopia=1; iCopia <= objMasApto[iOrgSelecci].m_iMaxGenOrg; iCopia++)
					{
						if (objMasApto[iOrgSelecci].m_oGen[iCopia].bEjecuta == true) iMutables++;
						objOrganismo.m_oGen[iCopia].bEjecuta = false;
						objOrganismo.m_oGen[iCopia].cOperacion = objMasApto[iOrgSelecci].m_oGen[iCopia].cOperacion;
						objOrganismo.m_oGen[iCopia].cTipInst = objMasApto[iOrgSelecci].m_oGen[iCopia].cTipInst;
						objOrganismo.m_oGen[iCopia].cVarActiva = objMasApto[iOrgSelecci].m_oGen[iCopia].cVarActiva;
						objOrganismo.m_oGen[iCopia].cVariable = objMasApto[iOrgSelecci].m_oGen[iCopia].cVariable;
						objOrganismo.m_oGen[iCopia].iGotoLabel = objMasApto[iOrgSelecci].m_oGen[iCopia].iGotoLabel;
						strcpy(objOrganismo.m_oGen[iCopia].sbExpresion,objMasApto[iOrgSelecci].m_oGen[iCopia].sbExpresion);
					}
					objOrganismo.m_iMaxGenOrg = objMasApto[iOrgSelecci].m_iMaxGenOrg;

					//Escoge que Gen mutar�, muta los que se ejecutaron
					iMutar = rand() % (iMutables-1) + 2;
					for (iCopia=1; iCopia <= objMasApto[iOrgSelecci].m_iMaxGenOrg; iCopia++)
					{
						if (objMasApto[iOrgSelecci].m_oGen[iCopia].bEjecuta == true) iMutar--;
						if (iMutar==0) break;
					}
					iMutar = iCopia; //La posici�n real a mutar

					//Muta el Gen
					objOrganismo.vHaceGen(iMutar, objOrganismo.m_iMaxGenOrg,
							objInicializa.stDatVA.iPosibIf,
							objInicializa.stDatVA.iPosibSet,
							objInicializa.stDatVA.iPosW,
							objInicializa.stDatVA.iPosX,
							objInicializa.stDatVA.iPosY,
							objInicializa.stDatVA.iPosZ,
							objInicializa.stDatVA.iPosIg,
							objInicializa.stDatVA.iPosMay,
							objInicializa.stDatVA.iPosMen,
							objInicializa.stDatVA.iPosDif,
							objInicializa.stDatVA.iLongExpr,
							objInicializa.stDatVA.iPosibX,
							objInicializa.stDatVA.iPosibP,
							objInicializa.stDatVA.iPosibN);
					break;

				case 4: //Muta un Gen pero de forma sutil
						iMutables=0;
						for (iCopia=1; iCopia <= objMasApto[iOrgSelecci].m_iMaxGenOrg; iCopia++)
						{
							if (objMasApto[iOrgSelecci].m_oGen[iCopia].bEjecuta == true) iMutables++;
							objOrganismo.m_oGen[iCopia].bEjecuta = false;
							objOrganismo.m_oGen[iCopia].cOperacion = objMasApto[iOrgSelecci].m_oGen[iCopia].cOperacion;
							objOrganismo.m_oGen[iCopia].cTipInst = objMasApto[iOrgSelecci].m_oGen[iCopia].cTipInst;
							objOrganismo.m_oGen[iCopia].cVarActiva = objMasApto[iOrgSelecci].m_oGen[iCopia].cVarActiva;
							objOrganismo.m_oGen[iCopia].cVariable = objMasApto[iOrgSelecci].m_oGen[iCopia].cVariable;
							objOrganismo.m_oGen[iCopia].iGotoLabel = objMasApto[iOrgSelecci].m_oGen[iCopia].iGotoLabel;
							strcpy(objOrganismo.m_oGen[iCopia].sbExpresion,objMasApto[iOrgSelecci].m_oGen[iCopia].sbExpresion);
						}
						objOrganismo.m_iMaxGenOrg = objMasApto[iOrgSelecci].m_iMaxGenOrg;

						//Escoge que Gen mutar�, muta los que se ejecutaron
						iMutar = rand() % (iMutables - 1) + 2;
						for (iCopia=1; iCopia <= objMasApto[iOrgSelecci].m_iMaxGenOrg; iCopia++)
						{
							if (objMasApto[iOrgSelecci].m_oGen[iCopia].bEjecuta == true) iMutar--;
							if (iMutar==0) break;
						}
						iMutar = iCopia; //La posici�n real a mutar

						//Muta el Gen en forma sutil
						objOrganismo.vMutaGen(iMutar, objOrganismo.m_iMaxGenOrg,
										objInicializa.stDatVA.iLongExpr,
										objInicializa.stDatVA.iPosibX,
										objInicializa.stDatVA.iPosibP,
										objInicializa.stDatVA.iPosibN);
						break;
			} //Fin switch()
		}
		else //Nunca se ha creado un organismo
		{
		    objOrganismo.cMuta.vCrearExpresion(objInicializa.stDatVA.iLongExpr, objInicializa.stDatVA.iPosibX, objInicializa.stDatVA.iPosibP, objInicializa.stDatVA.iPosibN);
		    strcpy(objOrganismo.m_oGen[1].sbExpresion,objOrganismo.cMuta.sExpresion);
		}

        //Evalua previamente el organismo
		objOrganismo.vEvaluaPrevio();


		// Busca en que parte del ciclo es mejor el organismo
		iCicl=0;
		fMinimo = 9999999;
		iLugar = 0;
		iMejorLugar=-1;
		for (fY=0; fY<=PI; fY+=PI/8)
		{
			fAcumErr=0;
			for (iX=objAmbiente.iInicio; iX<=objAmbiente.iFinal; iX++)
			{
				fDiferen = (float) fabs(objOrganismo.fEvalOrganismo((float)iX) - sin(fY)*objAmbiente.m_fAmbiente[iX]);
				fAcumErr += fDiferen;
			}

			if (fAcumErr < fMinimo)
			{
				fMinimo = fAcumErr;
				iMejorLugar = iLugar;
			}

			iLugar++;
		}

		if (iMejorLugar==-1) continue;

		/* Sabiendo en que parte del ciclo es mejor el organismo,
		   chequea si esta vacio el lugar y graba el nuevo registro,
		   en caso de que este lleno, entonces compara el organismo
		   que lo habita, si el nuevo es mejor, lo reemplaza. */
		if (objMasApto[iMejorLugar].fErrAdapta > fMinimo)
		{
			for (iCopia=1; iCopia <= objOrganismo.m_iMaxGenOrg; iCopia++)
			{
				objMasApto[iMejorLugar].m_oGen[iCopia].bEjecuta = objOrganismo.m_oGen[iCopia].bEjecuta;
				objMasApto[iMejorLugar].m_oGen[iCopia].cOperacion = objOrganismo.m_oGen[iCopia].cOperacion;
				objMasApto[iMejorLugar].m_oGen[iCopia].cTipInst = objOrganismo.m_oGen[iCopia].cTipInst;
				objMasApto[iMejorLugar].m_oGen[iCopia].cVarActiva = objOrganismo.m_oGen[iCopia].cVarActiva;
				objMasApto[iMejorLugar].m_oGen[iCopia].cVariable = objOrganismo.m_oGen[iCopia].cVariable;
				objMasApto[iMejorLugar].m_oGen[iCopia].iGotoLabel = objOrganismo.m_oGen[iCopia].iGotoLabel;
				strcpy(objMasApto[iMejorLugar].m_oGen[iCopia].sbExpresion, objOrganismo.m_oGen[iCopia].sbExpresion);
			}
			objMasApto[iMejorLugar].fErrAdapta = fMinimo;
			objMasApto[iMejorLugar].iCodMasApto = iMejorLugar;
			objMasApto[iMejorLugar].m_iMaxGenOrg = objOrganismo.m_iMaxGenOrg;
			objOrganismo.IniciaSemillaT(); //Inicializa la semilla

			/* Chequea si todos los lugares estan llenos y por debajo del nivel de error permitido */
			unsigned int iFinSimul=1;
			for (unsigned int iLleno=0; iLleno<9; iLleno++)
				if (objMasApto[iLleno].iCodMasApto==-1 || objMasApto[iLleno].fErrAdapta > objInicializa.stDatVA.fMaximoError)
				{
					iFinSimul=0;
					break;
				}

			if (iFinSimul) break;
		}
	}

	//Imprime los resultados
	char sTextOrganismo[5000];
	for (iMejorLugar=0; iMejorLugar<9; iMejorLugar++)
	{
		for (iCopia=1; iCopia <= objMasApto[iMejorLugar].m_iMaxGenOrg; iCopia++)
		{
			objOrganismo.m_oGen[iCopia].cOperacion = objMasApto[iMejorLugar].m_oGen[iCopia].cOperacion;
			objOrganismo.m_oGen[iCopia].cTipInst = objMasApto[iMejorLugar].m_oGen[iCopia].cTipInst;
			objOrganismo.m_oGen[iCopia].cVarActiva = objMasApto[iMejorLugar].m_oGen[iCopia].cVarActiva;
			objOrganismo.m_oGen[iCopia].cVariable = objMasApto[iMejorLugar].m_oGen[iCopia].cVariable;
			objOrganismo.m_oGen[iCopia].iGotoLabel = objMasApto[iMejorLugar].m_oGen[iCopia].iGotoLabel;
			strcpy(objOrganismo.m_oGen[iCopia].sbExpresion,objMasApto[iMejorLugar].m_oGen[iCopia].sbExpresion);
		}
		objOrganismo.m_iMaxGenOrg = objMasApto[iOrgSelecci].m_iMaxGenOrg;
		objOrganismo.sDisplayADN(sTextOrganismo);
		objInicializa.vImprMacroOrg(iMejorLugar, sTextOrganismo, objMasApto[iMejorLugar].fErrAdapta);
	}
	return 1;
}

