/* Evaluador de Expresiones escrito en Java

OPTIMIZADO PARA ARTIFICIAL LIFE ENGINE

El evaluador de expresiones que uso en los programas de graficaci�n 3D y 2D es complejo porque
evalua funciones trigonometricas, exponenciaci�n y numeros reales. Adem�s valida la sintaxis
de la expresi�n porque es digitada por un ser humano.

En cambio, las simulaciones de vida artificial, las expresiones son generadas aleatoriamente
por un programa pero con una sitaxis mas sencilla:
1. No hay expresiones trigonometricas: seno, coseno, arcotangente, etc..
2. Los numeros son enteros de un solo digito. No existen los reales.
3. No hay exponenciaci�n.

Adem�s debido a la naturaleza de la investigaci�n (no estoy persiguiendo la aproximaci�n cero
sino como se comporta la aproximaci�n bajo diferentes condiciones) no requiero la escala Double
sino la Float.

El evaluador de expresiones bajo estas nuevas condiciones es menos complejo y por lo tanto
mas r�pido, lo cual redunda en simulaciones m�s r�pidas.

Si desea conocer el evaluador de expresiones completo, dirijase a las gr�ficas 2D y 3D y
descargue el codigo fuente.
   
 Propiedad Intelectual
 Nombre:	Rafael Alberto Moreno Parra
 Direccion: http://alife.webjump.com 

*/

class EvalExpr
{
	// Variables de clase, se cumple el estandar de prefijo m_
	String m_sAcum[] = new String[30];
	String m_sVectorNumeros[][] = new String[30][70];
	String m_sVectorOperador[][] = new String[30][70];
	int m_iNumAcums=0;
	float m_AcumFloat[] = new float[30];

	// Este es el constructor, inicializa variables
	EvalExpr()
	{
		int iCont;

		m_iNumAcums=0;
		for(iCont=0; iCont<=29; iCont++) m_sAcum[iCont]="";
	}

	// Esta es la rutina p�blica para usuario
	public float dCapturaecuacion(String sEcuacion, float dX, float dY)
	{
		int iCont, iChar;
		float dResult=0;
	    m_iNumAcums=0;
		

		//Encierra en un parentesis
		sEcuacion = sEcuacion.toLowerCase();
		sEcuacion = "@(" + sEcuacion + ")";
		
		// Desintegra la expresion en Acums
		vOptimizador(sEcuacion);

		// Desintegra cada Acums
		vDesintegraAcumn();

		//Manda a evaluar
		dResult = CicloEvalua(dX, dY);

		//Devuelve el valor de la expresion
		return dResult;
	}

	// Convierte la expresion en Acums
	void vOptimizador(String sEcuacion)
	{
		int iCont, iCont2, iCont3, iCadena;
		String sTempor;
		
		do{
			// Busca parentesis '(' de derecha a izquierda
			for (iCont=sEcuacion.length()-1; iCont>=0; iCont--)
				if (sEcuacion.charAt(iCont) == '(' )
					break;
			
			//Busca la pareja del '(', es decir: ')'
			if(iCont>0)
			{
				for (iCont2=iCont; iCont2<=sEcuacion.length()-1; iCont2++)
					if (sEcuacion.charAt(iCont2) == ')' )
						break;
				
				
				//Extraigo la subcadena entre parentesis y lo coloco en los acums...
				m_sAcum[m_iNumAcums] = sEcuacion.substring(iCont+1, iCont2);
				
				// Cambio la ecuacion por la nueva expresion basada en acums
				sEcuacion = sEcuacion.substring(0, iCont) + 'a' + (char) (m_iNumAcums+65) + sEcuacion.substring(iCont2+1);
				m_iNumAcums++;
			}
		} while (iCont > 0);


		// Arregla los m_sAcum, las expresiones negativas, ej: -x*3 quedan 0-x*3
		for(iCont=0; iCont<m_iNumAcums; iCont++)
			if (m_sAcum[iCont].charAt(0) == '-')
				m_sAcum[iCont] = "0" + m_sAcum[iCont];
	}


	// Desintegra los Acumns en operandos y operadores
	void vDesintegraAcumn()
	{
		int iCont, iChar, iColumn=0, iColumn2=0, iTemp;
		char cCaracter;
		String sNumero;

		//Inicializa las pilas de operadores y operandos
/*		for(iCont=0; iCont<30; iCont++)
			for(iChar=0; iChar<70; iChar++)
			{
				m_sVectorNumeros[iCont][iChar] = "";
				m_sVectorOperador[iCont][iChar] = "";
			} */

		// Se va por todos los Acums
		for(iCont=0; iCont<m_iNumAcums; iCont++)
		{
			// Verifica si es una expresion simple (no una funci�n)
			if (m_sAcum[iCont].charAt(0) < 'A' || m_sAcum[iCont].charAt(0) > 'Z')
			{
				sNumero = ""; //Variable que lleva el acumulado de los numeros
				iColumn =0; // Variable que lleva la cuenta de los operandos
				iColumn2=0; // Variable que lleva la cuenta de los signos de operacion
				for(iChar=0; iChar < m_sAcum[iCont].length(); iChar++)
				{
					cCaracter=m_sAcum[iCont].charAt(iChar);
					switch(cCaracter)
					{
						case 'x':  // Variables
						case 'y':  m_sVectorNumeros[iCont][iColumn++] = String.valueOf(cCaracter);
								   break;

						case 'a':	//Es un Acumn. Lo convierte a letras mayusculas. Esto da una limitante de 25 Acums (A..Z).
									m_sVectorNumeros[iCont][iColumn++] = String.valueOf(m_sAcum[iCont].charAt(iChar+1));
									iChar++;
									break;
						case '*':
						case '/':
						case '+':
						case '-':
						case '^':   m_sVectorOperador[iCont][iColumn2++] = String.valueOf(cCaracter);
									break;
						default:    m_sVectorNumeros[iCont][iColumn++] = String.valueOf(cCaracter);
					} // Fin switch
				} // Fin for
				m_sVectorOperador[iCont][iColumn2] = "F";
			}	// Fin if

			// Imprime los resultados
	//		System.out.println("Pilas de Operadores y Operandos");
	//		for(iTemp=0; iTemp<=iColumn; iTemp++)
	//			System.out.println(m_sVectorNumeros[iCont][iTemp] + " #### " + m_sVectorOperador[iCont][iTemp]);
		} //Fin for

	} // Fin m�todo


	//Esta es la subrutina publica. Evalua a gran velocidad.
	public float CicloEvalua(float dX, float dY)
	{
	    int iCont;
		for(iCont=0; iCont<m_iNumAcums; iCont++)
			m_AcumFloat[iCont]=  EvaluaExpresion(iCont, dX, dY);

		return m_AcumFloat[iCont-1];
	}


	// Las expresiones simples son evaluadas
	float EvaluaExpresion(int iAcum, float dX, float dY)
	{
		char sOperando[] = new char[70];
		float dNumero[] = new float[70];
		Float fPrueba;
		float dAcumula=0;
		int iNum1, iNum2, iNum3, iLimArray=0, iIndice;

		for(iNum1=0;;iNum1++)
		{
			switch(m_sVectorNumeros[iAcum][iNum1].charAt(0))
			{
			   // Trae el valor de las variables
			   case 'x': dNumero[iNum1] = dX; break;
			   case 'y': dNumero[iNum1] = dY; break;

			   // Es un numero
			   case '1':
			   case '2':
			   case '3':
			   case '4':
			   case '5':
			   case '6':
			   case '7':
			   case '8':
			   case '9':
			   case '0':
						dNumero[iNum1]= (float) Integer.parseInt(m_sVectorNumeros[iAcum][iNum1]);
						break;
			   // Trae el valor del Acumn anterior
			   default:	iIndice = m_sVectorNumeros[iAcum][iNum1].charAt(0)-'A';
						dNumero[iNum1] = m_AcumFloat[iIndice];
						
			}
			sOperando[iNum1] = m_sVectorOperador[iAcum][iNum1].charAt(0);
			if ( sOperando[iNum1] =='F' )
				break;
		}
		iLimArray=iNum1;

		
		//Evalua para cada signo de operacion
//		for(iNum2=0; iNum2<=iLimArray; iNum2++)
//			System.out.println("Numero: #" + dNumero[iNum2] + "#  Operador: #" + sOperando[iNum2] + "#");
	

		//Evalua division. OJO: primero es la division luego la multiplicacion
		//Ejemplo: 5 + 24 / 2 * 3
		// Si evaluo primero la multiplicacion seria: 5 + 24 / 6 = 9
		// Si evaluo primero la divisi�n seria:       5 + 12 * 3 = 41
		try
		{
			for(iNum2=0; iNum2<=iLimArray; iNum2++)
			  while( sOperando[iNum2]=='/' )
			  {
				if ( dNumero[iNum2+1] == 0 )
				{
					dAcumula = 0;
					return dAcumula;
				}
				dNumero[iNum2] = dNumero[iNum2] / dNumero[iNum2+1];
				for(iNum3=iNum2+2; iNum3<=iLimArray+1; iNum3++)
				{
					dNumero[iNum3-1] = dNumero[iNum3];
					sOperando[iNum3-2] = sOperando[iNum3-1];
				}
				iLimArray--;
			  }
		}
		catch (ArithmeticException a)
		{
			dAcumula = 0;
			return dAcumula;
		}


		// Evaluo la multiplicacion
		for(iNum2=0; iNum2<=iLimArray; iNum2++)
		  while( sOperando[iNum2]=='*' )
		  {
			dNumero[iNum2] = dNumero[iNum2] * dNumero[iNum2+1];
			for(iNum3=iNum2+2; iNum3<=iLimArray+1; iNum3++)
			{
				dNumero[iNum3-1] = dNumero[iNum3];
				sOperando[iNum3-2] = sOperando[iNum3-1];
			}
		    iLimArray--;
		  }
		
		 //Finalmente me voy sumando y restando
		 dAcumula=dNumero[0];
		 for(iNum2=0; iNum2<iLimArray; iNum2++)
			if(sOperando[iNum2]=='+') dAcumula+=dNumero[iNum2+1];
			else
			if(sOperando[iNum2]=='-') dAcumula-=dNumero[iNum2+1];

		 return dAcumula;
	}
}
