import java.applet.*;
import java.awt.*;
import EvalExpr;

//Ser vivo
class cSerVivo
{
	//Instancia del evaluador de expresiones
	EvalExpr eEvalua;

	//Expresion o ADN del ser vivo
	String sExpresion;
	
	//Adaptacion del ser vivo al medio ambiente (entre mas se aproxime a cero mejor)
	float fAproxima;

	//El ambiente
	int m_iValEntra[] = new int[70];	//Valores de Entrada
	int m_iSerieNum[] = new int[70];	//Valores de salida
	int m_iContSerie;					//Numero de elementos en la serie


	public cSerVivo()
	{
		eEvalua = new EvalExpr();
	}

	public void vAmbiente(String m_sSerieNum)
	{
		int iCont;
		String sAcum="";
		m_iContSerie=0;

		// Ahora deshace la expresion en un arreglo de enteros
		for(iCont=0; iCont<=m_sSerieNum.length()-1; iCont++)
		{
			if (m_sSerieNum.charAt(iCont) != ',' )
				sAcum += m_sSerieNum.charAt(iCont);
			else
			{
				if (sAcum.length()>0)
				{
					m_iSerieNum[m_iContSerie]=Integer.parseInt(sAcum);
					m_iContSerie++;
					sAcum="";
				}
			}
		}
	}
	
	public void vAmbEntra(String m_sEntraVal)
	{
		int iCont;
		String sAcum="";
		m_iContSerie=0;

		// Ahora deshace la expresion en un arreglo de enteros
		for(iCont=0; iCont<=m_sEntraVal.length()-1; iCont++)
		{
			if (m_sEntraVal.charAt(iCont) != ',' )
				sAcum += m_sEntraVal.charAt(iCont);
			else
			{
				if (sAcum.length()>0)
				{
					m_iValEntra[m_iContSerie]=Integer.parseInt(sAcum);
					m_iContSerie++;
					sAcum="";
				}
			}
		}
	}
	
	public float dAdaptarse02() //Chequea su adaptacion a la serie (ambiente)
	{
		float dDiferenc; // La diferencia entre la serie y el valor que deduce la expresion
		float dTotDifer=0; //La sumatoria de diferencias
		float dResultado;
		int iCont;

	//	double dResult = eEvalua.dCapturaecuacion(sExpresion, 0, 0);
	//  sExpresion = "x+x";
	    float dResult = eEvalua.dCapturaecuacion(sExpresion, 0, 0);

		for(iCont=0; iCont<m_iContSerie; iCont++)
		{
		   dResult = eEvalua.CicloEvalua((float) m_iValEntra[iCont], 0);
		   dDiferenc = m_iSerieNum[iCont]- dResult;
		   if (dDiferenc<0) dDiferenc*=-1;
		   dTotDifer+=dDiferenc;
		}
		return dTotDifer;
	}
}
