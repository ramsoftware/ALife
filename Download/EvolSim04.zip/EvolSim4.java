/* *****************************************************************************
 Propiedad Intelectual
 Nombre:	Rafael Alberto Moreno Parra
 C.C.:		16.832.929 Jdi/Valle
 
 Programa:  Simulacion 04. Serie 1. Vida Artificial: Al principio se generan las
			expresiones de forma totalmente aleatoria por un numero determinado de
			veces y luego se toma las expresiones mas aptas para mutarlas (modificando
			operadores y operandos, y en algunas ocasiones adicionando), para luego
			volverlas a evaluar.

 Fecha:		Enero 22 de 1999

****************************************************************************** */
import java.applet.*;
import java.awt.*;
import java.util.*;
import EvalExpr; // Evaluador de expresiones
import cMutacion;
import cSerVivo;


//Applet
public class EvolSim4 extends Applet implements Runnable
{
	//Trabajar con hilos
	private Thread	 m_thRunner = null;

	//Variables globales
	String m_sEntraVal = new String(); //Valores de Entrada
	String m_sSerieNum = new String(); //Valores de Salida

	//Ser vivo
	cSerVivo objSerVivo;

	//Mutacion
	cMutacion objMutacion;

	//Maximo # de intentos o seres generados
	int m_iTotalIntentos;
	
	//Contador de intentos al azar antes de empezar a mutar los mas aptos
	int m_iIntentoAzar;

	//Probabilidades
	int m_iProbX, m_iProbP, m_iProbN, m_iProbMutX, m_iProbMutN;
	int m_iPosibAleat, m_iPosibAdic, m_iPosibMutac;
	
	//Longitud de la expresion
	int m_iLongExpr;
	
	//Contadores de las estrategias
	int m_iNumAleat;
	int m_iNumAdic;
	int m_iNumMuta;



	public EvolSim4()
	{
		// TODO: Add constructor code here
	}

	public String getAppletInfo()
	{
		return "Name: EvolSim1\r\n" +
		       "Author: Rafael Alberto Moreno Parra\r\n" +
		       "Created with Microsoft Visual J++ Version 1.1\r\n" +
		       "\r\n" +
		       "A-Life: Vida Artificial\r\n" +
		       "Simulacion IV: La simulaci�n consiste en generar aleatoriamente expresiones\r\n" +
		       "matem�ticas de una variable independiente X por cierto numero de intentos\r\n" +
		       "luego se cambian los operadores y operandos, y en ocasiones se adiciona\r\n" +
		       "Solo sobrevive la expresi�n que su serie se acerque m�s a la predefinida.\r\n" +
		       "\r\n" +
		       "\r\n" +
		       "\r\n" +
		       "";
	}


	public void init()
	{
    	int iCont;
		String sAcum="";
		
		resize(620, 370);

		//Inicializa el ambiente por defecto
		m_sEntraVal="1,2,3,4,5,6,7,8,9,10,11,12,13,";
		m_sSerieNum="1,-2,3,-4,5,-6,7,-8,9,-10,11,-12,13,";

		// Llama el cuadro de dialogo con valores por defecto
		txtEntraX.setText(m_sEntraVal);
		txtSerie.setText(m_sSerieNum);
		txtTotalIntento.setText("30000");

		//Inicializa con valores por defecto
		txtLongExpr.setText("10");
		txtProbX.setText("50");
		txtProbP.setText("0");
		txtProbN.setText("50");
		txtProbMutX.setText("50");
		txtProbMutN.setText("50");
		txtProbAleat.setText("20");
		txtProbAdic.setText("0");
		txtProbMuta.setText("80");
		

		//Ser vivo
		objSerVivo = new cSerVivo();

		//Mutacion
		objMutacion = new cMutacion();

		IniciarValores();
	
		//{{INIT_CONTROLS
		setLayout(null);
		setBackground(java.awt.Color.lightGray);
		setSize(631,394);
		lblSalida.setText("Serie Salida (Y):");
		add(lblSalida);
		lblSalida.setBounds(12,36,108,24);
		lblSerieEntra.setText("Serie Entrada (X):");
		add(lblSerieEntra);
		lblSerieEntra.setBounds(12,12,108,24);
		add(txtEntraX);
		txtEntraX.setBounds(132,12,408,24);
		add(txtSerie);
		txtSerie.setBounds(132,36,408,24);
		lblProbX.setText("Probabilidad de X:");
		add(lblProbX);
		lblProbX.setBounds(12,60,108,23);
		lblProbN.setText("de 1..9");
		add(lblProbN);
		lblProbN.setBounds(192,60,36,24);
		lblProbParent.setText("Parentesis");
		add(lblProbParent);
		lblProbParent.setBounds(300,60,72,24);
		lblPosibVida.setText("Probabilidades de las tres(3) estrat�gias de adaptaci�n");
		add(lblPosibVida);
		lblPosibVida.setBounds(12,108,312,24);
		lblGenAleatoria.setText("1. Generaci�n Aleatoria");
		add(lblGenAleatoria);
		lblGenAleatoria.setBounds(12,132,144,24);
		lblAdicion.setText("2. Adici�n Operadores y Operandos");
		add(lblAdicion);
		lblAdicion.setBounds(12,156,204,24);
		lblMutacion.setText("3. Mutacion (Cambio de partes)");
		add(lblMutacion);
		lblMutacion.setBounds(12,180,204,24);
		lblPrimer.setText("1er. Lugar:");
		add(lblPrimer);
		lblPrimer.setBounds(12,252,72,20);
		lblSegundo.setText("2do. Lugar");
		add(lblSegundo);
		lblSegundo.setBounds(12,276,72,21);
		lblTercero.setText("3er. Lugar");
		add(lblTercero);
		lblTercero.setBounds(12,300,72,15);
		lblSerVivo.setText("Ser Vivo");
		add(lblSerVivo);
		lblSerVivo.setBounds(216,228,60,24);
		add(txtProbX);
		txtProbX.setBounds(132,60,37,24);
		add(txtProbN);
		txtProbN.setBounds(240,60,37,24);
		add(txtProbP);
		txtProbP.setBounds(372,60,37,24);
		add(txtProbAleat);
		txtProbAleat.setBounds(228,132,40,22);
		add(txtProbAdic);
		txtProbAdic.setBounds(228,156,40,22);
		add(txtProbMuta);
		txtProbMuta.setBounds(228,180,40,22);
		add(txtExpr01);
		txtExpr01.setBounds(84,252,396,24);
		add(txtExpr02);
		txtExpr02.setBounds(84,276,396,24);
		add(txtExpr03);
		txtExpr03.setBounds(84,300,396,24);
		lblProbMutX.setText("Probabilidad de X");
		add(lblProbMutX);
		lblProbMutX.setBounds(276,180,108,24);
		lblProbMutN.setText("de 1 a 9:");
		add(lblProbMutN);
		lblProbMutN.setBounds(444,180,59,27);
		lblIntento.setText("Intento #");
		add(lblIntento);
		lblIntento.setBounds(12,336,55,24);
		add(txtIntento);
		txtIntento.setBounds(84,336,72,24);
		cmdOK.setLabel("Simule");
		add(cmdOK);
		cmdOK.setBackground(java.awt.Color.lightGray);
		cmdOK.setBounds(552,12,72,24);
		cmdStop.setLabel("Detener");
		add(cmdStop);
		cmdStop.setBackground(java.awt.Color.lightGray);
		cmdStop.setBounds(552,36,72,24);
		add(txtProbMutX);
		txtProbMutX.setBounds(384,180,59,22);
		add(txtProbMutN);
		txtProbMutN.setBounds(504,180,59,22);
		lblSumaP.setText("Suma 100%");
		add(lblSumaP);
		lblSumaP.setBounds(420,60,68,24);
		lblAprox.setText("Aproximaci�n");
		add(lblAprox);
		lblAprox.setBounds(492,228,84,19);
		add(txtAprox01);
		txtAprox01.setBounds(492,252,72,24);
		add(txtAprox02);
		txtAprox02.setBounds(492,276,72,24);
		add(txtAprox03);
		txtAprox03.setBounds(492,300,72,24);
		lblSumaCien.setText("Suma 100%");
		add(lblSumaCien);
		lblSumaCien.setBounds(228,204,72,24);
		lblLongExpr.setText("Longitud de la Expresi�n:");
		add(lblLongExpr);
		lblLongExpr.setBounds(12,84,156,24);
		add(txtLongExpr);
		txtLongExpr.setBounds(180,84,48,22);
		lblNumAleat.setText("Total Aleatoria:");
		add(lblNumAleat);
		lblNumAleat.setBounds(168,336,84,24);
		lblNumAdic.setText("Total Adiciones:");
		add(lblNumAdic);
		lblNumAdic.setBounds(312,336,96,24);
		lblNumMuta.setText("Total Mutaciones:");
		add(lblNumMuta);
		lblNumMuta.setBounds(456,336,96,24);
		add(txtNumAleat);
		txtNumAleat.setBounds(252,336,62,23);
		add(txtNumAdic);
		txtNumAdic.setBounds(408,336,47,23);
		add(txtNumMuta);
		txtNumMuta.setBounds(564,336,55,21);
		lblTotalIntentos.setText("Maximo # de intentos (0 es infinito)");
		add(lblTotalIntentos);
		lblTotalIntentos.setBounds(252,84,192,24);
		add(txtTotalIntento);
		txtTotalIntento.setBounds(456,84,67,20);
		//}}
	
		//{{REGISTER_LISTENERS
		SymAction lSymAction = new SymAction();
		cmdOK.addActionListener(lSymAction);
		cmdStop.addActionListener(lSymAction);
		//}}
	}

	public void start()
	{
		if (m_thRunner == null)
		{
			m_thRunner = new Thread(this);
			m_thRunner.start();
		}
	}
	
	public void stop()
	{
		if (m_thRunner != null)
		{
			m_thRunner.stop();
			m_thRunner=null;
		}	

	}

	public void run()
	{
		float dTotDifer=0;
		Float fPrimerP, fSegundP, fTercerP;
		float dPrimerP=999999, dSegundP=999999, dTercerP=99999;
		int iSerVivo, iEstrateg, iContIntento=0;

		while(true)
		{
			/* Hace una mezcla de creaci�n espont�nea, adici�n y mutaci�n
			1. Al principio genera totalmente aleatorio.
			2. Despues de un numero determinado de intentos selecciona entre tres estrategias:
				a. Generaci�n aleatoria
				b. Adicion de Operadores y Operandos
				c. Mutacion de Operadores y Operandos
			3. En los casos b. y c. se selecciona al azar cual de las tres expresiones
			   se modificara.
			
			El usuario podra configurar en que porcentaje se cumplen las estrategias */

			//Los primeros seres vivos son totalmente aleatorios, luego vienen las mutaciones del mas apto
			if (m_iIntentoAzar>0)
			{
				objMutacion.vCrearExpresion(m_iLongExpr, m_iProbX, m_iProbP, m_iProbN);
				m_iIntentoAzar--;
			}
			else
			{
				//Selecciona uno de los puestos al azar
				iSerVivo = objMutacion.iMetodoSer(34, 33, 33);
				switch(iSerVivo)
				{
					case 1: objMutacion.sAcum = txtExpr01.getText(); break;
					case 2: objMutacion.sAcum = txtExpr02.getText(); break;
					case 3: objMutacion.sAcum = txtExpr03.getText(); break;
				}

				//Selecciona una estrategia al azar
				iEstrateg = objMutacion.iMetodoSer(m_iPosibAleat, m_iPosibAdic, m_iPosibMutac);
				switch(iEstrateg)
				{
					case 1:
					    m_iNumAleat++;
						objMutacion.vCrearExpresion(m_iLongExpr, m_iProbX, m_iProbP, m_iProbN);
						txtNumAleat.setText(String.valueOf(m_iNumAleat));
						break;
					case 2:
					    m_iNumAdic++;
						objMutacion.vAdicMutacion(m_iProbX, m_iProbP, m_iProbN);
						txtNumAdic.setText(String.valueOf(m_iNumAdic));
						break;
					case 3:
					    m_iNumMuta++;
						objMutacion.vMutarPartes(m_iProbMutX, m_iProbMutN);
						txtNumMuta.setText(String.valueOf(m_iNumMuta));
						break;
				}
			}
			//Sale un ser vivo o una mutaci�n de los m�s aptos
			if (objMutacion.sAcum.length()>80) continue;

			//Sube el numero de seres generados
			iContIntento++;
			if (iContIntento > m_iTotalIntentos && m_iTotalIntentos != 0) break;
			txtIntento.setText(String.valueOf(iContIntento));

			//La envia a evaluar
			objSerVivo.sExpresion = objMutacion.sAcum;
			dTotDifer = objSerVivo.dAdaptarse02();

    		//Ahora se ordena los primeros tres puestos en adaptaci�n.

			//Evita que los tres puestos se llenen con la misma expresion
			if (objSerVivo.sExpresion.compareTo(txtExpr01.getText())==0 ||
				objSerVivo.sExpresion.compareTo(txtExpr02.getText())==0 ||
				objSerVivo.sExpresion.compareTo(txtExpr03.getText())==0 )
					dTotDifer=99999999;

			if (dTotDifer<dPrimerP)
			{
				//Mueve los puestos
				txtExpr03.setText(txtExpr02.getText());
				txtAprox03.setText(txtAprox02.getText());
				dTercerP = dSegundP;
				
				txtExpr02.setText(txtExpr01.getText());
				txtAprox02.setText(txtAprox01.getText());
				dSegundP = dPrimerP;
				
				//Coloca el primer lugar
				txtExpr01.setText(objSerVivo.sExpresion);
				txtAprox01.setText(String.valueOf(dTotDifer));
				dPrimerP = dTotDifer;
			}
			else if (dTotDifer<dSegundP)
			{
				//Mueve los puestos
				txtExpr03.setText(txtExpr02.getText());
				txtAprox03.setText(txtAprox02.getText());
				dTercerP = dSegundP;
				
				//Coloca el segundo lugar
				txtExpr02.setText(objSerVivo.sExpresion);
				txtAprox02.setText(String.valueOf(dTotDifer));
				dSegundP=dTotDifer;
			}
			else if (dTotDifer<dTercerP)
			{
				//Coloca el tercer lugar
				txtExpr03.setText(objSerVivo.sExpresion);
				txtAprox03.setText(String.valueOf(dTotDifer));
				dTercerP=dTotDifer;
			}
		}
	}

	void IniciarValores()
	{
		int iCont;
		String sAcum="";

		m_sSerieNum = txtSerie.getText();
		m_sEntraVal = txtEntraX.getText();
		objSerVivo.vAmbiente(m_sSerieNum);
		objSerVivo.vAmbEntra(m_sEntraVal);
		
		//Valores iniciales de los puestos
		txtExpr01.setText("??????????????");
		txtExpr02.setText("??????????????");
		txtExpr03.setText("??????????????");
		txtAprox01.setText("99999999");
		txtAprox02.setText("99999999");
		txtAprox03.setText("99999999");

		//Contador de Intentos
		m_iTotalIntentos = Integer.parseInt(txtTotalIntento.getText());

		//Probabilidades de creacion de expresiones
		m_iProbX = Integer.parseInt(txtProbX.getText());
		m_iProbP = Integer.parseInt(txtProbP.getText());
		m_iProbN = Integer.parseInt(txtProbN.getText());
		m_iProbMutX = Integer.parseInt(txtProbMutX.getText());
		m_iProbMutN = Integer.parseInt(txtProbMutN.getText());
		m_iPosibAleat = Integer.parseInt(txtProbAleat.getText());
		m_iPosibAdic = Integer.parseInt(txtProbAdic.getText());
		m_iPosibMutac = Integer.parseInt(txtProbMuta.getText());

		//Contador de Intentos antes de Mutar
		m_iIntentoAzar = 3;
		
		//Longitud de la expresion que se generar� aleatoriamente
		m_iLongExpr = Integer.parseInt(txtLongExpr.getText());
		
		//Inicializa contadores de estrategias
		m_iNumAleat=m_iIntentoAzar;
		m_iNumAdic=0;
		m_iNumMuta=0;
	}


	//{{DECLARE_CONTROLS
	java.awt.Label lblSalida = new java.awt.Label();
	java.awt.Label lblSerieEntra = new java.awt.Label();
	java.awt.TextField txtEntraX = new java.awt.TextField();
	java.awt.TextField txtSerie = new java.awt.TextField();
	java.awt.Label lblProbX = new java.awt.Label();
	java.awt.Label lblProbN = new java.awt.Label();
	java.awt.Label lblProbParent = new java.awt.Label();
	java.awt.Label lblPosibVida = new java.awt.Label();
	java.awt.Label lblGenAleatoria = new java.awt.Label();
	java.awt.Label lblAdicion = new java.awt.Label();
	java.awt.Label lblMutacion = new java.awt.Label();
	java.awt.Label lblPrimer = new java.awt.Label();
	java.awt.Label lblSegundo = new java.awt.Label();
	java.awt.Label lblTercero = new java.awt.Label();
	java.awt.Label lblSerVivo = new java.awt.Label();
	java.awt.TextField txtProbX = new java.awt.TextField();
	java.awt.TextField txtProbN = new java.awt.TextField();
	java.awt.TextField txtProbP = new java.awt.TextField();
	java.awt.TextField txtProbAleat = new java.awt.TextField();
	java.awt.TextField txtProbAdic = new java.awt.TextField();
	java.awt.TextField txtProbMuta = new java.awt.TextField();
	java.awt.TextField txtExpr01 = new java.awt.TextField();
	java.awt.TextField txtExpr02 = new java.awt.TextField();
	java.awt.TextField txtExpr03 = new java.awt.TextField();
	java.awt.Label lblProbMutX = new java.awt.Label();
	java.awt.Label lblProbMutN = new java.awt.Label();
	java.awt.Label lblIntento = new java.awt.Label();
	java.awt.TextField txtIntento = new java.awt.TextField();
	java.awt.Button cmdOK = new java.awt.Button();
	java.awt.Button cmdStop = new java.awt.Button();
	java.awt.TextField txtProbMutX = new java.awt.TextField();
	java.awt.TextField txtProbMutN = new java.awt.TextField();
	java.awt.Label lblSumaP = new java.awt.Label();
	java.awt.Label lblAprox = new java.awt.Label();
	java.awt.TextField txtAprox01 = new java.awt.TextField();
	java.awt.TextField txtAprox02 = new java.awt.TextField();
	java.awt.TextField txtAprox03 = new java.awt.TextField();
	java.awt.Label lblSumaCien = new java.awt.Label();
	java.awt.Label lblLongExpr = new java.awt.Label();
	java.awt.TextField txtLongExpr = new java.awt.TextField();
	java.awt.Label lblNumAleat = new java.awt.Label();
	java.awt.Label lblNumAdic = new java.awt.Label();
	java.awt.Label lblNumMuta = new java.awt.Label();
	java.awt.TextField txtNumAleat = new java.awt.TextField();
	java.awt.TextField txtNumAdic = new java.awt.TextField();
	java.awt.TextField txtNumMuta = new java.awt.TextField();
	java.awt.Label lblTotalIntentos = new java.awt.Label();
	java.awt.TextField txtTotalIntento = new java.awt.TextField();
	//}}

	class SymAction implements java.awt.event.ActionListener
	{
		public void actionPerformed(java.awt.event.ActionEvent event)
		{
			Object object = event.getSource();
			if (object == cmdOK)
				cmdOK_ActionPerformed(event);
			else if (object == cmdStop)
				cmdStop_ActionPerformed(event);
		}
	}

	void cmdOK_ActionPerformed(java.awt.event.ActionEvent event)
	{
	    stop();
	    IniciarValores();
	    start();
	}

	void cmdStop_ActionPerformed(java.awt.event.ActionEvent event)
	{
		stop();
	}
}
