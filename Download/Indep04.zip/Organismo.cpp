/*
Autor:		Rafael Alberto Moreno Parra
URL:		http://www.geocities.com/krousky
Clase:		Organismo
Lenguaje:	C++
Fecha:		05 de Febrero de 2002

Prop�sito:


M�todos:
IniciaSemillaT: Inicializa la semilla dependiendo del tiempo
IniciaSemillaR: Inicializa la semilla aleatoriamente
sDisplayADN: Despliega el organismo como si fuera c�digo Java
vCreaADN: Crea el organismo, llamando la funci�n que hace sus genes
vHaceGen: Crea una linea de codigo fuente (la llam� Gen). El formato es:
          label, [, IF/SET, Variable, =/>/</!, (, expresion, ), Goto, Label, ]
          para mayor velocidad, se ubica en una clase el Gen
vEvaluaPrevio: Optimiza la velocidad de evaluaci�n del organismo en un
               ambiente.
fEvalOrganismo: Evalua el organismo en el ambiente
vMutaGen: Mutaci�n suave de un gen del organismo

*/

#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <float.h>
#include "Organismo.h"

//Constructor
Organismo::Organismo()
{
	time(&ltime1);
}


//Inicializa la semilla dependiendo del tiempo
void Organismo::IniciaSemillaT()
{
	time_t ltime2;
	do
	{
		time(&ltime2);
	}while(ltime2==ltime1);
	srand( ltime2 );
	ltime1 = ltime2;
}

//Inicializa la semilla aleatoriamente
void Organismo::IniciaSemillaR()
{
	srand(rand());
};

//Fija las probabilidades del Organismo
void Organismo::vInicio (bool bGenRandom, unsigned int iMaxGenes, unsigned int iMaxiCiclos,
                   unsigned int iPosibIf, unsigned int iPosibSet,
                   unsigned int iPosIg, unsigned int iPosMay, unsigned int iPosMen, unsigned int iPosDif,
                   unsigned int iLongExpr, unsigned int iPosibV1, unsigned int iPosibV2, unsigned int iPosibP, unsigned int iPosibN,
				   unsigned int iTotalFuncion, unsigned int iTotalSensor, unsigned int iTotalAccion)
{
		stProbOrg.bGenRandom = bGenRandom; //N�mero de Genes fijos o aleatorio
		stProbOrg.iMaxGenes = iMaxGenes; //M�ximo n�mero de genes de los genes
		stProbOrg.iMaxiCiclos = iMaxiCiclos; //Maximo numero de ciclos que se gastaran para evaluar el organismo
        stProbOrg.iPosibIf = iPosibIf; //Posibilidad de If
		stProbOrg.iPosibSet = iPosibSet; //Posibilidad de Asignaci�n
        stProbOrg.iPosIg = iPosIg; //Posibilidad de = en el IF
		stProbOrg.iPosMay = iPosMay; //Posibilidad de > en el IF
		stProbOrg.iPosMen = iPosMen; //Posibilidad de < en el IF
		stProbOrg.iPosDif = iPosDif; //Posibilidad de <> en el IF
		stProbOrg.iLongExpr = iLongExpr; //Longitud maxima de la expresi�n
		stProbOrg.iPosibV1 = iPosibV1; //Posibilidad de variable 1 en la expresion 
		stProbOrg.iPosibV2 = iPosibV2; //Posibilidad de variable 2 en la expresion 
		stProbOrg.iPosibP = iPosibP; //Posibilidad de parentesis en la expresion 
		stProbOrg.iPosibN = iPosibN; //Posibilidad de numero en la expresion 

		m_iTotalFuncion = iTotalFuncion;
		m_iTotalSensor  = iTotalSensor;
		m_iTotalAccion  = iTotalAccion;
};

// Crea el organismo, llamando la funci�n que hace sus genes
void Organismo::vCreaADN ()
{
    unsigned int iCont;

	if(stProbOrg.bGenRandom)
		m_iMaxGenOrg = abs(rand() % stProbOrg.iMaxGenes ) + 1; //Crea organismos entre 1 y iMaxGenes instrucciones

    for (iCont=1; iCont<=m_iMaxGenOrg; iCont++)
		vHaceGen(iCont);
};

/* Crea una linea de codigo fuente (la llam� Gen). El formato es:
   label, [, IF/SET, Variable, =/>/</!, (, expresion, ), Goto, Label, ]
   para mayor velocidad, se ubica en una clase el Gen */
void Organismo::vHaceGen(unsigned int iLabel)
{
	unsigned int iAleatorio;

    //Por defecto, nunca se ha ejecutado esta instruccion
    m_oGen[iLabel].bEjecuta = false;
       
    //Decide si usa =, >, <, ! Estos son tenidos en cuenta si es un IF condicional
   	iAleatorio = abs(rand() % 100) + 1;
	if (iAleatorio<=stProbOrg.iPosIg)
		m_oGen[iLabel].cOperacion = '=';
	else if (iAleatorio<=stProbOrg.iPosIg+stProbOrg.iPosMay)
		m_oGen[iLabel].cOperacion = '>';
    else if (iAleatorio<=stProbOrg.iPosIg+stProbOrg.iPosMay+stProbOrg.iPosMen)
		m_oGen[iLabel].cOperacion = '<';
	else
		m_oGen[iLabel].cOperacion = '!';

    //Trae la expresion (SET o IF) y los par�metros (FUNCION)
    objGenExpr.vCrearExpresion(stProbOrg.iLongExpr, stProbOrg.iPosibV1, stProbOrg.iPosibV2, stProbOrg.iPosibP, stProbOrg.iPosibN);
    strcpy(m_oGen[iLabel].sbExpresion,objGenExpr.sExpresion);

	//Decide si es un IF, un SET o una FUNCION
	iAleatorio = abs(rand() % 100) + 1;
	if (iAleatorio<=stProbOrg.iPosibIf)
		m_oGen[iLabel].cTipInst = 'I'; //If
	else if (iAleatorio<=stProbOrg.iPosibIf+stProbOrg.iPosibSet)
		m_oGen[iLabel].cTipInst = 'S'; //Set o Asignacion
	else
	{
		m_oGen[iLabel].cTipInst = 'F'; //Funcion	
		m_oGen[iLabel].iCodFunc = abs(rand() % m_iTotalFuncion) + 1;
	}
    
	//Decide que variable accion va a usar
	m_oGen[iLabel].iVarAccion = abs(rand() % m_iTotalAccion) + 1;

    //Decide Variable Expresion 1 (son sensores)
	m_oGen[iLabel].iVarExpr1 = abs(rand() % m_iTotalSensor) + 1;

	//Decide Variable Expresion 1 (son sensores)
	m_oGen[iLabel].iVarExpr2 = abs(rand() % m_iTotalSensor) + 1;

	//Decide que variable sensor va a usar
	do
	{
   		iAleatorio = abs(rand() % m_iTotalSensor) + 1;
	} while (iAleatorio == m_oGen[iLabel].iVarExpr1 || iAleatorio == m_oGen[iLabel].iVarExpr1);
	m_oGen[iLabel].iVarSensor = iAleatorio;


    //Decide hacia que label va (entre 1 y MaxGenes) o si es el FIN, el resultado siempre sera Y
    unsigned int iNumCiclo;
	do
	{
		iNumCiclo = abs(rand() % (stProbOrg.iMaxGenes+1));
	} while (iNumCiclo==iLabel); //Evita el goto hacia la misma instruccion
    m_oGen[iLabel].iGotoLabel = iNumCiclo; //Retorna 0 para FINalizar

};

    
/* Evalua el organismo en el ambiente
Retorna:
-1 Si hubo un error
0 Finalizo la ejecucion
1 Si ejecuta alguna funcion
*/
   
int Organismo::fEvalOrganismo (unsigned int *iOrgGenInst,
							   unsigned int *iFuncion)
{                   
	/* Interpretador de los algoritmos gen�ticos */
    float fValor1=0, fValor2=0, fResultado=0, fCompara=0;
    unsigned int iGenOrg; //# de Instrucci�n de inicio
    unsigned int iNumCiclos=0; //Contador de Ciclos
    
	
	iGenOrg = *iOrgGenInst; //Continua por donde estaba
	
    while (iGenOrg!=0 && iGenOrg<=m_iMaxGenOrg)
    {
		//Coloca a TRUE la instruci�n porque se ejecuta
        m_oGen[iGenOrg].bEjecuta = true;
            
        //Aumenta el # de Ciclos
        iNumCiclos++;

		//M�ximo n�mero de ciclos que se evaluar�n del organismo, si el
        //organismo supera este n�mero de ciclos sin dar con un resultado
        //es desechado.
		if (iNumCiclos > stProbOrg.iMaxiCiclos)
			return -1; //Error ejecutando
            
		//Es una funcion
		if (m_oGen[iGenOrg].cTipInst == 'F')
		{
			//Estas son las respuestas del organismo a las funciones
			*iFuncion = m_oGen[iGenOrg].iCodFunc;
			*iOrgGenInst = iGenOrg+1;
			return 1; //Ejecuta una funcion
		}

        //Que variable esta jugando dentro de la expresion
        fValor1 = fSensor[m_oGen[iGenOrg].iVarExpr1];
        fValor2 = fSensor[m_oGen[iGenOrg].iVarExpr2];

        //Evalua la expresion
		fResultado = m_eEvalua.dCapturaEcuacion(m_oGen[iGenOrg].sbExpresion, fValor1, fValor2);
		if (m_eEvalua.ERRORMATEMATICO==1 ||
			fResultado >= 9999999 || fResultado <= -9999999 )
			return -1; //Error ejecutando

		if (m_oGen[iGenOrg].cTipInst == 'S') //Si es un SET asigna el valor a la variable del Gen
		{
			fAccion[m_oGen[iGenOrg].iVarAccion] = fResultado;
		    iGenOrg++; //Ignora el salto en un SET
        }
        else //Es un If condicional
        {
			fCompara = fSensor[m_oGen[iGenOrg].iVarSensor];
                
            switch(m_oGen[iGenOrg].cOperacion)
            {
				case '>': if (fCompara > fResultado) 
		                      iGenOrg=m_oGen[iGenOrg].iGotoLabel;
		                  else
						      iGenOrg++;
		                  break;
                case '<': if (fCompara < fResultado) 
		                      iGenOrg=m_oGen[iGenOrg].iGotoLabel;
		                  else
					         iGenOrg++;
		                  break;
		        case '=': if (fCompara == fResultado) 
		                      iGenOrg=m_oGen[iGenOrg].iGotoLabel;
		                  else
						      iGenOrg++;
		                  break;
                case '!': if (fCompara != fResultado) 
		                      iGenOrg=m_oGen[iGenOrg].iGotoLabel;
		                  else
						      iGenOrg++;
		                  break;
		    }
		}
	 }//Fin de la evaluacion del ser vivo
	 return 0; //Finalizo la ejecucion
};

//Despliega el organismo como si fuera c�digo Delphi
void Organismo::sDisplayADN(char *sbADN)
{
	char sExprTemp1[250], sExprTemp2[250]="";
	char cEnter[4];
    cEnter[0]= '\n';
    cEnter[1]= '\0';

	strcpy(sbADN,"function Organismo.fSerVivo(Sensores: real, Acciones: real):real;");
	strcat(sbADN,cEnter);
	strcat(sbADN, "begin");
    strcat(sbADN,cEnter);

	for (unsigned int iCont=1; iCont<= m_iMaxGenOrg; iCont++)
    {
		sprintf(sExprTemp1, "%d: ", iCont);
		strcat(sbADN, sExprTemp1);

        //Reemplaza la expresion por la variable activa
		int iLongExpr = strlen(m_oGen[iCont].sbExpresion);
		sExprTemp1[2]='\0';
		sExprTemp2[0]='\0';
        for (int iChar=0; iChar < iLongExpr; iChar++)
        {
			char cCharAt = m_oGen[iCont].sbExpresion[iChar];
            if (cCharAt=='x')
				sprintf(sExprTemp1, "S%d", m_oGen[iCont].iVarExpr1); 
            else if (cCharAt=='y')
				sprintf(sExprTemp1, "S%d", m_oGen[iCont].iVarExpr1);
			else
				sprintf(sExprTemp1, "%c", cCharAt);
   			strcat(sExprTemp2, sExprTemp1);
        }
                    
        //Organiza los if y asignaciones
        if (m_oGen[iCont].cTipInst == 'I')
        {
			sprintf(sExprTemp1, "S%d", m_oGen[iCont].iVarSensor);
			strcat(sbADN, "if ");  //if(
			strcat(sbADN, sExprTemp1);  //if ( Z
			strcat(sbADN, " ");
			sprintf(sExprTemp1, "%c", m_oGen[iCont].cOperacion); // if ( Z >
			strcat(sbADN, sExprTemp1);
			strcat(sbADN, " ");
			strcat(sbADN, sExprTemp2); // if (Z > 4*X*X
			strcat(sbADN, " then Goto ");
			sprintf(sExprTemp1, "%d", m_oGen[iCont].iGotoLabel);
			strcat(sbADN, sExprTemp1); // if (Z > 4*X*X ) goto 4
			strcat(sbADN, ";");
		}
        else if (m_oGen[iCont].cTipInst == 'S')
		{
			sprintf(sExprTemp1, "A%d", m_oGen[iCont].iVarAccion);
			strcat(sbADN, sExprTemp1);
			strcat(sbADN, " := ");
			strcat(sbADN, sExprTemp2);
			strcat(sbADN, ";");
		}
		else
		{
			sprintf(sExprTemp1, "F:%d;", m_oGen[iCont].iCodFunc);
			strcat(sbADN, sExprTemp1);
		}
        strcat(sbADN, cEnter);
    }    
    //Finaliza la expresion
	strcat(sbADN, "end;");
	strcat(sbADN, cEnter);
};


