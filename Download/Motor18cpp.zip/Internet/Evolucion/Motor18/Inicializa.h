/*
Autor:		Rafael Alberto Moreno Parra
URL:		http://www.geocities.com/krousky
Clase:		Inicializa.
Lenguaje:	C++

Prop�sito:
Inicializa las variables para la simulaci�n

M�todos:

*/
class Inicializa {
public:

	struct stDatosSimul
	{
   		//Probabilidades, estos datos se leen de un archivo de inicializaci�n
		unsigned int iPosibIf; //Posibilidad de que la instrucci�n sea IF
		unsigned int iPosibSet; //Posibilidad de que la instrucci�n sea Asignaci�n
		unsigned int iPosW; //Posibilidad de que la variable activa sea W
		unsigned int iPosX; //Posibilidad de que la variable activa sea X
		unsigned int iPosY; //Posibilidad de que la variable activa sea Y
		unsigned int iPosZ; //Posibilidad de que la variable activa sea Z
		unsigned int iPosIg; //Posibilidad de comparativo =
		unsigned int iPosMay;//Posibilidad de comparativo >
		unsigned int iPosMen;//Posibilidad de comparativo <
		unsigned int iPosDif;//Posibilidad de comparativo !
		unsigned int iLongExpr; //Longitud de las expresiones
		unsigned int iPosibX; //Posibilidad de salir X
		unsigned int iPosibP; //Posibilidad de salir Parentesis
		unsigned int iPosibN; //Posibilidad de salir N�mero
		unsigned int iNumCiclos; //Maximo CPU
		unsigned int iNumInstMin; //Numero de instrucciones(genes) m�nimo generado
		unsigned int iNumInstMax; //Numero de instrucciones(genes) m�ximo generado
		unsigned int iNumOrganismos; //Numero de instrucciones(genes) m�ximo generado
		unsigned int iParcCiclo; //Parte del Ciclo a evaluar
		unsigned int iDetiene; //En cuantos N*1000 ciclos se detiene la simulaci�n si la condici�n de error no lo permite

		float fMaximoError; //M�ximo Error para aceptar organismo
		char sAmbiente[80]; //Ambiente
		unsigned int iXini, iXfin; //Donde evaluo el ambiente
		char sArchResult[50]; //Archivo donde se guarda el resultado
	};  

	struct stDatosSimul stDatVA; //Datos Vida Artificial
	void vPantallaIni(void);
    int vLeeArchivoIni(void);
	void vArchResult(void);
    void vGrabaResult(int, char *, unsigned int, float);
	void vImprMacroOrg(unsigned int, unsigned int, char *, float);
	void vImprTiempoFin(void);
};
