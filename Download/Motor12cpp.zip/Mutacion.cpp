/*
Autor:		Rafael Alberto Moreno Parra
URL:		http://www.geocities.com/krousky
Clase:		Mutacion
Lenguaje:	C++

Prop�sito:
Clase de generaci�n/modificaci�n de expresiones matem�ticas en forma
aleatoria.

M�todos:
vIniLista: Optimiza la generaci�n/modificaci�n de expresiones
vCrearExpresion: Genera expresi�n
vMutarPartes: Modifica expresi�n

*/

#include <stdlib.h>
#include <string.h>
#include "Mutacion.h"

/* Se llena de manera previa a las simulaciones, sirve para
   la construcci�n r�pida de las expresiones */
int Mutacion::vIniLista(unsigned int iProbN, unsigned int iProbX, unsigned int iProbP)
{
   unsigned int iCont;
   unsigned char cCambiaNum='1', cCambiaPar='(';

   //Valida que la sumatoria de las probabilidades sea 100
   if ( (iProbN+iProbX+iProbP) != 100 ) return -1; //Es un error

   //Inicializa cadena sOperNumPar
   for(iCont=0; iCont<=100; iCont++) sOperNumPar[iCont]='\0';

   //Crea el vector de selecci�n r�pida
   for(iCont=0; iCont<100;iCont++)
   {
       if (iCont<iProbX)
          sOperNumPar[iCont]='x';
       else if(iCont>=iProbX && iCont<(iProbX+iProbN))
       {
          sOperNumPar[iCont]=cCambiaNum;
          cCambiaNum++;
          if (cCambiaNum>'9') cCambiaNum='1';
       }   
       else //Los par�ntesis
       {
          switch(cCambiaPar)
          {
             case '(': sOperNumPar[iCont]=cCambiaPar;
                       cCambiaPar=')';
                       break;
             case ')': sOperNumPar[iCont]=cCambiaPar;
                       cCambiaPar='(';
                       break;
          }
       }
   }
   return 1; //Todo bien
}

//Funci�n que crea la expresi�n en forma aleatoria
void Mutacion::vCrearExpresion(unsigned int iLongExpr, unsigned int iPosibX, unsigned int iPosibP, unsigned int iPosibN)
{
	unsigned int iCont=0; //Contador de elementos
	unsigned int iContP=0; //Contador de Parentesis
	unsigned char cElem='('; //Elemento para armar la expresi�n
	unsigned int iNumAleat;

    //Inicializa cadena sOperNumPar
    for(iCont=0; iCont<130; iCont++) sExpresion[iCont]='\0';
	iCont=0;

	while (iCont<=iLongExpr)
	{
		//Trae un N�mero, X o Par�ntesis
        do
        {
			iNumAleat = abs(rand() % 100 );
			cElem = sOperNumPar[iNumAleat];

		    if (cElem=='(' || cElem==')') // Si es par�ntesis valida que no se pasa de 20
		    {
				if (iContP<20)
				{
					sExpresion[iCont++]='(';
					iContP++;
				}
				else
				{
					iNumAleat = abs(rand() % (iPosibX+iPosibN));
					cElem = sOperNumPar[iNumAleat];
					sExpresion[iCont]=cElem; //Un n�mero o X
				}
		    }
            else
				sExpresion[iCont]=cElem; //Un n�mero o X
        }while(cElem=='(' || cElem==')');

		//Chequea si cierra los par�ntesis
        iNumAleat = abs(rand() % 100 );
        cElem = sOperNumPar[iNumAleat];
        if (cElem==')')
        {
			if (iContP>0)
            {
				iCont++;
                iContP--;
                sExpresion[iCont]=cElem;
            }
         }
                                
                            
		//Agrega luego un operador: +, -, *, /
        iCont++;
	    iNumAleat = abs(rand() % 4) + 1;
        switch(iNumAleat)
        {
			case 1: sExpresion[iCont]='+'; break;
            case 2: sExpresion[iCont]='-'; break;
            case 3: sExpresion[iCont]='*'; break;
            case 4: sExpresion[iCont]='/'; break;
		}
		iCont++;
	}

	//Completa la expresi�n
	iNumAleat = abs(rand() % (iPosibX+iPosibN));
	sExpresion[iCont++]= sOperNumPar[iNumAleat];
	for (unsigned int iParent=1; iParent<=iContP; iParent++) sExpresion[iCont++]=')';  //Equilibra parentesis
};

/* Recibe una expresi�n y cambia una parte de ella:
   Aleatoriamente determina la posici�n a cambiar siempre y cuando no sea parentesis
   Ahora bien:
   Si es operador(*,/-,+) la cambia por otro operador
   Si es n�mero la cambia por otro o una X
   Si es X la cambia por n�mero
*/
void Mutacion::vMutarPartes(unsigned int iPosibX, unsigned int iPosibN)
{
		unsigned int iNumAleat;
		int	iPosExpr=-1;
		unsigned char cPosic, cElem1, cElem2;
		unsigned int iLongExpr;
		
		iLongExpr = strlen(sExpresion);

		//Calcula alguna posici�n
		while (iPosExpr==-1)
		{
            iPosExpr = abs(rand() % iLongExpr);
			cPosic = sExpresion[iPosExpr];
			if (cPosic =='(' || cPosic ==')')	iPosExpr=-1;
		}

		//Si es operador lo reemplaza por otro operador
		if (cPosic=='+' || cPosic=='-' || cPosic=='*' || cPosic=='/')
		{
			iNumAleat = abs(rand() % 4) + 1;
            switch(iNumAleat)
            {
				case 1: sExpresion[iPosExpr]='+'; break;
                case 2: sExpresion[iPosExpr]='-'; break;
                case 3: sExpresion[iPosExpr]='*'; break;
                case 4: sExpresion[iPosExpr]='/'; break;
			}
			return;
		}

		//Si es n�mero lo reemplaza por otro n�mero o variable X
		if ( cPosic>='0' && cPosic<='9')
		{
			cElem1 = sExpresion[iPosExpr];
			do
			{
				iNumAleat = abs(rand() % (iPosibX+iPosibN));
				cElem2 = sOperNumPar[iNumAleat]; //Un n�mero o X
			} while (cElem1 == cElem2);
			sExpresion[iPosExpr]=cElem2;
			return;
		}

		//Si es una X lo reemplaza por un n�mero
		if (cPosic=='X')
		{
			iNumAleat = abs(rand() % iPosibN) + iPosibX + 1;
			sExpresion[iPosExpr] = sOperNumPar[iNumAleat]; //Un n�mero o X
			return;
		}
};
