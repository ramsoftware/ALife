/* Autor: Rafael Alberto Moreno Parra
   Fecha: 28 de Mayo de 2000

MOTOR12. Escrito en C++ (Compilado en Visual C++ 6.0)
Dualidad

El ser vivo capta informaci�n de su medio ambiente mediante sus sentidos
(vista, olfato, gusto, ...), cada sentido (sensor) envia una determinada
informaci�n al organismo. Dependiendo de esta informaci�n, el organismo
reacciona (o evoluciona).

Entre mas especializado este un sensor, de mejor calidad ser� la informaci�n,
entre mas sentidos tenga un ser vivo mas informaci�n habr� del medio
ambiente.

Cuando comenc� la investigaci�n sobre Vida Artificial, estos fueron
los pasos que hice:
1. Expresi�n simple (la cual llam� Gen)
2. Conjunto de Genes (el cual llam� Organismo)
3. Ahora, conjunto de Organismos (la cual llamo Simbiosis)

Voy escalando cada concepto.

Estas simulaciones, servir�n para el manejo de:
1. M�ltiples y diversos datos de entrada.
2. M�ltiples y diversos datos de salida.


*/

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>

#include "Organismo.h"
#include "MasApto.h"
#include "MedioAmbiente.h"
#include "Inicializa.h"

void Simular(void);
void vQuitaEspacios(char *sCadena);
void vLeft(char *cad1, char *cad2, char num_letras);
void vRight(char *cad1, char *cad2, char num_letras);
void vMid(char *cad1, char *cad2, char desde, char hasta);


//Programa Principal
main()
{
	Inicializa objInicializa; //Inicializa la simulaci�n
    MedioAmbiente objAmbiente1; //El ambiente de entrada
    MedioAmbiente objAmbiente2; //El ambiente de salida
	MasApto OrgMasApto; //Objeto que guarda el mejor objeto organismo
	Organismo objOrganismo; //Objeto que guarda el organismo a probar en el ambiente

    //Lee los parametros de simulaci�n
	objInicializa.vLeeArchivoIni();

	//Genera encabezado del archivo de salida
	objInicializa.vArchResult();

    //Deduce el ambiente
	objAmbiente1.vDeshaceIO(objInicializa.stDatVA.sEntrada);
	objAmbiente2.vDeshaceIO(objInicializa.stDatVA.sSalidas);

    //Inicializa el comportamiento aleatorio
	objOrganismo.IniciaSemillaT();
	objOrganismo.cMuta.vIniLista(	objInicializa.stDatVA.iPosibN,
									objInicializa.stDatVA.iPosibX,
									objInicializa.stDatVA.iPosibP);
	objOrganismo.m_iMaxiCiclos =  objInicializa.stDatVA.iNumCiclos;
	objOrganismo.vCreaADN(false, 65,
					objInicializa.stDatVA.iPosibIf,
					objInicializa.stDatVA.iPosibSet,
					objInicializa.stDatVA.iPosW,
					objInicializa.stDatVA.iPosX,
					objInicializa.stDatVA.iPosY,
					objInicializa.stDatVA.iPosZ,
					objInicializa.stDatVA.iPosIg,
					objInicializa.stDatVA.iPosMay,
					objInicializa.stDatVA.iPosMen,
					objInicializa.stDatVA.iPosDif,
					objInicializa.stDatVA.iLongExpr,
					objInicializa.stDatVA.iPosibX,
					objInicializa.stDatVA.iPosibP,
					objInicializa.stDatVA.iPosibN);

    //Informaci�n Inicial de la simulaci�n para simple expresi�n
	objInicializa.vGrabaResult(1,"================ SIMPLE EXPRESION ================", 0, 0.0);
	objOrganismo.m_oGen[1].bEjecuta = false;
	objOrganismo.m_oGen[1].cTipInst = 'S';	
	objOrganismo.m_oGen[1].cVarActiva = 'X';
	objOrganismo.m_oGen[1].cVariable = 'Y';
	objOrganismo.m_oGen[1].iGotoLabel = 0;
	objOrganismo.m_iMaxGenOrg = 1;


	//Variables de la simulaci�n
    unsigned int iContIntentos=0; //Contador de intentos
	unsigned int iContSemilla=0; //Inicializa semilla
	unsigned int iGeneracion = 1; //Variable que decide que tipo de generaci�n hay: aleatoria, mutaci�n, sutil
	unsigned int iNumGenes=0;  //Contador de genes(instrucciones a generar)
	unsigned int iMutar=1; //Que gen mutara
	unsigned int iCopia;  //Copia el mejor algoritmo para ser mutado
	unsigned int iMutables=0; //Numero de instrucciones realmente ejecutadas
	float fResult; //Resultado de la evaluaci�n del organismo en un item del ambiente
	float fErrOrg; //Aproximaci�n del Algoritmo (Organismo) al Ambiente
	float fPuesto1=(float)999999; //Variable para chequear los algoritmos mas aptos
	char OrganismoGen[4500]; //Mejor Algoritmo

    //Ciclo de evaluacion
	while(true) 
	{
        iContIntentos++;
		iContSemilla++;

		//Inicializa semilla
		if (iContSemilla > 4000)
		{
			objOrganismo.IniciaSemillaR();
			iContSemilla = 0;
		}

	    //Decide la estrategia
		if (iContIntentos > objInicializa.stDatVA.iGeneraSimple && iGeneracion == 1)
		{
			iGeneracion++;
			iContIntentos = 0;

			objInicializa.vGrabaResult(1, "================ MUTA SIMPLE ================", 0, 0.0);
			objOrganismo.IniciaSemillaT();
		}
		else if (iContIntentos > objInicializa.stDatVA.iMutaSimple && iGeneracion == 2)
		{
			iGeneracion++;
			iContIntentos = 0;

			objInicializa.vGrabaResult(1, "================ ALEATORIO ================", 0, 0.0);
			objOrganismo.IniciaSemillaT();
		}
		else if (iContIntentos > objInicializa.stDatVA.iGeneraAzar && iGeneracion == 3)
		{
			iGeneracion++;
			iContIntentos = 0;

            if (OrgMasApto.m_iMaxGenOrg == 1) //No se pudo adaptar mejor
			{
				objInicializa.vGrabaResult(1, "================ TERMINO ================", 0, 0.0);
				return 1;
			}
			else
				objInicializa.vGrabaResult(1, "================ MUTANDO GENES ================", 0, 0.0);

			objOrganismo.IniciaSemillaT();
		}
		else if (iContIntentos > objInicializa.stDatVA.iMutaTodoGen && iGeneracion == 4)
		{
			iGeneracion++;
			iContIntentos = 0;

			objInicializa.vGrabaResult(1, "================ SUTIL ================", 0, 0.0);
			objOrganismo.IniciaSemillaT();
		}
		else if (iContIntentos > objInicializa.stDatVA.iMutaParcGen && iGeneracion == 5) 
		{
			objInicializa.vGrabaResult(1, "================ TERMINO ================", 0, 0.0);
			break;
		}


		//Genera el organismo dependiendo de la estrat�gia
		switch(iGeneracion)
		{
		case 1: //Genera simple expresion

			/* OJO!: �Cuanto se puede variar en una expresi�n?
			Si es un solo numero:
			n = 10 combinaciones (1..9 y X)
			n op n = 40 combinaciones (ej: X * 5)
			n op n op n = 16000 combinaciones (ej: 7 / X + 5)
			n op n op n op n = 640.000 combinaciones
			n op n op n op n op n = 25.600.000 combinaciones
			Siempre multiplicando por 40 a medida que agrego un operador y
			un operando. Luego podriamos hablar de 9 la longitud */
			objOrganismo.cMuta.vCrearExpresion(9, objInicializa.stDatVA.iPosibX, objInicializa.stDatVA.iPosibP, objInicializa.stDatVA.iPosibN);
		    strcpy(objOrganismo.m_oGen[1].sbExpresion,objOrganismo.cMuta.sExpresion);
			break;

		case 2: //Muta la simple expresion
			strcpy(objOrganismo.cMuta.sExpresion, OrgMasApto.m_oGen[1].sbExpresion);
			objOrganismo.cMuta.vMutarPartes(objInicializa.stDatVA.iPosibX, objInicializa.stDatVA.iPosibN);
		    strcpy(objOrganismo.m_oGen[1].sbExpresion,objOrganismo.cMuta.sExpresion);
			break;

		case 3: //Genera Aleatoriamente los Algoritmos
			iNumGenes = rand() % (objInicializa.stDatVA.iNumInstMax-objInicializa.stDatVA.iNumInstMin) + objInicializa.stDatVA.iNumInstMin;
			objOrganismo.vCreaADN(false, iNumGenes,
					objInicializa.stDatVA.iPosibIf,
					objInicializa.stDatVA.iPosibSet,
					objInicializa.stDatVA.iPosW,
					objInicializa.stDatVA.iPosX,
					objInicializa.stDatVA.iPosY,
					objInicializa.stDatVA.iPosZ,
					objInicializa.stDatVA.iPosIg,
					objInicializa.stDatVA.iPosMay,
					objInicializa.stDatVA.iPosMen,
					objInicializa.stDatVA.iPosDif,
					objInicializa.stDatVA.iLongExpr,
					objInicializa.stDatVA.iPosibX,
					objInicializa.stDatVA.iPosibP,
					objInicializa.stDatVA.iPosibN);
				
			objOrganismo.m_oGen[1].cOperacion = OrgMasApto.m_oGen[1].cOperacion;
            objOrganismo.m_oGen[1].cTipInst = OrgMasApto.m_oGen[1].cTipInst;
            objOrganismo.m_oGen[1].cVarActiva = OrgMasApto.m_oGen[1].cVarActiva;
            objOrganismo.m_oGen[1].cVariable = OrgMasApto.m_oGen[1].cVariable;
            objOrganismo.m_oGen[1].iGotoLabel = OrgMasApto.m_oGen[1].iGotoLabel;
            strcpy(objOrganismo.m_oGen[1].sbExpresion,OrgMasApto.m_oGen[1].sbExpresion);
			break;

        case 4: //Muta todo un Gen

			//Escoge que Gen mutar�, muta los que se ejecutaron
			iMutar = rand() % (iMutables-1) + 2;
			for (iCopia=1; iCopia <= OrgMasApto.m_iMaxGenOrg; iCopia++)
            {
				if (OrgMasApto.m_oGen[iCopia].bEjecuta == true) iMutar--;
				if (iMutar==0) break;
			}
			iMutar = iCopia; //La posici�n real a mutar
			
			for (iCopia=1; iCopia <= OrgMasApto.m_iMaxGenOrg; iCopia++)
            {
				objOrganismo.m_oGen[iCopia].bEjecuta = false;
                objOrganismo.m_oGen[iCopia].cOperacion = OrgMasApto.m_oGen[iCopia].cOperacion;
                objOrganismo.m_oGen[iCopia].cTipInst = OrgMasApto.m_oGen[iCopia].cTipInst;
                objOrganismo.m_oGen[iCopia].cVarActiva = OrgMasApto.m_oGen[iCopia].cVarActiva;
                objOrganismo.m_oGen[iCopia].cVariable = OrgMasApto.m_oGen[iCopia].cVariable;
                objOrganismo.m_oGen[iCopia].iGotoLabel = OrgMasApto.m_oGen[iCopia].iGotoLabel;
                strcpy(objOrganismo.m_oGen[iCopia].sbExpresion,OrgMasApto.m_oGen[iCopia].sbExpresion);
            }
            objOrganismo.m_iMaxGenOrg = OrgMasApto.m_iMaxGenOrg;

			//Muta el Gen
			objOrganismo.vHaceGen(iMutar, objOrganismo.m_iMaxGenOrg,
					objInicializa.stDatVA.iPosibIf,
					objInicializa.stDatVA.iPosibSet,
					objInicializa.stDatVA.iPosW,
					objInicializa.stDatVA.iPosX,
					objInicializa.stDatVA.iPosY,
					objInicializa.stDatVA.iPosZ,
					objInicializa.stDatVA.iPosIg,
					objInicializa.stDatVA.iPosMay,
					objInicializa.stDatVA.iPosMen,
					objInicializa.stDatVA.iPosDif,
					objInicializa.stDatVA.iLongExpr,
					objInicializa.stDatVA.iPosibX,
					objInicializa.stDatVA.iPosibP,
					objInicializa.stDatVA.iPosibN);
			break;

		case 5: //Muta un Gen pero de forma sutil
				//Escoge que Gen mutar�, muta los que se ejecutaron
				iMutar = rand() % (iMutables-1) + 2;
				for (iCopia=1; iCopia <= OrgMasApto.m_iMaxGenOrg; iCopia++)
                {
					if (OrgMasApto.m_oGen[iCopia].bEjecuta == true) iMutar--;
					if (iMutar==0) break;
				}
				iMutar = iCopia; //La posici�n real a mutar

			    for (iCopia=1; iCopia <= OrgMasApto.m_iMaxGenOrg; iCopia++)
                {
					objOrganismo.m_oGen[iCopia].bEjecuta = false;
                    objOrganismo.m_oGen[iCopia].cOperacion = OrgMasApto.m_oGen[iCopia].cOperacion;
                    objOrganismo.m_oGen[iCopia].cTipInst = OrgMasApto.m_oGen[iCopia].cTipInst;
                    objOrganismo.m_oGen[iCopia].cVarActiva = OrgMasApto.m_oGen[iCopia].cVarActiva;
                    objOrganismo.m_oGen[iCopia].cVariable = OrgMasApto.m_oGen[iCopia].cVariable;
                    objOrganismo.m_oGen[iCopia].iGotoLabel = OrgMasApto.m_oGen[iCopia].iGotoLabel;
                    strcpy(objOrganismo.m_oGen[iCopia].sbExpresion,OrgMasApto.m_oGen[iCopia].sbExpresion);
                }
                objOrganismo.m_iMaxGenOrg = OrgMasApto.m_iMaxGenOrg;

				//Muta el Gen en forma sutil
				objOrganismo.vMutaGen(iMutar, objOrganismo.m_iMaxGenOrg,
									objInicializa.stDatVA.iLongExpr,
									objInicializa.stDatVA.iPosibX,
									objInicializa.stDatVA.iPosibP,
									objInicializa.stDatVA.iPosibN);
				break;
        }
				
		//Evalua previamente el algoritmo gen�tico para luego hacer las pruebas		
        objOrganismo.vEvaluaPrevio();
    
		//Calcula el acercamiento
		fErrOrg=0;
        for (unsigned int iCont=0; iCont<objAmbiente1.m_iContador; iCont++)
        {
			fResult = objOrganismo.fEvalOrganismo(objAmbiente1.m_fAmbiente[iCont]);
			fErrOrg += (float) fabs(fResult-objAmbiente2.m_fAmbiente[iCont]);
        }

		// Compara con el puesto anterior y si la aproximaci�n es menor reemplaza
        if (fErrOrg < fPuesto1)
        {
			fPuesto1 = fErrOrg;

			//Almacena el mejor objeto organismo
			iMutables=0;
			for (iCopia=1; iCopia <= objOrganismo.m_iMaxGenOrg; iCopia++)
			{
				if (objOrganismo.m_oGen[iCopia].bEjecuta == true) iMutables++;
				OrgMasApto.m_oGen[iCopia].bEjecuta = objOrganismo.m_oGen[iCopia].bEjecuta;
				OrgMasApto.m_oGen[iCopia].cOperacion = objOrganismo.m_oGen[iCopia].cOperacion;
                OrgMasApto.m_oGen[iCopia].cTipInst = objOrganismo.m_oGen[iCopia].cTipInst;
                OrgMasApto.m_oGen[iCopia].cVarActiva = objOrganismo.m_oGen[iCopia].cVarActiva;
                OrgMasApto.m_oGen[iCopia].cVariable = objOrganismo.m_oGen[iCopia].cVariable;
                OrgMasApto.m_oGen[iCopia].iGotoLabel = objOrganismo.m_oGen[iCopia].iGotoLabel;
                strcpy(OrgMasApto.m_oGen[iCopia].sbExpresion, objOrganismo.m_oGen[iCopia].sbExpresion);
			}
			OrgMasApto.m_iMaxGenOrg = objOrganismo.m_iMaxGenOrg;
		    objOrganismo.IniciaSemillaT();
                    
			//Escribe el resultado a archivo
	        objOrganismo.sDisplayADN(OrganismoGen);
			objInicializa.vGrabaResult(2, OrganismoGen, iContIntentos, fErrOrg);
	     } // End If
    } // End While(true)
	return 1;
}
