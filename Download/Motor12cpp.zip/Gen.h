/*
Autor:		Rafael Alberto Moreno Parra
URL:		http://www.geocities.com/krousky
Clase:		Gen
Lenguaje:	C++

Prop�sito:
   Linea de codigo fuente (la llam� Gen). El formato es:
   label, [, IF/SET, Variable, =/>/</!, (, expresion, ), Goto, Label, ]
   para mayor velocidad, se ubica en una clase el Gen

*/
class Gen
{
public:
    bool bEjecuta; // Se coloca a TRUE si la instruccion es ejecutada

    /* ======================================================================= */
    char cTipInst; /* Operacion IF o SET */
    char cVariable; /* Variable a la que van a asignarle un valor o a compararla */
    char cOperacion; /* Que operacion >,<,=,! se hara si es un IF condicional */
    char cVarActiva; /* Variable activa en la expresion */
    char sbExpresion[130]; /* Expresion en X */
    unsigned int iGotoLabel; /* Hacia que gen ir� */
};