/*
Autor:		Rafael Alberto Moreno Parra
URL:		http://www.geocities.com/krousky
Clase:		Organismo
Lenguaje:	C++

Prop�sito:
Clase de administraci�n del medio ambiente (serie num�rica de entrada y
salida)

M�todos:
IniciaSemilla2: Inicializa la semilla dependiendo del tiempo
IniciaSemilla: Inicializa la semilla aleatoriamente
sDisplayADN: Despliega el organismo como si fuera c�digo Java
vCreaADN: Crea el organismo, llamando la funci�n que hace sus genes
vHaceGen: Crea una linea de codigo fuente (la llam� Gen). El formato es:
          label, [, IF/SET, Variable, =/>/</!, (, expresion, ), Goto, Label, ]
          para mayor velocidad, se ubica en una clase el Gen
vEvaluaPrevio: Optimiza la velocidad de evaluaci�n del organismo en un
               ambiente.
fEvalOrganismo: Evalua el organismo en el ambiente
vMutaGen: Mutaci�n suave de un gen del organismo

*/

#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <float.h>
#include <time.h>
#include "Organismo.h"

//Inicializa la semilla dependiendo del tiempo
void Organismo::IniciaSemillaT()
{
	srand( (unsigned)time( NULL ) );
}

//Inicializa la semilla aleatoriamente
void Organismo::IniciaSemillaR()
{
	srand(rand());
};

//Despliega el organismo como si fuera c�digo Java
void Organismo::sDisplayADN(char *sbADN)
{
	char sExprTemp1[250], sExprTemp2[250]="";
	char cEnter[4];
	strcpy(sbADN,"float fSerVivo(float X)");
    cEnter[0]= '\n';
    cEnter[1]= '\0';

	strcat(sbADN,cEnter);
	strcat(sbADN, "{");
    strcat(sbADN,cEnter);

    strcat(sbADN,"float W=0, Y=0, Z=0;");
    strcat(sbADN,cEnter);
    strcat(sbADN,cEnter);

	for (unsigned int iCont=1; iCont<=m_iMaxGenOrg; iCont++)
    {
		sprintf(sExprTemp1, "%d", iCont);
		strcat(sbADN, sExprTemp1);
		strcat(sbADN, ": ");

        //Reemplaza la expresion por la variable activa
		int iLongExpr = strlen(m_oGen[iCont].sbExpresion);
		sExprTemp2[0]='\0';
        for (int iChar=0; iChar < iLongExpr; iChar++)
        {
			char cCharAt = m_oGen[iCont].sbExpresion[iChar];
            sExprTemp1[1]='\0';
            if (cCharAt=='X' || cCharAt=='x')
				sExprTemp1[0]=m_oGen[iCont].cVarActiva;
            else
				sExprTemp1[0]=cCharAt;
   			strcat(sExprTemp2, sExprTemp1);
        }
                    
        //Organiza los if y asignaciones
        if (m_oGen[iCont].cTipInst == 'I')
        {
			sExprTemp1[0]=m_oGen[iCont].cVariable;
			strcat(sbADN, "if( ");  //if(
			strcat(sbADN, sExprTemp1);  //if ( Z
			strcat(sbADN, " ");
			sExprTemp1[0]=m_oGen[iCont].cOperacion; // if ( Z >
			strcat(sbADN, sExprTemp1);
			strcat(sbADN, " ");
			strcat(sbADN, sExprTemp2); // if (Z > 4*X*X
			strcat(sbADN, " ) goto ");
			sprintf(sExprTemp1, "%d", m_oGen[iCont].iGotoLabel);
			strcat(sbADN, sExprTemp1); // if (Z > 4*X*X ) goto 4
			strcat(sbADN, ";");
		}
        else
		{
			sExprTemp1[0]=m_oGen[iCont].cVariable;
			strcat(sbADN, sExprTemp1);
			strcat(sbADN, " = ");
			strcat(sbADN, sExprTemp2);
			strcat(sbADN, ";");
		}
        strcat(sbADN, cEnter);
    }    
    //Finaliza la expresion
	strcat(sbADN, "return Y;");
	strcat(sbADN, cEnter);
	strcat(sbADN, "}");
	strcat(sbADN, cEnter);
};

// Crea el organismo, llamando la funci�n que hace sus genes
void Organismo::vCreaADN (bool bGenRandom, unsigned int iMaxGenes,
                   unsigned int iPosibIf, unsigned int iPosibSet,
                   unsigned int iPosW,  unsigned int iPosX, unsigned int iPosY, unsigned int iPosZ,
                   unsigned int iPosIg, unsigned int iPosMay, unsigned int iPosMen, unsigned int iPosDif,
                   unsigned int iLongExpr, unsigned int iPosibX, unsigned int iPosibP, unsigned int iPosibN)
{
    unsigned int iCont;

	if(bGenRandom)
		m_iMaxGenOrg = abs(rand() % iMaxGenes ) + 1; //Crea organismos entre 1 y iMaxGenes instrucciones
	else
        m_iMaxGenOrg = iMaxGenes;        
     
    for (iCont=1; iCont<=m_iMaxGenOrg; iCont++)
		vHaceGen (iCont, m_iMaxGenOrg,
                  iPosibIf, iPosibSet,
                  iPosW,  iPosX, iPosY, iPosZ,
                  iPosIg, iPosMay, iPosMen, iPosDif,
                  iLongExpr, iPosibX, iPosibP, iPosibN);
};

/* Crea una linea de codigo fuente (la llam� Gen). El formato es:
   label, [, IF/SET, Variable, =/>/</!, (, expresion, ), Goto, Label, ]
   para mayor velocidad, se ubica en una clase el Gen */
void Organismo::vHaceGen(unsigned int iLabel, unsigned int iMaxGenes,
                   unsigned int iPosibIf, unsigned int iPosibSet,
                   unsigned int iPosW,  unsigned int iPosX, unsigned int iPosY, unsigned int iPosZ,
                   unsigned int iPosIg, unsigned int iPosMay, unsigned int iPosMen, unsigned int iPosDif,
                   unsigned int iLongExpr, unsigned int iPosibX, unsigned int iPosibP, unsigned int iPosibN)
{
	unsigned int iAleatorio;

    //Por defecto, nunca se ha ejecutado esta instruccion
    m_oGen[iLabel].bEjecuta = false;
       
  
    //Decide que variable usar W, X, Y, Z (para ser asignada o comparada)
   	iAleatorio = abs(rand() % 100) + 1;
	if (iAleatorio<=iPosW)
		m_oGen[iLabel].cVariable = 'W';
	else if (iAleatorio<=iPosW+iPosX)
		m_oGen[iLabel].cVariable = 'X';
    else if (iAleatorio<=iPosW+iPosX+iPosY)
		m_oGen[iLabel].cVariable = 'Y';
	else
		m_oGen[iLabel].cVariable = 'Z';
        
    //Decide si usa =, >, <, ! Estos son tenidos en cuenta si es un IF condicional
   	iAleatorio = abs(rand() % 100) + 1;
	if (iAleatorio<=iPosIg)
		m_oGen[iLabel].cOperacion = '=';
	else if (iAleatorio<=iPosIg+iPosMay)
		m_oGen[iLabel].cOperacion = '>';
    else if (iAleatorio<=iPosIg+iPosMay+iPosMen)
		m_oGen[iLabel].cOperacion = '<';
	else
		m_oGen[iLabel].cOperacion = '!';

   //Trae la expresion
    cMuta.vCrearExpresion(iLongExpr, iPosibX, iPosibP, iPosibN);
    strcpy(m_oGen[iLabel].sbExpresion,cMuta.sExpresion);
       
    //Como la trae para X, aqui la cambio a W, X, Y, Z
   	iAleatorio = abs(rand() % 100) + 1;
	if (iAleatorio<=iPosW)
		m_oGen[iLabel].cVarActiva = 'W';
	else if (iAleatorio<=iPosW+iPosX)
		m_oGen[iLabel].cVarActiva = 'X';
    else if (iAleatorio<=iPosW+iPosX+iPosY)
		m_oGen[iLabel].cVarActiva = 'Y';
	else
		m_oGen[iLabel].cVarActiva = 'Z';

	//Decide si es un IF o una asignaci�n, si es un IF la
	//cVariable debe ser diferente de cVarActiva
    if (m_oGen[iLabel].cVarActiva != m_oGen[iLabel].cVariable)
	{
		iAleatorio = abs(rand() % 100) + 1;
		if (iAleatorio<=iPosibIf)
			m_oGen[iLabel].cTipInst = 'I';
		else
			m_oGen[iLabel].cTipInst = 'S';	
	}
	else
			m_oGen[iLabel].cTipInst = 'S';	


    //Decide hacia que label va (entre 1 y MaxGenes) o si es el FIN, el resultado siempre sera Y
    unsigned int iNumCiclo;
	do
	{
		iNumCiclo = abs(rand() % (iMaxGenes+1));
	} while (iNumCiclo==iLabel); //Evita el goto hacia la misma instruccion
    m_oGen[iLabel].iGotoLabel = iNumCiclo; //Retorna 0 para FINalizar
};

    
//Por velocidad de evaluaci�n
void Organismo::vEvaluaPrevio()
{
	double dResultado;
    for (unsigned int iCont=1; iCont<=m_iMaxGenOrg; iCont++)
		dResultado = m_eEvalua[iCont].dCapturaEcuacion(m_oGen[iCont].sbExpresion, 0, 0);
};
        
//Evalua el organismo en el ambiente    
float Organismo::fEvalOrganismo (float fValX)
{                   
	/* Viene la interpretacion, los valores X se disparan de 1 a n y se comparan con el ambiente Y */
    float fValW=0, fValY=0, fValZ=0, fValor=0, fResultado=0, fCompara=0;
    unsigned int iGenOrg=1; //# de Instrucci�n de inicio
    unsigned int iNumCiclos=0; //Contador de Ciclos
       
    while (iGenOrg!=0 && iGenOrg<=m_iMaxGenOrg)
    {
		//Coloca a TRUE la instruci�n porque se ejecuta
        m_oGen[iGenOrg].bEjecuta = true;
            
        //Aumenta el # de Ciclos
        iNumCiclos++;

		//M�ximo n�mero de ciclos que se evaluar�n del organismo, si el
        //organismo supera este n�mero de ciclos sin dar con un resultado
        //es desechado.
		if (iNumCiclos > m_iMaxiCiclos)
			return 9999999;
            
        //Que variable esta jugando dentro de la expresion
        switch (m_oGen[iGenOrg].cVarActiva)
        {
		   case 'W': fValor = fValW; break;
           case 'X': fValor = fValX; break;
           case 'Y': fValor = fValY; break;
           case 'Z': fValor = fValZ; break;
        }
            
        //Evalua la expresion
        //double dResultado = m_eEvalua.dCapturaecuacion(m_oGen[iGenOrg].sbExpresion, dValor, 0);
		fResultado = m_eEvalua[iGenOrg].dCicloEvalua(fValor, 0);
		if (m_eEvalua[iGenOrg].ERRORMATEMATICO==1 ||
			fResultado >= 9999999 || fResultado <= -9999999 )
			return 9999999;

		//Si es un SET asigna el valor a la variable del Gen
		if (m_oGen[iGenOrg].cTipInst == 'S')
		{
		    switch(m_oGen[iGenOrg].cVariable)
		    {
				case 'W': fValW = fResultado;
		                  break;
                case 'X': fValX = fResultado;
		                  break;
		        case 'Y': fValY = fResultado;
		                  break;
		        case 'Z': fValZ = fResultado;
		                  break;
		    }
		    iGenOrg++; //Ignora el salto en un SET
        }
        else //Es un If condicional
        {
            switch(m_oGen[iGenOrg].cVariable)
		    {
				case 'W': fCompara = fValW; break;
		        case 'X': fCompara = fValX; break;
		        case 'Y': fCompara = fValY; break;
		        case 'Z': fCompara = fValZ; break;
		    }
                
            switch(m_oGen[iGenOrg].cOperacion)
            {
				case '>': if (fCompara > fResultado) 
		                      iGenOrg=m_oGen[iGenOrg].iGotoLabel;
		                  else
						      iGenOrg++;
		                  break;
                case '<': if (fCompara < fResultado) 
		                      iGenOrg=m_oGen[iGenOrg].iGotoLabel;
		                  else
					         iGenOrg++;
		                  break;
		        case '=': if (fCompara == fResultado) 
		                      iGenOrg=m_oGen[iGenOrg].iGotoLabel;
		                  else
						      iGenOrg++;
		                  break;
                case '!': if (fCompara != fResultado) 
		                      iGenOrg=m_oGen[iGenOrg].iGotoLabel;
		                  else
						      iGenOrg++;
		                  break;
		    }
		}
	 }//Fin de la evaluacion del ser vivo
	 return fValY;
};
     

//Muta de forma suave el Gen
void Organismo::vMutaGen(unsigned int iLabel, unsigned int iMaxGenes,
                         unsigned int iLongExpr, unsigned int iPosibX,
						 unsigned int iPosibP, unsigned int iPosibN)
{
	unsigned int iAleatorio;
	unsigned int iModif;
	char cVariable;

    //Por defecto, nunca se ha ejecutado esta instruccion
    m_oGen[iLabel].bEjecuta = false;
       
    //Si es una instrucci�n IF que hay que modificar, entonces se puede
	//modificar (y se nota el cambio) en las dos ultimas categorias
	//"Goto Label" y ">,<,!,="
	if (m_oGen[iLabel].cTipInst == 'I')
		iModif = abs(rand() % 6) + 1;
	else
		iModif = abs(rand() % 4) + 1;

	switch (iModif)
	{
	case 1: // Modifica de Asignacion a If, o , de If a Asignacion
		if(m_oGen[iLabel].cTipInst=='I')
			m_oGen[iLabel].cTipInst = 'S';
		else
			m_oGen[iLabel].cTipInst = 'I';
		break;

	case 2: //Cambia la variable
		do
		{
   			iAleatorio = abs(rand() % 100) + 1;
			if (iAleatorio<=25)
				cVariable = 'W';
			else if (iAleatorio<=50)
				cVariable = 'X';
			else if (iAleatorio<=75)
				cVariable = 'Y';
			else
				cVariable = 'Z';
		} while (m_oGen[iLabel].cVariable == cVariable);
		m_oGen[iLabel].cVariable = cVariable;
		break;

	case 3: //Cambia la expresion
		cMuta.vCrearExpresion(iLongExpr, iPosibX, iPosibP, iPosibN);
		strcpy(m_oGen[iLabel].sbExpresion,cMuta.sExpresion);
		break;

	case 4://Cambia la variable activa de la expresion
		do
		{
   			iAleatorio = abs(rand() % 100) + 1;
			if (iAleatorio<=25)
				cVariable = 'W';
			else if (iAleatorio<=50)
				cVariable = 'X';
			else if (iAleatorio<=75)
				cVariable = 'Y';
			else
				cVariable = 'Z';
		} while (m_oGen[iLabel].cVarActiva == cVariable);
		m_oGen[iLabel].cVarActiva = cVariable;
		break;

    case 5:
		//Cambia hacia que label va (entre 1 y MaxGenes) o si es el FIN, el resultado siempre sera Y
	    unsigned int iNumCiclo;
		do
		{
			iNumCiclo = abs(rand() % (iMaxGenes+1));
		} while (iNumCiclo == m_oGen[iLabel].iGotoLabel && iNumCiclo == iLabel);
		m_oGen[iLabel].iGotoLabel = iNumCiclo;
		break;

	case 6: //Decide si usa =, >, <, ! Estos son tenidos en cuenta si es un IF condicional
   		char cOperacion;
		do
		{
   			iAleatorio = abs(rand() % 100) + 1;
			if (iAleatorio<=25)
				cOperacion = '=';
			else if (iAleatorio<=50)
				cOperacion = '>';
			else if (iAleatorio<=75)
				cOperacion = '<';
			else
				cOperacion = '!';
		} while (m_oGen[iLabel].cOperacion == cOperacion);
		m_oGen[iLabel].cOperacion = cOperacion;
		break;
	}
};