/*
Autor:		Rafael Alberto Moreno Parra
URL:		http://www.geocities.com/krousky
Clase:		Inicializa. Motor12.
Lenguaje:	C++

Prop�sito:
Inicializa las variables para la simulaci�n

M�todos:

*/

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>
#include "Inicializa.h"
#include "StringUtil.h"

//Abre y estudia el archivo de inicializaci�n
void Inicializa::vLeeArchivoIni()
{
	FILE *fpInicio;
	char sFrase[600], sVariable[200], sValor[200];
    unsigned int iCar;
	StringUtil StrUtil;

	fpInicio = fopen("Motor12.ini", "r+t");
	if (fpInicio == NULL)
    {
		printf("Error al tratar de abrir archivo de inicializaci�n Motor11.ini\n");
		return;
    }
	while(!feof(fpInicio))
	{
		fgets(sFrase, 298, fpInicio);
		StrUtil.vQuitaEspacios(sFrase);

		//Extrae variables y valores
		for (iCar=0; iCar<strlen(sFrase) && sFrase[iCar]!='='; iCar++);
		StrUtil.vLeft(sVariable, sFrase, iCar);
		StrUtil.vMid(sValor, sFrase, iCar+2,strlen(sFrase)-1);

		//Clasifica variables
		if(strcmp(sVariable, "iPosibIf")==0) stDatVA.iPosibIf = atoi(sValor);
		if(strcmp(sVariable, "iPosibSet")==0) stDatVA.iPosibSet = atoi(sValor);
		if(strcmp(sVariable, "iPosW")==0) stDatVA.iPosW = atoi(sValor);
		if(strcmp(sVariable, "iPosX")==0) stDatVA.iPosX = atoi(sValor);
		if(strcmp(sVariable, "iPosY")==0) stDatVA.iPosY = atoi(sValor);
		if(strcmp(sVariable, "iPosZ")==0) stDatVA.iPosZ = atoi(sValor);
		if(strcmp(sVariable, "iPosIg")==0) stDatVA.iPosIg = atoi(sValor);
		if(strcmp(sVariable, "iPosMay")==0) stDatVA.iPosMay = atoi(sValor);
		if(strcmp(sVariable, "iPosMen")==0) stDatVA.iPosMen = atoi(sValor);
		if(strcmp(sVariable, "iPosDif")==0) stDatVA.iPosDif = atoi(sValor);
		if(strcmp(sVariable, "iLongExpr")==0) stDatVA.iLongExpr = atoi(sValor);
		if(strcmp(sVariable, "iPosibX")==0) stDatVA.iPosibX = atoi(sValor);
		if(strcmp(sVariable, "iPosibP")==0) stDatVA.iPosibP = atoi(sValor);
		if(strcmp(sVariable, "iPosibN")==0) stDatVA.iPosibN = atoi(sValor);
		if(strcmp(sVariable, "iNumIntentos")==0) stDatVA.iNumIntentos = atol(sValor);
		if(strcmp(sVariable, "sEntrada")==0) strcpy(stDatVA.sEntrada, sValor);
		if(strcmp(sVariable, "sSalidas")==0) strcpy(stDatVA.sSalidas, sValor);
		if(strcmp(sVariable, "sArchResult")==0) strcpy(stDatVA.sArchResult, sValor);

        //Motor12. Uni�n.
		if(strcmp(sVariable, "iGeneraSimple")==0) stDatVA.iGeneraSimple = atoi(sValor);
		if(strcmp(sVariable, "iMutaSimple")==0) stDatVA.iMutaSimple = atoi(sValor);
		if(strcmp(sVariable, "iGeneraAzar")==0) stDatVA.iGeneraAzar = atoi(sValor);
		if(strcmp(sVariable, "iMutaTodoGen")==0) stDatVA.iMutaTodoGen = atoi(sValor);
		if(strcmp(sVariable, "iMutaParcGen")==0) stDatVA.iMutaParcGen = atoi(sValor);
		if(strcmp(sVariable, "iNumInstMin")==0) stDatVA.iNumInstMin = atoi(sValor);
		if(strcmp(sVariable, "iNumInstMax")==0) stDatVA.iNumInstMax = atoi(sValor);
		if(strcmp(sVariable, "iNumCiclos")==0) stDatVA.iNumCiclos = atoi(sValor);

	}
	fclose(fpInicio);
};

//Hace el encabezado del archivo de resultados
void Inicializa::vArchResult()
{
    //Leidos de una vez los par�metros de simulaci�n, comienza a simular
	FILE *fpSimular;
	fpSimular = fopen(stDatVA.sArchResult, "a+t");
	fprintf(fpSimular,"MOTOR12. Mejoras. \n");
	fprintf(fpSimular,"Serie Entrada: %s\n", stDatVA.sEntrada);
	fprintf(fpSimular,"Serie Salida: %s\n", stDatVA.sSalidas);
	fprintf(fpSimular,"\nPosibilidades:\n");
	fprintf(fpSimular,"1. Tipo de Instrucciones. If Condicional: %d, Asignacion: %d\n", stDatVA.iPosibIf, stDatVA.iPosibSet);
	fprintf(fpSimular,"2. En Instrucciones de If Condicional, el operador de comparacion es:  '==':%d, '>':%d, '<':%d, '!=':%d\n", stDatVA.iPosIg, stDatVA.iPosMay, stDatVA.iPosMen, stDatVA.iPosDif);
	fprintf(fpSimular,"3. Longitud de la expresi�n (n�mero de operadores): %d\n\n", stDatVA.iLongExpr);
	fprintf(fpSimular,"4. Construcci�n de las expresiones, posiblidad de salir X=%d, Parentesis:%d, N�meros=%d\n", stDatVA.iPosibX, stDatVA.iPosibP, stDatVA.iPosibN);
	fprintf(fpSimular,"5. Variables que se asignaran, compararan o estaran al interior de las expresiones: W=%d, X=%d, Y=%d, Z=%d\n", stDatVA.iPosW, stDatVA.iPosX, stDatVA.iPosY, stDatVA.iPosZ);
	fprintf(fpSimular,"\n\n");
	fprintf(fpSimular,"N�mero de veces que se crear� expresi�n simple: %d\n", stDatVA.iGeneraSimple);
	fprintf(fpSimular,"N�mero de veces que se mutar� la expresi�n simple: %d\n", stDatVA.iMutaSimple);
	fprintf(fpSimular,"N�mero de veces que se generar� algoritmos al azar: %d\n", stDatVA.iGeneraAzar);
	fprintf(fpSimular,"N�mero de veces que se mutar� todo un Gen:          %d\n", stDatVA.iMutaTodoGen);
	fprintf(fpSimular,"N�mero de veces que se mutar� parcialmente un Gen:  %d\n", stDatVA.iMutaParcGen);
	fprintf(fpSimular,"N�mero de Genes m�nimo: %d\n", stDatVA.iNumInstMin);
	fprintf(fpSimular,"N�mero de Genes m�ximo: %d\n", stDatVA.iNumInstMax);
	fprintf(fpSimular,"N�mero de ciclos CPU: %d\n\n", stDatVA.iNumCiclos);
	fclose(fpSimular);
};

void Inicializa::vGrabaResult(int iTipResult, char *sMensaje, unsigned int iContIntentos, float fErrOrg)
{
	FILE *fpSimular;
	time_t ltime;

	fpSimular = fopen(stDatVA.sArchResult, "a+t");

	if (iTipResult==1)
	{
		time( &ltime );
		fprintf(fpSimular,"Fecha: %s", ctime( &ltime ) );
	}
	else
		fprintf(fpSimular,"Intento: [%d]  Aproximaci�n: [%f]\n", iContIntentos, fErrOrg);

	fprintf(fpSimular,"%s\n", sMensaje);
	fclose(fpSimular);
};