﻿/* Autor: Rafael Alberto Moreno Parra
Fecha: 24 de julio de 2022

Programa 11. Teniendo en cuenta el sobreajuste
El sobreajuste es un problema que aparece cuando se busca la mejor curva de tendencia que represente a una serie de datos. Visualmente es detectable cuando entre un punto y el siguiente en los datos de entrenamiento, la curva es radicalmente distinta a una recta o curva sencilla que une a esos dos puntos, presentando un dibujado con profundos valles o enormes crestas como se ve en el gráfico:

Una curva así no sirve para hacer interpolación, ni mucho menos extrapolación porque simplemente no logra generalizar el comportamiento de los datos.

¿Cómo detectarlo? Hay una solución clásica y es la siguiente:

1. Del conjunto de datos de entrenamiento, tomar el 80% al azar.

2. Con ese 80% se generan varias curvas de tendencia.

3. Cada curva se evalúa con el 20% restante (datos de evaluación) y se mide su ajuste.

4. La curva que tenga el mejor ajuste a esos datos de evaluación es la que se escoge.

Con los algoritmos evolutivos lo anterior se cumple generando varias poblaciones y cada población tendrá su mejor individuo. Luego cada uno de esos individuos se le calcula su ajuste con los datos de validación.
Con las redes neuronales, es crear una nueva red con pesos al inicio al azar y hacer el proceso de BackPropagation. Luego a cada red se le calcula su ajuste con los datos de validación.
Como el programa genera un dataset de una ecuación al azar, entonces se pueden generar 150 datos para entrenar y 150 datos para validar.
*/
using System;
using System.Collections.Generic;


namespace Colaborar11 {
    internal class Program {
        //Para manejar la red neuronal
        static List<Perceptron> RedNeuronal;
        static double MejorRedAjuste;
        static int MejorRedNeuronal;

        //Para manejar el algoritmo evolutivo
        static List<Poblacion> Evolutivo;
        static double MejorPoblacionAjuste;
        static int MejorPoblacion;

        static void Main(string[] args) {
            //Generador único de números aleatorios
            Random Azar = new Random();

            //Configuración del generador de datos
            double ValorXini = -2;
            double ValorXfin = 2;
            int RegistrosGenera = 100;

            //Configuración del algoritmo evolutivo
            int IndividuosPorPoblacion = 300;

            //Configuración del perceptrón multicapa
            int TotalNeuronasCapaOculta1 = 5; //Total neuronas en la capa 0
            int TotalNeuronasCapaOculta2 = 5; //Total neuronas en la capa 1
            int NumeroEntradas = 1; //El valor de X
            int NumeroSalidas = 1; //El valor de Y

            //Número de veces que se generará poblaciones y redes neuronales
            int CiclosProceso = 4;

            //Tiempo en milisegundos que se dará en cada ciclo al algoritmo evolutivo y a la red neuronal
            int TiempoEvaluar = 20000;

            Console.WriteLine("COLABORAR 11. Teniendo en cuenta el sobreajuste.");
            Console.WriteLine("Fecha: " + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"));
            Console.WriteLine("Número de poblaciones y redes neuronales que se generarán: " + CiclosProceso.ToString());
            Console.WriteLine("Tiempo en milisegundos que tendrá cada población y cada red para ajustarse: " + TiempoEvaluar.ToString());

            Console.WriteLine("\r\n\r\nALGORITMO GENETICO: MEJORA LOS INDIVIDUOS Y LUEGO COMPITEN");
            Console.WriteLine("Número de individuos en la población: " + IndividuosPorPoblacion.ToString());

            Console.WriteLine("\r\n\r\nPERCEPTRON MULTICAPA");
            Console.WriteLine("Número de neuronas Primera Capa Oculta: " + TotalNeuronasCapaOculta1.ToString());
            Console.WriteLine("Número de neuronas Segunda Capa Oculta: " + TotalNeuronasCapaOculta2.ToString() + "\r\n");

            //Prepara el generador de datos y genera el dataset
            GeneradorDatos ConjuntoDatos = new GeneradorDatos();
            ConjuntoDatos.GeneraEcuacion(Azar, ValorXini, ValorXfin, RegistrosGenera);
            Console.WriteLine("Paso 1: Dataset generado");

            //Inicia la lista de poblaciones (algoritmo evolutivo)
            Evolutivo = new List<Poblacion>();

            //Inicia la lista de redes neuronales
            RedNeuronal = new List<Perceptron>();

            Console.WriteLine("Paso 2: Ciclos de entrenamiento a hacer: " + CiclosProceso.ToString());
            for (int Ciclos = 1; Ciclos <= CiclosProceso; Ciclos++) {
                Console.WriteLine("Ciclo #" + Ciclos.ToString());

                //===================
                //Algoritmo evolutivo
                //===================
                Evolutivo.Add(new Poblacion(Azar, IndividuosPorPoblacion));
                Evolutivo[Evolutivo.Count - 1].Proceso(Azar, TiempoEvaluar, ConjuntoDatos.Entradas, ConjuntoDatos.Salidas);

                //===================                
                //Red neuronal
                //===================
                RedNeuronal.Add(new Perceptron(Azar, NumeroEntradas, TotalNeuronasCapaOculta1, TotalNeuronasCapaOculta2, NumeroSalidas));
                RedNeuronal[RedNeuronal.Count - 1].Proceso(ConjuntoDatos.Entradas, ConjuntoDatos.Salidas, TiempoEvaluar);
            }
            Console.WriteLine("Finalizó el entrenamiento. Poblaciones generadas: " + Evolutivo.Count.ToString() + "  Redes neuronales generadas: " + RedNeuronal.Count.ToString());


            //El mejor de cada población del algoritmo evolutivo, se procesa con los datos de validación.
            //El que se acerque más a esos datos es el que se muestra
            Console.WriteLine("\r\nPaso 3: Algoritmo evolutivo. Yendo de población en población.");
            MejorPoblacionAjuste = double.MaxValue;
            MejorPoblacion = -1;
            for (int Cont = 0; Cont < Evolutivo.Count; Cont++) {
                Console.Write("Población #" + Cont.ToString());
                int Mejor = Evolutivo[Cont].MejorIndividuo;
                Console.Write(" Mejor individuo: " + Mejor.ToString() + " Ajuste entrenamiento: " + Evolutivo[Cont].Individuos[Mejor].Ajuste);

                Evolutivo[Cont].Individuos[Mejor].Ajuste = -1;
                Evolutivo[Cont].Individuos[Mejor].AjusteIndividuo(ConjuntoDatos.ValidaEntra, ConjuntoDatos.ValidaSale);
                Console.WriteLine(" Ajuste validación: " + Evolutivo[Cont].Individuos[Mejor].Ajuste);

                if (Evolutivo[Cont].Individuos[Mejor].Ajuste < MejorPoblacionAjuste) {
                    MejorPoblacionAjuste = Evolutivo[Cont].Individuos[Mejor].Ajuste;
                    MejorPoblacion = Cont;
                }
            }

            //Se evalúa cada red neuronal con los datos de validación.
            //La que se acerque más a esos datos es la que se muestra.
            Console.WriteLine("\r\nPaso 4: Buscando la mejor red neuronal con los datos de validación");
            MejorRedAjuste = double.MaxValue;
            MejorRedNeuronal = -1;
            for (int Cont = 0; Cont < Evolutivo.Count; Cont++) {
                double AjusteRed = RedNeuronal[Cont].Ajuste(ConjuntoDatos.Entradas, ConjuntoDatos.Salidas);
                Console.Write("Red #" + Cont.ToString() + " Ajuste entrenamiento: " + AjusteRed.ToString());
                AjusteRed = RedNeuronal[Cont].Ajuste(ConjuntoDatos.ValidaEntra, ConjuntoDatos.ValidaSale);
                Console.WriteLine(" Ajuste a validación: " + AjusteRed.ToString());

                if (AjusteRed < MejorRedAjuste) {
                    MejorRedAjuste = AjusteRed;
                    MejorRedNeuronal = Cont;
                }
            }


            //Salida del algoritmo evolutivo
            double TotalDiferencia = 0;
            for (int Num = 0; Num < ConjuntoDatos.Salidas.Length; Num++) {
                double SalidaEvolutivo = Evolutivo[MejorPoblacion].Individuos[Evolutivo[MejorPoblacion].MejorIndividuo].ValorSalida(ConjuntoDatos.Entradas[Num]);
                double Diferencia = (ConjuntoDatos.Salidas[Num] - SalidaEvolutivo) * (ConjuntoDatos.Salidas[Num] - SalidaEvolutivo);
                //Console.WriteLine(SalidaEvolutivo.ToString() + ";" + Diferencia.ToString());
                TotalDiferencia += Diferencia;
            }
            Console.WriteLine("\r\nALGORITMO EVOLUTIVO: " + TotalDiferencia.ToString());


            //Salida del algoritmo evolutivo
            //Console.WriteLine("\r\n=== RED NEURONAL ===");
            TotalDiferencia = 0;
            double[] Entradas = new double[1];
            for (int Num = 0; Num < ConjuntoDatos.Salidas.Length; Num++) {
                Entradas[0] = ConjuntoDatos.Entradas[Num];
                RedNeuronal[MejorRedNeuronal].CalculaSalidaRed(Entradas);
                double SalidaRed = RedNeuronal[MejorRedNeuronal].Capas[2].Salidas[0];
                double Diferencia = (ConjuntoDatos.Salidas[Num] - SalidaRed) * (ConjuntoDatos.Salidas[Num] - SalidaRed);
                //Console.WriteLine(SalidaRed.ToString() + ";" + Diferencia.ToString());
                TotalDiferencia += Diferencia;
            }
            Console.WriteLine("RED NEURONAL: " + TotalDiferencia.ToString());

            Console.WriteLine("\r\nFINAL");
            Console.ReadKey();
        }
    }
}
