﻿/* Autor: Rafael Alberto Moreno Parra
 * Fecha: 13 de julio de 2022
 * 
 */
using System;
using System.Diagnostics;

namespace Colaborar11 {
    internal class Poblacion {
        //Almacena los individuos de la población
        public Individuo[] Individuos;

        //Mejor individuo de la población
        public int MejorIndividuo;

        //Inicializa la población con un número de individuos
        public Poblacion(Random Azar, int numIndividuos) {
            Individuos = new Individuo[numIndividuos];
            for (int Contador = 0; Contador < numIndividuos; Contador++)
                Individuos[Contador] = new Individuo(Azar);
        }

        public void Proceso(Random Azar, long TiempoEvalua, double[] Entradas, double[] Salidas) {
            //Medidor de tiempos
            Stopwatch Cronometro = new Stopwatch();
            Cronometro.Reset();
            Cronometro.Start();

            while (Cronometro.ElapsedMilliseconds <= TiempoEvalua) {

                //Almacena el mejor individuo
                MejorIndividuo = -1;
                double MejorAjuste = double.MaxValue;

                //Almacena el peor individuo
                int PeorIndividuo = -1;
                double PeorAjuste = double.MinValue;

                //*******************************************
                //Parte 1: Mejora cada individuo
                //*******************************************
                for (int Contador = 0; Contador < Individuos.Length; Contador++) {
                    Individuos[Contador].MejoraIndividuo(Azar, Entradas, Salidas);

                    if (Individuos[Contador].Ajuste < MejorAjuste) {
                        MejorIndividuo = Contador;
                        MejorAjuste = Individuos[Contador].Ajuste;
                    }

                    if (Individuos[Contador].Ajuste > PeorAjuste) {
                        PeorIndividuo = Contador;
                        PeorAjuste = Individuos[Contador].Ajuste;
                    }
                }

                //****************************************************************
                //Parte 2: El mejor individuo sobreescribe al peor individuo
                for (int Copia = 0; Copia < Individuos[MejorIndividuo].Coef.Length; Copia++)
                    Individuos[PeorIndividuo].Coef[Copia] = Individuos[MejorIndividuo].Coef[Copia];
                Individuos[PeorIndividuo].Ajuste = Individuos[MejorIndividuo].Ajuste;
                //****************************************************************
            }
        }
    }
}
