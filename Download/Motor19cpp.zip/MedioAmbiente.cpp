/*
Autor:		Rafael Alberto Moreno Parra
URL:		http://www.geocities.com/krousky
Clase:		MedioAmbiente
Lenguaje:	C++

Prop�sito:
Analiza el medio ambiente para evaluaci�n posterior

M�todos:

*/

#include "MedioAmbiente.h"
#include "EvalExpr.h"

void MedioAmbiente::vEvalAmbiente(unsigned int Xini, unsigned int Xfin, char *sExpresion)
{
	/* evalua el ambiente previamente y lo almacena en un vector */
	EvalExpr eEvalua;

	double dResultado = eEvalua.dCapturaEcuacion(sExpresion, 0, 0);
	for(unsigned int iCont=Xini; iCont<=Xfin; iCont++)
		m_fAmbiente[iCont] = eEvalua.dCicloEvalua((float)iCont, 0.00);
};