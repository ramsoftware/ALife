/*
Autor:		Rafael Alberto Moreno Parra
URL:		http://www.geocities.com/krousky
Clase:		Organismo
Lenguaje:	C++

Prop�sito:
Clase de administraci�n del medio ambiente (serie num�rica de entrada y
salida)

M�todos:
IniciaSemillaT: Inicializa la semilla dependiendo del tiempo
IniciaSemillaR: Inicializa la semilla aleatoriamente
sDisplayADN: Despliega el organismo como si fuera c�digo Java
vCreaADN: Crea el organismo, llamando la funci�n que hace sus genes
vHaceGen: Crea una linea de codigo fuente (la llam� Gen). El formato es:
          label, [, IF/SET, Variable, =/>/</!, (, expresion, ), Goto, Label, ]
          para mayor velocidad, se ubica en una clase el Gen
vEvaluaPrevio: Optimiza la velocidad de evaluaci�n del organismo en un
               ambiente.
fEvalOrganismo: Evalua el organismo en el ambiente
vMutaGen: Mutaci�n suave de un gen del organismo

*/

#include <time.h>
#include "Gen.h"

class Organismo
{
public:
    Gen m_oGen[67]; //Genes del ser vivo

    Organismo(); //Constructor
	unsigned int m_iMaxGenOrg; //Maximo numero de genes para el organismo
    unsigned int m_iMaxiCiclos; //Maximo numero de ciclos que se gastaran para evaluar el organismo
	void sDisplayADN(char *sbADN);
    void vCreaADN (bool bGenRandom, unsigned int iMaxGenes,
                   unsigned int iPosibIf, unsigned int iPosibSet,
                   unsigned int iPosW,  unsigned int iPosX, unsigned int iPosY, unsigned int iPosZ,
                   unsigned int iPosIg, unsigned int iPosMay, unsigned int iPosMen, unsigned int iPosDif,
				   unsigned int iNumPosA, unsigned int iNumPosB, unsigned int iNumPosC, unsigned int iNumPosD, unsigned int iNumPosE);
    void vEvaluaPrevio(void);
    float fEvalOrganismo (float fValX);

    /* Crea una linea de codigo fuente (la llam� Gen). El formato es:
       label, [, IF/SET, Variable, =/>/</!, (, expresion, ), Goto, Label, ]
       para mayor velocidad, se ubica en una clase el Gen */
    void vHaceGen(unsigned int iLabel, unsigned int iMaxGenes,
                  unsigned int iPosibIf, unsigned int iPosibSet,
                  unsigned int iPosW,  unsigned int iPosX, unsigned int iPosY, unsigned int iPosZ,
                  unsigned int iPosIg, unsigned int iPosMay, unsigned int iPosMen, unsigned int iPosDif,
				  unsigned int iNumPosA, unsigned int iNumPosB, unsigned int iNumPosC, unsigned int iNumPosD, unsigned int iNumPosE);

	//Inicia la semilla de los n�meros aleatorios
    time_t ltime1;
	void IniciaSemillaT();
	void IniciaSemillaR();

	//Muta suavemente un Gen
	void vMutaGen(unsigned int iLabel, unsigned int iMaxGenes, unsigned int iNumPosA, unsigned int iNumPosB, unsigned int iNumPosC, unsigned int iNumPosD, unsigned int iNumPosE);
};