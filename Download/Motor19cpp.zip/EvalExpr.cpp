/* ARTIFICIAL LIFE ENGINE. EVALUADOR DE EXPRESIONES OPTIMIZADO.

   AUTOR: RAFAEL ABERTO MORENO PARRA

   EvalExpr de expresiones en Visual C++.	Enero 30 del 2000.

   Sus caracter�sticas principales son:
   - Evaluador NO recursivo.
   - Optimizado para Artificial Life Engine 
   - Evalua m_sFuncion trigonometricas en radianes.

   Forma de uso:

	 float dCapturaEcuacion(char *expresion, float valor_x, float valor_y);

		 Donde *expresion es una cadena donde reposa la expresion a evaluar,
		 por ejemplo: "4*2-x+y*3".
		 valor_x y valor_y son los valores con que va las variables 'x' y 'y'
		 en la expresi�n.
		 Esta subrutina retorna el valor de la expresi�n.

		 Ej:
			 void main()
			 {
			  float resultado;
			   char funcion[]="3*4+y-21*x";
			  float x=10.4, y=23.5;

			  resultado=dCapturaEcuacion(funcion, x, y);

			  printf("el resultado es %f", resultado);
			 }


	 float dCicloEvalua(float valor_x, float valor_y);

		 retorna los valores de una expresion anteriormente evaluada,
		 es muy veloz para ciclos.

		 Ej:

			 void main()
			 {
			  float resultado;
			   char funcion[]="3*4+y-21*x";
			  float x=10.4, y=23.5;
			   int contador;

			  resultado=dCapturaEcuacion(funcion, x, y);

			  printf("el resultado es %f\n", resultado);

			  for(i=1; i<=60; i++)
			  {
			   x*=i; y+=i;
			   resultado=dCicloEvalua(x, y);
			   printf("resultados parciales %f\n", resultado);
			  }
			 }



	  int iChequeaSintaxis( char *expresion)

	 retorna 0 si NO hay errores en la expresi�n.
	 retorna
		 1:  Dobles operandos. Ej: 5*+3
		 2:  Parentesis desbalanceados  Ej: 4-(3*4
		 3:  Numero seguido de (      Ej: 7-4(3*2)
		 4:  Operando(+,-,*,/) seguido de )   Ej: 3-(4*)+2
		 5:  Letra seguida de )     Ej: 7-(5-a)
		 6:  Mandato Desconocido  Ej: flow(3*4)

*/


/* COMO FUE PROGRAMADO:

   Supongamos una cadena de expresi�n as�:
	3-4*(3+x)+8-(2+x*x)

   la expresi�n se desintegra en acums:

   m_sAcum[0]="2+x*x"             => 3-4*(3+x)+8-@A;
   m_sAcum[1]="3x+8"               => 3-4*@B+8-@A;
   m_sAcum[2]="3-4*@B+8-@A"

   cada '@?' es evaluado como una expresi�n simple.
   m_sAcum[0]="2+x*y"
   => m_sVectorNumeros[0][0]="2"  m_sVectorOperador[0][0]='+';
	  m_sVectorNumeros[0][1]="x"   m_sVectorOperador[0][1]='*';
	  m_sVectorNumeros[0][2]="y"   m_sVectorOperador[0][2]='F';
*/


#include <stdio.h> //temporal
#include <string.h>
#include <ctype.h>
#include <math.h>
#include <stdlib.h>
#include "EvalExpr.h"

float EvalExpr::dCapturaEcuacion(char *sEcuacion, float dX, float dY)
{
 char *sEcuacion2, iCont;
 float resultado;

 m_iNumAcums=0;
 for(iCont=0; iCont<=29; iCont++) m_sAcum[iCont][0]='\0';
 vStringtoLower(sEcuacion);
 vEliminaEspacios(sEcuacion);

 sEcuacion2=(char *)malloc(strlen(sEcuacion)+4);
 strcpy(sEcuacion2, "@\0");
 strcat(sEcuacion2, sEcuacion); // la expresi�n debe empezar siempre en @

 vOptimizador(sEcuacion2); // desglosa la cadena(expresion algebraica) en acums
 vArreglaAcumn();

 //Depuraci�n......
 vCicloAcumn();
 free(sEcuacion2);

 resultado=dCicloEvalua(dX, dY);
 if(ERRORMATEMATICO==1){ resultado=0; ERRORMATEMATICO=0; }
 return resultado;
}

void EvalExpr::vOptimizador(char *sEcuacion)
{
 // convierte la expresion algebraica en acums
 char cCont1, cCont2, *sSubExpresion, *sReemplazo;

 sSubExpresion=(char *) malloc(strlen(sEcuacion)+5);
 sReemplazo=(char *) malloc(4);

 do{
  for(cCont1=strlen(sEcuacion); cCont1>=1; cCont1--)
   if( *(sEcuacion+cCont1) == '(' ) // busca parentesis
   {
	*(sEcuacion+cCont1)='<'; // los cambia por "<"
    break;
   }
  if(cCont1) // si hay parentesis "(" se debe buscar el ")"
  {
   for(cCont2=cCont1; *(sEcuacion+cCont2); cCont2++)
    if( *(sEcuacion+cCont2) == ')')
    {
     *(sEcuacion+cCont2)='>'; // cambia el ) por >
     vMid(sSubExpresion,sEcuacion,cCont1+2,cCont2); // extrae la expresion entre parentesis
     strcpy(m_sAcum[m_iNumAcums], sSubExpresion);

     // reemplaza la sSubExpresion entre parentesis por un @A, @B, @C hasta @Z (el l�mite)
	 sReemplazo[0]='@';
	 sReemplazo[1]=m_iNumAcums+65;
	 sReemplazo[2]='\0';
     vReemplazarExpr(sEcuacion, sReemplazo, cCont1, cCont2+2);
     m_iNumAcums++;
     break;
    }
  }
 }while(cCont1); // para hasta que se acaben los parentesis
 strcpy(m_sAcum[m_iNumAcums], sEcuacion);
 free(sReemplazo); free(sSubExpresion);
}


void EvalExpr::vReemplazarExpr( char *sEcuacion,  char *sReemplazo,
		      char cDesde,  char cHasta)
{
 char *sTemCad1, *sTemCad2;

 sTemCad1=( char *)malloc(strlen(sEcuacion)+2);
 sTemCad2=( char *)malloc(strlen(sEcuacion)+2);

 vLeft(sTemCad1, sEcuacion, cDesde);
 strcat(sTemCad1, sReemplazo);
 vRight(sTemCad2, sEcuacion, cHasta);
 strcat(sTemCad1, sTemCad2);
 strcpy(sEcuacion, sTemCad1);

 free(sTemCad1);
 free(sTemCad2);
}


// subrutina que arregla los acums
void EvalExpr::vArreglaAcumn()
{
 int iCont;
 char *sTemCad;

 sTemCad=( char *)malloc(strlen(m_sAcum[m_iNumAcums])+3);
 vRight(sTemCad, m_sAcum[m_iNumAcums], 2);
 strcpy(m_sAcum[m_iNumAcums], sTemCad);
 free(sTemCad);

 for(iCont=0; iCont<=m_iNumAcums; iCont++)
  if(m_sAcum[iCont][0]=='-')  // cualquier expresion negativa ej: -x*3 => 0-x*3
  {
   sTemCad=( char *)malloc(strlen(m_sAcum[iCont])+3);
   strcpy(sTemCad, "0\0");
   strcat(sTemCad, m_sAcum[iCont]);
   strcpy(m_sAcum[iCont], sTemCad);
   free(sTemCad);
  }
}


void EvalExpr::vCicloAcumn()
{
 char iCont;

 //Pasa expresiones simples, no trigonometricas
 for(iCont=0; iCont<=m_iNumAcums; iCont++)
  if(m_sAcum[iCont][0]<'A' || m_sAcum[iCont][0]>'Z')
	  vDesintegraAcumn(m_sAcum[iCont], iCont);
}


// Desintegra los Acumns en operandos y operadores
void EvalExpr::vDesintegraAcumn(char *sExprSimple, char cIndAcum)
{
	char cCiclo, cCaract, cContLetr=0;
	char *cAcumNumeros, iContOper=0;

	cAcumNumeros=(char *)malloc(strlen(sExprSimple)+2);
	*cAcumNumeros='\0';
	for(cCiclo=0; cCiclo<=(char)strlen(sExprSimple); cCiclo++)
	switch( cCaract=*(sExprSimple+cCiclo) )
	{
		case 'x': // variable
		case 'y':
			m_sVectorNumeros[cIndAcum][cContLetr][0]=cCaract;
			cContLetr++;
			break;
		case '@': // Es un acumn
			 m_sVectorNumeros[cIndAcum][cContLetr][0]= *(sExprSimple+cCiclo+1);
			 cContLetr++;
			 cCiclo+=1;
			 break;
		case '*':
		case '/':
		case '+':
		case '-':
		case '^':
			m_sVectorOperador[cIndAcum][iContOper++]=cCaract;
			break;
		default: // o sea un numero
			cAcumNumeros[0]=cCaract;
			cAcumNumeros[1]='\0';
			strcpy(m_sVectorNumeros[cIndAcum][cContLetr++], cAcumNumeros);
			cAcumNumeros[0]='\0';
	   } // switch
   if( *cAcumNumeros != '\0') strcpy(m_sVectorNumeros[cIndAcum][cContLetr], cAcumNumeros);
   m_sVectorOperador[cIndAcum][iContOper]='F';
   free(cAcumNumeros);
}


float EvalExpr::dCicloEvalua(float dX, float dY)
{
 char iIndAcum;
  
 ERRORMATEMATICO=0;
 for(iIndAcum=0; iIndAcum<=m_iNumAcums; iIndAcum++)
   m_AcumFloat[iIndAcum]=dEvaluaExpresion(iIndAcum, dX, dY);

  if(ERRORMATEMATICO==0)
	  return(m_AcumFloat[m_iNumAcums]);
  else
	  return 0;
}



float EvalExpr::dEvaluaExpresion(char cIndiceAcum, float dX, float dY)
{
 char cOperando[20];
 float dNumero[20], dAcumResult=0;
 char cExplVect, cAjustVect, cExploraAcum, cLimArray=0;

 for(cExploraAcum=0;;cExploraAcum++)
 {
  switch(m_sVectorNumeros[cIndiceAcum][cExploraAcum][0])
  {
   case 'x': dNumero[cExploraAcum]=dX; break;
   case 'y': dNumero[cExploraAcum]=dY; break;
   case '.':
   case '1':
   case '2':
   case '3':
   case '4':
   case '5':
   case '6':
   case '7':
   case '8':
   case '9':
   case '0':
			 dNumero[cExploraAcum]=(float)atof(m_sVectorNumeros[cIndiceAcum][cExploraAcum]);
			 break;
   default:	 dNumero[cExploraAcum]=m_AcumFloat[m_sVectorNumeros[cIndiceAcum][cExploraAcum][0]-65];
  }
  cOperando[cExploraAcum]=m_sVectorOperador[cIndiceAcum][cExploraAcum];
  if(cOperando[cExploraAcum]=='F') break;
 }
 cLimArray=cExploraAcum;

 for(cExplVect=0; cExplVect<=cLimArray; cExplVect++)
  while(cOperando[cExplVect]=='/')
  {
   if(dNumero[cExplVect+1]!=0) dNumero[cExplVect]=dNumero[cExplVect]/dNumero[cExplVect+1];
   else { ERRORMATEMATICO=1; dNumero[cExplVect]=0; return 0; }
   for(cAjustVect=cExplVect+2; cAjustVect<=cLimArray+1; cAjustVect++)
   {
	dNumero[cAjustVect-1]=dNumero[cAjustVect];
	cOperando[cAjustVect-2]=cOperando[cAjustVect-1];
   }
   cLimArray--;
  }

 for(cExplVect=0; cExplVect<=cLimArray; cExplVect++)
  while(cOperando[cExplVect]=='*')
  {
   dNumero[cExplVect]=dNumero[cExplVect]*dNumero[cExplVect+1];
   for(cAjustVect=cExplVect+2; cAjustVect<=cLimArray+1; cAjustVect++)
   {
	dNumero[cAjustVect-1]=dNumero[cAjustVect];
	cOperando[cAjustVect-2]=cOperando[cAjustVect-1];
   }
   cLimArray--;
  }

 dAcumResult=dNumero[0];
 for(cExplVect=0; cExplVect<=cLimArray; cExplVect++)
  if(cOperando[cExplVect]=='+') dAcumResult+=dNumero[cExplVect+1];
  else
   if(cOperando[cExplVect]=='-') dAcumResult-=dNumero[cExplVect+1];

 return dAcumResult;
}

int EvalExpr::_matherr(struct exception *a)
{
	printf("Hubo un error\n");
	ERRORMATEMATICO=1;
    return 1;
}


// ******************************
// m_sFuncion DE CADENA (Librer�a)
// ****************************** 

// convierte a min�sculas
void EvalExpr::vStringtoLower(char *p)
{
 unsigned int iCont;
 for(iCont=0; iCont<=strlen(p); iCont++) *(p+iCont)=tolower(*(p+iCont));
}

// elimina los espacios, tabuladores, etc.. de la cadena
void EvalExpr::vEliminaEspacios( char *sCadena)
{
 unsigned int iCont=0, iCont2=0;
 char *sTempCad;

 sTempCad=( char *)malloc(strlen(sCadena)+5);
 for(iCont=0; *(sCadena+iCont); iCont++)
  if( *(sCadena+iCont) > 30 && *(sCadena+iCont)!=' ')
  {
   *(sTempCad+iCont2) = *(sCadena+iCont);
   iCont2++;
  }
 *(sTempCad+iCont2)='\0';
 strcpy(sCadena, sTempCad);
 free(sTempCad);
}

// Toma las primeras cNumLetras de la cadena sCadena2 y las deposita en sCadena1
void EvalExpr::vLeft(char *sCadena1, char *sCadena2, char cNumLetras)
{
 unsigned int iCont;
 for(iCont=0; iCont<=cNumLetras-1 && *(sCadena2+iCont); iCont++) *(sCadena1+iCont)=*(sCadena2+iCont);
 *(sCadena1+iCont)='\0';
}

// Toma las �ltimas cNumLetras de sCadena2 y las deposita en sCadena1
void EvalExpr::vRight( char *sCadena1,  char *sCadena2,  char cNumLetras)
{
 char iCont1, iCont2;
 for(iCont2=0, iCont1=cNumLetras-1; *(sCadena2+iCont1); iCont2++, iCont1++) *(sCadena1+iCont2)=*(sCadena2+iCont1);
 *(sCadena1+iCont2)='\0';
}

// Extrae una subcadena de sCadena2 y la deposita en sCadena1
void EvalExpr::vMid( char *sCadena1,  char *sCadena2,  char cDesde,  char cHasta)
{
 char iCont1, iCont2;
 for(iCont2=0, iCont1=cDesde-1; iCont1<=cHasta-1 && *(sCadena2+iCont1); iCont2++, iCont1++) *(sCadena1+iCont2)=*(sCadena2+iCont1);
 *(sCadena1+iCont2)='\0';
}