/* Autor: Rafael Alberto Moreno Parra
   Fecha: 19 de Noviembre de 2000

MOTOR19. Escrito en C++ (Compilado en Visual C++ 6.0)

Optimizaci�n agresiva
Analizando las expresiones generadas aleatoriamente en los motores anteriores, al factorizarlas
, la gran mayor�a son simples polin�mios del tipo a*X*X + b*X + c, luego se puede recortar el
proceso de generaci�n y an�lisis de expresiones para simplemente generar aleatoriamente los
factores a,b,c .
Beneficios:
1. Aumento dram�tico de la velocidad de evaluaci�n de algoritmos gen�ticos.
2. Poder usar n�meros reales (estaba limitado a enteros).
3. Expresiones ya factorizadas, luego mas eficientes.
Posibles problemas:
1. Limitaci�n de las expresiones aleatorias a solo ser polin�mios.
Observe estas expresiones:
y = 3-(4/x)
y = (x+3)/(x-7)
Pueden solucionarse estos problemas usando la siguientes estrat�gias:
a. y = (polinomio) / (polinomio)
b. y = a*Xe2 + b*Xe1 + c*Xe0 + d*Xe-1 + e*Xe-2
  
	
	  
Aqui se simula el comportamiento c�clico de un ambiente.
Por ejemplo:
		
Ambiente = sin(y) * (4+3*X-X*X)
Genero un valor Y=PI/2 y doy valores de X = 1..10 entonces:
		
sin(PI/2) * (4+3*X-X*X) = 1 * (4+3*X-X*X) = 6,6,4,0,-6,-14,-24,-36,-50,-66
Ahora genero un organismo que se adapte a ese ambiente (6,6,4,0,-6,-14,-24,-36,-50,-66)

Luego cambio el valor de Y=PI/3 y doy valores de X=1..10 entonces obtengo el ambiente
5.1961, 5.1961, 3.4641, 0, -5.1961, -12.1243, -20.7846, -31.1769, -43.30127, -50.1576
Ahora genero otro organismo para dicho ambiente

Y asi sucesivamente de Y=0 hasta 2*PI. Con eso obtengo una serie de organismos que se adaptan
a un determinado ciclo de un ambiente c�clico. Ahora es hacer que logren hacer simbiosis
y se obtiene el macroorganismo.
		
*/

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>

#include "Organismo.h"
#include "MasApto.h"
#include "MedioAmbiente.h"
#include "Inicializa.h"

void Simular(void);
void vQuitaEspacios(char *sCadena);
void vLeft(char *cad1, char *cad2, char num_letras);
void vRight(char *cad1, char *cad2, char num_letras);
void vMid(char *cad1, char *cad2, char desde, char hasta);

#define PI 3.1415926537


//Programa Principal
int main()
{
	//Definici�n de variables
	unsigned int iOrgSelecci=0; //Decide con que organismo jugar
	unsigned int iGeneracion=0; //Que estrat�gia usar� para generar organismos
	unsigned int iNumGenes=0;  //Contador de genes(instrucciones a generar)
	unsigned int iMutables=0; //N�mero de instrucciones realmente ejecutadas
	unsigned int iCopia=0; //Para copiar de MasAptos a Organismo
	unsigned int iMutar=1; //Que gen mutar�
	unsigned int iCicl=0; //En que parte del ciclo es mejor el organismo
	float fY=0; //Valor que tendr� el ciclo en un momento
	float fAcumErr; //Acumula el error de aproximaci�n del organismo al ambiente
	int iX=0; //Valor X de la expresi�n de ambiente
	float fDiferen; //Diferencia entre ambiente y organismo
	float fMinimo; //Buscar la mejor adaptaci�n
	int iLugar; //Contador temporal para averiguar la mejor adpataci�n
	float fAvance; //N�mero de partes en que se divide el ciclo
	unsigned int iRefrescaSemilla; //Para refrescar la semilla del generador aleatorio
	unsigned int iAcumRefresco;
	unsigned int iLleno;
	unsigned int iParcialLleno=0;
	unsigned int iFinSimul=1;
	float fTamanoCiclo; //Porci�n del ciclo a evaluar, m�ximo de 0 a 2*PI


	Inicializa objInicializa; //Inicializa la simulaci�n
    MedioAmbiente objAmbiente;
	Organismo objOrganismo;

    //Presentaci�n
	objInicializa.vPantallaIni();
	
	//Lee los parametros de simulaci�n
	int iLeeDatos = objInicializa.vLeeArchivoIni();
	if (iLeeDatos == -1) return 1;
	objAmbiente.iInicio = objInicializa.stDatVA.iXini;
	objAmbiente.iFinal = objInicializa.stDatVA.iXfin;

	//Reserva memoria para el total de organismos
	MasApto objMasApto[100]; //Los mejores organismos
	
	//Evalua las partes en que se dividir� el ciclo
	fTamanoCiclo = 2*PI/objInicializa.stDatVA.iParcCiclo;
	fAvance = fTamanoCiclo / objInicializa.stDatVA.iNumOrganismos;

	//Inicializa Organismos Aptos (c�digo -1)
	for (int iCont=0; iCont<objInicializa.stDatVA.iNumOrganismos+1; iCont++)
	{
		objMasApto[iCont].iCodMasApto = -1;
		objMasApto[iCont].fErrAdapta = (float) 99999999;
	}

    //Deduce el ambiente
	objAmbiente.vEvalAmbiente(objInicializa.stDatVA.iXini, objInicializa.stDatVA.iXfin, objInicializa.stDatVA.sAmbiente);


    //Inicializa el comportamiento aleatorio
	objOrganismo.IniciaSemillaT();
	objOrganismo.m_iMaxiCiclos =  objInicializa.stDatVA.iNumCiclos;
	objOrganismo.vCreaADN(false, 65,
					objInicializa.stDatVA.iPosibIf,
					objInicializa.stDatVA.iPosibSet,
					objInicializa.stDatVA.iPosW,
					objInicializa.stDatVA.iPosX,
					objInicializa.stDatVA.iPosY,
					objInicializa.stDatVA.iPosZ,
					objInicializa.stDatVA.iPosIg,
					objInicializa.stDatVA.iPosMay,
					objInicializa.stDatVA.iPosMen,
					objInicializa.stDatVA.iPosDif,
					objInicializa.stDatVA.iNumPosA,
					objInicializa.stDatVA.iNumPosB,
					objInicializa.stDatVA.iNumPosC,
					objInicializa.stDatVA.iNumPosD,
					objInicializa.stDatVA.iNumPosE);

    //Informaci�n Inicial de la simulaci�n para simple expresi�n
	objOrganismo.m_oGen[1].bEjecuta = false;
	objOrganismo.m_oGen[1].cTipInst = 'S';
	objOrganismo.m_oGen[1].cVarActiva = 'X';
	objOrganismo.m_oGen[1].cVariable = 'Y';
	objOrganismo.m_oGen[1].iGotoLabel = 0;
	objOrganismo.m_iMaxGenOrg = 1;


	//Encabezado archivo de resultados
	objInicializa.vArchResult(); //Encabezado

	/* En esta simulaci�n ambiente c�clico, se tendr� en cuenta la generaci�n
	   de organismos simples (una l�nea) y tipo algoritmo: Proceso de mutaci�n
	   fuerte y sutil */
	iRefrescaSemilla=0;
	iAcumRefresco=0;
	while(true)
	{
		//En pruebas muy largas, es necesario refrescar el generador de n�meros aleatorios
		iRefrescaSemilla++;
		if (iRefrescaSemilla > 1000)
		{
			iAcumRefresco++;
			iRefrescaSemilla = 0;
			printf("\nRefrescos (grupos de 1000): [%d]\n",iAcumRefresco);

			iFinSimul=1;
			for (iLleno=0; iLleno < objInicializa.stDatVA.iNumOrganismos; iLleno++)
			{
				printf("Asi esta: [%d] Error: [%f]\n", iLleno, objMasApto[iLleno].fErrAdapta);
				if (objMasApto[iLleno].fErrAdapta > objInicializa.stDatVA.fMaximoError)
					iFinSimul=0;
			}

			if (iAcumRefresco >= objInicializa.stDatVA.iDetiene) break;
			if (iFinSimul==1) break;

			objOrganismo.IniciaSemillaT(); //Inicializa la semilla por medio del reloj
		}

		iOrgSelecci = rand()%objInicializa.stDatVA.iNumOrganismos; //Decide con que organismo jugar
		if (objMasApto[iOrgSelecci].iCodMasApto != -1) //Si ya lo ocupaba alguien
		{
			if (objMasApto[iOrgSelecci].m_iMaxGenOrg > 1 )
        		iGeneracion = rand()%4+1; //Decide entre las 4 estrat�gias
			else
      			iGeneracion = rand()%2+1; //Decide entre las 2 estrat�gias

			switch(iGeneracion)
			{
				case 1: //Genera un organismo
					if (objInicializa.stDatVA.iNumPosA!=0)
						objOrganismo.m_oGen[1].iA = objInicializa.stDatVA.iNumPosA - rand()%(objInicializa.stDatVA.iNumPosA*2);
					else
						objOrganismo.m_oGen[1].iA = 0;

					if (objInicializa.stDatVA.iNumPosB!=0)
						objOrganismo.m_oGen[1].iB = objInicializa.stDatVA.iNumPosB - rand()%(objInicializa.stDatVA.iNumPosB*2);
					else
						objOrganismo.m_oGen[1].iB = 0;

					if (objInicializa.stDatVA.iNumPosC!=0)
						objOrganismo.m_oGen[1].iC = objInicializa.stDatVA.iNumPosC - rand()%(objInicializa.stDatVA.iNumPosC*2);
					else
						objOrganismo.m_oGen[1].iC = 0;

					if (objInicializa.stDatVA.iNumPosD!=0)
						objOrganismo.m_oGen[1].iD = objInicializa.stDatVA.iNumPosD - rand()%(objInicializa.stDatVA.iNumPosD*2);
					else
						objOrganismo.m_oGen[1].iD = 0;

					if (objInicializa.stDatVA.iNumPosE!=0)
						objOrganismo.m_oGen[1].iE = objInicializa.stDatVA.iNumPosE - rand()%(objInicializa.stDatVA.iNumPosE*2);
					else
						objOrganismo.m_oGen[1].iE = 0;

					break;

				case 2: //Genera Aleatoriamente los Algoritmos
					iNumGenes = rand() % (objInicializa.stDatVA.iNumInstMax - objInicializa.stDatVA.iNumInstMin) + objInicializa.stDatVA.iNumInstMin;
					objOrganismo.vCreaADN(false, iNumGenes,
							objInicializa.stDatVA.iPosibIf,
							objInicializa.stDatVA.iPosibSet,
							objInicializa.stDatVA.iPosW,
							objInicializa.stDatVA.iPosX,
							objInicializa.stDatVA.iPosY,
							objInicializa.stDatVA.iPosZ,
							objInicializa.stDatVA.iPosIg,
							objInicializa.stDatVA.iPosMay,
							objInicializa.stDatVA.iPosMen,
							objInicializa.stDatVA.iPosDif,
							objInicializa.stDatVA.iNumPosA,
							objInicializa.stDatVA.iNumPosB,
							objInicializa.stDatVA.iNumPosC,
							objInicializa.stDatVA.iNumPosD,
							objInicializa.stDatVA.iNumPosE);

					objOrganismo.m_iMaxGenOrg = iNumGenes;

					//Restaura la primera instruccion
					objOrganismo.m_oGen[1].cOperacion = objMasApto[iOrgSelecci].m_oGen[1].cOperacion;
					objOrganismo.m_oGen[1].cTipInst = objMasApto[iOrgSelecci].m_oGen[1].cTipInst;
					objOrganismo.m_oGen[1].cVarActiva = objMasApto[iOrgSelecci].m_oGen[1].cVarActiva;
					objOrganismo.m_oGen[1].cVariable = objMasApto[iOrgSelecci].m_oGen[1].cVariable;
					objOrganismo.m_oGen[1].iGotoLabel = objMasApto[iOrgSelecci].m_oGen[1].iGotoLabel;
					break;

				case 3: //Muta todo un Gen
					iMutables=0;
					for (iCopia=1; iCopia <= objMasApto[iOrgSelecci].m_iMaxGenOrg; iCopia++)
					{
						if (objMasApto[iOrgSelecci].m_oGen[iCopia].bEjecuta == true) iMutables++;
						objOrganismo.m_oGen[iCopia].bEjecuta = false;
						objOrganismo.m_oGen[iCopia].cOperacion = objMasApto[iOrgSelecci].m_oGen[iCopia].cOperacion;
						objOrganismo.m_oGen[iCopia].cTipInst = objMasApto[iOrgSelecci].m_oGen[iCopia].cTipInst;
						objOrganismo.m_oGen[iCopia].cVarActiva = objMasApto[iOrgSelecci].m_oGen[iCopia].cVarActiva;
						objOrganismo.m_oGen[iCopia].cVariable = objMasApto[iOrgSelecci].m_oGen[iCopia].cVariable;
						objOrganismo.m_oGen[iCopia].iGotoLabel = objMasApto[iOrgSelecci].m_oGen[iCopia].iGotoLabel;
						objOrganismo.m_oGen[iCopia].iA = objMasApto[iOrgSelecci].m_oGen[iCopia].iA;
						objOrganismo.m_oGen[iCopia].iB = objMasApto[iOrgSelecci].m_oGen[iCopia].iB;
						objOrganismo.m_oGen[iCopia].iC = objMasApto[iOrgSelecci].m_oGen[iCopia].iC;
						objOrganismo.m_oGen[iCopia].iD = objMasApto[iOrgSelecci].m_oGen[iCopia].iD;
						objOrganismo.m_oGen[iCopia].iE = objMasApto[iOrgSelecci].m_oGen[iCopia].iE;
					}
					objOrganismo.m_iMaxGenOrg = objMasApto[iOrgSelecci].m_iMaxGenOrg;

					//Escoge que Gen mutar�, muta los que se ejecutaron
					iMutar = rand() % (iMutables-1) + 2;
					for (iCopia=1; iCopia <= objMasApto[iOrgSelecci].m_iMaxGenOrg; iCopia++)
					{
						if (objMasApto[iOrgSelecci].m_oGen[iCopia].bEjecuta == true) iMutar--;
						if (iMutar==0) break;
					}
					iMutar = iCopia; //La posici�n real a mutar

					//Muta el Gen
					objOrganismo.vHaceGen(iMutar, objOrganismo.m_iMaxGenOrg,
							objInicializa.stDatVA.iPosibIf,
							objInicializa.stDatVA.iPosibSet,
							objInicializa.stDatVA.iPosW,
							objInicializa.stDatVA.iPosX,
							objInicializa.stDatVA.iPosY,
							objInicializa.stDatVA.iPosZ,
							objInicializa.stDatVA.iPosIg,
							objInicializa.stDatVA.iPosMay,
							objInicializa.stDatVA.iPosMen,
							objInicializa.stDatVA.iPosDif,
							objInicializa.stDatVA.iNumPosA,
							objInicializa.stDatVA.iNumPosB,
							objInicializa.stDatVA.iNumPosC,
							objInicializa.stDatVA.iNumPosD,
							objInicializa.stDatVA.iNumPosE);
					break;

				case 4: //Muta un Gen pero de forma sutil
						iMutables=0;
						for (iCopia=1; iCopia <= objMasApto[iOrgSelecci].m_iMaxGenOrg; iCopia++)
						{
							if (objMasApto[iOrgSelecci].m_oGen[iCopia].bEjecuta == true) iMutables++;
							objOrganismo.m_oGen[iCopia].bEjecuta = false;
							objOrganismo.m_oGen[iCopia].cOperacion = objMasApto[iOrgSelecci].m_oGen[iCopia].cOperacion;
							objOrganismo.m_oGen[iCopia].cTipInst = objMasApto[iOrgSelecci].m_oGen[iCopia].cTipInst;
							objOrganismo.m_oGen[iCopia].cVarActiva = objMasApto[iOrgSelecci].m_oGen[iCopia].cVarActiva;
							objOrganismo.m_oGen[iCopia].cVariable = objMasApto[iOrgSelecci].m_oGen[iCopia].cVariable;
							objOrganismo.m_oGen[iCopia].iGotoLabel = objMasApto[iOrgSelecci].m_oGen[iCopia].iGotoLabel;
							objOrganismo.m_oGen[iCopia].iA = objMasApto[iOrgSelecci].m_oGen[iCopia].iA;
							objOrganismo.m_oGen[iCopia].iB = objMasApto[iOrgSelecci].m_oGen[iCopia].iB;
							objOrganismo.m_oGen[iCopia].iC = objMasApto[iOrgSelecci].m_oGen[iCopia].iC;
							objOrganismo.m_oGen[iCopia].iD = objMasApto[iOrgSelecci].m_oGen[iCopia].iD;
							objOrganismo.m_oGen[iCopia].iE = objMasApto[iOrgSelecci].m_oGen[iCopia].iE;
						}
						objOrganismo.m_iMaxGenOrg = objMasApto[iOrgSelecci].m_iMaxGenOrg;

						//Escoge que Gen mutar�, muta los que se ejecutaron
						iMutar = rand() % (iMutables - 1) + 2;
						for (iCopia=1; iCopia <= objMasApto[iOrgSelecci].m_iMaxGenOrg; iCopia++)
						{
							if (objMasApto[iOrgSelecci].m_oGen[iCopia].bEjecuta == true) iMutar--;
							if (iMutar==0) break;
						}
						iMutar = iCopia; //La posici�n real a mutar

						//Muta el Gen en forma sutil
						objOrganismo.vMutaGen(iMutar, objOrganismo.m_iMaxGenOrg, objInicializa.stDatVA.iNumPosA, objInicializa.stDatVA.iNumPosB, objInicializa.stDatVA.iNumPosC, objInicializa.stDatVA.iNumPosD, objInicializa.stDatVA.iNumPosE);
						break;
			} //Fin switch()
		}
		else //Es la primera vez que se genera para esta parte del ciclo un organismo
		{
					if (objInicializa.stDatVA.iNumPosA!=0)
						objOrganismo.m_oGen[1].iA = objInicializa.stDatVA.iNumPosA - rand()%(objInicializa.stDatVA.iNumPosA*2);
					else
						objOrganismo.m_oGen[1].iA = 0;

					if (objInicializa.stDatVA.iNumPosB!=0)
						objOrganismo.m_oGen[1].iB = objInicializa.stDatVA.iNumPosB - rand()%(objInicializa.stDatVA.iNumPosB*2);
					else
						objOrganismo.m_oGen[1].iB = 0;

					if (objInicializa.stDatVA.iNumPosC!=0)
						objOrganismo.m_oGen[1].iC = objInicializa.stDatVA.iNumPosC - rand()%(objInicializa.stDatVA.iNumPosC*2);
					else
						objOrganismo.m_oGen[1].iC = 0;

					if (objInicializa.stDatVA.iNumPosD!=0)
						objOrganismo.m_oGen[1].iD = objInicializa.stDatVA.iNumPosD - rand()%(objInicializa.stDatVA.iNumPosD*2);
					else
						objOrganismo.m_oGen[1].iD = 0;

					if (objInicializa.stDatVA.iNumPosE!=0)
						objOrganismo.m_oGen[1].iE = objInicializa.stDatVA.iNumPosE - rand()%(objInicializa.stDatVA.iNumPosE*2);
					else
						objOrganismo.m_oGen[1].iE = 0;
		}

		// Busca en que parte del ciclo es mejor el organismo
		iCicl=0;
		fMinimo = 9999999;
		iLugar = 0;

		for (fY=0; fY<=fTamanoCiclo; fY+=fAvance)
		{
			fAcumErr=0;
			for (iX=objAmbiente.iInicio; iX<=objAmbiente.iFinal; iX++)
			{
				fDiferen = (float) fabs(objOrganismo.fEvalOrganismo((float)iX) - sin(fY)*objAmbiente.m_fAmbiente[iX]);
				fAcumErr += fDiferen;
			}

			// El organismo ocupa las posiciones en el ciclo donde mejor se desempe�e
			if (objMasApto[iLugar].fErrAdapta > fAcumErr)
			{
				for (iCopia=1; iCopia <= objOrganismo.m_iMaxGenOrg; iCopia++)
				{
					objMasApto[iLugar].m_oGen[iCopia].bEjecuta = objOrganismo.m_oGen[iCopia].bEjecuta;
					objMasApto[iLugar].m_oGen[iCopia].cOperacion = objOrganismo.m_oGen[iCopia].cOperacion;
					objMasApto[iLugar].m_oGen[iCopia].cTipInst = objOrganismo.m_oGen[iCopia].cTipInst;
					objMasApto[iLugar].m_oGen[iCopia].cVarActiva = objOrganismo.m_oGen[iCopia].cVarActiva;
					objMasApto[iLugar].m_oGen[iCopia].cVariable = objOrganismo.m_oGen[iCopia].cVariable;
					objMasApto[iLugar].m_oGen[iCopia].iGotoLabel = objOrganismo.m_oGen[iCopia].iGotoLabel;
					objMasApto[iLugar].m_oGen[iCopia].iA = objOrganismo.m_oGen[iCopia].iA;
					objMasApto[iLugar].m_oGen[iCopia].iB = objOrganismo.m_oGen[iCopia].iB;
					objMasApto[iLugar].m_oGen[iCopia].iC = objOrganismo.m_oGen[iCopia].iC;
					objMasApto[iLugar].m_oGen[iCopia].iD = objOrganismo.m_oGen[iCopia].iD;
					objMasApto[iLugar].m_oGen[iCopia].iE = objOrganismo.m_oGen[iCopia].iE;
				}
				objMasApto[iLugar].fErrAdapta = fAcumErr;
				objMasApto[iLugar].iCodMasApto = iLugar;
				objMasApto[iLugar].m_iMaxGenOrg = objOrganismo.m_iMaxGenOrg;
				objOrganismo.IniciaSemillaR(); //Inicializa la semilla aleatoriamente
			}
			iLugar++;
		}

	}

	//Imprime los resultados
	char sTextOrganismo[5000];
	for (iLugar=0; iLugar < objInicializa.stDatVA.iNumOrganismos; iLugar++)
	{
		for (iCopia=1; iCopia <= objMasApto[iLugar].m_iMaxGenOrg; iCopia++)
		{
			objOrganismo.m_oGen[iCopia].cOperacion = objMasApto[iLugar].m_oGen[iCopia].cOperacion;
			objOrganismo.m_oGen[iCopia].cTipInst = objMasApto[iLugar].m_oGen[iCopia].cTipInst;
			objOrganismo.m_oGen[iCopia].cVarActiva = objMasApto[iLugar].m_oGen[iCopia].cVarActiva;
			objOrganismo.m_oGen[iCopia].cVariable = objMasApto[iLugar].m_oGen[iCopia].cVariable;
			objOrganismo.m_oGen[iCopia].iGotoLabel = objMasApto[iLugar].m_oGen[iCopia].iGotoLabel;
			objOrganismo.m_oGen[iCopia].iA = objMasApto[iLugar].m_oGen[iCopia].iA;
			objOrganismo.m_oGen[iCopia].iB = objMasApto[iLugar].m_oGen[iCopia].iB;
			objOrganismo.m_oGen[iCopia].iC = objMasApto[iLugar].m_oGen[iCopia].iC;
			objOrganismo.m_oGen[iCopia].iD = objMasApto[iLugar].m_oGen[iCopia].iD;
			objOrganismo.m_oGen[iCopia].iE = objMasApto[iLugar].m_oGen[iCopia].iE;
		}
		objOrganismo.m_iMaxGenOrg = objMasApto[iLugar].m_iMaxGenOrg;
		objOrganismo.sDisplayADN(sTextOrganismo);
		objInicializa.vImprMacroOrg(iLugar, objInicializa.stDatVA.iNumOrganismos, sTextOrganismo, objMasApto[iLugar].fErrAdapta);
	}
	objInicializa.vImprTiempoFin();
	return 1;
}