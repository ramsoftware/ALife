/*
[A-Life]: Investigaci�n sobre Vida Artificial. El Algoritmo Evolutivo.

Autor: Rafael Alberto Moreno Parra. enginelife@hotmail.com
URL:   http://www.geocities.com/krousky
Fecha: 24 de Marzo de 2001

Simulaci�n:  AlgEvo003
Herramienta: Microsoft Visual C++ 6.0

Objetivo:
Hay un Universo
Universo tiene ambientes
Universo tiene tipos de materiales
Hay materiales de cada tipo dispersos por todo el Universo
El ser vivo es la cooperaci�n entre materiales
Hay tipos de seres vivos (el concepto de especie).

*/
#include <stdlib.h>
#include <stdio.h>

#include "Universo.h"

//Constructor
Universo::Universo()
{
	time(&ltime1);
}


//Inicializa la semilla dependiendo del tiempo
void Universo::IniciaSemillaT()
{
	time_t ltime2;
	do
	{
		time(&ltime2);
	}while(ltime2==ltime1);
	srand( ltime2 );
	ltime1 = ltime2;
}

//Inicializa la semilla aleatoriamente
void Universo::IniciaSemillaR()
{
	srand(rand());
};


//Genera ambientes, tipos de materiales, materiales, especies y organismos
unsigned int Universo::BigBang(void)
{
	unsigned int iCont, iCont1, iCont2, iDentro, iEspecie;
	signed int iNacio;

	//Trae los datos del archivo de configuracion
	objInicia.vPantallaIni();
	objInicia.vLeeArchivoIni();

	// Valores de inicializaci�n
	m_iTotalAmb = objInicia.stDatVA.iTotalAmb;
	m_iTotalTip = objInicia.stDatVA.iTotalTip;
	m_iTotalMat = objInicia.stDatVA.iTotalMat;
	m_iTotalEsp = objInicia.stDatVA.iTotalEsp;
	m_iTotalOrg = objInicia.stDatVA.iTotalOrg;
	m_iTotalTipMatEsp = objInicia.stDatVA.iTipMatEsp;
	m_iTotalMaterialporTipo = objInicia.stDatVA.iMaxMatTip;
	m_iXmin = objInicia.stDatVA.iXmin;
	m_iYmin = objInicia.stDatVA.iYmin;
	m_iXmax = objInicia.stDatVA.iXmax;
	m_iYmax	= objInicia.stDatVA.iYmax;

	// Reserva memoria
	objAmb = (Ambiente *) malloc ( sizeof(Ambiente) * m_iTotalAmb );
	if (objAmb == NULL) return ERRORMEMORIA;

	objTip = (TipoMat *) malloc ( sizeof(TipoMat) * m_iTotalTip );
	if (objTip == NULL) return ERRORMEMORIA;

	objMat = (Material *) malloc ( sizeof(Material) * m_iTotalMat );
	if (objMat == NULL) return ERRORMEMORIA;

	objEsp = (TipoOrg *) malloc ( sizeof(TipoOrg) * m_iTotalEsp );
	if (objEsp == NULL) return ERRORMEMORIA;

	objOrg = (Organismo *) malloc ( sizeof(Organismo) * m_iTotalOrg );
	if (objOrg == NULL) return ERRORMEMORIA;

	//Reserva memoria para la lista de ID de materia para cada organismo
	for (iCont=0; iCont < m_iTotalOrg; iCont++)
	{
		objOrg[iCont].m_iIDmaterial = (unsigned int *) malloc ( sizeof(unsigned int) * (m_iTotalTipMatEsp *  m_iTotalMaterialporTipo) );
	}
	
	//Inicia proceso aleatorio
	IniciaSemillaT();

	//Crea los ambientes
	for (iCont=0; iCont < m_iTotalAmb; iCont++)
		objAmb[iCont].iInicia(iCont, m_iXmin, m_iYmin, m_iXmax, m_iYmax,
								objInicia.stDatVA.iLongExprAmb,
								objInicia.stDatVA.iProbN,
								objInicia.stDatVA.iProbX,
								objInicia.stDatVA.iProbY,
								objInicia.stDatVA.iProbP);

	//Crea los tipos de materiales
	for (iCont=0; iCont < m_iTotalTip; iCont++)
		objTip[iCont].iInicia(iCont,
								objInicia.stDatVA.iLongExprTip,
								objInicia.stDatVA.iTipProbN,
								objInicia.stDatVA.iTipProbX,
								objInicia.stDatVA.iTipProbP);

	//Crea los materiales y los relaciona a un tipo de material
	for (iCont=0; iCont < m_iTotalMat; iCont++)
		objMat[iCont].vInicia(iCont, m_iXmin, m_iYmin, m_iXmax, m_iYmax, m_iTotalTip);

	//Crea los tipos de organismos (especies)
	//Debe haber un m�nimo n�mero de tipos y materiales en si para una especie
	for (iCont=0; iCont < m_iTotalEsp; iCont++)
	{
		//Aleatoriamente decide cuantos tipos de materiales tendr� esa especie
		objEsp[iCont].m_iIdTipMat = (unsigned int *) malloc ( sizeof(unsigned int) * objInicia.stDatVA.iTipMatEsp );
		if (objEsp[iCont].m_iIdTipMat == NULL) return ERRORMEMORIA;

		//Reserva memoria tambi�n para el puntero que tendr� el n�mero de materiales por tipo
		objEsp[iCont].iNumMaterialporTipo = (unsigned int *) malloc ( sizeof(unsigned int) * objInicia.stDatVA.iMaxMatTip );
		if (objEsp[iCont].iNumMaterialporTipo == NULL) return ERRORMEMORIA;

		//Codigo de la especie
		objEsp[iCont].m_iIdTipOrg = iCont;

		//Tolerancia de la especie (al azar)
		do
		{
			objEsp[iCont].m_iToleranciaMin = objInicia.stDatVA.iTolVivoMin + rand()%(objInicia.stDatVA.iTolVivoMax - objInicia.stDatVA.iTolVivoMin);
			objEsp[iCont].m_iToleranciaMax = objInicia.stDatVA.iTolVivoMax - rand()%(objInicia.stDatVA.iTolVivoMax - objInicia.stDatVA.iTolVivoMin);
		}while (objEsp[iCont].m_iToleranciaMin > objEsp[iCont].m_iToleranciaMax);
		
		//Tipos de material y cantidad que tendr� cada especie
		for (iCont1=0; iCont1 < m_iTotalTipMatEsp; iCont1++) 
		{
			do
			{
				objEsp[iCont].m_iIdTipMat[iCont1] = rand()%m_iTotalTip; //Escoge al azar el tipo de material
				
				//Evita que el tipo de material se repita dentro de una misma especie
				iDentro=0;	
				for (iCont2=0; iCont2<iCont1; iCont2++)
					if (objEsp[iCont].m_iIdTipMat[iCont2] == objEsp[iCont].m_iIdTipMat[iCont1])
						iDentro=1;
			}while(iDentro==1);
			
			 // �Cuantos materiales por tipo?
			objEsp[iCont].iNumMaterialporTipo[iCont1] = rand()%m_iTotalMaterialporTipo + 1;
		}
	}
	
	//Imprime los resultados en consola
	for (iCont=0; iCont < m_iTotalEsp; iCont++)
	{
		printf("\n\nEspecie = %d  ", objEsp[iCont].m_iIdTipOrg);
		printf("Compuesta de:\n");
		for (iCont1=0; iCont1 < m_iTotalTipMatEsp; iCont1++) 
			printf("[%d,%d] ", objEsp[iCont].m_iIdTipMat[iCont1], objEsp[iCont].iNumMaterialporTipo[iCont1]);
	}

	//Crea Organismos por especie
	for (iCont=0; iCont < m_iTotalOrg; iCont++)
	{
		iEspecie = rand() % m_iTotalEsp;
		iNacio = iNaceOrg(iCont, iEspecie);
	}
	
	//Imprime los resultados en consola
	for (iCont=0; iCont < m_iTotalOrg; iCont++)
	{
		printf("\n\nOrganismo = %d\n", iCont);
		printf("Vive? = %d\n", objOrg[iCont].m_cVivo);

		if (objOrg[iCont].m_cVivo == ORG_VIVO)
		{
			printf("Especie = %d\n", objOrg[iCont].iEspecie);
			printf("Estabilidad = %d\n", objOrg[iCont].m_iEstabilidad);
			printf("Numero Materiales = %d\n", objOrg[iCont].iTotalMaterial);
			printf("Compuesta de:\n");
			for (iCont1=0; iCont1 < objOrg[iCont].iTotalMaterial; iCont1++) 
				printf("%d,", objOrg[iCont].m_iIDmaterial[iCont1]);
		}
	}

	return OPERACIONEXITOSA;
}

/* Procedimiento para que un organismo nazca */
int Universo::iNaceOrg(unsigned int iOrganismo, unsigned int iEspecie)
{
	unsigned int iCont, iTipoMaterial, iCantidad, iMater, iAcumula=0;

	/* Por defecto el ser vivo esta muerto */
    objOrg[iOrganismo].m_cVivo = ORG_MUERTO;

	/* Especie del Organismo */
	objOrg[iOrganismo].iEspecie = iEspecie;

	/* Inicia la energia (en la mitad de estabilidad m�nima y m�xima) */
	objOrg[iOrganismo].m_iEstabilidad = objEsp[iEspecie].m_iToleranciaMin + (objEsp[iEspecie].m_iToleranciaMax - objEsp[iEspecie].m_iToleranciaMin)/2;
	
	/* Determina si hay materiales libres para esa especie */
	for (iCont=0; iCont < m_iTotalTipMatEsp; iCont++)
	{
		/* Datos de la especie */
		iTipoMaterial = objEsp[iEspecie].m_iIdTipMat[iCont];
		iCantidad = objEsp[iEspecie].iNumMaterialporTipo[iCont];
		if (iCantidad==0) continue;

		/* Chequea toda la materia del Universo */
		for (iMater=0; iMater < m_iTotalMat; iMater++)
		{
			if (objMat[iMater].m_iTipMaterial == iTipoMaterial)
				if (objMat[iMater].m_cUsado == MAT_NOOCUPADO)
					iCantidad--;

			if (iCantidad==0)
				break;
		}

		if (iCantidad>0)
			return -1;  /* No hay suficiente cantidad */
	}

	/* Crea el ser vivo */
	objOrg[iOrganismo].m_cVivo = ORG_VIVO;

	/* Reserva el material para el organismo */
	for (iCont=0; iCont < m_iTotalTipMatEsp; iCont++)
	{
		/* Datos de la especie */
		iTipoMaterial = objEsp[iEspecie].m_iIdTipMat[iCont];
		iCantidad = objEsp[iEspecie].iNumMaterialporTipo[iCont];
		if (iCantidad==0) continue;

		/* Chequea la materia del Universo */
		for (iMater=0; iMater < m_iTotalMat; iMater++)
		{
			if (objMat[iMater].m_iTipMaterial == iTipoMaterial)
				if (objMat[iMater].m_cUsado == MAT_NOOCUPADO)
				{
					objMat[iMater].m_cUsado = MAT_OCUPADO;
					objOrg[iOrganismo].m_iIDmaterial[iAcumula++] = objMat[iMater].m_iIDmat;
					objOrg[iOrganismo].iTotalMaterial = iAcumula;
					iCantidad--;
				}

			if (iCantidad==0)
				break;
		}
	}
	return 1;
};


/* Procedimiento para que un organismo muera */
void Universo::iMuereOrg(unsigned int iOrganismo)
{
	unsigned int iCont, iIDmaterial;

	objOrg[iOrganismo].m_cVivo = ORG_MUERTO;
	
	/* Libera el material del organismo */
	for (iCont=0; iCont < objOrg[iOrganismo].iTotalMaterial; iCont++)
	{
		iIDmaterial = objOrg[iOrganismo].m_iIDmaterial[iCont];
		objMat[iIDmaterial].m_cUsado = MAT_NOOCUPADO;
	}
};


/* Dado un punto, que valor tiene este cubierto de 0 a N ambientes */
float Universo::fValPosXY(unsigned int iPosX, unsigned int iPosY)
{
	unsigned int iCont;
	float fValor=0;

	for (iCont=0; iCont < m_iTotalAmb; iCont++)
		fValor += objAmb[iCont].fValCoord(iPosX, iPosY);

	return fValor;
};


/* Ciclo de la vida */
void Universo::vCicloVida()
{
	unsigned int iCont, iCont1, iContinua, iEspecie;
	signed int iNacio;

	//Es un ciclo de vida, los que sobreviven a cada ciclo tienen la oportunidad de 
	//reproducirse.
	for(;;)
	{
		iContinua=0;
		printf("\n\nSobreviven: ");
		for (iCont=0; iCont < m_iTotalOrg; iCont++)
		{
			if ( objOrg[iCont].m_cVivo == ORG_VIVO )
			{
				iContinua=1;
				iEspecie = objOrg[iCont].iEspecie;

				//Busca algun c�digo que no est� usado
				for (iCont1=0; iCont1<m_iTotalOrg; iCont1++)
				{
					if ( objOrg[iCont1].m_cVivo == ORG_MUERTO )
						break;
				}

				if (iCont1!=m_iTotalOrg)
					iNacio = iNaceOrg(iCont1, iEspecie);
			}
		}

		for (iCont=0; iCont < m_iTotalOrg; iCont++)
			if ( objOrg[iCont].m_cVivo == ORG_VIVO )
				printf("[Id=%d,Esp=%d,Est=%d] ", iCont, objOrg[iCont].iEspecie, objOrg[iCont].m_iEstabilidad);

		if (iContinua==0) break;
		vEvaluaOrganismo();
	}
	printf("\n");
}


/* Evalua el Organismo */
void Universo::vEvaluaOrganismo()
{
	unsigned int iCont, iCont1, iMaterial, iTipMaterial, iPosX, iPosY, iEspecie;
	signed int iEnergia;
	float fValor;

	/* Toma cada organismo que a�n viva */
	for (iCont=0; iCont < m_iTotalOrg; iCont++)
	{
		iEspecie = objOrg[iCont].iEspecie;

		if ( objOrg[iCont].m_cVivo == ORG_VIVO )
		{
			// Se va por cada material de que este hecho el organismo
			for (iCont1=0; iCont1 < objOrg[iCont].iTotalMaterial; iCont1++)
			{
				// �De que material esta hecho?
				iMaterial = objOrg[iCont].m_iIDmaterial[iCont1];

				// �Donde esta ubicado ese material?
				iPosX = objMat[iMaterial].m_iPosX;
				iPosY = objMat[iMaterial].m_iPosY;

				// �Que tipo de material es?
				iTipMaterial = objMat[iMaterial].m_iTipMaterial;

				// �Que ambiente hay en esa ubicaci�n?
				fValor = fValPosXY(iPosX, iPosY);

				//�Como reacciona el material a ese ambiente?
				iEnergia = objTip[iTipMaterial].iEnergia(fValor);

				//�Como afecta esa reacci�n al organismo?
				objOrg[iCont].m_iEstabilidad += iEnergia;
			}

			// �Sobrevivir� el organismo?
			if ( objOrg[iCont].m_iEstabilidad > objEsp[iEspecie].m_iToleranciaMax ||
				 objOrg[iCont].m_iEstabilidad < objEsp[iEspecie].m_iToleranciaMin)
				 iMuereOrg(iCont);
		}
	}
}
