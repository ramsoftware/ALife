/*
[A-Life]: Investigaci�n sobre Vida Artificial. El Algoritmo Evolutivo.

Autor: Rafael Alberto Moreno Parra. enginelife@hotmail.com
URL:   http://www.geocities.com/krousky
Fecha: 24 de Marzo de 2001

Simulaci�n:  AlgEvo003
Herramienta: Microsoft Visual C++ 6.0

Objetivo:
Hay un Universo
Universo tiene ambientes
Universo tiene tipos de materiales
Hay materiales de cada tipo dispersos por todo el Universo
El ser vivo es la cooperaci�n entre materiales

*/

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>
#include "Inicializa.h"
#include "StringUtil.h"

void Inicializa::vPantallaIni()
{
	printf("Motor de Vida Artificial\n\n");
	printf("Algoritmo Evolutivo 004: Inicios\n\n");
	printf("Autor: Rafael Alberto Moreno Parra\n");
	printf("Fecha: 30 de Marzo de 2001\n");
	printf("E-mail: enginelife@hotmail.com\n");
	printf("http://www.geocities.com/krousky\n");
};

//Abre y estudia el archivo de inicializaci�n
int Inicializa::vLeeArchivoIni()
{
	FILE *fpInicio;
	char sFrase[600], sVariable[200], sValor[200];
    unsigned int iCar, iResultado;
	StringUtil StrUtil;

	fpInicio = fopen("AlgEv004.ini", "r+t");
	if (fpInicio == NULL)
    {
		printf("Error al tratar de abrir archivo de inicializacion AlgEv004.ini\n");
		return -1;
    }

	while(!feof(fpInicio))
	{
		fgets(sFrase, 298, fpInicio);
		iResultado = StrUtil.vQuitaEspacios(sFrase);
		if (iResultado==0) continue;

		//Extrae variables y valores
		for (iCar=0; iCar<strlen(sFrase) && sFrase[iCar]!='='; iCar++);
		StrUtil.vLeft(sVariable, sFrase, iCar);
		StrUtil.vMid(sValor, sFrase, iCar+2,strlen(sFrase)-1);

		//Clasifica

		//Para Universo
		if(strcmp(sVariable, "iXmin")==0) stDatVA.iXmin = atoi(sValor);
		if(strcmp(sVariable, "iYmin")==0) stDatVA.iYmin = atoi(sValor);
		if(strcmp(sVariable, "iXmax")==0) stDatVA.iXmax = atoi(sValor);
		if(strcmp(sVariable, "iYmax")==0) stDatVA.iYmax = atoi(sValor);

		if(strcmp(sVariable, "iTotalAmb")==0) stDatVA.iTotalAmb = atoi(sValor); //Total ambientes
		if(strcmp(sVariable, "iTotalTip")==0) stDatVA.iTotalTip = atoi(sValor); //Total tipos de materia
		if(strcmp(sVariable, "iTotalMat")==0) stDatVA.iTotalMat = atoi(sValor); //Total materiales
		if(strcmp(sVariable, "iTotalEsp")==0) stDatVA.iTotalEsp = atoi(sValor); //N�mero de especies
		if(strcmp(sVariable, "iTotalOrg")==0) stDatVA.iTotalOrg = atoi(sValor); //Total organismos

		//Para ambiente
		if(strcmp(sVariable, "iLongExprAmb")==0) stDatVA.iLongExprAmb = atoi(sValor); //Longitud de la expresi�n de ambiente
		if(strcmp(sVariable, "iProbN")==0) stDatVA.iProbN = atoi(sValor); // Probabilidad de Numero
		if(strcmp(sVariable, "iProbX")==0) stDatVA.iProbX = atoi(sValor); // Probabilidad de variable X
		if(strcmp(sVariable, "iProbY")==0) stDatVA.iProbY = atoi(sValor); // Probabilidad de variable Y
		if(strcmp(sVariable, "iProbP")==0) stDatVA.iProbP = atoi(sValor); // Probabilidad de parentesis

		//Para tipo de material
		if(strcmp(sVariable, "iLongExprTip")==0) stDatVA.iLongExprTip = atoi(sValor); //Longitud de la expresi�n de tipo de material
		if(strcmp(sVariable, "iTipProbN")==0) stDatVA.iTipProbN = atoi(sValor); // Probabilidad de Numero
		if(strcmp(sVariable, "iTipProbX")==0) stDatVA.iTipProbX = atoi(sValor); // Probabilidad de variable X
		if(strcmp(sVariable, "iTipProbP")==0) stDatVA.iTipProbP = atoi(sValor); // Probabilidad de parentesis

		//Para especie
		if(strcmp(sVariable, "iTipMatEsp")==0) stDatVA.iTipMatEsp = atoi(sValor); //M�ximo n�mero de tipos de material que tendr� cada especie
		if(strcmp(sVariable, "iMaxMatTip")==0) stDatVA.iMaxMatTip = atoi(sValor); //M�ximos materiales por tipo de material que tendr� cada especie
		if(strcmp(sVariable, "iTolVivoMin")==0) stDatVA.iTolVivoMin = atoi(sValor); // Probabilidad de Numero
		if(strcmp(sVariable, "iTolVivoMax")==0) stDatVA.iTolVivoMax = atoi(sValor); // Probabilidad de variable X
	}
	fclose(fpInicio);
	return 0;
};
