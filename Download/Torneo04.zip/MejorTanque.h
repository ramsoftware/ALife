/* Los mejores tanques */

// Ocupa 4+5*4 = 24 bytes
class MejorTanque
{
public:
	unsigned int iCodigo;
	unsigned int iEvento[5];
};