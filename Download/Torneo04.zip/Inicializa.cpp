/*
Autor:		Rafael Alberto Moreno Parra
URL:		http://www.geocities.com/krousky
Clase:		Inicializa.
Lenguaje:	C++
Prop�sito:
Inicializa las variables para la simulaci�n
*/

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>
#include "Inicializa.h"
#include "StringUtil.h"

void Inicializa::vPantallaIni()
{
	printf("Torneo 04: MacroOrganismo\n\n");
	printf("Autor: Rafael Alberto Moreno Parra\n");
	printf("Fecha: 05 de Diciembre de 2004\n");
	printf("E-mail: enginelife@hotmail.com\n");
	printf("http://www.geocities.com/krousky\n\n");
};

//Abre y estudia el archivo de inicializaci�n
int Inicializa::vLeeArchivoIni()
{
	FILE *fpInicio;
	char sFrase[600], sVariable[200], sValor[200];
	unsigned int iCar;
	StringUtil StrUtil;
	
	//Inicializa la estructura
	stDatVA.bMutacion = false;
	
	fpInicio = fopen("Tanque04.ini", "r+t");
	if (fpInicio == NULL)
    {
		printf("Error al tratar de abrir archivo de inicializaci�n Tanque04.ini\n");
		return -1;
    }
	
	while(!feof(fpInicio))
	{
		fgets(sFrase, 298, fpInicio);
		StrUtil.vQuitaEspacios(sFrase);
		
		//Extrae variables y valores
		for (iCar=0; iCar<strlen(sFrase) && sFrase[iCar]!='='; iCar++);
		StrUtil.vLeft(sVariable, sFrase, iCar);
		StrUtil.vMid(sValor, sFrase, iCar+2,strlen(sFrase)-1);
		
		//Clasifica variables
		if(strcmp(sVariable, "NUMTANQUES")==0) stDatVA.iNumTanques = atoi(sValor);
		if(strcmp(sVariable, "NUMINSTRUC")==0) stDatVA.iBloqueInstr = atoi(sValor);
		if(strcmp(sVariable, "TABLEROX")==0) stDatVA.iTableroX = atoi(sValor);
		if(strcmp(sVariable, "TABLEROY")==0) stDatVA.iTableroY = atoi(sValor);
		if(strcmp(sVariable, "CONSTVIDA")==0) stDatVA.iConstVida = atoi(sValor);
		if(strcmp(sVariable, "MAXCICLOS")==0) stDatVA.iMaxCiclos = atoi(sValor);
		if(strcmp(sVariable, "LIMREPRODUCE")==0) stDatVA.iLimReproduce = atoi(sValor);
		if(strcmp(sVariable, "TORNEOS")==0) stDatVA.iTorneos = atoi(sValor);
		if(strcmp(sVariable, "MUTACION")==0) 
			if (atoi(sValor) == 1 )
				stDatVA.bMutacion = true;
	}
	
	
	//Valida los valores de entrada
	if (stDatVA.iNumTanques < 2 && stDatVA.iNumTanques > 3999)
	{
		printf("N�mero de tanques debe ser entre 2 y 3999\n");
		return -1;
	}

	if (stDatVA.iBloqueInstr < 3 && stDatVA.iBloqueInstr > 199)
	{
		printf("N�mero de bloque de instrucciones debe ser entre 3 y 199\n");
		return -1;
	}

	if (stDatVA.iTableroX * stDatVA.iTableroY < stDatVA.iNumTanques )
	{
		printf("Tamano del tablero debe ser mayor que el n�mero de tanques a ubicar\n");
		return -1;
	}

	fclose(fpInicio);
    return 0;
};

void Inicializa::vInforme()
{
	printf("Numero de Organismos simples que se generan: %d\n", stDatVA.iBloqueInstr);
	printf("Numero de Organismos simples para crear un MacroOrganismo: 5\n");
	printf("Numero de MacroOrganismos que se generan: %d\n", stDatVA.iNumTanques);
	printf("Ambiente cuadrado es de: %d x %d\n", stDatVA.iTableroX, stDatVA.iTableroY);
	printf("Valor energ�tico con que empieza cada MacroOrganismo: %d\n", stDatVA.iConstVida);
	printf("Maximos ciclos de CPU por evento procesado: %d\n", stDatVA.iMaxCiclos);
	printf("Valor minimo de energia del MacroOrganismo para reproducirse: %d\n", stDatVA.iLimReproduce);
	printf("Torneos a realizarse: %d\n", stDatVA.iTorneos);
	printf("El hijo muta o es un clon de su padre?: ");
	if (stDatVA.bMutacion)
		printf("Muta\n");
	else
		printf("Clon\n");
};