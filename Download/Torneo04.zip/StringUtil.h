/*
Autor:		Rafael Alberto Moreno Parra
URL:		http://www.geocities.com/krousky
Clase:		StringUtil
Lenguaje:	C++
Prop�sito:
Clase de generaci�n/modificaci�n de expresiones matem�ticas en forma
aleatoria.

M�todos:
void StringUtil::vLeft(char *sCadena1, char *sCadena2, char cNumLetras)

*/

class StringUtil
{
public:
	void vLeft(char *, char *, unsigned int);
	void vMid( char *, char *, unsigned int, unsigned int);
	int vQuitaEspacios(char *);
};