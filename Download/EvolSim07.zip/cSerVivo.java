import java.applet.*;
import java.awt.*;
import EvalExpr;

//Ser vivo
class cSerVivo extends Applet
{
	//Memoria c�clica
	double fMemoValY[] = new double [180];
	int iMemoAmbi[] = new int [180];
	double fMemoRecvsAdapta[] = new double [180];
	
	//Instancia del evaluador de expresiones
	EvalExpr eEvalua;

	//Expresion o ADN del ser vivo
	String sExpresion;
	
	//Adaptacion del ser vivo al medio ambiente (entre mas se aproxime a cero mejor)
	float fAproxima;

	//Energia acumulada del ser vivo
	double dEnergia;
	double dRecursovsAdaptacion;

	
	//El ambiente
	int m_iSerieNum[] = new int[50]; //El ambiente en numeros enteros
	double m_dSerieNum[] = new double [50]; //El ambiente en numeros double
	int m_iContSerie;	//Numero de elementos en la serie
	int m_iCodAmbiente; // Codigo del Ambiente


	public cSerVivo()
	{
		eEvalua = new EvalExpr();
		dEnergia = 0.0;
		fAproxima = 0;
		dRecursovsAdaptacion = 0.0;
		m_iContSerie = 0;
		m_iCodAmbiente = 0;
	}

	public void vAmbiente(String m_sSerieNum)
	{
		int iCont;
		String sAcum="";
		m_iContSerie=0;

		// Ahora deshace la expresion en un arreglo de enteros
		for(iCont=0; iCont<=m_sSerieNum.length()-1; iCont++)
		{
			if (m_sSerieNum.charAt(iCont) != ',' )
				sAcum += m_sSerieNum.charAt(iCont);
			else
			{
				if (sAcum.length()>0)
				{
					m_iSerieNum[m_iContSerie]=Integer.parseInt(sAcum);
					m_iContSerie++;
					sAcum="";
				}
			}
		}
	}
	
	public int iAdaptarse01()  //Chequea su sintaxis
	{
		if (sExpresion.length() > 0)
			return eEvalua.iChequeaSintaxis(sExpresion,1);
		else
			return -1;
	}

	public double dAdaptarse02() //Chequea su adaptacion a la serie (ambiente)
	{
		double dDiferenc; // La diferencia entre la serie y el valor que deduce la expresion
		double dTotDifer=0; //La sumatoria de diferencias
		double dX=0; //Variable X
		int iCont;

		double dResult = eEvalua.dCapturaecuacion(sExpresion, 0, 0);

		for(iCont=0; iCont<m_iContSerie; iCont++)
		{
		   dX++;
		   dDiferenc=m_iSerieNum[iCont]-eEvalua.CicloEvalua(dX, 0);
		   if (eEvalua.m_iERROR==1) return 99999999;
		   if (dDiferenc<0) dDiferenc*=-1;
		   dTotDifer+=dDiferenc;
		}
		return dTotDifer;
	}

	public void vAdaptarse03() //Chequea su adaptacion y los recursos
	{
		double dDiferenc; // La diferencia entre la serie y el valor que deduce la expresion
		double dTotDifer=0; //La sumatoria de diferencias
		double dX=0; //Variable X
		int iCont;
		double dRecurso=0;

		double dResult = eEvalua.dCapturaecuacion(sExpresion, 0, 0);

		for(iCont=0; iCont<m_iContSerie; iCont++)
		{
		   dX++;
		   dDiferenc=m_dSerieNum[iCont]-eEvalua.CicloEvalua(dX, 0);
		   dRecurso+=Math.abs(m_dSerieNum[iCont]);
		   if (eEvalua.m_iERROR==1) break;
		   if (dDiferenc<0) dDiferenc*=-1;
		   dTotDifer+=dDiferenc;
		}
		dRecursovsAdaptacion = dRecurso - dTotDifer;
	}


	//===========================================================//
	//Metodos de la memoria c�clica
	public void vIniMemoria()
	{
		int iCont;

		for (iCont=0; iCont<180; iCont++)
		{
			fMemoValY[iCont] = -99999999.9;
			iMemoAmbi[iCont] = -99;
			fMemoRecvsAdapta[iCont] = -99999999.9;
		}
	}

	public void vMemoCiclica (double fValorY, int iAmbiente, double fRecvsAdapta)
	{
		int iCont;
		String sRegistro;

		//Valida que no exista ese registro
		for (iCont=1; iCont<180; iCont++)
			if (fMemoValY[iCont]==fValorY && iMemoAmbi[iCont]==iAmbiente) return;
		
		//Si no existe lo adiciona a la memoria
		for (iCont=1; iCont<180; iCont++)
			if (iMemoAmbi[iCont]==-99)
			{
				fMemoValY[iCont] = fValorY;
				iMemoAmbi[iCont] = iAmbiente;
				fMemoRecvsAdapta[iCont] = fRecvsAdapta;
				break;
			}
		
	}


	//Busca en memoria si alguno de los ambientes da mas energia (o menos perdida)
	public int iAmbMemorizado(double fValY, int iNumAmbientes, int iAmbActual, double fEnergia)
	{
		int iCont, iContAmbiente=0;
		double fEnergiaMax=-99999999, fEnergiaNeg=-9999999;
		int iAmbienteOK=-1, iAmbMenosDano=-1;
		int iAmbEncuentra[] = new int[iNumAmbientes+2];
		String sRegistro="";

		//Inicializa la lista
		for (iCont=1; iCont<=iNumAmbientes; iCont++)
			iAmbEncuentra[iCont]=-99;

		for (iCont=1; iCont<180; iCont++)
		{
			//Encuentra un registro en memoria
			if (fValY == fMemoValY[iCont])
			{
				//Este codigo se requiere despues para saber
				//que ambientes habia almacenado
				iContAmbiente = iMemoAmbi[iCont];
				iAmbEncuentra[iContAmbiente] = 0;
				
				//Si da energia positiva
				if (fMemoRecvsAdapta[iCont] > 0)
				{
					//Busca el mejor ambiente positivo
					if(fMemoRecvsAdapta[iCont] > fEnergiaMax)
					{
						fEnergiaMax = fMemoRecvsAdapta[iCont];
						iAmbienteOK = iMemoAmbi[iCont];
					}
				}
				else //Busca el ambiente menos da�ino.
				{
					if (fEnergiaNeg < -1*fMemoRecvsAdapta[iCont])
					{
						fEnergiaNeg = -1*fMemoRecvsAdapta[iCont];
						iAmbMenosDano = iMemoAmbi[iCont];
					}
				}
			}
		}
		
		//Si no encontro um ambiente que da energia entonces
		//busca en un ambiente desconocido...puede que haya suerte
		//pero si ya todos los conoce se va por el de menor perdida.
		if (iAmbienteOK==-1)
		{
			//Busca ambiente desconocido
			for(iCont=1; iCont<=iNumAmbientes; iCont++)
				if(iAmbEncuentra[iCont]==-99)
				{
					if (iCont==iAmbActual && fEnergia < 0 )
						iAmbActual = iAmbActual; // No haga nada
					else
						return iCont;
				}
			
			//Retorna el de menor perdida
			return iAmbMenosDano;
		}

		//Retorna ambiente que da Energia
		return iAmbienteOK;
	}
}
