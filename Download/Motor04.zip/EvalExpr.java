/* Evaluador de Expresiones escrito en Java
   
 Propiedad Intelectual
 Nombre:	Rafael Alberto Moreno Parra
 C.C.:		16.832.929 Jdi/Valle
 
 Programa:	Evaluador de expresiones en Java

 Descripcion: Esta clase sirve para entender expresiones algebraicas
			  hasta con dos variables (x,y)

 Fecha:		Marzo 03 de 1998

 Explicacion:

   Sus caracterisiticas principales son:
   - Evaluador NO recursivo.
   - Optimizado para ciclos.
   - Evalua funciones trigonometricas en radianes.
   - No se utilizan arboles, ni grafos.

   Forma de uso:

	 Ej:

		 public static void main(String args[])
		 {
		  // Variables comunes
		  double dResult;
		  String sEcuacion = "sin(x+y)+4*x^2-tan(y)"; // Una expresi�n algebraica con 2 variables
		  double dX=10.4, dY=23.5;
		  int iCont;

		  // Define la variable tipo clase 
		  EvalExpr eEvalua = new EvalExpr();

			//	Validar la sintaxis de la expresion
			//	Retorna
			//	 0:	 NO hay errores en la expresi�n.
			//	 1:  Dobles operandos. Ej: 5*+3
			//	 2:  Parentesis desbalanceados  Ej: 4-(3*4
			//	 3:  Numero seguido de (      Ej: 7-4(3*2)
			//	 4:  Operando(+,-,*,/) seguido de )   Ej: 3-(4*)+2
			//	 5:  Letra seguida de )     Ej: 7-(5-a)
			//	 6:  Mandato Desconocido  Ej: flow(3*4)
			

		  iValida = eEvalua.iChequeaSintaxis(sEcuacion);
		  
		  if (iValida != 0)
			switch(iValida)
			{
				case 1: System.out.println("Error de Sintaxis!: Dobles operandos");
						break;
				case 2: System.out.println("Error de Sintaxis!: Parentesis desbalanceados");
						break;
				case 3: System.out.println("Error de Sintaxis!: Numero seguido de (");
						break;
				case 4: System.out.println("Error de Sintaxis!: Operando seguido de )");
						break;
				case 5: System.out.println("Error de Sintaxis!: Funcion desconocida");
						break;
				case 6: System.out.println("Error de Sintaxis!: Signos raros");
						break;
			}
		  else
		  {
			
			  // Debe llamar primero al evaluador
			  dResultad = eEvalua.dCapturaecuacion(sEcuacion, 0, 0);
			  System.out.println("el resultado es " + dResult);


			  // Puede seguir usando la expresion ya evaluada en ciclos
			  // esto ofrece un gran desempe�o
			  for(iCont=1; iCont<=60; iCont++)
			  {
				   dX++; dY--;
				   dResult = eEvalua.dCicloEvalua(dX, dY);
				   System.out.println("Ciclo Resultado= " + dResult);
			  }
		   }
		 }


Algoritmo:

   Por ejemplo, si tuviesemos una expresion algebraica as�:
	13-4*sin(3+x)+8-(12+x*y)

   la expresi�n se desintegra en acums (siempre de derecha a izquierda)

   acum[0]="12+x*y"             => 13-4*sin(3+x)+8-acum0;
   acum[1]="3+x"                => 13-4*sinacum1+8-acum0;
   acum[2]="sinacum1"           => 13-4*acum2+8-acum0;
   acum[3]="13-4*acum2+8-acum0"

   cada 'acum' es evaluado como una expresion simple (se desintegra en operandos y operadores)
   acum[0]="12+x*y"
   => vector_numeros[0][0]="12"  vector_operador[0][0]='+';
	  vector_numeros[0][1]="x"   vector_operador[0][1]='*';
	  vector_numeros[0][2]="y"   vector_operador[0][2]='F';  //F fin de la expresion simple

Estandares:
 En el codigo, se uso el estandar Hungaro para nombrar variables y estandares aceptados Java
 Prefijo		Para
	i			integer
	d			double
	f			float
	s			String
	c			char
	m_			Variables de clase


*/

class EvalExpr
{
	// Variables de clase, se cumple el estandar de prefijo m_
	String m_sFuncion[] = new String[16];
	String m_sTabFunc[] = new String[16];
	String m_sAcum[] = new String[30];
	String m_sVectorNumeros[][] = new String[27][27];
	String m_sVectorOperador[][] = new String[27][27];
	int m_iNumAcums=0;
	double m_AcumFloat[] = new double[30];

	// Este es el constructor, inicializa variables
	EvalExpr()
	{
		int iCont, iCont2;

		m_sFuncion[0]="asn";
		m_sFuncion[1]="arcoseno";
		m_sFuncion[2]="acs";
		m_sFuncion[3]="arcocoseno";
		m_sFuncion[4]="atn";
		m_sFuncion[5]="arcotangente";
		m_sFuncion[6]="cos";
		m_sFuncion[7]="coseno";
		m_sFuncion[8]="sin";
		m_sFuncion[9]="sen";
		m_sFuncion[10]="seno";
		m_sFuncion[11]="tan";
		m_sFuncion[12]="tangente";
		m_sFuncion[13]="exp";
		m_sFuncion[14]="exponencial";
		m_sFuncion[15]="abs";
	
		
		m_sTabFunc[0] ="A";
		m_sTabFunc[1] ="A";
		m_sTabFunc[2] ="B";
		m_sTabFunc[3] ="B";
		m_sTabFunc[4] ="C";
		m_sTabFunc[5] ="C";
		m_sTabFunc[6] ="D";
		m_sTabFunc[7] ="D";
		m_sTabFunc[8] ="E";
		m_sTabFunc[9] ="E";
		m_sTabFunc[10] ="E";
		m_sTabFunc[11] ="F";
		m_sTabFunc[12] ="F";
		m_sTabFunc[13] ="G";
		m_sTabFunc[14] ="G";
		m_sTabFunc[15] ="H";

		m_iNumAcums=0;
		for(iCont=0; iCont<=29; iCont++) m_sAcum[iCont]="";
		
	}

	// Esta es la rutina p�blica para usuario
	public double dCapturaecuacion(String sEcuacion, double dX, double dY)
	{
		int iCont, iChar;
		double dResult=0;
	    m_iNumAcums=0;
		

		//La vuelve a minusculas, elimina espacios y la encierra en un parentesis
		sEcuacion = sEcuacion.toLowerCase();
		sEcuacion = Eliminaespacios(sEcuacion);
		sEcuacion = "@(" + sEcuacion + ")";
		
		// Desintegra la expresion en Acums
		vOptimizador(sEcuacion);

		// Desintegra cada Acums
		vDesintegraAcumn();

		//Manda a evaluar
		dResult = CicloEvalua(dX, dY);

		//Devuelve el valor de la expresion
		return dResult;
	}

	// Convierte la expresion en Acums
	void vOptimizador(String sEcuacion)
	{
		int iCont, iCont2, iCont3, iCadena;
		String sTempor;
		
		do{
			// Busca parentesis '(' de derecha a izquierda
			for (iCont=sEcuacion.length()-1; iCont>=0; iCont--)
				if (sEcuacion.charAt(iCont) == '(' )
					break;
			
			//Busca la pareja del '(', es decir: ')'
			if(iCont>0)
			{
				for (iCont2=iCont; iCont2<=sEcuacion.length()-1; iCont2++)
					if (sEcuacion.charAt(iCont2) == ')' )
						break;
				
				
				//Extraigo la subcadena entre parentesis y lo coloco en los acums...
				m_sAcum[m_iNumAcums] = sEcuacion.substring(iCont+1, iCont2);
				
				// Cambio la ecuacion por la nueva expresion basada en acums
				sEcuacion = sEcuacion.substring(0, iCont) + 'a' + (char) (m_iNumAcums+65) + sEcuacion.substring(iCont2+1);
				m_iNumAcums++;
								

				//Debe chequearse el uso de funciones como seno, coseno, tangente...
				for (iCont3=0; iCont3<16; iCont3++)
				{
					iCadena = m_sFuncion[iCont3].length();
					if ( iCont - iCadena > 0 )
					{
						sTempor = sEcuacion.substring(iCont - iCadena, iCont );
						if	( m_sFuncion[iCont3].compareTo(sTempor)  == 0)
						{
							m_sAcum[m_iNumAcums] = m_sTabFunc[iCont3] + 'a' + (char)(m_iNumAcums + 65 - 1);
							sEcuacion = sEcuacion.substring(0, iCont - iCadena ) + 'a' + (char) (m_iNumAcums+65) + sEcuacion.substring(iCont + m_sAcum[m_iNumAcums].length() - 1);
							m_iNumAcums++;
							break;
						}
					}
				}
			}
		} while (iCont > 0);


		// Arregla los m_sAcum, las expresiones negativas, ej: -x*3 quedan 0-x*3
		for(iCont=0; iCont<m_iNumAcums; iCont++)
			if (m_sAcum[iCont].charAt(0) == '-')
				m_sAcum[iCont] = "0" + m_sAcum[iCont];
	}


	// Desintegra los Acumns en operandos y operadores
	void vDesintegraAcumn()
	{
		int iCont, iChar, iColumn=0, iColumn2=0, iTemp;
		char cCaracter;
		String sNumero;


		//Inicializa las pilas de operadores y operandos
		for(iCont=0; iCont<27; iCont++)
			for(iChar=0; iChar<27; iChar++)
			{
				m_sVectorNumeros[iCont][iChar] = "";
				m_sVectorOperador[iCont][iChar] = "";
			}

		// Se va por todos los Acums
		for(iCont=0; iCont<m_iNumAcums; iCont++)
		{
			// Verifica si es una expresion simple (no una funci�n)
			if (m_sAcum[iCont].charAt(0) < 'A' || m_sAcum[iCont].charAt(0) > 'Z')
			{
				sNumero = ""; //Variable que lleva el acumulado de los numeros
				iColumn =0; // Variable que lleva la cuenta de los operandos
				iColumn2=0; // Variable que lleva la cuenta de los signos de operacion
				for(iChar=0; iChar < m_sAcum[iCont].length(); iChar++)
				{
					cCaracter=m_sAcum[iCont].charAt(iChar);
					switch(cCaracter)
					{
						case 'x':  // Variables
						case 'y':
									m_sVectorNumeros[iCont][iColumn] += cCaracter;
									iColumn++;

									break;

						case 'a':	//Es un Acumn. Lo convierte a letras mayusculas. Esto da una limitante de 25 Acums (A..Z).
									m_sVectorNumeros[iCont][iColumn] += m_sAcum[iCont].charAt(iChar+1);
									iColumn++;
									iChar++;
									break;
						case '*':
						case '/':
						case '+':
						case '-':
						case '^':   //Si lleva acumulado un numero entonces lo coloca en la pila de operandos
									//posteriormente coloca el signo de operacion en la pila de los operadores
									if( sNumero.length() > 0 )
									{
										m_sVectorNumeros[iCont][iColumn] = sNumero;
										iColumn++;
										sNumero = "";
									}
									m_sVectorOperador[iCont][iColumn2] += cCaracter;
									iColumn2++;
									break;
						default: /* es un numero */
									sNumero = sNumero + cCaracter;
					} // Fin switch
				} // Fin for
				
				// Si queda numeros remanentes lo adiciona a las pilas respectivas
				if( sNumero.length() > 0 )
					m_sVectorNumeros[iCont][iColumn] = sNumero;
				m_sVectorOperador[iCont][iColumn2] = "F";
			}	// Fin if

			// Imprime los resultados
//			System.out.println("Pilas de Operadores y Operandos");
//			for(iTemp=0; iTemp<=iColumn; iTemp++)
//				System.out.println(m_sVectorNumeros[iCont][iTemp] + " #### " + m_sVectorOperador[iCont][iTemp]);
		} //Fin for

	} // Fin m�todo


	//Esta es la subrutina publica. Evalua a gran velocidad.
	public double CicloEvalua(double dX, double dY)
	{
		int iCont;

		for(iCont=0; iCont<m_iNumAcums; iCont++)
			switch(m_sAcum[iCont].charAt(0))
			{
				case 'A':  // Arcoseno
						try
						{
							m_AcumFloat[iCont] = Math.asin(m_AcumFloat[iCont-1]);
							break;
						}
						catch(ArithmeticException a)
						{
							m_AcumFloat[iCont] = 0;
							return m_AcumFloat[iCont];
						}

				case 'B': //Arcocoseno
						try
						{
							m_AcumFloat[iCont] = Math.acos(m_AcumFloat[iCont-1]);
							break;
						}
						catch(ArithmeticException a)
						{
							m_AcumFloat[iCont] = 0;
							return m_AcumFloat[iCont];
						}

   				case 'C': //ArcoTangente
						try
						{
							m_AcumFloat[iCont]=  Math.atan(m_AcumFloat[iCont-1]);
							break;
						}
						catch(ArithmeticException a)
						{
							m_AcumFloat[iCont] = 0;
							return m_AcumFloat[iCont];
						}

				case 'D': //Coseno
						try
						{
							m_AcumFloat[iCont]=  Math.cos(m_AcumFloat[iCont-1]);
							break;
						}
						catch(ArithmeticException a)
						{
							m_AcumFloat[iCont] = 0;
							return m_AcumFloat[iCont];
						}

				case 'E': // Seno
						try
						{
							m_AcumFloat[iCont]=  Math.sin(m_AcumFloat[iCont-1]);
							break;
						}
						catch(ArithmeticException a)
						{
							m_AcumFloat[iCont] = 0;
							return m_AcumFloat[iCont];
						}
				case 'F': // Tangente
						try
						{
							m_AcumFloat[iCont]=  Math.tan(m_AcumFloat[iCont-1]);
							break;
						}
						catch(ArithmeticException a)
						{
							m_AcumFloat[iCont] = 0;
							return m_AcumFloat[iCont];
						}
				case 'G': // Exponencial
						try
						{
							m_AcumFloat[iCont]=  Math.exp(m_AcumFloat[iCont-1]);
							break;
						}
						catch(ArithmeticException a)
						{
							m_AcumFloat[iCont] = 0;
							return m_AcumFloat[iCont];
						}
				case 'H': // Valor Absoluto
						try
						{
							m_AcumFloat[iCont]=	 Math.abs(m_AcumFloat[iCont-1]);
							break;
						}
						catch(ArithmeticException a)
						{
							m_AcumFloat[iCont] = 0;
							return m_AcumFloat[iCont];
						}

				default:	m_AcumFloat[iCont]=  EvaluaExpresion(iCont, dX, dY);
							
			}
		return m_AcumFloat[iCont-1];
	}


	// Las expresiones simples son evaluadas
	double EvaluaExpresion(int iAcum, double dX, double dY)
	{
		char sOperando[] = new char[20];
		double dNumero[] = new double[20];
		Float fPrueba;
		double dAcumula=0;
		int iNum1, iNum2, iNum3, iLimArray=0, iIndice;


		for(iNum1=0;;iNum1++)
		{
			switch(m_sVectorNumeros[iAcum][iNum1].charAt(0))
			{
			   // Trae el valor de las variables
			   case 'x': dNumero[iNum1] = dX; break;
			   case 'y': dNumero[iNum1] = dY; break;

			   // Es un numero
			   case '.':
			   case '1':
			   case '2':
			   case '3':
			   case '4':
			   case '5':
			   case '6':
			   case '7':
			   case '8':
			   case '9':
			   case '0':
						fPrueba	 = Float.valueOf(m_sVectorNumeros[iAcum][iNum1]);
						dNumero[iNum1]= (double) fPrueba.floatValue();
						break;
			   // Trae el valor del Acumn anterior
			   default:	iIndice = m_sVectorNumeros[iAcum][iNum1].charAt(0)-'A';
						dNumero[iNum1] = m_AcumFloat[iIndice];
						
			}

			sOperando[iNum1] = m_sVectorOperador[iAcum][iNum1].charAt(0);
			if ( sOperando[iNum1] =='F' )
				break;
		}
		iLimArray=iNum1;

		
		//Evalua para cada signo de operacion
//		for(iNum2=0; iNum2<=iLimArray; iNum2++)
//			System.out.println("Numero: #" + dNumero[iNum2] + "#  Operador: #" + sOperando[iNum2] + "#");
	

		// Evalua potencia
		for(iNum2=0; iNum2<=iLimArray; iNum2++)
			while( sOperando[iNum2]=='^' )
			{
				dNumero[iNum2] = Math.pow(dNumero[iNum2], dNumero[iNum2+1]);
				if( Double.isNaN(dNumero[iNum2]) || Double.isInfinite(dNumero[iNum2]))
				{
					dAcumula = 0;
					return dAcumula;
				}
		
				for(iNum3=iNum2+2; iNum3<=iLimArray+1; iNum3++)
				{
					dNumero[iNum3-1] = dNumero[iNum3];
					sOperando[iNum3-2] = sOperando[iNum3-1];
				}
				iLimArray--;
			}

		//Evalua division. OJO: primero es la division luego la multiplicacion
		//Ejemplo: 5 + 24 / 2 * 3
		// Si evaluo primero la multiplicacion seria: 5 + 24 / 6 = 9
		// Si evaluo primero la divisi�n seria:       5 + 12 * 3 = 41

		try
		{
			for(iNum2=0; iNum2<=iLimArray; iNum2++)
			  while( sOperando[iNum2]=='/' )
			  {
				if ( dNumero[iNum2+1] == 0 )
				{
					dAcumula = 0;
					return dAcumula;
				}
				dNumero[iNum2] = dNumero[iNum2] / dNumero[iNum2+1];
				for(iNum3=iNum2+2; iNum3<=iLimArray+1; iNum3++)
				{
					dNumero[iNum3-1] = dNumero[iNum3];
					sOperando[iNum3-2] = sOperando[iNum3-1];
				}
				iLimArray--;
			  }
		}
		catch (ArithmeticException a)
		{
			dAcumula = 0;
			return dAcumula;
		}


		// Evaluo la multiplicacion
		for(iNum2=0; iNum2<=iLimArray; iNum2++)
		  while( sOperando[iNum2]=='*' )
		  {
			dNumero[iNum2] = dNumero[iNum2] * dNumero[iNum2+1];
			for(iNum3=iNum2+2; iNum3<=iLimArray+1; iNum3++)
			{
				dNumero[iNum3-1] = dNumero[iNum3];
				sOperando[iNum3-2] = sOperando[iNum3-1];
			}
		    iLimArray--;
		  }

		
		 //Finalmente me voy sumando y restando
		 dAcumula=dNumero[0];
		 for(iNum2=0; iNum2<iLimArray; iNum2++)
			if(sOperando[iNum2]=='+') dAcumula+=dNumero[iNum2+1];
			else
			if(sOperando[iNum2]=='-') dAcumula-=dNumero[iNum2+1];

		 return dAcumula;
	}




		
	/* Elimina espacios, tabuladores y caracteres extra�os de la cadena.
		Observe que Java trata los String como si fuese Visual Basic */
	String Eliminaespacios(String sCadena)
	{
		String sCadenaNew="";
		int iCont;

		for(iCont=0; iCont < sCadena.length(); iCont++)
		{
			if( sCadena.charAt(iCont) != ' ')
				sCadenaNew = sCadenaNew + sCadena.charAt(iCont);
		}

		return sCadenaNew;
	}


	/* Validar la sintaxis de la expresi�n algebraica
	RETORNA:
	1:  Dobles operandos. Ej: 5*+3
	2:  Parentesis desbalanceados  Ej: 4-(3*4
	3:  Numero seguido de (      Ej: 7-4(3*2)
	4:  Operando(+,-,*,/,^) seguido de )   Ej: 3-(4*)+2
	5:  Mandato Desconocido  Ej: flow(3*4)
	6:  signos raros Ej:!@#~`
	*/
	public int iChequeaSintaxis(String sEcuacion, int iNumVar)
	{
		int iCont, iConPerm, iNoPerm, iCont3, iCadena;
		char cCar, cCar2;
		int iParent=0;
		String sPermitido=".^/*+-()0123456789";
		String sTempor;

		sEcuacion = sEcuacion.toLowerCase();
		sEcuacion = Eliminaespacios(sEcuacion);

		for(iCont=0; iCont < sEcuacion.length()-1; iCont++)
		{
			cCar = sEcuacion.charAt(iCont);
			cCar2 = sEcuacion.charAt(iCont+1);

			// Valida dobles operandos
			if( cCar=='^' || cCar =='-' || cCar== '*' || cCar=='+')
				if( cCar2=='^' || cCar2=='-' || cCar2== '*' || cCar2=='+')
					return 1;

			// valida numero seguido de (
			if( cCar>='0' && cCar<='9' && cCar2=='(')
				return 3;

			//Valida operador seguido de )
			if( cCar=='+' || cCar=='-' || cCar=='*' || cCar=='/' || cCar=='^')
				if( cCar2==')')
					return 4;
		}

		// valida parentesis desbalanceados
		for(iCont=0; iCont < sEcuacion.length(); iCont++)
		{
			cCar = sEcuacion.charAt(iCont);
			if( cCar=='(' ) iParent++;
			if( cCar==')' ) iParent--;
		}

		if(iParent!=0) return 2;

		//Debe chequearse el uso de funciones como seno, coseno, tangente...
		for(iCont=0; iCont < sEcuacion.length(); iCont++)
		{
			cCar = sEcuacion.charAt(iCont);
			if ( cCar == '(' )
				for (iCont3=0; iCont3<16; iCont3++)
				{
					iCadena = m_sFuncion[iCont3].length();
					if ( iCont - iCadena >= 0 )
					{
						sTempor = sEcuacion.substring(iCont - iCadena, iCont );
						if	( m_sFuncion[iCont3].compareTo(sTempor)  == 0)
						{
							sEcuacion = sEcuacion.substring(0, iCont - iCadena ) + 'x' + sEcuacion.substring(iCont);
							iCont=0;
							break;
						}
					}
				}
		}


		/* si hay una variable o letra diferente de 'x' y 'y', hay un error */
		for(iCont=0; iCont < sEcuacion.length(); iCont++)
		{
			cCar = sEcuacion.charAt(iCont);
			if (iNumVar==1)
				if (cCar >= 'a' && cCar <= 'z' && cCar != 'x')
					return 5;

			if (iNumVar==2)
				if (cCar >= 'a' && cCar <= 'z' && cCar != 'y' && cCar != 'x')
					return 5;
		}

		
		/* chequea si hay signos raros */
		for(iCont=0; iCont < sEcuacion.length(); iCont++)
		{
			cCar = sEcuacion.charAt(iCont);
			if (cCar < 'a' || cCar > 'z' )
			{
				iNoPerm=1;
				for ( iConPerm=0; iConPerm<sPermitido.length(); iConPerm++)
				{
					cCar2 = sPermitido.charAt(iConPerm);
					if (cCar == cCar2) iNoPerm = 0;
				}
				if (iNoPerm == 1) return 6;
			}
		}

		return 0;

	} //Fin del metodo ChequeaSintaxis

}
