/*
* @(#)Motor de Vida Artificial
* 
* Es un conjunto de subrutinas que simulando la Evoluci�n de las Especies,
* puedan crear programas (codigo fuente) que se adapten a un ambiente en particular.
* Todo software tiene entradas y salidas. Las entradas son procesadas y se emite un resultado
* que son las salidas. Este proceso es implementado por un Dise�ador/Programador.
* Ahora bien, si usamos un sistema que usa principios evolutivos, este proceso puede nacer
* por si solo, esto tiene sus ventajas:
* 1. No se requiere de personal humano (programadores) para crear el proceso.
* 2. Puede disminuirse o anularse la posiblidad de errores en el proceso.
* 3. Ante nuevos requerimientos (nuevas entradas o formatos de salida) el proceso se adaptara.
* 4. Capaz de encontrar o acercarse a soluciones deporblemas muy complejos.
* 
* El obst�culo:
*  Conseguir un proceso que ofrezca salidas esperadas a unas entradas, usando principios evolutivos
*  puede tardar un tiempo considerablemente alto. Con los nuevos procesadores a mayores velocidades y
*  un buen algoritmo evolutivo, el tiempo puede ser disminuido, de tal manera que podria entrar a
*  competir con programadores humanos.
*/

import java.util.*;

class MedioAmbiente
{
    public int m_iEntradas[] = new int[50]; //Valores de Entrada que quiere el usuario
    public int m_iSalidas[] = new int[50]; //Valores de Salida que quiere el usuario
    public int m_iContEntra = 0;
    public int m_iContSale = 0;
    
  
    public void vDeshaceIO(String m_sSerieNum, int iEntraSale)
	{
		String sAcum="";
		
		switch(iEntraSale)
		{
		    case 1: m_iContEntra=0; break;
		    case 2: m_iContSale=0; break;
		}

		// Ahora deshace la expresion en un arreglo de enteros
		for(int iCont=0; iCont<=m_sSerieNum.length()-1; iCont++)
		{
			if (m_sSerieNum.charAt(iCont) != ',' )
				sAcum += m_sSerieNum.charAt(iCont);
			else
				if (sAcum.length()>0)
				{
				    switch(iEntraSale)
				    {
				        case 1:
					        m_iEntradas[m_iContEntra++]=Integer.parseInt(sAcum);
					        break;
					    case 2: 
					        m_iSalidas[m_iContSale++]=Integer.parseInt(sAcum);
					        break;
					}
					sAcum="";
				}
		} // Fin For
	} // Fin DeshaceIO
}