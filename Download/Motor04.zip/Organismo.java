/*
* @(#)Motor de Vida Artificial
* 
* Es un conjunto de subrutinas que simulando la Evoluci�n de las Especies,
* puedan crear programas (codigo fuente) que se adapten a un ambiente en particular.
* Todo software tiene entradas y salidas. Las entradas son procesadas y se emite un resultado
* que son las salidas. Este proceso es implementado por un Dise�ador/Programador.
* Ahora bien, si usamos un sistema que usa principios evolutivos, este proceso puede nacer
* por si solo, esto tiene sus ventajas:
* 1. No se requiere de personal humano (programadores) para crear el proceso.
* 2. Puede disminuirse o anularse la posiblidad de errores en el proceso.
* 3. Ante nuevos requerimientos (nuevas entradas o formatos de salida) el proceso se adaptara.
* 4. Capaz de encontrar o acercarse a soluciones de problemas muy complejos.
* 
* El obst�culo:
*  Conseguir un proceso que ofrezca salidas esperadas a unas entradas, usando principios evolutivos
*  puede tardar un tiempo considerablemente alto. Con los nuevos procesadores a mayores velocidades y
*  un buen algoritmo evolutivo, el tiempo puede ser disminuido, de tal manera que podria entrar a
*  competir con programadores humanos.
*/

import java.util.*;
import java.lang.*;

public class Organismo
{
    public Gen oGen[] = new Gen[80]; //Genes del ser vivo
    EvalExpr eEvalua[] = new EvalExpr[80]; //Expresiones de asignacion evaluadas previamente
    int iMaxGenOrg; //Maximo numero de genes para el organismo
    int iMaxiCiclos; //Maximo numero de ciclos que se gastaran para evaluar el organismo
   
    
    public String sDisplayADN()
    {
        char cEnter = '\n';
        String sbADN="float fSerVivo(float X)" + cEnter + "{" + cEnter + "float W=0, Y=0, Z=0;" + cEnter + cEnter;
        for (int iCont=1; iCont<=iMaxGenOrg; iCont++)
        {
            sbADN += String.valueOf(iCont) + ": ";

            //Reemplaza la expresion por la variable activa
            String sbTmp = "";
            int iLongExpr = oGen[iCont].sbExpresion.length();
            for (int iChar=0; iChar < iLongExpr; iChar++)
            {
                char cCharAt = oGen[iCont].sbExpresion.charAt(iChar);
                if (cCharAt=='X')
                    sbTmp += oGen[iCont].cVarActiva;
                else
                    sbTmp += cCharAt;
            }
                    
            //Organiza los if y asignaciones
            if (oGen[iCont].cTipInst == 'I')
                sbADN += "if( " + oGen[iCont].cVariable + " " + oGen[iCont].cOperacion + " " + sbTmp + " ) goto " + String.valueOf(oGen[iCont].iGotoLabel) + ";" + cEnter;
            else                
                sbADN += oGen[iCont].cVariable + " = " + sbTmp + ";" + cEnter;
        }    
        //Finaliza la expresion
        sbADN += "return Y;" + cEnter + "}";
                
        return sbADN;
    }

    public void vCreaADN (int iMaxGenes, int iMaxCicl,
                   int iPosibIf, int iPosibSet,
                   int iPosW,  int iPosX, int iPosY, int iPosZ,
                   int iPosIg, int iPosMay, int iPosMen, int iPosDif,
                   int iLongExpr, int iPosibX, int iPosibP, int iPosibN)
    {
        int iCont, iCont1, iCont2, iCont3, iCont4;
     
        //Crea organismos entre 1 y iMaxGenes instrucciones
		long iSemilla= (long) System.currentTimeMillis();
		Random mAleat= new Random(iSemilla);
        iMaxGenOrg = Math.abs(mAleat.nextInt() % iMaxGenes ) + 1;
     //   System.out.println("Numero de Genes: " + iMaxGenOrg);
        
        //M�ximo n�mero de ciclos que se evaluar�n del organismo, si el
        //organimso supera este n�mero de ciclos sin dar con un resultado
        //es desechado.
        iMaxiCiclos = iMaxCicl;
        
        //Crea los genes, crea al maximo.
        for (iCont=1; iCont<=iMaxGenes; iCont++)
        {
            oGen[iCont] = new Gen();
            eEvalua[iCont] = new EvalExpr();
        }
            
        for (iCont=1; iCont<=iMaxGenOrg; iCont++)
           vHaceGen ( iCont, iMaxGenOrg,
                      iPosibIf, iPosibSet,
                      iPosW,  iPosX, iPosY, iPosZ,
                      iPosIg, iPosMay, iPosMen, iPosDif,
                      iLongExpr, iPosibX, iPosibP, iPosibN);
    }
    
    public void vEvaluaPrevio()
    {
        double dResultado;
        for (int iCont=1; iCont<=iMaxGenOrg; iCont++)
           dResultado = eEvalua[iCont].dCapturaecuacion(oGen[iCont].sbExpresion, 0, 0);
    }
        
    
    public float fEvalOrganismo (float fValX)
    {                   
        /* Viene la interpretacion, los valores X se disparan de 1 a n y se comparan con el ambiente Y */
        float fValW=0, fValY=0, fValZ=0, fValor=0, fResultado=0;
        int iGenOrg=1;
        int iNumCiclos=0; //Contador de Ciclos
        while (iGenOrg!=0 && iGenOrg<=iMaxGenOrg)
        {
             // Aumenta el # de Ciclos
             iNumCiclos++;
             if (iNumCiclos > iMaxiCiclos)
             {
                fValY = 9999999;
                break;
             }
            
             //Que variable esta jugando dentro de la expresion
             switch (oGen[iGenOrg].cVarActiva)
             {
                case 'W': fValor = fValW; break;
                case 'X': fValor = fValX; break;
                case 'Y': fValor = fValY; break;
                case 'Z': fValor = fValZ; break;
             }
            
             //Evalua la expresion
             //double dResultado = eEvalua.dCapturaecuacion(oGen[iGenOrg].sbExpresion, dValor, 0);
		     fResultado = (float) eEvalua[iGenOrg].CicloEvalua((double)fValor, 0);

		     //Si es un SET asigna el valor a la variable del Gen
		     if (oGen[iGenOrg].cTipInst == 'S')
		     {
		        switch(oGen[iGenOrg].cVariable)
		        {
		            case 'W': fValW = fResultado; break;
		            case 'X': fValX = fResultado; break;
		            case 'Y': fValY = fResultado; break;
		            case 'Z': fValZ = fResultado; break;
		        }
		        iGenOrg++; //Ignora el salto en un SET
             }
             else //Es un If condicional
             {
                switch(oGen[iGenOrg].cOperacion)
                {
                    case '>':
                        switch(oGen[iGenOrg].cVariable)
		                {
		                    case 'W': if (fValW > fResultado) iGenOrg=oGen[iGenOrg].iGotoLabel; else iGenOrg++; break;
		                    case 'X': if (fValX > fResultado) iGenOrg=oGen[iGenOrg].iGotoLabel; else iGenOrg++; break;
		                    case 'Y': if (fValY > fResultado) iGenOrg=oGen[iGenOrg].iGotoLabel; else iGenOrg++; break;
		                    case 'Z': if (fValZ > fResultado) iGenOrg=oGen[iGenOrg].iGotoLabel; else iGenOrg++; break;
		                }
		                break;
                    case '<':
                        switch(oGen[iGenOrg].cVariable)
		                {
		                    case 'W': if (fValW < fResultado) iGenOrg=oGen[iGenOrg].iGotoLabel; else iGenOrg++; break;
		                    case 'X': if (fValX < fResultado) iGenOrg=oGen[iGenOrg].iGotoLabel; else iGenOrg++; break;
		                    case 'Y': if (fValY < fResultado) iGenOrg=oGen[iGenOrg].iGotoLabel; else iGenOrg++; break;
		                    case 'Z': if (fValZ < fResultado) iGenOrg=oGen[iGenOrg].iGotoLabel; else iGenOrg++; break;
		                }
		                break;
                    case '=':
                        switch(oGen[iGenOrg].cVariable)
		                {
		                    case 'W': if (fValW == fResultado) iGenOrg=oGen[iGenOrg].iGotoLabel; else iGenOrg++; break;
		                    case 'X': if (fValX == fResultado) iGenOrg=oGen[iGenOrg].iGotoLabel; else iGenOrg++; break;
		                    case 'Y': if (fValY == fResultado) iGenOrg=oGen[iGenOrg].iGotoLabel; else iGenOrg++; break;
		                    case 'Z': if (fValZ == fResultado) iGenOrg=oGen[iGenOrg].iGotoLabel; else iGenOrg++; break;
		                }
		                break;
                    case '!':
                        switch(oGen[iGenOrg].cVariable)
		                {
		                    case 'W': if (fValW != fResultado) iGenOrg=oGen[iGenOrg].iGotoLabel; else iGenOrg++; break;
		                    case 'X': if (fValX != fResultado) iGenOrg=oGen[iGenOrg].iGotoLabel; else iGenOrg++; break;
		                    case 'Y': if (fValY != fResultado) iGenOrg=oGen[iGenOrg].iGotoLabel; else iGenOrg++; break;
		                    case 'Z': if (fValZ != fResultado) iGenOrg=oGen[iGenOrg].iGotoLabel; else iGenOrg++; break;
		                }
		                break;
		        }
		     }
		} //Fin de la evaluacion del ser vivo
		return fValY;
     }
     
     /* Crea una linea de codigo fuente (la llam� Gen). El formato es:
        label, [, IF/SET, Variable, =/>/</!, (, expresion, ), Goto, Label, ]
        para mayor velocidad, se ubica en una clase el Gen */
     public void vHaceGen(int iLabel, int iMaxGenes,
                   int iPosibIf, int iPosibSet,
                   int iPosW,  int iPosX, int iPosY, int iPosZ,
                   int iPosIg, int iPosMay, int iPosMen, int iPosDif,
                   int iLongExpr, int iPosibX, int iPosibP, int iPosibN)
     {
        char cVar, cOper;

        //Clase que maneja los valores aleatorios
        cMutacion cMuta = new cMutacion();
        
        //Decide si es una asignaci�n(Set) o un If condicional
        cOper = cMuta.cRandomElem(iPosibIf, iPosibSet, 0, 0);
        if (cOper == 'X') oGen[iLabel].cTipInst = 'I';
        else oGen[iLabel].cTipInst = 'S';
       
        //Decide que variable usar W, X, Y, Z
        cVar = cMuta.cRandomElem(iPosW, iPosX, iPosY, iPosZ);
        if (cVar == 'X') oGen[iLabel].cVariable = 'W';
        else if (cVar == '(') oGen[iLabel].cVariable = 'X';
        else if (Character.isDigit(cVar)) oGen[iLabel].cVariable = 'Z';
        else oGen[iLabel].cVariable = 'Y';
        
        //Decide si usa =, >, <, ! Estos son tenidos en cuenta si es un IF condicional
        cVar = cMuta.cRandomElem(iPosIg, iPosMay, iPosMen, iPosDif);
        if (cVar == 'X') oGen[iLabel].cOperacion = '=';
        else if (cVar == '(') oGen[iLabel].cOperacion = '>';
        else if (Character.isDigit(cVar)) oGen[iLabel].cOperacion = '!';
        else oGen[iLabel].cOperacion = '<';
        
        //Trae la expresion
        cMuta.vCrearExpresion(iLongExpr, iPosibX, iPosibP, iPosibN);
        oGen[iLabel].sbExpresion = cMuta.sAcum;
        
        //Como la trae para X, aqui la cambio a W, X, Y, Z
        char cCambia;
        cVar = cMuta.cRandomElem(iPosW, iPosX, iPosY, iPosZ);
        if (cVar == 'X') oGen[iLabel].cVarActiva = 'W';
        else if (cVar == '(') oGen[iLabel].cVarActiva = 'X';
        else if (Character.isDigit(cVar)) oGen[iLabel].cVarActiva = 'Z';
        else oGen[iLabel].cVarActiva = 'Y';
        
        
        //Decide hacia que label va (entre 0 y MaxGenes) o si es el FIN, el resultado siempre sera Y
		Random mAleat = new Random();
        int iNumCiclo = Math.abs(mAleat.nextInt() % iMaxGenes);
        oGen[iLabel].iGotoLabel = iNumCiclo; //Retorna 0 para FINalizar
     }
     
     public void Muta(int iLabel, int iMaxGenes,
                   int iPosibIf, int iPosibSet,
                   int iPosW,  int iPosX, int iPosY, int iPosZ,
                   int iPosIg, int iPosMay, int iPosMen, int iPosDif,
                   int iLongExpr, int iPosibX, int iPosibP, int iPosibN)
     {
        vHaceGen ( iLabel, iMaxGenes,
                      iPosibIf, iPosibSet,
                      iPosW,  iPosX, iPosY, iPosZ,
                      iPosIg, iPosMay, iPosMen, iPosDif,
                      iLongExpr, iPosibX, iPosibP, iPosibN);

        //Evalua la expresion previamente
        double dResultado = eEvalua[iLabel].dCapturaecuacion(oGen[iLabel].sbExpresion, 0, 0);            
     }
}