#include <stdio.h>
#include <time.h>
#include <malloc.h>
#include <string.h>
#include <stdlib.h>

#include "Aleatorio.h"
#include "Inicializa.h" //Acceso al archivo plano


//=============== El ambiente ==========================
unsigned int **iAmbiente;

//========= Marca que parte del ambiente tiene organismo =======
bool *bOrganismo;

//========= Valores que almacena cada variable del organismo ====
int **iVarOrganismo;
int *iAdaptacion;

//========= Valores de entrada y salida ====
int *iEntrada, *iSalida;


//========== Clase de inicializacion ====
Inicializa objInicializa; //Lee el archivo de inicializaci�n


void main(void);
void vInterpretaOrganismo(unsigned int, int);
void vDeshaceIO(char *, int);

// ===========================================================
// INICIO
// ===========================================================
void main()
{
	//==============================================
	//Archivo plano
	//==============================================
	objInicializa.vPantallaIni(); //Pantalla de Inicio
	int iError = objInicializa.iLeeArchivoIni(); //Archivo de Inicializaci�n
	if (iError == -1)
	{
		printf("Un error ocurri� al inicializar la simulaci�n\n");
		return;
	}
	objInicializa.vArchResult(); //Encabezado archivo de resultados


	//================================================
	//Inicia el generador de numeros pseudo-aleatorios
	//================================================
	Aleatorio objAzar;
	time_t objTiempo;
	time(&objTiempo);
	objAzar.sgenrand(objTiempo);

	//Aqui se almacena y se trabaja con el n�mero pseudo-aleatorio
	unsigned int iCont, iPosAmbiente, iMuta;
	int iDiferencia, iAdapta;

	//======================================================
	//Inicializa las entradas y salidas
	//======================================================
	iEntrada = (int *) malloc(objInicializa.stDatVA.ENTRADAS*sizeof(int));
	iSalida = (int *) malloc(objInicializa.stDatVA.ENTRADAS*sizeof(int));
	vDeshaceIO(objInicializa.stDatVA.sEntrada, 1);
	vDeshaceIO(objInicializa.stDatVA.sSalidas, 2);

	//Muestra entradas y salidas del ambiente
//	printf("Entradas son: ");
//	for (int iPrueba=0; iPrueba<objInicializa.stDatVA.ENTRADAS; iPrueba++)
//		printf("%d, ", iEntrada[iPrueba]);

//	printf("\nSalidas son: ");
//	for (iPrueba=0; iPrueba<objInicializa.stDatVA.ENTRADAS; iPrueba++)
//		printf("%d, ", iSalida[iPrueba]);
//	printf("\n");

	
	//Inicializa el ambiente
	unsigned int iFila, iColumna;
	iAdaptacion = (int *) malloc(objInicializa.stDatVA.TAMANOAMBIENTE*sizeof(int));
	bOrganismo = (bool *)  malloc(objInicializa.stDatVA.TAMANOAMBIENTE*sizeof(bool));
	iAmbiente = (unsigned int **) malloc((objInicializa.stDatVA.TAMANOAMBIENTE)*sizeof(int));
	iVarOrganismo = (int **) malloc((objInicializa.stDatVA.TAMANOAMBIENTE)*sizeof(int));


	for (iFila=0; iFila<objInicializa.stDatVA.TAMANOAMBIENTE; iFila++)
	{
		iAmbiente[iFila] = (unsigned int *) malloc((objInicializa.stDatVA.MAXINSTRUCCIONES+2)*sizeof(int));
		iVarOrganismo[iFila] = (int *) malloc((objInicializa.stDatVA.MAXINSTRUCCIONES+2)*sizeof(int));
		
		iAdaptacion[iFila]=0;
		bOrganismo[iFila]=false;
		for (iColumna=0; iColumna<objInicializa.stDatVA.MAXINSTRUCCIONES+2; iColumna++)
			iAmbiente[iFila][iColumna]=0;
	}

	//Ciclo de generar los organismos
	//printf("\nAntes de generar");
	for(unsigned int iSimula=0; iSimula<objInicializa.stDatVA.TOTALSIMULACION; iSimula++)
	{
		//Busca una posici�n del ambiente al azar
		iPosAmbiente = objAzar.genrand()%(objInicializa.stDatVA.TAMANOAMBIENTE-1)+1;
		
		//Si esa posici�n no ten�a ning�n organismo entonces genera al azar la criatura
		if (bOrganismo[iPosAmbiente]==false)
		{
			//Genera al azar las instrucciones
			for (iCont=0; iCont<objInicializa.stDatVA.MAXINSTRUCCIONES; iCont++)
				iAmbiente[iPosAmbiente][iCont] = (unsigned int) objAzar.genrand()%150994945;

			//Enfrenta el organismo con la entrada y la salida
			iAdapta=0;
			for (iCont=0; iCont<objInicializa.stDatVA.ENTRADAS; iCont++)
			{
				vInterpretaOrganismo(iPosAmbiente, iEntrada[iCont]);
				iDiferencia = iSalida[iCont]-iVarOrganismo[iPosAmbiente][1];
				if (iDiferencia<0) iDiferencia*=-1;
				iAdapta+=iDiferencia;
			}

			if (iAdapta <= objInicializa.stDatVA.MAXTOLERANCIA)
			{
				bOrganismo[iPosAmbiente]=true; //Ahora si hay un organismo
				iAdaptacion[iPosAmbiente]=iAdapta;
				//printf("Nuevo organismo en %d se adapta en %d\n", iPosAmbiente, iAdapta);
			}

		}
		else //Ya hab�a un organismo all�
		{
			//Reproduce el organismo que estaba all� y env�a el hijo a la posici�n cero
			for (iCont=0; iCont<objInicializa.stDatVA.MAXINSTRUCCIONES; iCont++)
				iAmbiente[0][iCont] = iAmbiente[iPosAmbiente][iCont];

			//Modifica alguna parte de este hijo
			iMuta = (unsigned int) objAzar.genrand()%objInicializa.stDatVA.MAXINSTRUCCIONES;
			iAmbiente[0][iMuta] = (unsigned int) objAzar.genrand()%150994945;

			//Enfrenta el organismo hijo con la entrada y la salida
			iAdapta=0;
			for (iCont=0; iCont<objInicializa.stDatVA.ENTRADAS; iCont++)
			{
				vInterpretaOrganismo(0, iEntrada[iCont]);
				iDiferencia = iSalida[iCont]-iVarOrganismo[0][1];
				if (iDiferencia<0) iDiferencia*=-1;
				iAdapta+=iDiferencia;
			}
			if (iAdapta > objInicializa.stDatVA.MAXTOLERANCIA) continue;

			//Busca algun lugar donde mudarse
			iCont = objAzar.genrand()%(objInicializa.stDatVA.TAMANOAMBIENTE-1)+1;

			//Si el nuevo organismo es mejor que el viejo entonces lo reemplaza
			if (iAdapta < iAdaptacion[iCont] || bOrganismo[iCont]==false)
			{
			    //printf(" (%d) se muda a %d con adaptacion %d\n", iAdapta, iCont, iAdaptacion[iCont]);
				bOrganismo[iCont]=true;
				for (int iCont2=0; iCont2<objInicializa.stDatVA.MAXINSTRUCCIONES; iCont2++)
					iAmbiente[iCont][iCont2]=iAmbiente[0][iCont2];
				iAdaptacion[iCont]=iAdapta;
			}
		}
	}


	//Muestra los organismos que sobrevivieron a la selecci�n
	for(iCont=1; iCont<objInicializa.stDatVA.TAMANOAMBIENTE;iCont++)
		if (bOrganismo[iCont]==true)
		{
			printf("// Organismo=%d se adapta=%d\n", iCont, iAdaptacion[iCont]);
			printf("#include <stdio.h>\n");
			printf("void main(void);\n");
			printf("void main()\n");
			printf("{\n");
			printf("int V0=0, V1=0, V2=0, V3=0, iError=0;\n");
			printf("int iEntrada[%d], iSalida[%d];\n",objInicializa.stDatVA.ENTRADAS,objInicializa.stDatVA.ENTRADAS); 
			for (int iImprime=0; iImprime<objInicializa.stDatVA.ENTRADAS; iImprime++)
				printf("iEntrada[%d]=%d;\n", iImprime, iEntrada[iImprime]);
			for (iImprime=0; iImprime<objInicializa.stDatVA.ENTRADAS; iImprime++)
				printf("iSalida[%d]=%d;\n", iImprime, iSalida[iImprime]);
			printf("for (int iCont=0; iCont<%d; iCont++)\n", objInicializa.stDatVA.ENTRADAS);
			printf("{\n");
			printf("V0=iEntrada[iCont];\n");
			printf("V1=0;\n");
			printf("V2=0;\n");
			printf("V3=0;\n");
			printf("//Codigo generado por el algoritmo genetico\n");

			for (int iCont2=0; iCont2<objInicializa.stDatVA.MAXINSTRUCCIONES; iCont2++)
			{
				printf("a%d: ", iCont2);
				unsigned int iLinea = iAmbiente[iCont][iCont2];
				unsigned int iPos0 = ((iLinea >> 24) & 0xFF) % objInicializa.stDatVA.TIPOINSTRUCCION;
				unsigned int iPos1 = ((iLinea >> 16) & 0xFF) % objInicializa.stDatVA.NUMVARIABLES;
				unsigned int iPos2 = ((iLinea >> 8) & 0xFF) % objInicializa.stDatVA.NUMVARIABLES;
				unsigned int iPos3 = 0;

				if (iPos0<=3)
					iPos3 = (iLinea & 0xFF) % objInicializa.stDatVA.NUMVARIABLES;
				else
					iPos3 = (iLinea & 0xFF) % objInicializa.stDatVA.MAXINSTRUCCIONES;

				//Interpreta la l�nea de c�digo
				switch(iPos0)
				{
					case 0: printf("V%d = V%d + V%d;\n", iPos1, iPos2, iPos3); break;
					case 1: printf("V%d = V%d - V%d;\n", iPos1, iPos2, iPos3); break;
					case 2: printf("V%d = V%d * V%d;\n", iPos1, iPos2, iPos3); break;
					case 3: printf("if (V%d!=0) V%d = V%d / V%d;\n", iPos3, iPos1, iPos2, iPos3); break;
					case 4: printf("if (V%d > V%d) goto a%d;\n", iPos1, iPos2, iPos3); break;
					case 5: printf("if (V%d >= V%d) goto a%d;\n", iPos1, iPos2, iPos3); break;
					case 6: printf("if (V%d < V%d) goto a%d;\n", iPos1, iPos2, iPos3); break;
					case 7: printf("if (V%d <= V%d) goto a%d;\n", iPos1, iPos2, iPos3); break;
					case 8: printf("if (V%d == V%d) goto a%d;\n", iPos1, iPos2, iPos3); break;
					case 9: printf("if (V%d != V%d) goto a%d;\n", iPos1, iPos2, iPos3); break;
				}
			}
			printf("//Fin del codigo\n");
			printf("int iDiferencia = iSalida[iCont]-V1;\n");
			printf("if (iDiferencia<0) iDiferencia *= -1;\n");
			printf("iError += iDiferencia;\n");
			printf("}\n");
			printf("printf(\"Adaptacion: %cd\", iError);\n", 37);
			printf("}\n");
		}
}

void vInterpretaOrganismo(unsigned int iOrganismo, int iEntra)
{
	unsigned int iPos0, iPos1, iPos2, iPos3, iLinea, iEjecuta=0;
	unsigned int iMaximoInterpreta=0;

	//Inicializa los valores de variables
	for (unsigned int iCont=1; iCont<objInicializa.stDatVA.NUMVARIABLES; iCont++) iVarOrganismo[iOrganismo][iCont]=0;
	iVarOrganismo[iOrganismo][0]=iEntra;

	while(true)
	{
		iLinea = iAmbiente[iOrganismo][iEjecuta++];
		if (iLinea==0) break; //Termino el algoritmo correctamente
		if (iMaximoInterpreta++ > objInicializa.stDatVA.MAXIMOINTERPRETA)
		{
			iVarOrganismo[iOrganismo][1]=objInicializa.stDatVA.MAXTOLERANCIA+5; //El algoritmo se pas� del l�mite de ciclos, luego es rechazado
			break;
		}
				
		iPos0 = ((iLinea >> 24) & 0xFF) % objInicializa.stDatVA.TIPOINSTRUCCION;
		iPos1 = ((iLinea >> 16) & 0xFF) % objInicializa.stDatVA.NUMVARIABLES;
		iPos2 = ((iLinea >> 8) & 0xFF) % objInicializa.stDatVA.NUMVARIABLES;

		//Si NO es una instrucci�n de salto
		if (iPos0<=3)
			iPos3 = (iLinea & 0xFF) % objInicializa.stDatVA.NUMVARIABLES;
		else
			iPos3 = (iLinea & 0xFF) % objInicializa.stDatVA.MAXINSTRUCCIONES;

		//Interpreta la l�nea de c�digo
		switch(iPos0)
		{
			case 0: //Suma
					iVarOrganismo[iOrganismo][iPos1] = iVarOrganismo[iOrganismo][iPos2] + iVarOrganismo[iOrganismo][iPos3];
					break;
			case 1: //Resta
					iVarOrganismo[iOrganismo][iPos1] = iVarOrganismo[iOrganismo][iPos2] - iVarOrganismo[iOrganismo][iPos3];
					break;
			case 2: //Multiplica
					iVarOrganismo[iOrganismo][iPos1] = iVarOrganismo[iOrganismo][iPos2] * iVarOrganismo[iOrganismo][iPos3];
					break;
			case 3: //Divide
					if (iVarOrganismo[iOrganismo][iPos3]!=0)
						iVarOrganismo[iOrganismo][iPos1] = iVarOrganismo[iOrganismo][iPos2] / iVarOrganismo[iOrganismo][iPos3];
					break;
			case 4: //Si [iPos1]>[iPos2] Goto iPos3
					if (iVarOrganismo[iOrganismo][iPos1]>iVarOrganismo[iOrganismo][iPos2]) iEjecuta = iPos3;
					break;
			case 5: //Si [iPos1]>=[iPos2] Goto iPos3
					if (iVarOrganismo[iOrganismo][iPos1]>=iVarOrganismo[iOrganismo][iPos2]) iEjecuta = iPos3;
					break;
			case 6: //Si [iPos1]<[iPos2] Goto iPos3
					if (iVarOrganismo[iOrganismo][iPos1]<iVarOrganismo[iOrganismo][iPos2]) iEjecuta = iPos3;
					break;
			case 7: //Si [iPos1]<=[iPos2] Goto iPos3
					if (iVarOrganismo[iOrganismo][iPos1]<=iVarOrganismo[iOrganismo][iPos2]) iEjecuta = iPos3;
					break;
			case 8: //Si [iPos1]==[iPos2] Goto iPos3
					if (iVarOrganismo[iOrganismo][iPos1]==iVarOrganismo[iOrganismo][iPos2]) iEjecuta = iPos3;
					break;
			case 9: //Si [iPos1]!=[iPos2] Goto iPos3
					if (iVarOrganismo[iOrganismo][iPos1]!=iVarOrganismo[iOrganismo][iPos2]) iEjecuta = iPos3;
					break;
		}

		//Limita el valor m�ximo que tendr� las variables y evitar el overflow de enteros
		if (iVarOrganismo[iOrganismo][iPos1]>40000 || iVarOrganismo[iOrganismo][iPos1]<-40000 ||
			iVarOrganismo[iOrganismo][iPos2]>40000 || iVarOrganismo[iOrganismo][iPos2]<-40000 ||
			iVarOrganismo[iOrganismo][iPos3]>40000 || iVarOrganismo[iOrganismo][iPos2]<-40000)
		{
			iVarOrganismo[iOrganismo][1]=objInicializa.stDatVA.MAXTOLERANCIA+5; //El algoritmo se pas� del l�mite de valor, luego es rechazado
			break;
		}
	}
}


void vDeshaceIO(char *m_sSerieNum, int iEntraSale)
{
		char sAcum[30];
		unsigned int iProgreso=0, iCont;
		int iEntra=0, iSale=0;
		
		// Ahora deshace la expresion en un arreglo de enteros
		for(iCont=0; iCont<=strlen(m_sSerieNum); iCont++)
		{
			if(m_sSerieNum[iCont] != ',')
			{
				sAcum[iProgreso++] = m_sSerieNum[iCont];
				sAcum[iProgreso]='\0';
			}
			else
				if(strlen(sAcum)>0)
				{
				    switch(iEntraSale)
				    {
				        case 1:
					        iEntrada[iEntra++]=atoi(sAcum);
					        break;
					    case 2: 
					        iSalida[iSale++]=atoi(sAcum);
					        break;
					}
					iProgreso=0;
				}
		} // Fin For
}; // Fin DeshaceIO



/*		unsigned int number = 1705498053;
		unsigned int iPrueba = 0;
		
		//Desensambla en bytes
		int iPos0 = ((number >> 24) & 0xFF);
		int iPos1 = ((number >> 16) & 0xFF);
		int iPos2 = ((number >> 8) & 0xFF);
		int iPos3 = (number & 0xFF);
		
		printf("%d\n",iPos0);
		printf("%d\n",iPos1);
		printf("%d\n",iPos2);
		printf("%d\n",iPos3);

		//Ensambla los bytes
		iPrueba = (iPos0 << 24) + (iPos1 << 16) + (iPos2 << 8) + iPos3;
		printf("%d\n", iPrueba); */