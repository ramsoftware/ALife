/*
Autor:		Rafael Alberto Moreno Parra
URL:		http://darwin.50webs.com
Clase:		Inicializa.
Lenguaje:	C++

Prop�sito:
Inicializa las variables para la simulaci�n

*/

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>
#include "Inicializa.h"
#include "StringUtil.h"

void Inicializa::vPantallaIni()
{
	printf("Poblacion 02: Uso de poblaciones\n\n");
	printf("Autor: Rafael Alberto Moreno Parra\n");
	printf("Fecha: 26 de Junio de 2006\n");
	printf("E-mail: enginelife@hotmail.com\n");
	printf("http://darwin.50webs.com\n\n");
};

//Abre y estudia el archivo de inicializaci�n
int Inicializa::iLeeArchivoIni()
{
	FILE *fpInicio;
	char sFrase[600], sVariable[200], sValor[200];
    unsigned int iCar;
	StringUtil StrUtil;

	//Inicializa la estructura
	strcpy(stDatVA.sArchResult, "Motor05p1.txt");
	
	fpInicio = fopen("Pobl02.ini", "r+t");
	if (fpInicio == NULL)
    {
		printf("Error al tratar de abrir archivo de inicializaci�n Pobl02.ini\n");
		return -1;
    }
	while(!feof(fpInicio))
	{
		fgets(sFrase, 298, fpInicio);
		StrUtil.vQuitaEspacios(sFrase);

		//Extrae variables y valores
		for (iCar=0; iCar<strlen(sFrase) && sFrase[iCar]!='='; iCar++);
		StrUtil.vLeft(sVariable, sFrase, iCar);
		StrUtil.vMid(sValor, sFrase, iCar+2,strlen(sFrase)-1);

		//Clasifica variables
		if(strcmp(sVariable, "TAMANOAMBIENTE")==0) stDatVA.TAMANOAMBIENTE = atoi(sValor);
		if(strcmp(sVariable, "MAXINSTRUCCIONES")==0) stDatVA.MAXINSTRUCCIONES = atoi(sValor);
		if(strcmp(sVariable, "NUMVARIABLES")==0) stDatVA.NUMVARIABLES = atoi(sValor);
		if(strcmp(sVariable, "TIPOINSTRUCCION")==0) stDatVA.TIPOINSTRUCCION = atoi(sValor);
		if(strcmp(sVariable, "TOTALSIMULACION")==0) stDatVA.TOTALSIMULACION = atoi(sValor);
		if(strcmp(sVariable, "MAXIMOINTERPRETA")==0) stDatVA.MAXIMOINTERPRETA = atoi(sValor);
		if(strcmp(sVariable, "ENTRADAS")==0) stDatVA.ENTRADAS = atoi(sValor);
		if(strcmp(sVariable, "MAXTOLERANCIA")==0) stDatVA.MAXTOLERANCIA = atoi(sValor);
		if(strcmp(sVariable, "sEntrada")==0) strcpy(stDatVA.sEntrada, sValor);
		if(strcmp(sVariable, "sSalidas")==0) strcpy(stDatVA.sSalidas, sValor);

		if(strcmp(sVariable, "sArchResult")==0)
		{
			if (strlen(sValor) > 15 || strlen(sValor) < 3)
			{
				printf("Mal Nombre de archivo de resultado. sArchResult M�nimo: 3 M�ximo: 15 caracteres\n");
				return -1;
			}
			strcpy(stDatVA.sArchResult, sValor);
		}
	}
	
	fclose(fpInicio);
	return 0;
};

//Hace el encabezado del archivo de resultados
void Inicializa::vArchResult()
{
    //Leidos de una vez los par�metros de simulaci�n, comienza a simular
	FILE *fpSimular;
    unlink(stDatVA.sArchResult);
	fpSimular = fopen(stDatVA.sArchResult, "a+t");
	fprintf(fpSimular,"Poblacion 02: Poblaciones\n");
	fprintf(fpSimular,"Serie Entrada: [%s]\n", stDatVA.sEntrada);
	fprintf(fpSimular,"Serie Salida: [%s]\n", stDatVA.sSalidas);
	fprintf(fpSimular,"Tamano ambiente: %d\n", stDatVA.TAMANOAMBIENTE);
	fprintf(fpSimular,"Instrucciones por organismo: %d\n", stDatVA.MAXINSTRUCCIONES);
	fprintf(fpSimular,"Total variables que maneja cada organismo: %d\n", stDatVA.NUMVARIABLES);
	fprintf(fpSimular,"Total tipo de instrucciones que maneja cada organismo: %d\n", stDatVA.TIPOINSTRUCCION);
	fprintf(fpSimular,"Maximo numero de organismos generados: %d\n", stDatVA.TOTALSIMULACION);
	fprintf(fpSimular,"Maximos ciclos que se interpreta cada organismo: %d\n", stDatVA.MAXIMOINTERPRETA);
	
	time_t ltime;
    time( &ltime );
    fprintf(fpSimular,"\nSimulaci�n inicia en: %s\n", ctime( &ltime ) );
	fclose(fpSimular);
};


//Graba una l�nea al archivo
void Inicializa::vGrabaLinea(char *sMensaje)
{
	FILE *fpSimular;

	fpSimular = fopen(stDatVA.sArchResult, "a+t");
	fprintf(fpSimular,"\n\n%s\n\n", sMensaje);
	fclose(fpSimular);
};

//Graba a archivo el algoritmo gen�tico
void Inicializa::vGrabaAlgoritmos(unsigned int iOrganismo, float fMargenError, char *sMensaje)
{
	FILE *fpSimular;

	fpSimular = fopen(stDatVA.sArchResult, "a+t");
	fprintf(fpSimular,"Organismo: [%d], Margen de Error (menor es mejor): [%f]\n", iOrganismo, fMargenError);
	fprintf(fpSimular,"%s\n", sMensaje);
	fclose(fpSimular);
};

//Este es el pie de p�gina del archivo de resultado
void Inicializa::vFinalSimulacion()
{
	FILE *fpSimular;
	time_t ltime;

	fpSimular = fopen(stDatVA.sArchResult, "a+t");
	time( &ltime );
	fprintf(fpSimular,"Finaliza en: %s\n", ctime( &ltime ) );
	fclose(fpSimular);
};