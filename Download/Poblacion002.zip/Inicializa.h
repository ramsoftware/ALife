/*
Autor:		Rafael Alberto Moreno Parra
URL:		http://www.geocities.com/krousky
Clase:		Inicializa.
Lenguaje:	C++

Prop�sito:
Inicializa las variables para la simulaci�n

M�todos:

*/
class Inicializa {
public:

	struct stDatosSimul
	{
		unsigned int TAMANOAMBIENTE; //Cuantos organismos tendr� el ambiente al tiempo
		unsigned int MAXINSTRUCCIONES; //El maximo son 256 instrucciones
		unsigned int NUMVARIABLES; //Total variables que tendr� cada algoritmo gen�tico
		unsigned int TIPOINSTRUCCION; //Los diferentes tipos de instruccion que tiene el algoritmo gen�tico: + - * / > >= < <= = !=
		unsigned int TOTALSIMULACION; //Cuantos organismos va a generar
		unsigned int MAXIMOINTERPRETA; //Cuantas instrucciones del algoritmo genetico ejecutar�.
		unsigned int ENTRADAS;  //Numero de entradas/salidas que tendr� 
		unsigned int MAXTOLERANCIA; //Si la adaptac�n del organismo comparado con este valor es menor entonces es evaluado para selecci�n

		char sEntrada[200];
		char sSalidas[200];
		char sArchResult[50]; //Archivo donde se guarda el resultado
	};  

	struct stDatosSimul stDatVA; //Datos Vida Artificial
	void vPantallaIni(void);
    int iLeeArchivoIni(void);
	void vArchResult(void);
	void vGrabaLinea(char *sMensaje);
	void vGrabaAlgoritmos(unsigned int iIntento, float fMargenError, char *sMensaje);
	void vFinalSimulacion(void);
};
