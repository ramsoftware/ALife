﻿<?php
/**
 * Autor: Rafael Alberto Moreno Parra
 * Correo: ramsoftware@gmail.com
 * Página Web: http://darwin.50webs.com
 * Licencia: LGPL
 * Fecha: Enero de 2012
 */
include("Pieza.php");
 
class EvaluadorExpresionAlgebraica
{
  /**
   * Constantes para determinar que tipo es cada pieza en que se divide la expresión algebraica
   */
  var $ESNUMERO = 1;
  var $ESOPERADOR = 2;
  var $ESVARIABLE = 3;
  var $ESFUNCION = 4;  

  /**
   * Esta constante sirve para que se reste al carácter y se obtenga el número
   * Ejemplo:  '7' - ASCIINUMERO =  7
   */
  var $ASCIINUMERO = 48;

  /**
   * Esta constante sirve para que se reste al carácter y se obtenga el número
   * usado en el arreglo unidimensional que alberga los valores de las variables
   * Ejemplo:  'b' - ASCIILETRA =  1
   */
  var $ASCIILETRA = 97;

   /**
   * Las funciones que soporta este evaluador
   */
  var $TAMANOFUNCION = 39;
  var $listaFunciones = "sinsencostanabsasnacsatnlogceiexpsqrrcb";  
  
  /**
   * Lista simplemente enlazada que tiene los componentes (número u operador)
   * de la expresión algebraica ya dividida.
   */
  var $Piezas = array();

  /**
   * Arreglo unidimensional con las 26 variables diferentes
   */
  var $valorVariable = array();

  /**
   * Almacena hasta que nivel se llega en paréntesis internos
   */
  var $MaximoNivel;

  /**
   * Variable que se pone a true cuando hay un error matemático
   */
  var $ERRORMATEMATICO;

  /**
   * Este método se encarga de analizar la expresión y convertirla en una 
   * estructura que permita evaluar la expresión.
   *
   * Convierte una expresión algebraica en una sucesión de nodos.
   * |2| |+| |8.3| |/| |5| |*| |7.4|
   * 
   * @param expr La expresión algebraica sin espacios y en minúsculas
  */
  public function Analizar($expr)
  {
    /* Inicializa la lista de piezas  */
    unset($this->Piezas);

    /* Inicializa el nivel */
    $nivel = 0;
    $this->MaximoNivel = 0;

    /* Tamaño de la expresión simple */
    $longitud = strlen($expr);

    /* Conversión de string a double */
    $entero = 0;
    $fraccion = 0;
    $divide = 1;
    $puntoentero = false;

    /* Si llevaba acumulando un valor numérico esta variable se vuelve true */
    $acumulabaNumero = false;

    for ($cont=0; $cont<$longitud; $cont++)
    {
      /* Trae la letra */
      $letra = $expr{$cont};

      /* Si hay un paréntesis que abre, el nivel aumenta */
      if ($letra=='(')
      {
        $nivel++;
        if ($nivel>$this->MaximoNivel) $this->MaximoNivel = $nivel;
      }
      /* Si es paréntesis que cierra, el nivel disminuye */
      else if ($letra==')')
        $nivel--;
      /* Si es una variable o una función */
      else if ($letra >= 'a' && $letra <= 'z')
      {
        /* Detecta si es una función porque tiene dos letras seguidas */
        if ($cont < $longitud-1)
        {
          /* Chequea si el siguiente carácter es una letra, dado el caso es una función */
          $letra2 = $expr{$cont+1};
          if ( $letra2 >= 'a' && $letra2 <= 'z')
          {
            $letra3 = $expr{$cont+2};

            /* Identifica las funciones */
            $funcionDetectada = 1;
            for ($funcion = 0; $funcion <= $this->TAMANOFUNCION; $funcion += 3)
            {
              if ($letra == $this->listaFunciones{$funcion}
                && $letra2 == $this->listaFunciones{$funcion + 1}
                && $letra3 == $this->listaFunciones{$funcion + 2})
                break;
              $funcionDetectada++;
            }

            /* Adiciona a la lista */
            $objeto = new Pieza();
            $objeto->ConstructorFuncion($funcionDetectada, $nivel);
            $this->Piezas[] = $objeto;

            $nivel++;
            if ($nivel > $this->MaximoNivel) $this->MaximoNivel = $nivel;

            /* Mueve tres caracteres  sin(  [s][i][n][(] */
            $cont+=3;
          }
          /* Es una variable, no una función */
          else
          {
            $objeto = new Pieza();
            $objeto->ConstructorVariable(ord($letra) - $this->ASCIILETRA, $nivel);
            $this->Piezas[] = $objeto;
          }
        }
        /* Es una variable, no una función */
        else
        {
          $objeto = new Pieza();
          $objeto->ConstructorVariable(ord($letra) - $this->ASCIILETRA, $nivel);
          $this->Piezas[] = $objeto;
        }
      }
      /* Si es un número */
      else if( ($letra >= '0' && $letra <= '9') || $letra == '.')
      {
        /* Ir armando el número de tipo double */
        if ($letra == '.')
          $puntoentero = true;
        else
          if(!$puntoentero)  /* $puntoentero == false */
            $entero = $entero * 10 + $letra;
          else
          {
            $fraccion = $fraccion * 10 + $letra;
            $divide *=10;
          }
          $acumulabaNumero = true;
      }
      else
      {
        /* Si es un operador entonces crea el nodo del operador y el
        nodo del número si venía acumulando un número */
        if ($acumulabaNumero)
        {
          $objeto = new Pieza();
          $objeto->ConstructorNumero($entero + $fraccion/$divide, $nivel);
          $this->Piezas[] = $objeto;
        }

        /* Agrega a la lista */
        $objeto = new Pieza();
        $objeto->ConstructorOperador($letra, $nivel);
        $this->Piezas[] = $objeto;

        /* Inicializa de nuevo las variables de conversión de string a número */
        $entero = 0;
        $fraccion = 0;
        $divide = 1;
        $puntoentero = false;
        $acumulabaNumero = false;
      }
    }

    /* Cierra la expresión simple preguntando si el último operando es un número */
    if ($acumulabaNumero)
    {
      $objeto = new Pieza();
      $objeto->ConstructorNumero($entero + $fraccion/$divide, $nivel);
      $this->Piezas[] = $objeto;
    }
  }

  /**
   * Ya construida la lista del tipo:
   * [nodo número]  [nodo operador]  [nodo número]  [nodo operador] .....
   * es ir del operador con mas precedencia al de menos precedencia.
   * 
   * Este método se llama después de haber sido analizada la expresión.
   * 
   * @return El valor de la expresión evaluada (double)
   */
 public function Evaluar()
 {
   $pos=0;
   $antes=0;
   $sigue=0;
   $this->ERRORMATEMATICO = false;

   /* Total de nodos en la lista creada */
   $totalPiezas = sizeof($this->Piezas);

   for ($pos=0; $pos<$totalPiezas; $pos++)
   {
      /* Activa todas las piezas para que sean evaluadas */
      $this->Piezas[$pos]->setEvaluado(false);
 
      /* Recorre toda la lista poniendo los valores de las variables en el acumulado de cada pieza.
         ¿Cómo? Extrae el valor del arreglo unidimensional que alberga los valores de las variables. */
      if ($this->Piezas[$pos]->getTipo() == $this->ESVARIABLE)
        $this->Piezas[$pos]->setAcumula($this->valorVariable[$this->Piezas[$pos]->getVariable()]);
      else if ($this->Piezas[$pos]->getTipo() == $this->ESNUMERO)
        $this->Piezas[$pos]->setAcumula($this->Piezas[$pos]->getNumero());
   }

   /* Va del nivel mas profundo al mas superficial */
   for ($evaluaNivel = $this->MaximoNivel; $evaluaNivel >= 0; $evaluaNivel--)
   {
     /* Recorre toda la lista */
     for ($pos=0; $pos<$totalPiezas; $pos++)
     {
        /* Si encuentra una pieza de tipo función la evalúa con el valor de la siguiente pieza */
        if ($this->Piezas[$pos]->getNivel() == $evaluaNivel && $this->Piezas[$pos]->getTipo() == $this->ESFUNCION )
        {
          switch ($this->Piezas[$pos]->getFuncion())
          {
            case 1:
            case 2:
               $this->Piezas[$pos]->setAcumula(sin($this->Piezas[$pos+1]->getAcumula()));
               break;
            case 3:
               $this->Piezas[$pos]->setAcumula(cos($this->Piezas[$pos+1]->getAcumula()));
               break;
            case 4:
               $this->Piezas[$pos]->setAcumula(tan($this->Piezas[$pos+1]->getAcumula()));
               break;
            case 5:
               if ($this->Piezas[$pos+1]->getAcumula() > 0)
                 $this->Piezas[$pos]->setAcumula($this->Piezas[$pos+1]->getAcumula());
               else
                 $this->Piezas[$pos]->setAcumula(-$this->Piezas[$pos+1]->getAcumula());
               break;
            case 6:
               if ($this->Piezas[$pos+1]->getAcumula() >= -1 && $this->Piezas[$pos+1]->getAcumula() <= 1)
                  $this->Piezas[$pos]->setAcumula(asin($this->Piezas[$pos+1]->getAcumula()));
               else
               {
                 $this->ERRORMATEMATICO = true;
                 return 0;
               }
               break;
            case 7:
               if ($this->Piezas[$pos+1]->getAcumula() >= -1 && $this->Piezas[$pos+1]->getAcumula() <= 1)
                  $this->Piezas[$pos]->setAcumula(acos($this->Piezas[$pos+1]->getAcumula()));
               else
               {
                  $this->ERRORMATEMATICO = true;
                  return 0;
               }
               break;
            case 8:
               $this->Piezas[$pos]->setAcumula(atan($this->Piezas[$pos+1]->getAcumula()));
               break;
            case 9:
               $this->Piezas[$pos]->setAcumula(log($this->Piezas[$pos+1]->getAcumula()));
               break;
            case 10:
               $this->Piezas[$pos]->setAcumula(ceil($this->Piezas[$pos+1]->getAcumula()));
               break;
            case 11:
               $this->Piezas[$pos]->setAcumula(exp($this->Piezas[$pos+1]->getAcumula()));
               break;
            case 12:
               if ($this->Piezas[$pos+1]->getAcumula() >= 0)
                  $this->Piezas[$pos]->setAcumula(sqrt($this->Piezas[$pos+1]->getAcumula()));
               else
               {
                  $this->ERRORMATEMATICO = true;
                  return 0;
               }
               break;
            case 13:
               $this->Piezas[$pos]->setAcumula(pow($this->Piezas[$pos+1]->getAcumula(), (double) 1 / 3));
               break;
         }

         /* Marca el nodo siguiente como ya evaluado */
         $this->Piezas[$pos+1]->setEvaluado(true);
        }
     }
 
 
     /* Recorre toda la lista */
     for ($pos=0; $pos<$totalPiezas; $pos++)
     {
       /* Si encuentra un nodo del tipo operador y es exponente */
       if ($this->Piezas[$pos]->getNivel() == $evaluaNivel && $this->Piezas[$pos]->getTipo() == $this->ESOPERADOR && $this->Piezas[$pos]->getOperador() == '^')
       {
         /* Busca un nodo anterior que sea número y no haya sido evaluado */
         for ($antes=$pos-1; $this->Piezas[$antes]->isEvaluado(); $antes--);

         /* Busca un nodo siguiente que sea número y no haya sido evaluado */
         for ($sigue=$pos+1; $this->Piezas[$sigue]->isEvaluado(); $sigue++);

         /* Marca esos nodos actual y siguiente como ya evaluados */
         $this->Piezas[$pos]->setEvaluado(true);
         $this->Piezas[$sigue]->setEvaluado(true);

         /* Hace la operación de Número elevado a Número */
         $this->Piezas[$antes]->setAcumula(pow($this->Piezas[$antes]->getAcumula(), $this->Piezas[$sigue]->getAcumula()));
       }
     }  

     /* Recorre toda la lista */
     for ($pos=0; $pos<$totalPiezas; $pos++)
     {
       /* Si encuentra un nodo del tipo operador y es multiplicación o división */
       if ($this->Piezas[$pos]->getNivel() == $evaluaNivel && $this->Piezas[$pos]->getTipo() == $this->ESOPERADOR && ($this->Piezas[$pos]->getOperador() == '*' || $this->Piezas[$pos]->getOperador() == '/'))
       {
         /* Busca un nodo anterior que sea número y no haya sido evaluado */
         for ($antes=$pos-1; $this->Piezas[$antes]->isEvaluado(); $antes--);

         /* Busca un nodo siguiente que sea número y no haya sido evaluado */
         for ($sigue=$pos+1; $this->Piezas[$sigue]->isEvaluado(); $sigue++);

         /* Marca esos nodos actual y siguiente como ya evaluados */
         $this->Piezas[$pos]->setEvaluado(true);
         $this->Piezas[$sigue]->setEvaluado(true);

         /* Hace la operación de Número * Número, o Número / Número */
         if ($this->Piezas[$pos]->getOperador() == '*')
            $this->Piezas[$antes]->setAcumula( $this->Piezas[$antes]->getAcumula() * $this->Piezas[$sigue]->getAcumula() );
         else
         {
            if ($this->Piezas[$sigue]->getAcumula() != 0)
               $this->Piezas[$antes]->setAcumula( $this->Piezas[$antes]->getAcumula() / $this->Piezas[$sigue]->getAcumula() );
            else
            {
               $this->ERRORMATEMATICO = true;
               return 0;
            }
         }
       }
     }

     /* Recorre toda la lista */
     for ($pos=0; $pos<$totalPiezas; $pos++)
     {
       /* Si encuentra un nodo del tipo operador y es suma o resta */
       if ($this->Piezas[$pos]->getNivel() == $evaluaNivel && $this->Piezas[$pos]->getTipo() == $this->ESOPERADOR && ($this->Piezas[$pos]->getOperador() == '+' || $this->Piezas[$pos]->getOperador() == '-'))
       {
         /* Busca un nodo anterior que sea número y no haya sido evaluado */
         for ($antes=$pos-1; $this->Piezas[$antes]->isEvaluado(); $antes--);

         /* Busca un nodo siguiente que sea número y no haya sido evaluado */
         for ($sigue=$pos+1; $this->Piezas[$sigue]->isEvaluado(); $sigue++);

         /* Marca esos nodos actual y siguiente como ya evaluados */
         $this->Piezas[$pos]->setEvaluado(true);
         $this->Piezas[$sigue]->setEvaluado(true);

         /* Hace la operación de Número + Número, o Número - Número */
         if ($this->Piezas[$pos]->getOperador() == '+')
            $this->Piezas[$antes]->setAcumula( $this->Piezas[$antes]->getAcumula() + $this->Piezas[$sigue]->getAcumula() );
         else
            $this->Piezas[$antes]->setAcumula( $this->Piezas[$antes]->getAcumula() - $this->Piezas[$sigue]->getAcumula() );
       }
     }
   }
   /* Resultado de la expresión */
   return $this->Piezas[0]->getAcumula();
 }
 
 /**
 * Guarda en un arreglo unidimensional el valor de las variables
 * @param variable ¿Qué variable de la expresión recibirá el valor? a..z
 * @param valor Valor de tipo double que tendrá esa variable.
 */
 public function DarValorVariable($variable, $valor)
 {
 $this->valorVariable[ord($variable) - $this->ASCIILETRA] = $valor;
 } 

  /**
   * Retorna true si hubo un error matemático
   * @return TRUE si hubo un error matemático
   */
  public function getERRORMATEMATICO()
  {
      return $this->ERRORMATEMATICO;
  }
}
?>