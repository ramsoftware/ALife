<?php
/**
 * Autor: Rafael Alberto Moreno Parra
 * Correo: ramsoftware@gmail.com
 * P�gina Web: http://darwin.50webs.com
 * Licencia: LGPL
 * Fecha: Enero de 2012
 */
include("EvaluadorExpresionAlgebraica.php");
$objEvaluador = new EvaluadorExpresionAlgebraica();
$expresion = 'x*4.700+x+4.409/5.17/2.95-x*3.886+8.451*(x/6.669/6.302)/9.124+0.179+7.539+x*abs(8.507+9.801)+8.133*acs(cos(x/x))';
$objEvaluador->Analizar($expresion);
$objEvaluador->DarValorVariable('x', 13.1729);
$valor = $objEvaluador->Evaluar();
echo $valor;
?>