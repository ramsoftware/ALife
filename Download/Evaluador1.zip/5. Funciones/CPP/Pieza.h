/**
 * Autor: Rafael Alberto Moreno Parra
 * Correo: ramsoftware@gmail.com
 * P�gina Web: http://darwin.50webs.com
 * Licencia: LGPL
 * Fecha: Enero de 2012
 */

/* Pieza ser� la unidad b�sica de la expresi�n algebraica, cada nodo tendr� o un operador 
   o un n�mero o una variable. Este nodo trabaja en una lista simplemente enlazada */
class Pieza
{
private:
    /* Nivel en la expresi�n, a mayor valor, es mayor profundidad en la expresi�n */
    int nivel;

    /* 1. Almacena un n�mero, 2. Almacena un operador, 3. Almacena una variable */
    int tipo;

    /* El n�mero en la expresi�n algebraica */
    double numero;
    
    /* El operador (+, -, *, /, ^) en la expresi�n algebraica */
    char operador;
    
    /* La variable */
    int variable;

    /* La funci�n */
    int funcion;

    /* Determina si esta pieza ya ha sido evaluada en el momento de hacer los 
       c�lculos que determinan el valor de la expresi�n */
    bool evaluado;
    
    /* El resultado parcial de la evaluaci�n de la expresi�n */
    double acumula;

public:
    /**
     * Constructor en caso que la pieza contenga un n�mero real
     * @param numero N�mero de tipo double
     * @param nivel Nivel en que se encuentra en la expresi�n este n�mero
     */
    Pieza(double, int);
    
    /**
     * Constructor en caso que el nodo contenga un operador (+, -, *, /, ^)
     * @param operador Que puede ser +, -, *, /, ^
     * @param nivel Nivel en que se encuentra en la expresi�n este operador
     */
    Pieza(char, int);
    
    /**
     * Constructor en caso que el nodo contenga una variable
     * @param variable Puede ir de 0 a 25 que representa de a..z
     * @param nivel Nivel en que se encuentra en la expresi�n este operador
     */
    Pieza(int, int);

    /**
     * Constructor en caso que la pieza contenga una funci�n
     * @param funcion Identificaci�n de la funci�n
     * @param nivel Nivel en que se encuentra en la expresi�n este operador
     * @param bandera S�lo sirve para diferenciarlo del anterior constructor
     */
    Pieza(int, int, char);

    /** Retorna el acumulado que tiene esta pieza
     * @return Acumulado de la pieza
     */
    double getAcumula();

    /** Retorna si la pieza ya fue evaluada
     * @return True si la pieza ya fue evaluada
     */
    bool isEvaluado();

    /**
     * Retorna el n�mero de tipo double que tiene la pieza
     * @return El valor del n�mero tipo double
     */
    double getNumero();

    /**
     * Retorna el operador (+, -, *, /, ^) que tiene la pieza
     * @return El operador en char
     */
    char getOperador();

    /**
     * Retorna la variable que tiene la pieza
     * @return La variable
     */
    int getVariable();

    /**
     * Retorna que tipo de pieza es: n�mero, operador, variable o funci�n
     * @return Tipo de pieza
     */
    int getTipo();

    /**
     * Retorna en qu� nivel se encuentra la pieza con respecto a la expresi�n
     * @return Nivel
     */
    int getNivel();

    /**
     * Retorna el c�digo de la funci�n (abs, sen, cos, tan) que tiene la pieza
     * @return C�digo de la funci�n
     */
    int getFuncion();

    /**
     * Da valor al acumulado por pieza
     * @param acumulado  Acumulado que nace de cada operaci�n simple es dado a la pieza aqu�.
     */
    void setAcumula(double);

    /**
     * Marca la pieza como ya evaluada
     * @param evaluado true si la pieza ya ha sido evaluada, false si no
     */
    void setEvaluado(bool);
};
