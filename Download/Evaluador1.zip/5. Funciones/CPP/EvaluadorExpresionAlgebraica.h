/**
 * Autor: Rafael Alberto Moreno Parra
 * Correo: ramsoftware@gmail.com
 * P�gina Web: http://darwin.50webs.com
 * Licencia: LGPL
 * Fecha: Enero de 2012
 */
#include "Pieza.h"
#include <vector>

class EvaluadorExpresionAlgebraica
{
private:
    /**
     * Constantes para determinar que tipo es cada pieza en que se divide la expresi�n algebraica
     */
    static const int ESNUMERO = 1;
    static const int ESOPERADOR = 2;
    static const int ESVARIABLE = 3;
    static const int ESFUNCION = 4;

    /**
     * Esta constante sirve para que se reste al car�cter y se obtenga el n�mero
     * Ejemplo:  '7' - ASCIINUMERO =  7
     */
    static const int ASCIINUMERO = 48;

    /**
     * Esta constante sirve para que se reste al car�cter y se obtenga el n�mero
     * usado en el arreglo unidimensional que alberga los valores de las variables
     * Ejemplo:  'b' - ASCIILETRA =  1
     */
    static const int ASCIILETRA = 97;

    /**
     * Las funciones que soporta este evaluador
     */
    static const int TAMANOFUNCION = 39;
    char listaFunciones[50];

    /* Lista simplemente enlazada que tiene los componentes (numero u operador
       de la expresi�n algebraica ya dividida */
    std::vector<Pieza> Piezas;
    
    /* Arreglo unidimensional con las 26 variables diferentes */
    double valorVariable[30];

    /* Almacena hasta que nivel se llega en par�ntesis internos */
    int MaximoNivel;

    /* Variable que se pone a true cuando hay error matem�tico */
    bool ERRORMATEMATICO;
   
public:
    EvaluadorExpresionAlgebraica(void);    
    void DarValorVariable(char, double);

    /* Analiza la expresi�n algebraica y la vuelve una lista */
    void Analizar(char *);

    /* Eval�a la expresi�n que ha sido previamente analizada */
    double Evaluar(void);

    /* Retorna si hubo error matem�tico */
    bool getErrorMatematico(); 
};
              
