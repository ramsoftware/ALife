/**
 * Autor: Rafael Alberto Moreno Parra
 * Correo: ramsoftware@gmail.com
 * P�gina Web: http://darwin.50webs.com
 * Licencia: LGPL
 * Fecha: Enero de 2012
 */
#include <math.h>
#include <stdio.h>

#include "EvaluadorExpresionAlgebraica.h"

/**
* Constructor
*/
EvaluadorExpresionAlgebraica::EvaluadorExpresionAlgebraica()
{
  char *funciones = "sinsencostanabsasnacsatnlogceiexpsqrrcb";
  for (int cont = 0; *(funciones+cont); cont++)
      listaFunciones[cont] = funciones[cont];
}

/**
 * Convierte una expresi�n simple en una sucesi�n de nodos.
 * |2| |+| |a| |/| |5| |*| |c| |-| |1.5|
*/
void EvaluadorExpresionAlgebraica::Analizar(char *expr)
{
  /* Inicializa la lista de piezas. http://www.codeguru.com/Cpp/Cpp/cpp_mfc/stl/article.php/c4027  */
  Piezas.clear();
  
  /* Inicializa el nivel */
  int nivel = 0;
  MaximoNivel = 0;

  /* Conversi�n de string a double */
  double decimal = 0;
  double fraccion = 0;
  double divide = 1;
  bool puntodecimal = false;

  /* Tama�o de la expresi�n simple */
  int longitud = strlen(expr);

  /* Va extrayendo letra a letra de la expresi�n simple */
  char letra;
 
  /* Si llevaba acumulando un valor num�rico esta variable se vuelve true */ 
  bool acumulabaNumero = false;
 
  for (int cont=0; cont<longitud; cont++)
  {
    /* Trae la letra */
    letra = expr[cont];

    /* Si hay un par�ntesis que abre, el nivel aumenta */
    if (letra=='(') 
    {
      nivel++;
      if (nivel>MaximoNivel) MaximoNivel = nivel;
    }
    /* Si es par�ntesis que cierra, el nivel disminuye */
    else if (letra==')')
      nivel--;
    /* Si es una variable o una funci�n */
    else if (letra >= 'a' && letra <= 'z')
    {
      /* Detecta si es una funci�n porque tiene dos letras seguidas */
      if (cont<longitud+1)
      {  
        /* Chequea si el siguiente car�cter es una letra, dado el caso es una funci�n */
        char letra2 = expr[cont+1];
        if ( letra2 >= 'a' && letra2 <= 'z')
        {
          char letra3 = expr[cont+2];

          /* Identifica las funciones */
          int funcionDetectada = 1;
          for (int funcion = 0; funcion <= TAMANOFUNCION; funcion += 3)
          {
            if (letra == listaFunciones[funcion] 
              && letra2 == listaFunciones[funcion + 1]
              && letra3 == listaFunciones[funcion + 2])
              break;
            funcionDetectada++;
          }

          /* Adiciona a la lista */
          Pieza objeto(funcionDetectada, nivel, 'f');
          Piezas.push_back(objeto);

          nivel++;
          if (nivel>MaximoNivel) MaximoNivel = nivel;

          /* Mueve tres caracteres  sin(  [s][i][n][(] */
          cont+=3;
        }
        /* Es una variable, no una funci�n */
        else 
        {
          Pieza objeto(letra - ASCIILETRA, nivel);
          Piezas.push_back(objeto);
        }
      }
      /* Es una variable, no una funci�n */
      else 
      {
        Pieza objeto(letra - ASCIILETRA, nivel);
        Piezas.push_back(objeto);
      }
    }
    /* Si es un n�mero */
    else if( (letra >= '0' && letra <= '9') || letra == '.')
    {
      /* Ir armando el n�mero de tipo double */
      if (letra == '.')
        puntodecimal = true;
      else
        if(!puntodecimal)  /* puntodecimal == false */
          decimal = decimal * 10 + letra-ASCIINUMERO;
        else
        {
          fraccion = fraccion * 10 + letra-ASCIINUMERO;
          divide *=10;
        }
      acumulabaNumero = true;
    }
    else
    {
      /* Si es un operador entonces crea el nodo del operador y el
         nodo del n�mero si ven�a acumulando un n�mero */
      if (acumulabaNumero)
      {
        /* El nodo del n�mero */
        Pieza objeto(decimal + fraccion/divide, nivel);
     
        /* Agrega a la lista */
        Piezas.push_back(objeto);
      }

      /* El nodo operador */
      Pieza objeto(letra, nivel);
  
      /* Agrega a la lista */
      Piezas.push_back(objeto);
  
      /* Inicializa de nuevo las variables de conversi�n de string a n�mero */
      decimal = 0;
      fraccion = 0;
      divide = 1;
      puntodecimal = false;
      acumulabaNumero = false;
    }
  }

  /* Cierra la expresi�n simple preguntando si el �ltimo operando es un n�mero */
  if (acumulabaNumero)
  {
    Pieza objeto(decimal + fraccion/divide, nivel);
    Piezas.push_back(objeto);
  }

}

/* Ya construida la lista del tipo:
   [nodo n�mero]  [nodo operador]  [nodo n�mero]  [nodo operador] ..... 
   es ir del operador con mas precedencia al de menos precedencia */
double EvaluadorExpresionAlgebraica::Evaluar()
{
  int pos=0, antes=0, sigue=0;
  ERRORMATEMATICO = false;
  
  /* Total de nodos en la lista creada */
  int totalPiezas = Piezas.size();

  for (pos=0; pos<totalPiezas; pos++)
  {
    /* Activa todas las piezas para que sean evaluadas */
    Piezas[pos].setEvaluado(false);

    /* Recorre toda la lista poniendo los valores de las variables en el acumulado de cada pieza.
      �C�mo? Extrae el valor del arreglo unidimensional que alberga los valores de las variables. */
    if (Piezas[pos].getTipo() == ESVARIABLE)
      Piezas[pos].setAcumula(valorVariable[Piezas[pos].getVariable()]);
    else if (Piezas[pos].getTipo() == ESNUMERO)
      Piezas[pos].setAcumula(Piezas[pos].getNumero());
  }

  /* Va del nivel mas profundo al mas superficial */
  for (int evaluaNivel = MaximoNivel; evaluaNivel >= 0; evaluaNivel--)
  {
    /* Recorre toda la lista */
    for (pos=0; pos<totalPiezas; pos++)
    {
      /* Si encuentra una funci�n la eval�a con la siguiente */ 
      if (Piezas[pos].getNivel() == evaluaNivel && Piezas[pos].getTipo()==ESFUNCION )
      {
          switch (Piezas[pos].getFuncion())
          {
            case 1:
            case 2:
              Piezas[pos].setAcumula(sin(Piezas[pos+1].getAcumula()));
              break;
            case 3:
              Piezas[pos].setAcumula(cos(Piezas[pos+1].getAcumula()));
              break;
            case 4:
              Piezas[pos].setAcumula(tan(Piezas[pos+1].getAcumula()));
              break;
            case 5:
              if (Piezas[pos+1].getAcumula() > 0)
                Piezas[pos].setAcumula(Piezas[pos+1].getAcumula());
              else
                Piezas[pos].setAcumula(-Piezas[pos+1].getAcumula());
              break;
            case 6:
              if (Piezas[pos+1].getAcumula() >= -1 && Piezas[pos+1].getAcumula() <= 1)
                Piezas[pos].setAcumula(asin(Piezas[pos+1].getAcumula()));
              else
              {
                ERRORMATEMATICO = true;
                return 0;
              }
              break;
            case 7:
              if (Piezas[pos+1].getAcumula() >= -1 && Piezas[pos+1].getAcumula() <= 1)
                Piezas[pos].setAcumula(acos(Piezas[pos+1].getAcumula()));
              else
              {
                ERRORMATEMATICO = true;
                return 0;
              }
              break;
            case 8:
              Piezas[pos].setAcumula(atan(Piezas[pos+1].getAcumula()));
              break;
            case 9:
              Piezas[pos].setAcumula(log(Piezas[pos+1].getAcumula()));
              break;
            case 10:
              Piezas[pos].setAcumula(ceil(Piezas[pos+1].getAcumula()));
              break;
            case 11:
              Piezas[pos].setAcumula(exp(Piezas[pos+1].getAcumula()));
              break;
            case 12:
              if (Piezas[pos+1].getAcumula() >= 0)
                Piezas[pos].setAcumula(sqrt(Piezas[pos+1].getAcumula()));
              else
              {
                ERRORMATEMATICO = true;
                return 0;
              }
              break;
            case 13:
              Piezas[pos].setAcumula(pow(Piezas[pos+1].getAcumula(), (double) 1 / 3));
              break;
          }

          /* Marca el nodo siguiente como ya evaluado */
          Piezas[pos+1].setEvaluado(true);
      }
    }

    /* Recorre toda la lista */
    for (pos=0; pos<totalPiezas; pos++)
    {
      /* Si encuentra un nodo del tipo operador y es exponente */
      if (Piezas[pos].getNivel() == evaluaNivel && Piezas[pos].getTipo() == ESOPERADOR && Piezas[pos].getOperador() == '^')
      {
        /* Busca un nodo anterior que sea n�mero o variable y no haya sido evaluado */
        for (antes=pos-1; Piezas[antes].isEvaluado(); antes--);

        /* Busca un nodo siguiente que sea n�mero o variable y no haya sido evaluado */
        for (sigue=pos+1; Piezas[sigue].isEvaluado(); sigue++);

        /* Marca esos nodos actual y siguiente como ya evaluados */
        Piezas[pos].setEvaluado(true);
        Piezas[sigue].setEvaluado(true);

        /* Hace la operaci�n de N�mero elevado a N�mero */
        Piezas[antes].setAcumula(pow(Piezas[antes].getAcumula(), Piezas[sigue].getAcumula()));
      }
    }

    /* Recorre toda la lista */
    for (pos=0; pos<totalPiezas; pos++)
    {
      /* Si encuentra un nodo del tipo operador y es multiplicaci�n o divisi�n */
      if (Piezas[pos].getNivel() == evaluaNivel && Piezas[pos].getTipo() == ESOPERADOR && (Piezas[pos].getOperador() == '*' || Piezas[pos].getOperador() == '/'))
      {
        /* Busca un nodo anterior que sea n�mero o variable y no haya sido evaluado */
        for (antes=pos-1; Piezas[antes].isEvaluado(); antes--);

        /* Busca un nodo siguiente que sea n�mero o variable y no haya sido evaluado */
        for (sigue=pos+1; Piezas[sigue].isEvaluado(); sigue++);

        /* Marca esos nodos actual y siguiente como ya evaluados */
        Piezas[pos].setEvaluado(true);
        Piezas[sigue].setEvaluado(true);
      
        /* Hace la operaci�n de N�mero * N�mero, o N�mero / N�mero */
        if (Piezas[pos].getOperador() == '*')
          Piezas[antes].setAcumula( Piezas[antes].getAcumula() *  Piezas[sigue].getAcumula() );
        else
        {
          if (Piezas[sigue].getAcumula() != 0)
            Piezas[antes].setAcumula( Piezas[antes].getAcumula() /  Piezas[sigue].getAcumula() );
          else
          {
            ERRORMATEMATICO = true;
            return 0;
          }
        }
      }
    }

    /* Recorre toda la lista */
    for (pos=0; pos<totalPiezas; pos++)
    {
      /* Si encuentra un nodo del tipo operador y es suma o resta */
      if (Piezas[pos].getNivel() == evaluaNivel && Piezas[pos].getTipo() == ESOPERADOR && (Piezas[pos].getOperador() == '+' || Piezas[pos].getOperador() == '-'))
      {
        /* Busca un nodo anterior que sea n�mero o variable y no haya sido evaluado */
        for (antes=pos-1; Piezas[antes].isEvaluado(); antes--);

        /* Busca un nodo siguiente que sea n�mero o variable y no haya sido evaluado */
        for (sigue=pos+1; Piezas[sigue].isEvaluado(); sigue++);

        /* Marca esos nodos actual y siguiente como ya evaluados */
        Piezas[pos].setEvaluado(true);
        Piezas[sigue].setEvaluado(true);
      
        /* Hace la operaci�n de N�mero + N�mero, o N�mero - N�mero */
        if (Piezas[pos].getOperador() == '+')
          Piezas[antes].setAcumula( Piezas[antes].getAcumula() +  Piezas[sigue].getAcumula() );
        else
          Piezas[antes].setAcumula( Piezas[antes].getAcumula() -  Piezas[sigue].getAcumula() );
      }
    }
  }

  /* Resultado de la expresi�n */
  return Piezas[0].getAcumula();
}

/* Guarda en un arreglo unidimensional el valor de las variables */
void EvaluadorExpresionAlgebraica::DarValorVariable(char variable, double valor)
{
   valorVariable[variable - ASCIILETRA] = valor;
}

/* Retorna true si hubo un error matem�tico */
bool EvaluadorExpresionAlgebraica::getErrorMatematico()
{
  return ERRORMATEMATICO;
}
