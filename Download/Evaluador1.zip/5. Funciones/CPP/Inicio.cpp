/**
 * Autor: Rafael Alberto Moreno Parra
 * Correo: ramsoftware@gmail.com
 * P�gina Web: http://darwin.50webs.com
 * Licencia: LGPL
 * Fecha: Enero de 2012
 */
#include <stdio.h>
#include <string.h>
#include <math.h>
#include "EvaluadorExpresionAlgebraica.h"

int main(void);

int main()
{
    char expresion[500];
    EvaluadorExpresionAlgebraica objEvaluador;
    double valor;
    strcpy(expresion, "4.763*5.704+(x-5.447+(x+sen(3.670/cos(sen(atn(sen(4.877*cos(7.330))/(abs(9.191+4.262)+x)+(x+(((x*3.382/(x/(9.922))))))))))))");
	objEvaluador.Analizar(expresion); 
	objEvaluador.DarValorVariable('x', 13.1729);
	valor=objEvaluador.Evaluar();
	printf("%f\n", valor);
    getchar();
    return 0;
}
