/**
 * Autor: Rafael Alberto Moreno Parra
 * Correo: ramsoftware@gmail.com
 * P�gina Web: http://darwin.50webs.com
 * Licencia: LGPL
 * Fecha: Enero de 2012
 */
#include <stdio.h>
#include <math.h>
#include "Pieza.h"

/**
 * Constructor en caso que la pieza contenga un n�mero real
 * @param numero N�mero de tipo double
 * @param nivel Nivel en que se encuentra en la expresi�n este n�mero
 */
Pieza::Pieza(double numero, int nivel)
{
 this->tipo = 1; //Es un n�mero
 this->numero = numero;
 this->nivel = nivel;

 this->evaluado = false;
 this->acumula = numero;
}

/**
 * Constructor en caso que el nodo contenga un operador (+, -, *, /, ^)
 * @param operador Que puede ser +, -, *, /, ^
 * @param nivel Nivel en que se encuentra en la expresi�n este operador
 */
Pieza::Pieza(char operador, int nivel)
{
 this->tipo = 2; //Es un operador
 this->operador = operador;
 this->nivel = nivel;

 this->evaluado = false;
 this->acumula = 0;
}

/**
 * Constructor en caso que el nodo contenga una variable
 * @param variable Puede ir de 0 a 25 que representa de a..z
 * @param nivel Nivel en que se encuentra en la expresi�n este operador
 */
Pieza::Pieza(int variable, int nivel)
{
 this->tipo = 3; //Es una variable
 this->variable = variable;
 this->nivel = nivel;

 this->evaluado = false;
 this->acumula = 0;
}

/**
 * Constructor en caso que la pieza contenga una funci�n
 * @param funcion Identificaci�n de la funci�n
 * @param nivel Nivel en que se encuentra en la expresi�n este operador
 * @param bandera S�lo sirve para diferenciarlo del anterior constructor
 */
Pieza::Pieza(int funcion, int nivel, char bandera)
{
 this->tipo = 4; //Es una funci�n
 this->funcion = funcion;
 this->nivel = nivel;

 this->evaluado = false;
 this->acumula = 0;
}

/** Retorna el acumulado que tiene esta pieza
 * @return Acumulado de la pieza
 */
double Pieza::getAcumula()
{
 return acumula;
}

/** Retorna si la pieza ya fue evaluada
 * @return True si la pieza ya fue evaluada
 */
bool Pieza::isEvaluado()
{
 return evaluado;
}

/**
 * Retorna el n�mero de tipo double que tiene la pieza
 * @return El valor del n�mero tipo double
 */
double Pieza::getNumero()
{
 return numero;
}

/**
 * Retorna el operador (+, -, *, /, ^) que tiene la pieza
 * @return El operador en char
 */
char Pieza::getOperador()
{
 return operador;
}

/**
 * Retorna la variable que tiene la pieza
 * @return La variable
 */
int Pieza::getVariable()
{
 return variable;
}

/**
 * Retorna que tipo de pieza es: n�mero, operador, variable o funci�n
 * @return Tipo de pieza
 */
int Pieza::getTipo()
{
 return tipo;
}

/**
 * Retorna en qu� nivel se encuentra la pieza con respecto a la expresi�n
 * @return Nivel
 */
int Pieza::getNivel()
{
    return nivel;
}

/**
 * Retorna el c�digo de la funci�n (abs, sen, cos, tan) que tiene la pieza
 * @return C�digo de la funci�n
 */
int Pieza::getFuncion()
{
    return funcion;
}

/**
 * Da valor al acumulado por pieza
 * @param acumulado  Acumulado que nace de cada operaci�n simple es dado a la pieza aqu�.
 */
void Pieza::setAcumula(double acumulado)
{
 this->acumula = acumulado;
}

/**
 * Marca la pieza como ya evaluada
 * @param evaluado true si la pieza ya ha sido evaluada, false si no
 */
void Pieza::setEvaluado(bool evaluado)
{
 this->evaluado = evaluado;
}
