/**
 * Autor: Rafael Alberto Moreno Parra
 * Correo: ramsoftware@gmail.com
 * Página Web: http://darwin.50webs.com
 * Licencia: LGPL
 * Fecha: Enero de 2012
 */
import java.util.ArrayList;

public class EvaluadorExpresionAlgebraica
{
  /**
   * Constantes para determinar que tipo es cada pieza en que se divide la expresión algebraica
   */
  private static final int ESNUMERO = 1;
  private static final int ESOPERADOR = 2;
  private static final int ESVARIABLE = 3;
  private static final int ESFUNCION = 4;

  /**
   * Esta constante sirve para que se reste al carácter y se obtenga el número
   * Ejemplo:  '7' - ASCIINUMERO =  7
   */
  private static final int ASCIINUMERO = 48;

  /**
   * Esta constante sirve para que se reste al carácter y se obtenga el número
   * usado en el arreglo unidimensional que alberga los valores de las variables
   * Ejemplo:  'b' - ASCIILETRA =  1
   */
  private static final int ASCIILETRA = 97;

  /**
   * Las funciones que soporta este evaluador
   */
  private static final int TAMANOFUNCION = 39;
  private static final String listaFunciones = "sinsencostanabsasnacsatnlogceiexpsqrrcb";

  /**
   * Lista simplemente enlazada que tiene los componentes (número, operador o función)
   * de la expresión algebraica ya dividida.
   */
  private ArrayList<Pieza> Piezas = new ArrayList<Pieza>();

  /**
   * Arreglo unidimensional con las 26 variables diferentes
   */
  private double valorVariable[] = new double[26];

  /**
   * Almacena hasta que nivel se llega en paréntesis internos
   */
  private int MaximoNivel;

  /**
   * Variable que se pone a true cuando hay un error matemático
   */
  private boolean ERRORMATEMATICO;

  /**
   * Este método se encarga de analizar la expresión y convertirla en una 
   * estructura que permita evaluar la expresión.
   *
   * Convierte una expresión algebraica en una sucesión de nodos.
   * |2| |+| |a| |/| |5| |*| |cos| |y|
   * 
   * @param expr La expresión algebraica sin espacios y en minúsculas
  */
  public void Analizar(String expr)
  {
    /* Inicializa la lista de piezas  */
    Piezas.clear();

    /* Inicializa el nivel */
    int nivel = 0;
    MaximoNivel = 0;

    /* Tamaño de la expresión simple */
    int longitud = expr.length();

    /* Va extrayendo letra a letra de la expresión simple */
    char letra;

    /* Conversión de string a double */
    double decimal = 0, fraccion = 0, divide = 1;
    boolean puntodecimal = false;

    /* Si llevaba acumulando un valor numérico esta variable se vuelve true */
    boolean acumulabaNumero = false;

    for (int cont=0; cont<longitud; cont++)
    {
      /* Trae la letra */
      letra = expr.charAt(cont);

      /* Si hay un paréntesis que abre, el nivel aumenta */
      if (letra=='(')
      {
        nivel++;
        if (nivel>MaximoNivel) MaximoNivel = nivel;
      }
      /* Si es paréntesis que cierra, el nivel disminuye */
      else if (letra==')')
        nivel--;
      /* Si es una variable o una función */
      else if (letra >= 'a' && letra <= 'z')
      {
        /* Detecta si es una función porque tiene dos letras seguidas */
        if (cont < longitud-1)
        {
          /* Chequea si el siguiente carácter es una letra, dado el caso es una función */
          char letra2 = expr.charAt(cont+1);
          if ( letra2 >= 'a' && letra2 <= 'z')
          {
            char letra3 = expr.charAt(cont+2);

            /* Identifica las funciones */
            int funcionDetectada = 1;
            for (int funcion = 0; funcion <= TAMANOFUNCION; funcion += 3)
            {
              if (letra == listaFunciones.charAt(funcion)
                && letra2 == listaFunciones.charAt(funcion + 1)
                && letra3 == listaFunciones.charAt(funcion + 2))
              break;
              funcionDetectada++;
            }

            /* Adiciona a la lista */
            Pieza objeto = new Pieza(funcionDetectada, nivel, 'f');
            Piezas.add(objeto);

            nivel++;
            if (nivel>MaximoNivel) MaximoNivel = nivel;

            /* Mueve tres caracteres  sin(  [s][i][n][(] */
            cont+=3;
          }
          /* Es una variable, no una función */
          else
          {
            Pieza objeto = new Pieza(letra - ASCIILETRA, nivel);
            Piezas.add(objeto);
          }
        }
        /* Es una variable, no una función */
        else
        {
          Pieza objeto = new Pieza(letra - ASCIILETRA, nivel);
          Piezas.add(objeto);
        }
      }
      /* Si es un número */
      else if( (letra >= '0' && letra <= '9') || letra == '.')
      {
        /* Ir armando el número de tipo double */
        if (letra == '.')
          puntodecimal = true;
        else
          if(!puntodecimal)  /* puntodecimal == false */
            decimal = decimal * 10 + letra-ASCIINUMERO;
          else
          {
            fraccion = fraccion * 10 + letra-ASCIINUMERO;
            divide *=10;
          }
          acumulabaNumero = true;
      }
      else
      {
        /* Si es un operador entonces crea el nodo del operador y el
          nodo del número si venía acumulando un número */
        if (acumulabaNumero)
        {
          /* El nodo del número */
          Pieza objeto = new Pieza(decimal + fraccion/divide, nivel);

          /* Agrega a la lista */
          Piezas.add(objeto);
        }

        /* El nodo operador */
        Pieza objeto = new Pieza(letra, nivel);

        /* Agrega a la lista */
        Piezas.add(objeto);

        /* Inicializa de nuevo las variables de conversión de string a número */
        decimal = fraccion = 0;
        divide = 1;
        puntodecimal = acumulabaNumero = false;
      }
    }

    /* Cierra la expresión simple preguntando si el último operando es un número */
    if (acumulabaNumero)
    {
      Pieza objeto = new Pieza(decimal + fraccion/divide, nivel);
      Piezas.add(objeto);
    }
  }

  /**
   * Ya construida la lista del tipo:
   * [nodo número]  [nodo operador]  [nodo número]  [nodo operador] .....
   * es ir del operador con mas precedencia al de menos precedencia.
   * 
   * Este método se llama después de haber sido analizada la expresión.
   * 
   * En el caso que sólo cambia el valor de una variable, no es necesario
   * analizar de nuevo la expresión, luego es muy rápido evaluar múltiples veces
   * la misma expresión.
   *
   * @return El valor de la expresión evaluada (double)
   */
  public double Evaluar()
  {
    int pos=0, antes=0, sigue=0;
    ERRORMATEMATICO = false;

    /* Total de nodos en la lista creada */
    int totalPiezas = Piezas.size();

    for (pos=0; pos<totalPiezas; pos++)
    {
      /* Activa todas las piezas para que sean evaluadas */
      Piezas.get(pos).setEvaluado(false);

      /* Recorre toda la lista poniendo los valores de las variables en el acumulado de cada pieza.
         ¿Cómo? Extrae el valor del arreglo unidimensional que alberga los valores de las variables. */
      if (Piezas.get(pos).getTipo() == ESVARIABLE)
        Piezas.get(pos).setAcumula(valorVariable[Piezas.get(pos).getVariable()]);
      else if (Piezas.get(pos).getTipo() == ESNUMERO)
        Piezas.get(pos).setAcumula(Piezas.get(pos).getNumero());
    }

    /* Va del nivel mas profundo al mas superficial */
    for (int evaluaNivel = MaximoNivel; evaluaNivel >= 0; evaluaNivel--)
    {
      /* Recorre toda la lista */
      for (pos=0; pos<totalPiezas; pos++)
      {
        /* Si encuentra una pieza de tipo función la evalúa con el valor de la siguiente pieza */
        if (Piezas.get(pos).getNivel() == evaluaNivel && Piezas.get(pos).getTipo() == ESFUNCION )
        {
          switch (Piezas.get(pos).getFuncion())
          {
            case 1:
            case 2:
              Piezas.get(pos).setAcumula(Math.sin(Piezas.get(pos+1).getAcumula()));
              break;
            case 3:
              Piezas.get(pos).setAcumula(Math.cos(Piezas.get(pos+1).getAcumula()));
              break;
            case 4:
              Piezas.get(pos).setAcumula(Math.tan(Piezas.get(pos+1).getAcumula()));
              break;
            case 5:
              if (Piezas.get(pos+1).getAcumula() > 0)
                Piezas.get(pos).setAcumula(Piezas.get(pos+1).getAcumula());
              else
                Piezas.get(pos).setAcumula(-Piezas.get(pos+1).getAcumula());
              break;
            case 6:
              if (Piezas.get(pos+1).getAcumula() >= -1 && Piezas.get(pos+1).getAcumula() <= 1)
                Piezas.get(pos).setAcumula(Math.asin(Piezas.get(pos+1).getAcumula()));
              else
              {
                ERRORMATEMATICO = true;
                return 0;
              }
              break;
            case 7:
              if (Piezas.get(pos+1).getAcumula() >= -1 && Piezas.get(pos+1).getAcumula() <= 1)
                Piezas.get(pos).setAcumula(Math.acos(Piezas.get(pos+1).getAcumula()));
              else
              {
                ERRORMATEMATICO = true;
                return 0;
              }
              break;
            case 8:
              Piezas.get(pos).setAcumula(Math.atan(Piezas.get(pos+1).getAcumula()));
              break;
            case 9:
              Piezas.get(pos).setAcumula(Math.log(Piezas.get(pos+1).getAcumula()));
              break;
            case 10:
              Piezas.get(pos).setAcumula(Math.ceil(Piezas.get(pos+1).getAcumula()));
              break;
            case 11:
              Piezas.get(pos).setAcumula(Math.exp(Piezas.get(pos+1).getAcumula()));
              break;
            case 12:
              if (Piezas.get(pos+1).getAcumula() >= 0)
                Piezas.get(pos).setAcumula(Math.sqrt(Piezas.get(pos+1).getAcumula()));
              else
              {
                ERRORMATEMATICO = true;
                return 0;
              }
              break;
            case 13:
              Piezas.get(pos).setAcumula(Math.pow(Piezas.get(pos+1).getAcumula(), (double) 1 / 3));
              break;
          }

          /* Marca el nodo siguiente como ya evaluado */
          Piezas.get(pos+1).setEvaluado(true);
        }
      }

      /* Recorre toda la lista */
      for (pos=0; pos<totalPiezas; pos++)
      {
        /* Si encuentra un nodo del tipo operador y es exponente */
        if (Piezas.get(pos).getNivel() == evaluaNivel && Piezas.get(pos).getTipo() == ESOPERADOR && Piezas.get(pos).getOperador() == '^')
        {
          /* Busca un nodo anterior que sea número o variable y no haya sido evaluado */
          for (antes=pos-1; Piezas.get(antes).isEvaluado(); antes--);

          /* Busca un nodo siguiente que sea número o variable y no haya sido evaluado */
          for (sigue=pos+1; Piezas.get(sigue).isEvaluado(); sigue++);

          /* Marca esos nodos actual y siguiente como ya evaluados */
          Piezas.get(pos).setEvaluado(true);
          Piezas.get(sigue).setEvaluado(true);

          /* Hace la operación de Número elevado a Número */
          Piezas.get(antes).setAcumula(Math.pow(Piezas.get(antes).getAcumula(), Piezas.get(sigue).getAcumula()));
        }
      }

      /* Recorre toda la lista */
      for (pos=0; pos<totalPiezas; pos++)
      {
        /* Si encuentra un nodo del tipo operador y es multiplicación o división */
        if (Piezas.get(pos).getNivel() == evaluaNivel && Piezas.get(pos).getTipo() == ESOPERADOR && (Piezas.get(pos).getOperador() == '*' || Piezas.get(pos).getOperador() == '/'))
        {
          /* Busca un nodo anterior que sea número o variable y no haya sido evaluado */
          for (antes=pos-1; Piezas.get(antes).isEvaluado(); antes--);

          /* Busca un nodo siguiente que sea número o variable y no haya sido evaluado */
          for (sigue=pos+1; Piezas.get(sigue).isEvaluado(); sigue++);

          /* Marca esos nodos actual y siguiente como ya evaluados */
          Piezas.get(pos).setEvaluado(true);
          Piezas.get(sigue).setEvaluado(true);

          /* Hace la operación de Número * Número, o Número / Número */
          if (Piezas.get(pos).getOperador() == '*')
            Piezas.get(antes).setAcumula( Piezas.get(antes).getAcumula() *  Piezas.get(sigue).getAcumula() );
          else
          {
            if (Piezas.get(sigue).getAcumula() != 0)
              Piezas.get(antes).setAcumula( Piezas.get(antes).getAcumula() /  Piezas.get(sigue).getAcumula() );
            else
            {
              ERRORMATEMATICO = true;
              return 0;
            }
          }

        }
      }

      /* Recorre toda la lista */
      for (pos=0; pos<totalPiezas; pos++)
      {
        /* Si encuentra un nodo del tipo operador y es suma o resta */
        if (Piezas.get(pos).getNivel() == evaluaNivel && Piezas.get(pos).getTipo() == ESOPERADOR && (Piezas.get(pos).getOperador() == '+' || Piezas.get(pos).getOperador() == '-'))
        {
          /* Busca un nodo anterior que sea número o variable y no haya sido evaluado */
          for (antes=pos-1; Piezas.get(antes).isEvaluado(); antes--);

          /* Busca un nodo siguiente que sea número o variable y no haya sido evaluado */
          for (sigue=pos+1; Piezas.get(sigue).isEvaluado(); sigue++);

          /* Marca esos nodos actual y siguiente como ya evaluados */
          Piezas.get(pos).setEvaluado(true);
          Piezas.get(sigue).setEvaluado(true);

          /* Hace la operación de Número + Número, o Número - Número */
          if (Piezas.get(pos).getOperador() == '+')
            Piezas.get(antes).setAcumula( Piezas.get(antes).getAcumula() +  Piezas.get(sigue).getAcumula() );
          else
            Piezas.get(antes).setAcumula( Piezas.get(antes).getAcumula() -  Piezas.get(sigue).getAcumula() );
        }
      }
    }

    /* Resultado de la expresión */
    return Piezas.get(0).getAcumula();
  }

  /**
   * Guarda en un arreglo unidimensional el valor de las variables
   * @param variable ¿Qué variable de la expresión recibirá el valor? a..z
   * @param valor  Valor de tipo double que tendrá esa variable.
   */
  public void DarValorVariable(char variable, double valor)
  {
     valorVariable[variable - ASCIILETRA] = valor;
  }

  /**
   * Retorna true si hubo un error matemático
   * @return TRUE si hubo un error matemático
   */
  public boolean getErrorMatematico()
  {
      return ERRORMATEMATICO;
  }
}
