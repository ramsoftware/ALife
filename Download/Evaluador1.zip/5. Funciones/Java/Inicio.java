/**
 * Autor: Rafael Alberto Moreno Parra
 * Correo: ramsoftware@gmail.com
 * Página Web: http://darwin.50webs.com
 * Licencia: LGPL
 * Fecha: Enero de 2012
 */
public class Inicio
{
    public static void main(String args[])
    {
        EvaluadorExpresionAlgebraica objEvaluador = new EvaluadorExpresionAlgebraica();
        String expresion;
        double valor;

		expresion = "x+((9.260/8.512-9.364-8.223-x+0.290+tan(tan(x)*x)+8.141*(cos((x/x*9.362*1.139+x-atn(x*5.10/7.900))/sen(5.525)))))";
		objEvaluador.Analizar(expresion);
		objEvaluador.DarValorVariable('x', 13.1729);
		valor = objEvaluador.Evaluar();
		System.out.println(valor);
    }
}
