﻿/**
 * Autor: Rafael Alberto Moreno Parra
 * Correo: ramsoftware@gmail.com
 * Página Web: http://darwin.50webs.com
 * Licencia: LGPL
 * Fecha: Enero de 2012
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace EvaluadorCSharp
{
    class Program
    {
        static void Main(string[] args)
        {
            EvaluadorExpresionAlgebraica objEvaluador = new EvaluadorExpresionAlgebraica();
            string expresion;
            double valor;

            expresion = "3.14159265368+x";
			objEvaluador.Analizar(expresion);
			objEvaluador.DarValorVariable('x', 13.1729);
			valor = objEvaluador.Evaluar();
			Console.WriteLine(valor);
            Console.ReadKey();
        }
    }
}
