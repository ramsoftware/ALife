﻿/**
 * Autor: Rafael Alberto Moreno Parra
 * Correo: ramsoftware@gmail.com
 * Página Web: http://darwin.50webs.com
 * Licencia: LGPL
 * Fecha: Enero de 2012
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace EvaluadorCSharp
{
    public class Pieza
    {
        /* Nivel en la expresión, a mayor valor, es mayor profundidad en la expresión */
        private int nivel;

        /* 1. Almacena un número, 2. Almacena un operador, 3. Almacena una variable, 4. Almacena una función */
        private int tipo;

        /* El número en la expresión algebraica */
        private double numero;

        /* El operador (+, -, *, /, ^) en la expresión algebraica */
        private char operador;

        /* La variable */
        private int variable;

        /* La función */
        private int funcion;

        /* Determina si esta pieza ya ha sido evaluada en el momento de hacer los
           cálculos que determinan el valor de la expresión */
        private bool evaluado;

        /* El resultado parcial de la evaluación de la expresión */
        private double acumula;

        /**
         * Constructor en caso que la pieza contenga un número real
         * @param numero Número de tipo double
         * @param nivel Nivel en que se encuentra en la expresión este número
         */
        public Pieza(double numero, int nivel)
        {
            this.tipo = 1; //Es un número
            this.numero = numero;
            this.nivel = nivel;

            this.evaluado = false;
            this.acumula = numero;
        }

        /**
         * Constructor en caso que el nodo contenga un operador (+, -, *, /, ^)
         * @param operador Que puede ser +, -, *, /, ^
         * @param nivel Nivel en que se encuentra en la expresión este operador
         */
        public Pieza(char operador, int nivel)
        {
            this.tipo = 2; //Es un operador
            this.operador = operador;
            this.nivel = nivel;

            this.evaluado = false;
            this.acumula = 0;
        }

        /**
         * Constructor en caso que el nodo contenga una variable
         * @param variable Puede ir de 0 a 25 que representa de a..z
         * @param nivel Nivel en que se encuentra en la expresión este operador
         */
        public Pieza(int variable, int nivel)
        {
            this.tipo = 3; //Es una variable
            this.variable = variable;
            this.nivel = nivel;

            this.evaluado = false;
            this.acumula = 0;
        }

        /**
         * Constructor en caso que la pieza contenga una función
         * @param funcion Identificación de la función
         * @param nivel Nivel en que se encuentra en la expresión este operador
         * @param bandera Sólo sirve para diferenciarlo del anterior constructor
         */
        public Pieza(int funcion, int nivel, char bandera)
        {
            this.tipo = 4; //Es una función
            this.funcion = funcion;
            this.nivel = nivel;

            this.evaluado = false;
            this.acumula = 0;
        }

        /** Retorna el acumulado que tiene esta pieza
         * @return Acumulado de la pieza
         */
        public double getAcumula()
        {
            return acumula;
        }

        /** Retorna si la pieza ya fue evaluada
         * @return True si la pieza ya fue evaluada
         */
        public bool isEvaluado()
        {
            return evaluado;
        }

        /**
         * Retorna el número de tipo double que tiene la pieza
         * @return El valor del número tipo double
         */
        public double getNumero()
        {
            return numero;
        }

        /**
         * Retorna el operador (+, -, *, /, ^) que tiene la pieza
         * @return El operador en char
         */
        public char getOperador()
        {
            return operador;
        }

        /**
         * Retorna la variable que tiene la pieza
         * @return La variable
         */
        public int getVariable()
        {
            return variable;
        }

        /**
         * Retorna que tipo de pieza es: número, operador, variable o función
         * @return Tipo de pieza
         */
        public int getTipo()
        {
            return tipo;
        }

        /**
         * Retorna en que nivel se encuentra la pieza con respecto a la expresión
         * @return Nivel
         */
        public int getNivel()
        {
            return nivel;
        }

        /**
         * Retorna el código de la función (abs, sen, cos, tan) que tiene la pieza
         * @return Código de la función
         */
        public int getFuncion()
        {
            return funcion;
        }

        /**
         * Da valor al acumulado por pieza
         * @param acumulado  Acumulado que nace de cada operación simple es dado a la pieza aquí.
         */
        public void setAcumula(double acumulado)
        {
            this.acumula = acumulado;
        }

         /**
         * Marca la pieza como ya evaluada
         * @param evaluado true si la pieza ya ha sido evaluada, false si no
         */
        public void setEvaluado(bool evaluado)
        {
            this.evaluado = evaluado;
        }
    }
}
