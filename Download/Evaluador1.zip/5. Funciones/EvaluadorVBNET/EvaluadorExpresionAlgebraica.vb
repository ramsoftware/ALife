﻿'Autor: Rafael Alberto Moreno Parra
'Correo: ramsoftware@gmail.com
'Página Web:  http://darwin.50webs.com
'Licencia: LGPL
'Fecha:  Enero de 2012

Public Class EvaluadorExpresionAlgebraica
  'Constantes para determinar que tipo es cada pieza en que se divide la expresión algebraica
  Private Shared ESNUMERO As Integer = 1
  Private Shared ESOPERADOR As Integer = 2
  Private Shared ESVARIABLE As Integer = 3
  Private Shared ESFUNCION As Integer = 4

  'Esta constante sirve para que se reste al caracter y se obtenga el número
  'Ejemplo:  '7' - ASCIINUMERO =  7
  Private Shared ASCIINUMERO As Integer = 48

  'Esta constante sirve para que se reste al caracter y se obtenga el número
  'usado en el arreglo unidimensional que alberga los valores de las variables
  'Ejemplo:  'b' - ASCIILETRA =  1
  Private Shared ASCIILETRA As Integer = 97

  'Las funciones que soporta este evaluador
  Private Shared TAMANOFUNCION As Integer = 39
  Private Shared listaFunciones As [String] = "sinsencostanabsasnacsatnlogceiexpsqrrcb"

  'Lista simplemente enlazada que tiene los componentes (número, operador o función)
  'de la expresión algebraica ya dividida.
  Private Piezas As New List(Of Pieza)()

  'Arreglo unidimensional con las 26 variables diferentes
  Private valorVariable As Double() = New Double(25) {}

  'Almacena hasta que nivel se llega en paréntesis internos
  Private MaximoNivel As Integer

  'Variable que se pone a true cuando hay un error matemático
  Private ERRORMATEMATICO As Boolean

  'Este método se encarga de analizar la expresión y convertirla en una 
  'estructura que permita evaluar la expresión.
  '     *
  'Convierte una expresión algebraica en una sucesión de nodos.
  '|2| |+| |a| |/| |5| |*| |cos| |y|
  '|2| |+| |a| |/| |5| |*| |cos| |y|
  '
  '@param expr La expresión algebraica sin espacios y en minúsculas
  Public Sub Analizar(ByVal expr As [String])
    ' Inicializa la lista de piezas  
    Piezas.Clear()

    ' Inicializa el nivel 
    Dim nivel As Integer = 0
    MaximoNivel = 0

    ' Tamaño de la expresión simple 
    Dim longitud As Integer = expr.Length

    ' Va extrayendo letra a letra de la expresión simple 
    Dim letra As Char

    ' Conversión de string a double 
    Dim entero As Double = 0, fraccion As Double = 0, divide As Double = 1
    Dim puntoentero As Boolean = False

    ' Si llevaba acumulando un valor numérico esta variable se vuelve true 
    Dim acumulabaNumero As Boolean = False

    For cont As Integer = 0 To longitud - 1
      ' Trae la letra 
      letra = expr(cont)

      ' Si hay un paréntesis que abre, el nivel aumenta 
      If letra = "(" Then
        nivel += 1
        If nivel > MaximoNivel Then
          MaximoNivel = nivel
        End If
        ' Si es paréntesis que cierra, el nivel disminuye 
      ElseIf letra = ")" Then
        nivel -= 1
        ' Si es una variable o una función 
      ElseIf letra >= "a" AndAlso letra <= "z" Then
        ' Detecta si es una función porque tiene dos letras seguidas 
        If cont < longitud - 1 Then
          ' Chequea si el siguiente carácter es una letra, dado el caso es una función 
          Dim letra2 As Char = expr(cont + 1)
          If letra2 >= "a" AndAlso letra2 <= "z" Then
            Dim letra3 As Char = expr(cont + 2)

            ' Identifica las funciones 
            Dim funcionDetectada As Integer = 1
            For funcion As Integer = 0 To TAMANOFUNCION Step 3
              If letra = listaFunciones(funcion) AndAlso letra2 = listaFunciones(funcion + 1) AndAlso letra3 = listaFunciones(funcion + 2) Then
                Exit For
              End If
              funcionDetectada += 1
            Next

            ' Adiciona a la lista 
            Dim objeto As New Pieza(funcionDetectada, nivel, "f")
            Piezas.Add(objeto)

            nivel += 1
            If nivel > MaximoNivel Then
              MaximoNivel = nivel
            End If

            ' Mueve tres caracteres  sin(  [s][i][n][(] 
            cont += 3
          Else
            ' Es una variable, no una función 
            Dim objeto As New Pieza(Asc(letra) - ASCIILETRA, nivel)
            Piezas.Add(objeto)
          End If
        Else
          ' Es una variable, no una función 
          Dim objeto As New Pieza(Asc(letra) - ASCIILETRA, nivel)
          Piezas.Add(objeto)
        End If
        ' Si es un número 

      ElseIf (letra >= "0" AndAlso letra <= "9") OrElse letra = "." Then
        ' Ir armando el número de tipo double 
        If letra = "." Then
          puntoentero = True
        ElseIf Not puntoentero Then
          ' puntoentero == false 
          entero = entero * 10 + Asc(letra) - ASCIINUMERO
        Else
          fraccion = fraccion * 10 + Asc(letra) - ASCIINUMERO
          divide *= 10
        End If
        acumulabaNumero = True
      Else
        ' Si es un operador entonces crea el nodo del operador y el
        ' nodo del número si venía acumulando un número 

        If acumulabaNumero Then
          ' El nodo del número 
          Dim objeto As New Pieza(entero + CDbl(fraccion) / divide, nivel)

          ' Agrega a la lista 
          Piezas.Add(objeto)
        End If

        ' El nodo operador 
        Dim objeto2 As New Pieza(letra, nivel)

        ' Agrega a la lista 
        Piezas.Add(objeto2)

        ' Inicializa de nuevo las variables de conversión de string a número 
        entero = 0
        fraccion = 0
        divide = 1
        puntoentero = False
        acumulabaNumero = False
      End If
    Next

    ' Cierra la expresión simple preguntando si el último operando es un número 
    If acumulabaNumero Then
      Dim objeto As New Pieza(entero + CDbl(fraccion) / divide, nivel)
      Piezas.Add(objeto)
    End If
  End Sub

  'Ya construida la lista del tipo:
  '[nodo número]  [nodo operador]  [nodo número]  [nodo operador] .....
  'es ir del operador con más precedencia al de menos precedencia.
  '
  'Este método se llama después de haber sido analizada la expresión.
  '
  'En el caso que sólo cambia el valor de una variable, no es necesario
  'analizar de nuevo la expresión, luego es muy rápido evaluar múltiples veces
  'la misma expresión.
  '
  '@return El valor de la expresión evaluada (double)
  Public Function Evaluar() As Double
    Dim pos As Integer = 0, antes As Integer = 0, sigue As Integer = 0
    ERRORMATEMATICO = False

    ' Total de nodos en la lista creada 
    Dim totalPiezas As Integer = Piezas.Count

    For pos = 0 To totalPiezas - 1
      ' Activa todas las piezas para que sean evaluadas 
      Piezas(pos).setEvaluado(False)

      ' Recorre toda la lista poniendo los valores de las variables en el acumulado de cada pieza.
      ' ¿Cómo? Extrae el valor del arreglo unidimensional que alberga los valores de las variables. 
      If Piezas(pos).getTipo() = ESVARIABLE Then
        Piezas(pos).setAcumula(valorVariable(Piezas(pos).getVariable()))
      ElseIf Piezas(pos).getTipo() = ESNUMERO Then
        Piezas(pos).setAcumula(Piezas(pos).getNumero())
      End If
    Next

    ' Va del nivel mas profundo al mas superficial 
    For evaluaNivel As Integer = MaximoNivel To 0 Step -1
      ' Recorre toda la lista 
      For pos = 0 To totalPiezas - 1
        ' Si encuentra una pieza de tipo función la evalúa con el valor de la siguiente pieza 
        If Piezas(pos).getNivel() = evaluaNivel AndAlso Piezas(pos).getTipo() = ESFUNCION Then
          Select Case Piezas(pos).getFuncion()
            Case 1, 2
              Piezas(pos).setAcumula(Math.Sin(Piezas(pos + 1).getAcumula()))
              Exit Select
            Case 3
              Piezas(pos).setAcumula(Math.Cos(Piezas(pos + 1).getAcumula()))
              Exit Select
            Case 4
              Piezas(pos).setAcumula(Math.Tan(Piezas(pos + 1).getAcumula()))
              Exit Select
            Case 5
              If Piezas(pos + 1).getAcumula() > 0 Then
                Piezas(pos).setAcumula(Piezas(pos + 1).getAcumula())
              Else
                Piezas(pos).setAcumula(-Piezas(pos + 1).getAcumula())
              End If
              Exit Select
            Case 6
              If Piezas(pos + 1).getAcumula() >= -1 AndAlso Piezas(pos + 1).getAcumula() <= 1 Then
                Piezas(pos).setAcumula(Math.Asin(Piezas(pos + 1).getAcumula()))
              Else
                ERRORMATEMATICO = True
                Return 0
              End If
              Exit Select
            Case 7
              If Piezas(pos + 1).getAcumula() >= -1 AndAlso Piezas(pos + 1).getAcumula() <= 1 Then
                Piezas(pos).setAcumula(Math.Acos(Piezas(pos + 1).getAcumula()))
              Else
                ERRORMATEMATICO = True
                Return 0
              End If
              Exit Select
            Case 8
              Piezas(pos).setAcumula(Math.Atan(Piezas(pos + 1).getAcumula()))
              Exit Select
            Case 9
              Piezas(pos).setAcumula(Math.Log(Piezas(pos + 1).getAcumula()))
              Exit Select
            Case 10
              Piezas(pos).setAcumula(Math.Ceiling(Piezas(pos + 1).getAcumula()))
              Exit Select
            Case 11
              Piezas(pos).setAcumula(Math.Exp(Piezas(pos + 1).getAcumula()))
              Exit Select
            Case 12
              If Piezas(pos + 1).getAcumula() >= 0 Then
                Piezas(pos).setAcumula(Math.Sqrt(Piezas(pos + 1).getAcumula()))
              Else
                ERRORMATEMATICO = True
                Return 0
              End If
              Exit Select
            Case 13
              Piezas(pos).setAcumula(Math.Pow(Piezas(pos + 1).getAcumula(), CDbl(1) / 3))
              Exit Select
          End Select

          ' Marca el nodo siguiente como ya evaluado 
          Piezas(pos + 1).setEvaluado(True)
        End If
      Next

      ' Recorre toda la lista 
      For pos = 0 To totalPiezas - 1
        ' Si encuentra un nodo del tipo operador y es exponente 
        If Piezas(pos).getNivel() = evaluaNivel AndAlso Piezas(pos).getTipo() = ESOPERADOR AndAlso Piezas(pos).getOperador() = "^" Then
          ' Busca un nodo anterior que sea número o variable y no haya sido evaluado 
          antes = pos - 1
          While Piezas(antes).isEvaluado()
            antes -= 1
          End While

          ' Busca un nodo siguiente que sea número o variable y no haya sido evaluado 
          sigue = pos + 1
          While Piezas(sigue).isEvaluado()
            sigue += 1
          End While

          ' Marca esos nodos actual y siguiente como ya evaluados 
          Piezas(pos).setEvaluado(True)
          Piezas(sigue).setEvaluado(True)

          ' Hace la operación de Número elevado a Número 
          Piezas(antes).setAcumula(Math.Pow(Piezas(antes).getAcumula(), Piezas(sigue).getAcumula()))
        End If
      Next

      ' Recorre toda la lista 
      For pos = 0 To totalPiezas - 1
        ' Si encuentra un nodo del tipo operador y es multiplicación o división 
        If Piezas(pos).getNivel() = evaluaNivel AndAlso Piezas(pos).getTipo() = ESOPERADOR AndAlso (Piezas(pos).getOperador() = "*" OrElse Piezas(pos).getOperador() = "/") Then
          ' Busca un nodo anterior que sea número o variable y no haya sido evaluado 
          antes = pos - 1
          While Piezas(antes).isEvaluado()
            antes -= 1
          End While

          ' Busca un nodo siguiente que sea número o variable y no haya sido evaluado 
          sigue = pos + 1
          While Piezas(sigue).isEvaluado()
            sigue += 1
          End While

          ' Marca esos nodos actual y siguiente como ya evaluados 
          Piezas(pos).setEvaluado(True)
          Piezas(sigue).setEvaluado(True)

          ' Hace la operación de Número * Número, o Número / Número 
          If Piezas(pos).getOperador() = "*" Then
            Piezas(antes).setAcumula(Piezas(antes).getAcumula() * Piezas(sigue).getAcumula())
          Else
            If Piezas(sigue).getAcumula() <> 0 Then
              Piezas(antes).setAcumula(Piezas(antes).getAcumula() / Piezas(sigue).getAcumula())
            Else
              ERRORMATEMATICO = True
              Return 0
            End If

          End If
        End If
      Next

      ' Recorre toda la lista 
      For pos = 0 To totalPiezas - 1
        ' Si encuentra un nodo del tipo operador y es suma o resta 
        If Piezas(pos).getNivel() = evaluaNivel AndAlso Piezas(pos).getTipo() = ESOPERADOR AndAlso (Piezas(pos).getOperador() = "+" OrElse Piezas(pos).getOperador() = "-") Then
          ' Busca un nodo anterior que sea número o variable y no haya sido evaluado 
          antes = pos - 1
          While Piezas(antes).isEvaluado()
            antes -= 1
          End While

          ' Busca un nodo siguiente que sea número o variable y no haya sido evaluado 
          sigue = pos + 1
          While Piezas(sigue).isEvaluado()
            sigue += 1
          End While

          ' Marca esos nodos actual y siguiente como ya evaluados 
          Piezas(pos).setEvaluado(True)
          Piezas(sigue).setEvaluado(True)

          ' Hace la operación de Número + Número, o Número - Número 
          If Piezas(pos).getOperador() = "+" Then
            Piezas(antes).setAcumula(Piezas(antes).getAcumula() + Piezas(sigue).getAcumula())
          Else
            Piezas(antes).setAcumula(Piezas(antes).getAcumula() - Piezas(sigue).getAcumula())
          End If
        End If
      Next
    Next

    ' Resultado de la evaluación 
    Return Piezas(0).getAcumula()
  End Function

  'Guarda en un arreglo unidimensional el valor de las variables
  '@param variable ¿Qué variable de la expresión recibirá el valor? a..z
  '@param valor  Valor de tipo double que tendrá esa variable.
  Public Sub DarValorVariable(ByVal variable As Char, ByVal valor As Double)
    valorVariable(Asc(variable) - ASCIILETRA) = valor
  End Sub

  'Retorna true si hubo un error matemático
  '@return TRUE si hubo un error matemático
  Public Function getErrorMatematico() As Boolean
    Return ERRORMATEMATICO
  End Function

End Class
