﻿Module Module1

    Sub Main()
        Dim objEvaluador As New EvaluadorExpresionAlgebraica
        Dim valor As Double
        Dim expresion As String

        expresion = "1+2"
        objEvaluador.Analizar(expresion)
        objEvaluador.DarValorVariable("x", 13.1729)
        valor = objEvaluador.Evaluar()
        Console.WriteLine(valor)
        Console.ReadKey()
    End Sub

End Module
