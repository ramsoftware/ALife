﻿'Autor: Rafael Alberto Moreno Parra
'Correo: ramsoftware@gmail.com
'Página Web:  http://darwin.50webs.com
'Licencia: LGPL
'Fecha:  Enero de 2012

Public Class Pieza
    'Nivel en la expresión, a mayor valor, es mayor profundidad en la expresión 
    Private nivel As Integer

    '1. Almacena un número, 2. Almacena un operador, 3. Almacena una variable, 4. Almacena una función 
    Private tipo As Integer

    'El número en la expresión algebraica 
    Private numero As Double

    'El operador (+, -, *, /, ^) en la expresión algebraica 
    Private operador As Char

    'La variable 
    Private variable As Integer

    'La función 
    Private funcion As Integer

    'Determina si esta pieza ya ha sido evaluada en el momento de hacer los
    'cálculos que determinan el valor de la expresión 
    Private evaluado As Boolean

    'El resultado parcial de la evaluación de la expresión 
        Private acumula As Double

    'Constructor en caso que la pieza contenga un número real
    '@param numero Número de tipo dim  as double
    '@param nivel Nivel en que se encuentra en la expresión este número
    Public Sub New(ByVal numero As Double, ByVal nivel As Integer)
        Me.tipo = 1 'Es un número
        Me.numero = numero
        Me.nivel = nivel

        Me.evaluado = False
        Me.acumula = numero
    End Sub

    'Constructor en caso que el nodo contenga un operador (+, -, *, /, ^)
    '@param operador Que puede ser +, -, *, /, ^
    '@param nivel Nivel en que se encuentra en la expresión este operador
    Public Sub New(ByVal operador As Char, ByVal nivel As Integer)

        Me.tipo = 2 'Es un operador
        Me.operador = operador
        Me.nivel = nivel

        Me.evaluado = False
        Me.acumula = 0
    End Sub


    'Constructor en caso que el nodo contenga una variable
    '@param variable Puede ir de 0 a 25 que representa de a..z
    '@param nivel Nivel en que se encuentra en la expresión este operador
    Public Sub New(ByVal variable As Integer, ByVal nivel As Integer)
        Me.tipo = 3 'Es una variable
        Me.variable = variable
        Me.nivel = nivel

        Me.evaluado = False
        Me.acumula = 0
    End Sub


    'Constructor en caso que la pieza contenga una función
    '@param funcion Identificación de la función
    '@param nivel Nivel en que se encuentra en la expresión este operador
    '@param bandera Sólo sirve para diferenciarlo del anterior constructor
    Public Sub New(ByVal funcion As Integer, ByVal nivel As Integer, ByVal bandera As String)
        Me.tipo = 4 'Es una función
        Me.funcion = funcion
        Me.nivel = nivel

        Me.evaluado = False
        Me.acumula = 0
    End Sub

    'Retorna el acumulado que tiene esta pieza
    '@return Acumulado de la pieza
    Public Function getAcumula() As Double
        Return acumula
    End Function

    'Retorna si la pieza ya fue evaluada
    '@return True si la pieza ya fue evaluada
    Public Function isEvaluado() As Boolean
        Return evaluado
    End Function


    'Retorna el número de tipo dim  as double que tiene la pieza
    '@return El valor del número tipo dim  as double
    Public Function getNumero() As Double
        Return numero
    End Function


    'Retorna el operador (+, -, *, /, ^) que tiene la pieza
    '@return El operador en dim  as char
    Public Function getOperador() As Char
        Return operador
    End Function


    'Retorna la variable que tiene la pieza
    '@return La variable
    Public Function getVariable() As Integer
        Return variable
    End Function


    'Retorna que tipo de pieza es: número, operador, variable o función
    '@return Tipo de pieza
    Public Function getTipo() As Integer
        Return tipo
    End Function


    'Retorna en qué nivel se encuentra la pieza con respecto a la expresión
    '@return Nivel
    Public Function getNivel() As Integer
        Return nivel
    End Function


    'Retorna el código de la función (abs, sen, cos, tan) que tiene la pieza
    '@return Código de la función
    Public Function getFuncion() As Integer
        Return funcion
    End Function


    'Da valor al acumulado por pieza
    '@param acumulado  Acumulado que nace de cada operación simple es dado a la pieza aquí.
    Public Sub setAcumula(ByVal acumulado As Double)
        Me.acumula = acumulado
    End Sub

    'Marca la pieza como ya evaluada
    '@param evaluado true si la pieza ya ha sido evaluada, false si no
    Public Sub setEvaluado(ByVal evaluado As Boolean)
        Me.evaluado = evaluado
    End Sub

End Class
