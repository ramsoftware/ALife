#include <stdio.h>
#include <time.h>
#include "Aleatorio.h"

#define TAMANOAMBIENTE 20 //Cuantos organismos tendr� el ambiente al tiempo
#define MAXINSTRUCCIONES 30 //El maximo son 256 instrucciones
#define NUMVARIABLES 5 //Total variables que tendr� cada algoritmo gen�tico
#define TIPOINSTRUCCION 10 //Los diferentes tipos de instruccion que tiene el algoritmo gen�tico: + - * / > >= < <= = !=
#define TOTALSIMULACION 80000 //Cuantos organismos va a generar
#define MAXIMOINTERPRETA 400 //Cuantas instrucciones del algoritmo genetico ejecutar�.
#define ENTRADAS 25  //Numero de entradas/salidas que tendr� 
#define MAXTOLERANCIA 5000 //Si la adaptac�n del organismo comparado con este valor es menor entonces es evaluado para selecci�n

//=============== El ambiente ==========================
unsigned int iAmbiente[TAMANOAMBIENTE][MAXINSTRUCCIONES+2];

//========= Marca que parte del ambiente tiene organismo =======
bool bOrganismo[TAMANOAMBIENTE];

//========= Valores que almacena cada variable del organismo ====
int iVarOrganismo[TAMANOAMBIENTE][NUMVARIABLES];
int iAdaptacion[TAMANOAMBIENTE];

void vInterpretaOrganismo(unsigned int, int);
void main(void);

void main()
{
	//Inicia el generador de numeros pseudo-aleatorios
	Aleatorio objAzar;

	time_t ltime1;
	time(&ltime1);
	objAzar.sgenrand(ltime1);

	//Aqui se almacena y se trabaja con el n�mero pseudo-aleatorio
	unsigned int iCont, iPosAmbiente, iMuta;
	int iDiferencia, iAdapta;

	//Inicializa las entradas y salidas
	int iEntrada[ENTRADAS];
	int iSalida[ENTRADAS];


	for (iCont=0; iCont<ENTRADAS; iCont++)
		iEntrada[iCont]=iCont;

	iSalida[0]=2;
	iSalida[1]=3;
	iSalida[2]=5;
	iSalida[3]=7;
	iSalida[4]=11;
	iSalida[5]=13;
	iSalida[6]=17;
	iSalida[7]=19;
	iSalida[8]=23;
	iSalida[9]=29;
	iSalida[10]=31;
	iSalida[11]=37;
	iSalida[12]=41;
	iSalida[13]=43;
	iSalida[14]=47;
	iSalida[15]=53;
	iSalida[16]=59;
	iSalida[17]=61;
	iSalida[18]=67;
	iSalida[19]=71;
	iSalida[20]=73;
	iSalida[21]=79;
	iSalida[22]=83;
	iSalida[23]=89;
	iSalida[24]=97;

	//Inicializa el ambiente
	unsigned int iFila, iColumna;
	for (iFila=0; iFila<TAMANOAMBIENTE; iFila++)
	{
		iAdaptacion[iFila]=0;
		for (iColumna=0; iColumna<MAXINSTRUCCIONES+2; iColumna++)
			iAmbiente[iFila][iColumna]=0;
	}

	//Ciclo de generar los organismos
	for(unsigned int iSimula=0; iSimula<TOTALSIMULACION; iSimula++)
	{
		//Busca una posici�n del ambiente al azar
		iPosAmbiente = objAzar.genrand()%(TAMANOAMBIENTE-1)+1;
		
		//Si esa posici�n no ten�a ning�n organismo entonces genera al azar la criatura
		if (bOrganismo[iPosAmbiente]==false)
		{
			//Genera al azar las instrucciones
			for (iCont=0; iCont<MAXINSTRUCCIONES; iCont++)
				iAmbiente[iPosAmbiente][iCont] = (unsigned int) objAzar.genrand()%150994945;

			//Enfrenta el organismo con la entrada y la salida
			iAdapta=0;
			for (iCont=0; iCont<ENTRADAS; iCont++)
			{
				vInterpretaOrganismo(iPosAmbiente, iEntrada[iCont]);
				iDiferencia = iSalida[iCont]-iVarOrganismo[iPosAmbiente][1];
				if (iDiferencia<0) iDiferencia*=-1;
				iAdapta+=iDiferencia;
			}

			if (iAdapta <= MAXTOLERANCIA)
			{
				bOrganismo[iPosAmbiente]=true; //Ahora si hay un organismo
				iAdaptacion[iPosAmbiente]=iAdapta;
				//printf("Nuevo organismo en %d se adapta en %d\n", iPosAmbiente, iAdapta);
			}

		}
		else //Ya hab�a un organismo all�
		{
			//Reproduce el organismo que estaba all� y env�a el hijo a la posici�n cero
			for (iCont=0; iCont<MAXINSTRUCCIONES; iCont++)
				iAmbiente[0][iCont] = iAmbiente[iPosAmbiente][iCont];

			//Modifica alguna parte de este hijo
			iMuta = (unsigned int) objAzar.genrand()%MAXINSTRUCCIONES;
			iAmbiente[0][iMuta] = (unsigned int) objAzar.genrand()%150994945;

			//Enfrenta el organismo hijo con la entrada y la salida
			iAdapta=0;
			for (iCont=0; iCont<ENTRADAS; iCont++)
			{
				vInterpretaOrganismo(0, iEntrada[iCont]);
				iDiferencia = iSalida[iCont]-iVarOrganismo[0][1];
				if (iDiferencia<0) iDiferencia*=-1;
				iAdapta+=iDiferencia;
			}

			//Busca algun lugar donde mudarse
			iCont = objAzar.genrand()%(TAMANOAMBIENTE-1)+1;

			//Si el nuevo organismo es mejor que el viejo entonces lo reemplaza
			if (iAdapta < iAdaptacion[iCont] || bOrganismo[iCont]==false)
			{
			    //printf(" (%d) se muda a %d con adaptacion %d\n", iAdapta, iCont, iAdaptacion[iCont]);
				bOrganismo[iCont]=true;
				for (int iCont2=0; iCont2<MAXINSTRUCCIONES; iCont2++)
					iAmbiente[iCont][iCont2]=iAmbiente[0][iCont2];
				iAdaptacion[iCont]=iAdapta;
			}
		}
	}

	//Muestra los organismos que sobrevivieron a la selecci�n
	for(iCont=1; iCont<TAMANOAMBIENTE;iCont++)
		if (bOrganismo[iCont]==true)
		{
			printf("Organismo=%d se adapta=%d\n", iCont, iAdaptacion[iCont]);
			for (int iCont2=0; iCont2<MAXINSTRUCCIONES; iCont2++)
			{
				printf("%d: ", iCont2);
				unsigned int iLinea = iAmbiente[iCont][iCont2];
				unsigned int iPos0 = ((iLinea >> 24) & 0xFF) % TIPOINSTRUCCION;
				unsigned int iPos1 = ((iLinea >> 16) & 0xFF) % NUMVARIABLES;
				unsigned int iPos2 = ((iLinea >> 8) & 0xFF) % NUMVARIABLES;
				unsigned int iPos3 = 0;

				if (iPos0<=3)
					iPos3 = (iLinea & 0xFF) % NUMVARIABLES;
				else
					iPos3 = (iLinea & 0xFF) % MAXINSTRUCCIONES;

				//Interpreta la l�nea de c�digo
				switch(iPos0)
				{
					case 0: printf("[%d] = [%d] + [%d]\n", iPos1, iPos2, iPos3); break;
					case 1: printf("[%d] = [%d] - [%d]\n", iPos1, iPos2, iPos3); break;
					case 2: printf("[%d] = [%d] * [%d]\n", iPos1, iPos2, iPos3); break;
					case 3: printf("[%d] = [%d] / [%d]\n", iPos1, iPos2, iPos3); break;
					case 4: printf("if [%d] > [%d] Goto [%d]\n", iPos1, iPos2, iPos3); break;
					case 5: printf("if [%d] >= [%d] Goto [%d]\n", iPos1, iPos2, iPos3); break;
					case 6: printf("if [%d] < [%d] Goto [%d]\n", iPos1, iPos2, iPos3); break;
					case 7: printf("if [%d] <= [%d] Goto [%d]\n", iPos1, iPos2, iPos3); break;
					case 8: printf("if [%d] == [%d] Goto [%d]\n", iPos1, iPos2, iPos3); break;
					case 9: printf("if [%d] != [%d] Goto [%d]\n", iPos1, iPos2, iPos3); break;
				}
			}
		}
}

void vInterpretaOrganismo(unsigned int iOrganismo, int iEntra)
{
	unsigned int iPos0, iPos1, iPos2, iPos3, iLinea, iEjecuta=0;
	unsigned int iMaximoInterpreta=0;

	//Inicializa los valores de variables
	for (unsigned int iCont=1; iCont<NUMVARIABLES; iCont++) iVarOrganismo[iOrganismo][iCont]=0;
	iVarOrganismo[iOrganismo][0]=iEntra;

	while(true)
	{
		iLinea = iAmbiente[iOrganismo][iEjecuta++];
		if (iLinea==0 || iMaximoInterpreta++ > MAXIMOINTERPRETA) break;
				
		iPos0 = ((iLinea >> 24) & 0xFF) % TIPOINSTRUCCION;
		iPos1 = ((iLinea >> 16) & 0xFF) % NUMVARIABLES;
		iPos2 = ((iLinea >> 8) & 0xFF) % NUMVARIABLES;

		//Si NO es una instrucci�n de salto
		if (iPos0<=3)
			iPos3 = (iLinea & 0xFF) % NUMVARIABLES;
		else
			iPos3 = (iLinea & 0xFF) % MAXINSTRUCCIONES;

		//Interpreta la l�nea de c�digo
		switch(iPos0)
		{
			case 0: //Suma
					iVarOrganismo[iOrganismo][iPos1] = iVarOrganismo[iOrganismo][iPos2] + iVarOrganismo[iOrganismo][iPos3];
					break;
			case 1: //Resta
					iVarOrganismo[iOrganismo][iPos1] = iVarOrganismo[iOrganismo][iPos2] - iVarOrganismo[iOrganismo][iPos3];
					break;
			case 2: //Multiplica
					iVarOrganismo[iOrganismo][iPos1] = iVarOrganismo[iOrganismo][iPos2] * iVarOrganismo[iOrganismo][iPos3];
					break;
			case 3: //Divide
					if (iVarOrganismo[iOrganismo][iPos3]!=0)
						iVarOrganismo[iOrganismo][iPos1] = iVarOrganismo[iOrganismo][iPos2] / iVarOrganismo[iOrganismo][iPos3];
					break;
			case 4: //Si [iPos1]>[iPos2] Goto iPos3
					if (iVarOrganismo[iOrganismo][iPos1]>iVarOrganismo[iOrganismo][iPos2]) iEjecuta = iPos3;
					break;
			case 5: //Si [iPos1]>=[iPos2] Goto iPos3
					if (iVarOrganismo[iOrganismo][iPos1]>=iVarOrganismo[iOrganismo][iPos2]) iEjecuta = iPos3;
					break;
			case 6: //Si [iPos1]<[iPos2] Goto iPos3
					if (iVarOrganismo[iOrganismo][iPos1]<iVarOrganismo[iOrganismo][iPos2]) iEjecuta = iPos3;
					break;
			case 7: //Si [iPos1]<=[iPos2] Goto iPos3
					if (iVarOrganismo[iOrganismo][iPos1]<=iVarOrganismo[iOrganismo][iPos2]) iEjecuta = iPos3;
					break;
			case 8: //Si [iPos1]==[iPos2] Goto iPos3
					if (iVarOrganismo[iOrganismo][iPos1]==iVarOrganismo[iOrganismo][iPos2]) iEjecuta = iPos3;
					break;
			case 9: //Si [iPos1]!=[iPos2] Goto iPos3
					if (iVarOrganismo[iOrganismo][iPos1]!=iVarOrganismo[iOrganismo][iPos2]) iEjecuta = iPos3;
					break;
		}

		//Limita el valor m�ximo que tendr� las variables y evitar el overflow de enteros
		iVarOrganismo[iOrganismo][iPos1] %= 40000;
		iVarOrganismo[iOrganismo][iPos2] %= 40000;
		iVarOrganismo[iOrganismo][iPos3] %= 40000;
	}
}



/*		unsigned int number = 1705498053;
		unsigned int iPrueba = 0;
		
		//Desensambla en bytes
		int iPos0 = ((number >> 24) & 0xFF);
		int iPos1 = ((number >> 16) & 0xFF);
		int iPos2 = ((number >> 8) & 0xFF);
		int iPos3 = (number & 0xFF);
		
		printf("%d\n",iPos0);
		printf("%d\n",iPos1);
		printf("%d\n",iPos2);
		printf("%d\n",iPos3);

		//Ensambla los bytes
		iPrueba = (iPos0 << 24) + (iPos1 << 16) + (iPos2 << 8) + iPos3;
		printf("%d\n", iPrueba); */