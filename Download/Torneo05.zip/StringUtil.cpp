/*
Autor:		Rafael Alberto Moreno Parra
URL:		http://www.geocities.com/krousky
Clase:		StringUtil
Lenguaje:	C++
Prop�sito:
Algunas utilidades de cadena
M�todos:
*/

#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include "StringUtil.h"

// Toma las primeras cNumLetras de la cadena sCadena2 y las deposita en sCadena1
void StringUtil::vLeft(char *sCadena1, char *sCadena2, unsigned int iNumLetras)
{
	unsigned int iCont;
	for(iCont=0; iCont<=iNumLetras-1 && *(sCadena2+iCont); iCont++) *(sCadena1+iCont)=*(sCadena2+iCont);
	*(sCadena1+iCont)='\0';
};

// Extrae una subcadena de sCadena2 y la deposita en sCadena1
void StringUtil::vMid( char *sCadena1, char *sCadena2, unsigned int iDesde, unsigned int iHasta)
{	
	unsigned int iCont1, iCont2;
	for(iCont2=0, iCont1=iDesde-1; iCont1<=iHasta-1 && *(sCadena2+iCont1); iCont2++, iCont1++) *(sCadena1+iCont2)=*(sCadena2+iCont1);
	*(sCadena1+iCont2)='\0';
};

//Quita los espacios y datos no �tiles de la inicializaci�n
int StringUtil::vQuitaEspacios(char *sCadena)
{
	char sTemp[500];
	unsigned int iCont1, iCont2=0;
	for(iCont1=strlen(sCadena)-1; sCadena[iCont1]!=';'; iCont1--)  sCadena[iCont1]='\0';

	for(iCont1=0; iCont1<=strlen(sCadena); iCont1++)
		if(sCadena[iCont1]!=' ')
			sTemp[iCont2++]=sCadena[iCont1];

	sTemp[iCont2]='\0';
	strcpy(sCadena, sTemp);
	return 1;
};