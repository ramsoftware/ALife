/*
Autor:		Rafael Alberto Moreno Parra
URL:		http://www.geocities.com/krousky
Clase:		Inicializa.
Lenguaje:	C++

Prop�sito:
Inicializa las variables para la simulaci�n
M�todos:
*/

class Inicializa {
public:

	struct stDatosSimul
	{
		//Estos datos se leen de un archivo de inicializaci�n
		unsigned int iNumTanques; // N�mero de tanques que empiezan a jugar
		unsigned int iBloqueInstr; // N�mero de bloques de instruccion generados los cuales ser�n asociados a eventos del tanque
		unsigned int iTableroX; // Tamano en X del tablero
		unsigned int iTableroY; // Tamano en Y del tablero
		unsigned int iConstVida; // Con cuanta energ�a (vida) arranca cada tanque
		unsigned int iMaxCiclos; // M�ximo n�mero de instrucciones interpretadas
		signed int iLimReproduce; // Cuanta energ�a m�nima debe tener el tanque para reproducirse
		unsigned int iTorneos; //Cuantos torneos se realizan
		bool bMutacion; //True muta hijo, false es un clon
	};
	
	struct stDatosSimul stDatVA; //Datos Vida Artificial
	void vPantallaIni(void);
	int vLeeArchivoIni(void);
	void vInforme(void);
};