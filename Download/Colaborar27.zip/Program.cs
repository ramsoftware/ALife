﻿/* Autor: Rafael Alberto Moreno Parra
 * Investigación sobre Vida Artificial
 * http://darwin.50webs.com 
 * 
 * Tomar una entradas y salidas como 
 * X            Y
 * 0.8157       0.9172
 * 
 * En una sucesión de enteros
 * X                    Y
 * 8,1,5,7              9,1,7,2
 * 
 * Luego volverlos entre 0 y 1
 * X                        Y
 * 0.8, 0.1, 0.5, 0.7       0.9, 0.1, 0.7, 0.2
 * 
 * Y de esa manera hacer uso de un perceptrón multicapa para tratar las 4 entradas y las 4 salidas.
 * Una colaboración
 * 
 * */
using System;
using System.Collections.Generic;

namespace GeneraEntradaSalida {
    internal class Program {
        static List<Datos> MisDatos;
        static void Main(string[] args) {
            Random Azar = new Random();
            MisDatos = new List<Datos>();
            int DigitosHacer = 7;
            int NumPiezas = 10;
            int NumRegistros = 100;
            while (true) {
                IngresaDatos(Azar, MisDatos, DigitosHacer, NumPiezas, NumRegistros);
                if (MisDatos.Count >= NumRegistros * 0.8)
                    Perceptrones(DigitosHacer);
            }
        }

        //Hace la prueba con los dos perceptrones
        public static void Perceptrones(int DigitosHacer) {
            //Crea dos perceptrones:
            //1. Trabaja con las múltiples entradas y salidas
            //2. Trabaja con una única entrada y una única salida

            //PERCEPTRON 1: TRABAJA CON MÚLTIPLES ENTRADAS Y SALIDAS
            int numEntradas = DigitosHacer; //Número de entradas
            int capa0 = 7; //Total neuronas en la capa 0
            int capa1 = 7; //Total neuronas en la capa 1
            int capa2 = DigitosHacer; //Total neuronas en la capa 2
            Perceptron perceptronA = new Perceptron(numEntradas, capa0, capa1, capa2);

            //Estas serán las entradas externas al perceptrón
            List<double> entradasA = new List<double>();
            for (int cont = 0; cont < DigitosHacer; cont++) entradasA.Add(0);

            //Estas serán las salidas esperadas externas al perceptrón
            List<double> salidasEsperadasA = new List<double>();
            for (int cont = 0; cont < DigitosHacer; cont++) salidasEsperadasA.Add(0);

            //Ciclo que entrena la red neuronal
            int totalCiclos = 10000; //Ciclos de entrenamiento
            for (int ciclo = 1; ciclo <= totalCiclos; ciclo++) {

                //Por cada ciclo, se entrena el perceptrón con todos los valores
                for (int conjunto = 0; conjunto < MisDatos.Count; conjunto++) {

                    //Entradas y salidas esperadas
                    int Divide = 10;
                    for (int cont = 0; cont < DigitosHacer; cont++) {
                        entradasA[cont] = (double)MisDatos[conjunto].Entradas[cont] / Divide;
                        salidasEsperadasA[cont] = (double)MisDatos[conjunto].Salidas[cont] / Divide;
                        Divide *= 10;
                    }

                    //Primero calcula la salida del perceptrón con esas entradas
                    perceptronA.CalculaSalida(entradasA);

                    //Luego entrena el perceptrón para ajustar los pesos y umbrales
                    perceptronA.Entrena(entradasA, salidasEsperadasA);
                }
            }

            //PERCEPTRON 2: TRABAJA CON UNA ENTRADA Y SALIDA
            numEntradas = 1; //Número de entradas
            capa0 = 5; //Total neuronas en la capa 0
            capa1 = 5; //Total neuronas en la capa 1
            capa2 = 1; //Total neuronas en la capa 2
            Perceptron perceptronB = new Perceptron(numEntradas, capa0, capa1, capa2);

            //Estas serán las entradas externas al perceptrón
            List<double> entradasB = new List<double>();
            entradasB.Add(0);

            //Estas serán las salidas esperadas externas al perceptrón
            List<double> salidasEsperadasB = new List<double>();
            salidasEsperadasB.Add(0);

            //Ciclo que entrena la red neuronal
            for (int ciclo = 1; ciclo <= totalCiclos; ciclo++) {

                //Por cada ciclo, se entrena el perceptrón con todos los valores
                for (int conjunto = 0; conjunto < MisDatos.Count; conjunto++) {

                    //Entradas y salidas esperadas
                    entradasB[0] = MisDatos[conjunto].EntradaReal;
                    salidasEsperadasB[0] = MisDatos[conjunto].SalidaReal;

                    //Primero calcula la salida del perceptrón con esas entradas
                    perceptronB.CalculaSalida(entradasB);

                    //Luego entrena el perceptrón para ajustar los pesos y umbrales
                    perceptronB.Entrena(entradasB, salidasEsperadasB);
                }
            }

            //Imprime los resultados
            //Console.WriteLine("Entrada ; Salida esperada ; Perceptrón una entrada/salida ; Perceptrón divide entrada/salida");
            double AjustePerceptronA = 0, AjustePerceptronB = 0;
            for (int conjunto = 0; conjunto < MisDatos.Count; conjunto++) {

                //Entradas y salidas esperadas
                int Divide = 10;
                for (int cont = 0; cont < DigitosHacer; cont++) {
                    entradasA[cont] = (double)MisDatos[conjunto].Entradas[cont] / Divide;
                    salidasEsperadasA[cont] = (double)MisDatos[conjunto].Salidas[cont] / Divide;
                    Divide *= 10;
                }

                entradasB[0] = MisDatos[conjunto].EntradaReal;
                salidasEsperadasB[0] = MisDatos[conjunto].SalidaReal;

                //Calcula la salida del perceptrón con esas entradas
                perceptronA.CalculaSalida(entradasA);
                perceptronB.CalculaSalida(entradasB);

                //Muestra la salida
                double Calculada = 0;
                for (int cont = 0; cont < perceptronA.capas[2].salidas.Count; cont++) Calculada += perceptronA.capas[2].salidas[cont];
                //Console.WriteLine(MisDatos[conjunto].EntradaReal.ToString() + ";" + MisDatos[conjunto].SalidaReal.ToString() + ";" + Calculada.ToString() + ";" + perceptronB.capas[2].salidas[0].ToString());

                //Acumula la diferencia entre salida esperada y lo que arroja los perceptrones
                AjustePerceptronA += Math.Abs(MisDatos[conjunto].SalidaReal - Calculada);
                AjustePerceptronB += Math.Abs(MisDatos[conjunto].SalidaReal - perceptronB.capas[2].salidas[0]);
            }

            Console.WriteLine("Divide: " + AjustePerceptronA.ToString() + " Una entrada/salida: " + AjustePerceptronB.ToString());
        }

        //Genera datasets al azar usanfo ecuaciones
        public static void IngresaDatos(Random Azar, List<Datos> MisDatos, int DigitosHacer, int numPiezas, int numDatos) {
            GeneraDatos Genera = new GeneraDatos();

            MisDatos.Clear();
            Genera.GeneraEcuacion(Azar, numPiezas, numDatos, MisDatos);

            //Luego los normaliza
            NormalizaDatos(MisDatos);

            //Posteriormente los convierte a entradas y salidas
            for (int cont = 0; cont < MisDatos.Count; cont++) {
                int[] DigitosEntra = ConvierteArreglo(MisDatos[cont].EntradaReal, DigitosHacer);
                int[] DigitosSale = ConvierteArreglo(MisDatos[cont].SalidaReal, DigitosHacer);
                MisDatos[cont].VuelveArreglo(DigitosEntra, DigitosSale);
            }

            //Elimina las entradas X repetidas
            for (int i = 0; i < MisDatos.Count - 1; i++) {
                for (int j = i + 1; j < MisDatos.Count; j++) {
                    bool EsIgual = true;
                    for (int k = 0; k < MisDatos[0].Entradas.Count; k++)
                        if (MisDatos[i].Entradas[k] != MisDatos[j].Entradas[k])
                            EsIgual = false;
                    if (EsIgual) { MisDatos.RemoveAt(j); j--; }
                }
            }
        }

        //Convierte el número real a una serie de digitos
        public static int[] ConvierteArreglo(double Valor, int Maximo) {
            string Cadena = Valor.ToString();
            int[] Digitos = new int[Maximo];
            for (int i = 2; i < Cadena.Length && i < Maximo + 2; i++) Digitos[i - 2] = int.Parse(Cadena[i].ToString());
            return Digitos;
        }

        //Normaliza
        public static void NormalizaDatos(List<Datos> MisDatos) {
            double MinX, MinY, MaxX, MaxY;
            MinX = MisDatos[0].EntradaReal;
            MaxX = MinX;
            MinY = MisDatos[0].SalidaReal;
            MaxY = MinY;
            for (int cont = 0; cont < MisDatos.Count; cont++) {
                if (MisDatos[cont].EntradaReal < MinX) MinX = MisDatos[cont].EntradaReal;
                if (MisDatos[cont].EntradaReal > MaxX) MaxX = MisDatos[cont].EntradaReal;
                if (MisDatos[cont].SalidaReal < MinY) MinY = MisDatos[cont].SalidaReal;
                if (MisDatos[cont].SalidaReal > MaxY) MaxY = MisDatos[cont].SalidaReal;
            }

            /* Normaliza */
            for (int cont = 0; cont < MisDatos.Count; cont++) {
                MisDatos[cont].EntradaReal = (MisDatos[cont].EntradaReal - MinX) / (MaxX - MinX);
                MisDatos[cont].SalidaReal = (MisDatos[cont].SalidaReal - MinY) / (MaxY - MinY);
            }

            /* Cómo se trabaja con los decimales, hay dos valores que dan problemas, el valor 
             * mínimo que es 0 y el valor máximo que es 1. En ambos, sus decimales son 00000
             * así que se borran de la lista los valores próximos a cero y próximos a 1 */
            for (int cont = 0; cont < MisDatos.Count; cont++) {
                if (MisDatos[cont].SalidaReal < 0.001 || MisDatos[cont].SalidaReal > 0.999) {
                    MisDatos.RemoveAt(cont);
                    cont = 0;
                }
            }
        }
     
    }
}

