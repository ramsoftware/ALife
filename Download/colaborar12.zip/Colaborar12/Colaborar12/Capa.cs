﻿/* Autor: Rafael Alberto Moreno Parra
 * Fecha: 22 de julio de 2022
 */

using System;

namespace Colaborar12{
    internal class Capa {
		private int TOTALNEURONAS;
		public Neurona[] Neuronas; //Las neuronas que tendrá la capa
		public double[] Salidas; //Almacena las salidas de cada neurona

		public Capa(Random Azar, int TotalNeuronas, int TotalEntradas) {
			TOTALNEURONAS = TotalNeuronas;
			Neuronas = new Neurona[TOTALNEURONAS];
			Salidas = new double[TOTALNEURONAS];

			//Genera las neuronas de esa capa
			for (int Contador = 0; Contador < TotalNeuronas; Contador++) 
				Neuronas[Contador] = new Neurona(Azar, TotalEntradas);
		}

		//Calcula las salidas de cada neurona de la capa
		public void CalculaCapa(double[] Entradas) {
			for (int Contador = 0; Contador < TOTALNEURONAS; Contador++) 
				Salidas[Contador] = Neuronas[Contador].CalculaSalida(Entradas);
		}

		//Actualiza los pesos y umbrales de las neuronas
		public void Actualiza() {
			for (int Contador = 0; Contador < TOTALNEURONAS; Contador++) 
				Neuronas[Contador].Actualiza();
		}
	}
}
