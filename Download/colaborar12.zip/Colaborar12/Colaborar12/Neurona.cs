﻿/* Autor: Rafael Alberto Moreno Parra
 * Fecha: 22 de julio de 2022
 */
using System;

namespace Colaborar12 {
	internal class Neurona {
		private readonly int TOTALENTRADAS;
		public double[] Pesos; //Los pesos para cada entrada
		public double[] NuevosPesos; //Nuevos pesos dados por el algoritmo de "backpropagation"
		public double Umbral; //El peso del umbral
		public double NuevoUmbral; //Nuevo umbral dado por el algoritmo de "backpropagation"

		//Inicializa los pesos y umbral con un valor al azar
		public Neurona(Random Azar, int TotalEntradas) {
            TOTALENTRADAS = TotalEntradas;
			Pesos = new double[TOTALENTRADAS];
			NuevosPesos = new double[TOTALENTRADAS];
			for (int Contador = 0; Contador < TotalEntradas; Contador++) 
				Pesos[Contador] = Azar.NextDouble();
			Umbral = Azar.NextDouble();
			NuevoUmbral = 0;
		}

		//Calcula la salida de la neurona dependiendo de las entradas
		public double CalculaSalida(double[] Entradas) {
			double Valor = 0;
			for (int Contador = 0; Contador < TOTALENTRADAS; Contador++) 
				Valor += Entradas[Contador] * Pesos[Contador];
			Valor += Umbral;
			return 1 / (1 + Math.Exp(-Valor));
		}

		//Reemplaza viejos pesos por nuevos
		public void Actualiza() {
			for (int Contador = 0; Contador < TOTALENTRADAS; Contador++) 
				Pesos[Contador] = NuevosPesos[Contador];
			Umbral = NuevoUmbral;
		}
	}
}
