﻿/* Autor: Rafael Alberto Moreno Parra
 * Fecha: 13 de julio de 2022
 */

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Windows.Forms;

namespace Colaborar12 {
    public partial class Form1 : Form {
        Random Azar;

        //Los datos generados para el dataset.
        GeneradorDatos ConjuntoDatos;

        //Para manejar la red neuronal
        List<Perceptron> RedNeuronal;
        double MejorRedAjuste;
        int MejorRedNeuronal;
        
        //Para manejar el algoritmo evolutivo
        List<Poblacion> Evolutivo;
        double MejorPoblacionAjuste;
        int MejorPoblacion;
        
        //Para mantener el proceso en ejecución
        bool MantenerProceso;

        public Form1() {
            InitializeComponent();
            Azar = new Random();
            Evolutivo = new List<Poblacion>();
            RedNeuronal = new List<Perceptron>();
        }


        private void LlenaGridChart() {
            //Llena el GridView con los datos
            dgDatos.Rows.Clear();
            dgDatos.Refresh();

            for (int Num = 0; Num < ConjuntoDatos.Entradas.Length; Num++) {
                var nuevaFila = dgDatos.Rows.Add();
                dgDatos.Columns[0].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                dgDatos.Columns[1].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;

                dgDatos.Rows[nuevaFila].Cells[0].Value = ConjuntoDatos.Entradas[Num];
                dgDatos.Rows[nuevaFila].Cells[1].Value = ConjuntoDatos.Salidas[Num];
            }

            //Inicializa las series de datos, algoritmo evolutivo y red neuronal
            chartDatos.Series[0].Points.Clear();
            chartDatos.Series[1].Points.Clear();
            chartDatos.Series[2].Points.Clear();

            //Muestra los datos generados en el Chart
            chartDatos.ChartAreas[0].AxisX.MajorGrid.Enabled = false;
            chartDatos.ChartAreas[0].AxisY.MajorGrid.Enabled = false;
            chartDatos.ChartAreas[0].AxisY.Maximum = 1;
            chartDatos.ChartAreas[0].AxisX.Maximum = 1;

            for (int Num = 0; Num < ConjuntoDatos.Entradas.Length; Num++)
                chartDatos.Series[0].Points.AddXY(ConjuntoDatos.Entradas[Num], ConjuntoDatos.Salidas[Num]);

            //Si el algoritmo evolutivo ha sido activado
            if (Evolutivo != null) {

                //El algoritmo evolutivo
                dgDatos.Columns[2].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                dgDatos.Columns[3].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;

                //Muestra en el grid la salida del algoritmo evolutivo
                for (int Num = 0; Num < ConjuntoDatos.Salidas.Length; Num++) {
                    double SalidaEvolutivo = Evolutivo[MejorPoblacion].Individuos[Evolutivo[MejorPoblacion].MejorIndividuo].ValorSalida(ConjuntoDatos.Entradas[Num]);
                    dgDatos.Rows[Num].Cells[2].Value = SalidaEvolutivo;

                    //Pone la diferencia
                    dgDatos.Rows[Num].Cells[3].Value = (ConjuntoDatos.Salidas[Num] - SalidaEvolutivo) * (ConjuntoDatos.Salidas[Num] - SalidaEvolutivo);

                    //Pone en el chart
                    chartDatos.Series[2].Points.AddXY(ConjuntoDatos.Entradas[Num], SalidaEvolutivo);
                }
            }

            //Si la red neuronal ha sido activada
            if (RedNeuronal != null) {

                //La red neuronal
                dgDatos.Columns[4].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                dgDatos.Columns[5].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;

                //Estas serán las entradas y salidas externas al perceptrón
                double[] Entradas = new double[1];

                //Muestra en el grid la salida del algoritmo evolutivo
                for (int Num = 0; Num < ConjuntoDatos.Salidas.Length; Num++) {
                    
                    //Entrada
                    Entradas[0] = ConjuntoDatos.Entradas[Num];
                    RedNeuronal[MejorRedNeuronal].CalculaSalidaRed(Entradas);
                    double SalidaRed = RedNeuronal[MejorRedNeuronal].Capas[2].Salidas[0];
                    dgDatos.Rows[Num].Cells[4].Value = SalidaRed;

                    //Pone la diferencia
                    dgDatos.Rows[Num].Cells[5].Value = (ConjuntoDatos.Salidas[Num] - SalidaRed) * (ConjuntoDatos.Salidas[Num] - SalidaRed);

                    //Pone en el chart
                    chartDatos.Series[1].Points.AddXY(ConjuntoDatos.Entradas[Num], SalidaRed);
                }
            }
        }

        private void btnGenera_Click(object sender, EventArgs e) {
            //Inicializa la red neuronal
            RedNeuronal = null;
            Evolutivo = null;

            //Prepara el generador de datos
            ConjuntoDatos = new GeneradorDatos();

            //Genera el dataset en forma aleatoria
            ConjuntoDatos.GeneraEcuacion(Azar, Convert.ToDouble(numXini.Value), Convert.ToDouble(numXfin.Value), Convert.ToInt32(numRegistros.Value));

            //Llena el gridview y el chart
            LlenaGridChart();

            //Habilita el proceso
            btnProceso.Enabled = true;
        }

        private void btnProceso_Click(object sender, EventArgs e) {
            btnProceso.Enabled =false;
            btnDetener.Enabled = true;

            if (bgwProceso.IsBusy != true) {

                //Si el hilo no está trabajando
                bgwProceso.RunWorkerAsync();
            }
        }

        private void Proceso(object sender, DoWorkEventArgs e) {
            //Tiempo que tendrá cada población y red neuronal para operar
            long TiempoEvaluar = Convert.ToInt32(numSegundos.Value) * 1000;

            //Configurando la red neuronal
            int NumeroEntradas = 1; //Número de entradas
            int TotalNeuronasCapaOculta1 = Convert.ToInt32(numCapa1.Value);
            int TotalNeuronasCapaOculta2 = Convert.ToInt32(numCapa2.Value);
            int TotalNeuronasCapaSalida = 1; //Total neuronas en la capa de salida

            //Configurando la poblaciónd del algoritmo evolutivo
            int IndividuosPorPoblacion = Convert.ToInt32(numIndividuos.Value);

            //Para detener el proceso
            MantenerProceso = true;

            //Inicia la lista de poblaciones (algoritmo evolutivo)
            Evolutivo = new List<Poblacion>();

            //Inicia la lista de redes neuronales
            RedNeuronal = new List<Perceptron>();

            //Llama al algoritmo evolutivo y a la red neuronal
            while (MantenerProceso) {

                //===================
                //Algoritmo evolutivo
                //===================
                Evolutivo.Add(new Poblacion(Azar, IndividuosPorPoblacion));
                Evolutivo[Evolutivo.Count - 1].Proceso(Azar, TiempoEvaluar, ConjuntoDatos.Entradas, ConjuntoDatos.Salidas);
                bgwProceso.ReportProgress(0);

                //===================                
                //Red neuronal
                //===================
                RedNeuronal.Add(new Perceptron(Azar, NumeroEntradas, TotalNeuronasCapaOculta1, TotalNeuronasCapaOculta2, TotalNeuronasCapaSalida));
                RedNeuronal[RedNeuronal.Count - 1].Proceso(ConjuntoDatos.Entradas, ConjuntoDatos.Salidas, TiempoEvaluar);
                bgwProceso.ReportProgress(0);
            }
        }

        //Nuestra cuantas poblaciones y cuantas redes neuronales han sido generadas.
        private void bgwProceso_ProgressChanged(object sender, ProgressChangedEventArgs e) {
            if (Evolutivo != null)  txtPoblacion.Text = Evolutivo.Count.ToString();
            if (RedNeuronal != null) txtRedNeuronal.Text = RedNeuronal.Count.ToString();
        }

        private void bgwProceso_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e) {
            //El mejor de cada población del algoritmo evolutivo, se procesa con los datos de validación.
            //El que se acerque más a esos datos es el que se muestra
            MejorPoblacionAjuste = double.MaxValue;
            MejorPoblacion = -1;
            for (int Cont = 0; Cont < Evolutivo.Count; Cont++) {
                int Mejor = Evolutivo[Cont].MejorIndividuo;
                Evolutivo[Cont].Individuos[Mejor].Ajuste = -1;
                Evolutivo[Cont].Individuos[Mejor].AjusteIndividuo(ConjuntoDatos.ValidaEntra, ConjuntoDatos.ValidaSale);
                if (Evolutivo[Cont].Individuos[Mejor].Ajuste < MejorPoblacionAjuste) {
                    MejorPoblacionAjuste = Evolutivo[Cont].Individuos[Mejor].Ajuste;
                    MejorPoblacion = Cont;
                }
            }

            //Se evalúa cada red neuronal con los datos de validación.
            //La que se acerque más a esos datos es la que se muestra.
            MejorRedAjuste = double.MaxValue;
            MejorRedNeuronal = -1;
            for (int Cont = 0; Cont < Evolutivo.Count; Cont++) {
                double AjusteRed = RedNeuronal[Cont].Ajuste(ConjuntoDatos.ValidaEntra, ConjuntoDatos.ValidaSale);
                if (AjusteRed < MejorRedAjuste) {
                    MejorRedAjuste = AjusteRed;
                    MejorRedNeuronal = Cont;
                }
            }

            //Llena el gridview y el chart
            LlenaGridChart();
        }

        private void btnDetener_Click(object sender, EventArgs e) {
            btnDetener.Enabled = false;
            btnProceso.Enabled = true;
            MantenerProceso = false;
        }
    }
}
