﻿/* Autor: Rafael Alberto Moreno Parra
 * Fecha: 22 de julio de 2022
 */

using System;


namespace Colaborar12 {
    internal class GeneradorDatos {
        //Coeficientes de la ecuación generada
        double E1a, E1b, E1c, E1d, E1e;
        double E2a, E2b, E2c, E2d, E2e;

        //Almacena los valores de la variable independiente (entrada)
        public double[] Entradas;

        //Almacena los valores de la variable dependiente (salida) 
        public double[] Salidas;

        //Para los valores de validación
        public double[] ValidaEntra;
        public double[] ValidaSale;

        //Genera la ecuación 
        public void GeneraEcuacion(Random Azar, double ValorXini, double ValorXfin, int NumRegistros) {
            Entradas = new double[NumRegistros];
            Salidas = new double[NumRegistros];
            ValidaEntra = new double[NumRegistros];
            ValidaSale = new double[NumRegistros];

            E1a = Azar.NextDouble() - Azar.NextDouble();
            E1b = Azar.NextDouble() - Azar.NextDouble();
            E1c = Azar.NextDouble() - Azar.NextDouble();
            E1d = Azar.NextDouble() - Azar.NextDouble();
            E1e = Azar.NextDouble() - Azar.NextDouble();

            E2a = Azar.NextDouble() - Azar.NextDouble();
            E2b = Azar.NextDouble() - Azar.NextDouble();
            E2c = Azar.NextDouble() - Azar.NextDouble();
            E2d = Azar.NextDouble() - Azar.NextDouble();
            E2e = Azar.NextDouble() - Azar.NextDouble();


            double MinimoX = double.MaxValue;
            double MaximoX = double.MinValue;
            double MinimoY = double.MaxValue;
            double MaximoY = double.MinValue;

            for (int Contador = 0; Contador < NumRegistros; Contador++) {

                //Datos del entrenamiento
                double valX = (Azar.NextDouble() * (ValorXfin - ValorXini)) + ValorXini;
                double valY = Evaluar(valX);
                Entradas[Contador] = valX;
                Salidas[Contador] = valY;

                //Para normalizar
                if (valX < MinimoX) MinimoX = valX;
                if (valX > MaximoX) MaximoX = valX;
                if (valY < MinimoY) MinimoY = valY;
                if (valY > MaximoY) MaximoY = valY;

                //Datos para validación de sobre ajuste
                valX = (Azar.NextDouble() * (ValorXfin - ValorXini)) + ValorXini;
                valY = Evaluar(valX);
                ValidaEntra[Contador] = valX;
                ValidaSale[Contador] = valY;

                //Para normalizar
                if (valX < MinimoX) MinimoX = valX;
                if (valX > MaximoX) MaximoX = valX;
                if (valY < MinimoY) MinimoY = valY;
                if (valY > MaximoY) MaximoY = valY;
            }

            //Ordena los valores
            Ordenar(Entradas, Salidas);
            Ordenar(ValidaEntra, ValidaSale);

            //Normaliza los valores de entrenamiento y validación
            for (int Contador = 0; Contador < NumRegistros; Contador++) {
                Entradas[Contador] = (Entradas[Contador] - MinimoX) / (MaximoX - MinimoX);
                Salidas[Contador] = (Salidas[Contador] - MinimoY) / (MaximoY - MinimoY);

                ValidaEntra[Contador] = (ValidaEntra[Contador] - MinimoX) / (MaximoX - MinimoX);
                ValidaSale[Contador] = (ValidaSale[Contador] - MinimoY) / (MaximoY - MinimoY);
            }
        }

        //Se va de pieza en pieza evaluando toda la ecuación
        public double Evaluar(double X) {
            double YE1 = Math.Sin(E1a * X * X * X * X + E1b * X * X * X + E1c * X * X + E1d * X + E1e);
            double YE2 = Math.Cos(E2a * X * X * X * X + E2b * X * X * X + E2c * X * X + E2d * X + E2e);
            return YE1 + YE2;
        }

        //Ordenamiento por Shell
        static void Ordenar(double[] Entrada, double[] Salida) {
            int N = Entrada.Length;
            int incremento = N;
            do {
                incremento /= 2;
                for (int k = 0; k < incremento; k++) {
                    for (int i = incremento + k; i < N; i += incremento) {
                        int j = i;
                        while (j - incremento >= 0 && Entrada[j] < Entrada[j - incremento]) {
                            double tmp = Entrada[j];
                            Entrada[j] = Entrada[j - incremento];
                            Entrada[j - incremento] = tmp;

                            tmp = Salida[j];
                            Salida[j] = Salida[j - incremento];
                            Salida[j - incremento] = tmp;

                            j -= incremento;
                        }
                    }
                }
            } while (incremento > 1);
        }
    }
}
