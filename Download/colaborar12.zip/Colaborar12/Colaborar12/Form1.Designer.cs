﻿namespace Colaborar12 {
    partial class Form1 {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing) {
            if (disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent() {
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea2 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend2 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series4 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.Series series5 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.Series series6 = new System.Windows.Forms.DataVisualization.Charting.Series();
            this.tabPrincipal = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.txtRedNeuronal = new System.Windows.Forms.TextBox();
            this.lblRedNeuronal = new System.Windows.Forms.Label();
            this.lblPoblacion = new System.Windows.Forms.Label();
            this.btnDetener = new System.Windows.Forms.Button();
            this.txtPoblacion = new System.Windows.Forms.TextBox();
            this.btnProceso = new System.Windows.Forms.Button();
            this.chartDatos = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.btnGenera = new System.Windows.Forms.Button();
            this.tabDatos = new System.Windows.Forms.TabPage();
            this.dgDatos = new System.Windows.Forms.DataGridView();
            this.tabConfiguracion = new System.Windows.Forms.TabPage();
            this.numSegundos = new System.Windows.Forms.NumericUpDown();
            this.lblMilisegundos = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.numRegistros = new System.Windows.Forms.NumericUpDown();
            this.label1 = new System.Windows.Forms.Label();
            this.numXfin = new System.Windows.Forms.NumericUpDown();
            this.numXini = new System.Windows.Forms.NumericUpDown();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.grbRed = new System.Windows.Forms.GroupBox();
            this.numCapa2 = new System.Windows.Forms.NumericUpDown();
            this.numCapa1 = new System.Windows.Forms.NumericUpDown();
            this.lblCapa2 = new System.Windows.Forms.Label();
            this.lblCapa1 = new System.Windows.Forms.Label();
            this.grbEvolutivo = new System.Windows.Forms.GroupBox();
            this.numIndividuos = new System.Windows.Forms.NumericUpDown();
            this.lblIndividuos = new System.Windows.Forms.Label();
            this.bgwProceso = new System.ComponentModel.BackgroundWorker();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colEvolutivo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colDifEvolutivo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colRed = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colDifRed = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tabPrincipal.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chartDatos)).BeginInit();
            this.tabDatos.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgDatos)).BeginInit();
            this.tabConfiguracion.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numSegundos)).BeginInit();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numRegistros)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numXfin)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numXini)).BeginInit();
            this.grbRed.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numCapa2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numCapa1)).BeginInit();
            this.grbEvolutivo.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numIndividuos)).BeginInit();
            this.SuspendLayout();
            // 
            // tabPrincipal
            // 
            this.tabPrincipal.Controls.Add(this.tabPage1);
            this.tabPrincipal.Controls.Add(this.tabDatos);
            this.tabPrincipal.Controls.Add(this.tabConfiguracion);
            this.tabPrincipal.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabPrincipal.Location = new System.Drawing.Point(0, 0);
            this.tabPrincipal.Margin = new System.Windows.Forms.Padding(4);
            this.tabPrincipal.Name = "tabPrincipal";
            this.tabPrincipal.SelectedIndex = 0;
            this.tabPrincipal.Size = new System.Drawing.Size(1331, 624);
            this.tabPrincipal.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.txtRedNeuronal);
            this.tabPage1.Controls.Add(this.lblRedNeuronal);
            this.tabPage1.Controls.Add(this.lblPoblacion);
            this.tabPage1.Controls.Add(this.btnDetener);
            this.tabPage1.Controls.Add(this.txtPoblacion);
            this.tabPage1.Controls.Add(this.btnProceso);
            this.tabPage1.Controls.Add(this.chartDatos);
            this.tabPage1.Controls.Add(this.btnGenera);
            this.tabPage1.Location = new System.Drawing.Point(4, 25);
            this.tabPage1.Margin = new System.Windows.Forms.Padding(4);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(4);
            this.tabPage1.Size = new System.Drawing.Size(1323, 595);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Generación y Proceso";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // txtRedNeuronal
            // 
            this.txtRedNeuronal.Location = new System.Drawing.Point(7, 230);
            this.txtRedNeuronal.Name = "txtRedNeuronal";
            this.txtRedNeuronal.ReadOnly = true;
            this.txtRedNeuronal.Size = new System.Drawing.Size(143, 23);
            this.txtRedNeuronal.TabIndex = 29;
            this.txtRedNeuronal.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // lblRedNeuronal
            // 
            this.lblRedNeuronal.AutoSize = true;
            this.lblRedNeuronal.Location = new System.Drawing.Point(9, 210);
            this.lblRedNeuronal.Name = "lblRedNeuronal";
            this.lblRedNeuronal.Size = new System.Drawing.Size(93, 16);
            this.lblRedNeuronal.TabIndex = 28;
            this.lblRedNeuronal.Text = "Red Neuronal";
            // 
            // lblPoblacion
            // 
            this.lblPoblacion.AutoSize = true;
            this.lblPoblacion.Location = new System.Drawing.Point(9, 142);
            this.lblPoblacion.Name = "lblPoblacion";
            this.lblPoblacion.Size = new System.Drawing.Size(69, 16);
            this.lblPoblacion.TabIndex = 27;
            this.lblPoblacion.Text = "Población";
            // 
            // btnDetener
            // 
            this.btnDetener.Enabled = false;
            this.btnDetener.Location = new System.Drawing.Point(7, 301);
            this.btnDetener.Name = "btnDetener";
            this.btnDetener.Size = new System.Drawing.Size(143, 36);
            this.btnDetener.TabIndex = 26;
            this.btnDetener.Text = "Detener";
            this.btnDetener.UseVisualStyleBackColor = true;
            this.btnDetener.Click += new System.EventHandler(this.btnDetener_Click);
            // 
            // txtPoblacion
            // 
            this.txtPoblacion.Location = new System.Drawing.Point(8, 161);
            this.txtPoblacion.Name = "txtPoblacion";
            this.txtPoblacion.ReadOnly = true;
            this.txtPoblacion.Size = new System.Drawing.Size(143, 23);
            this.txtPoblacion.TabIndex = 25;
            this.txtPoblacion.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // btnProceso
            // 
            this.btnProceso.Enabled = false;
            this.btnProceso.Location = new System.Drawing.Point(7, 72);
            this.btnProceso.Name = "btnProceso";
            this.btnProceso.Size = new System.Drawing.Size(144, 39);
            this.btnProceso.TabIndex = 24;
            this.btnProceso.Text = "Procesar";
            this.btnProceso.UseVisualStyleBackColor = true;
            this.btnProceso.Click += new System.EventHandler(this.btnProceso_Click);
            // 
            // chartDatos
            // 
            chartArea2.Name = "ChartArea1";
            this.chartDatos.ChartAreas.Add(chartArea2);
            legend2.Name = "Legend1";
            this.chartDatos.Legends.Add(legend2);
            this.chartDatos.Location = new System.Drawing.Point(157, 17);
            this.chartDatos.Name = "chartDatos";
            series4.ChartArea = "ChartArea1";
            series4.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
            series4.Legend = "Legend1";
            series4.Name = "Datos";
            series5.ChartArea = "ChartArea1";
            series5.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
            series5.Legend = "Legend1";
            series5.Name = "Red Neuronal";
            series6.ChartArea = "ChartArea1";
            series6.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
            series6.Legend = "Legend1";
            series6.Name = "Evolutivo";
            this.chartDatos.Series.Add(series4);
            this.chartDatos.Series.Add(series5);
            this.chartDatos.Series.Add(series6);
            this.chartDatos.Size = new System.Drawing.Size(1158, 561);
            this.chartDatos.TabIndex = 11;
            // 
            // btnGenera
            // 
            this.btnGenera.Location = new System.Drawing.Point(8, 17);
            this.btnGenera.Name = "btnGenera";
            this.btnGenera.Size = new System.Drawing.Size(143, 39);
            this.btnGenera.TabIndex = 9;
            this.btnGenera.Text = "Generar dataset";
            this.btnGenera.UseVisualStyleBackColor = true;
            this.btnGenera.Click += new System.EventHandler(this.btnGenera_Click);
            // 
            // tabDatos
            // 
            this.tabDatos.Controls.Add(this.dgDatos);
            this.tabDatos.Location = new System.Drawing.Point(4, 25);
            this.tabDatos.Margin = new System.Windows.Forms.Padding(4);
            this.tabDatos.Name = "tabDatos";
            this.tabDatos.Padding = new System.Windows.Forms.Padding(4);
            this.tabDatos.Size = new System.Drawing.Size(1323, 595);
            this.tabDatos.TabIndex = 1;
            this.tabDatos.Text = "Datos y Resultados";
            this.tabDatos.UseVisualStyleBackColor = true;
            // 
            // dgDatos
            // 
            this.dgDatos.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgDatos.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn5,
            this.dataGridViewTextBoxColumn6,
            this.colEvolutivo,
            this.colDifEvolutivo,
            this.colRed,
            this.colDifRed});
            this.dgDatos.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgDatos.Location = new System.Drawing.Point(4, 4);
            this.dgDatos.Name = "dgDatos";
            this.dgDatos.ReadOnly = true;
            this.dgDatos.Size = new System.Drawing.Size(1315, 587);
            this.dgDatos.TabIndex = 11;
            // 
            // tabConfiguracion
            // 
            this.tabConfiguracion.Controls.Add(this.numSegundos);
            this.tabConfiguracion.Controls.Add(this.lblMilisegundos);
            this.tabConfiguracion.Controls.Add(this.groupBox1);
            this.tabConfiguracion.Controls.Add(this.grbRed);
            this.tabConfiguracion.Controls.Add(this.grbEvolutivo);
            this.tabConfiguracion.Location = new System.Drawing.Point(4, 25);
            this.tabConfiguracion.Name = "tabConfiguracion";
            this.tabConfiguracion.Padding = new System.Windows.Forms.Padding(3);
            this.tabConfiguracion.Size = new System.Drawing.Size(1323, 595);
            this.tabConfiguracion.TabIndex = 2;
            this.tabConfiguracion.Text = "Configuración";
            this.tabConfiguracion.UseVisualStyleBackColor = true;
            // 
            // numSegundos
            // 
            this.numSegundos.Location = new System.Drawing.Point(482, 34);
            this.numSegundos.Minimum = new decimal(new int[] {
            5,
            0,
            0,
            0});
            this.numSegundos.Name = "numSegundos";
            this.numSegundos.Size = new System.Drawing.Size(246, 23);
            this.numSegundos.TabIndex = 27;
            this.numSegundos.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.numSegundos.Value = new decimal(new int[] {
            30,
            0,
            0,
            0});
            // 
            // lblMilisegundos
            // 
            this.lblMilisegundos.AutoSize = true;
            this.lblMilisegundos.Location = new System.Drawing.Point(479, 6);
            this.lblMilisegundos.Name = "lblMilisegundos";
            this.lblMilisegundos.Size = new System.Drawing.Size(249, 16);
            this.lblMilisegundos.TabIndex = 26;
            this.lblMilisegundos.Text = "Tiempo en segundos para el proceso";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.numRegistros);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.numXfin);
            this.groupBox1.Controls.Add(this.numXini);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Location = new System.Drawing.Point(27, 6);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(351, 143);
            this.groupBox1.TabIndex = 25;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Generador de datos";
            // 
            // numRegistros
            // 
            this.numRegistros.Location = new System.Drawing.Point(225, 99);
            this.numRegistros.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.numRegistros.Minimum = new decimal(new int[] {
            100,
            0,
            0,
            0});
            this.numRegistros.Name = "numRegistros";
            this.numRegistros.Size = new System.Drawing.Size(120, 23);
            this.numRegistros.TabIndex = 24;
            this.numRegistros.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.numRegistros.Value = new decimal(new int[] {
            100,
            0,
            0,
            0});
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(6, 101);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(207, 16);
            this.label1.TabIndex = 23;
            this.label1.Text = "Número de registros a generar";
            // 
            // numXfin
            // 
            this.numXfin.Location = new System.Drawing.Point(225, 64);
            this.numXfin.Maximum = new decimal(new int[] {
            2,
            0,
            0,
            0});
            this.numXfin.Name = "numXfin";
            this.numXfin.Size = new System.Drawing.Size(120, 23);
            this.numXfin.TabIndex = 22;
            this.numXfin.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.numXfin.Value = new decimal(new int[] {
            2,
            0,
            0,
            0});
            // 
            // numXini
            // 
            this.numXini.Location = new System.Drawing.Point(225, 33);
            this.numXini.Maximum = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.numXini.Minimum = new decimal(new int[] {
            5,
            0,
            0,
            -2147483648});
            this.numXini.Name = "numXini";
            this.numXini.Size = new System.Drawing.Size(120, 23);
            this.numXini.TabIndex = 19;
            this.numXini.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.numXini.Value = new decimal(new int[] {
            2,
            0,
            0,
            -2147483648});
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(6, 71);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(127, 16);
            this.label2.TabIndex = 18;
            this.label2.Text = "Valor máximo de X";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(6, 35);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(123, 16);
            this.label3.TabIndex = 17;
            this.label3.Text = "Valor mínimo de X";
            // 
            // grbRed
            // 
            this.grbRed.Controls.Add(this.numCapa2);
            this.grbRed.Controls.Add(this.numCapa1);
            this.grbRed.Controls.Add(this.lblCapa2);
            this.grbRed.Controls.Add(this.lblCapa1);
            this.grbRed.Location = new System.Drawing.Point(27, 261);
            this.grbRed.Name = "grbRed";
            this.grbRed.Size = new System.Drawing.Size(351, 102);
            this.grbRed.TabIndex = 22;
            this.grbRed.TabStop = false;
            this.grbRed.Text = "Red Neuronal";
            // 
            // numCapa2
            // 
            this.numCapa2.Location = new System.Drawing.Point(225, 57);
            this.numCapa2.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numCapa2.Name = "numCapa2";
            this.numCapa2.Size = new System.Drawing.Size(120, 23);
            this.numCapa2.TabIndex = 22;
            this.numCapa2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.numCapa2.Value = new decimal(new int[] {
            5,
            0,
            0,
            0});
            // 
            // numCapa1
            // 
            this.numCapa1.Location = new System.Drawing.Point(225, 28);
            this.numCapa1.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numCapa1.Name = "numCapa1";
            this.numCapa1.Size = new System.Drawing.Size(120, 23);
            this.numCapa1.TabIndex = 19;
            this.numCapa1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.numCapa1.Value = new decimal(new int[] {
            5,
            0,
            0,
            0});
            // 
            // lblCapa2
            // 
            this.lblCapa2.AutoSize = true;
            this.lblCapa2.Location = new System.Drawing.Point(6, 57);
            this.lblCapa2.Name = "lblCapa2";
            this.lblCapa2.Size = new System.Drawing.Size(145, 16);
            this.lblCapa2.TabIndex = 18;
            this.lblCapa2.Text = "Neuronas en capa 2:";
            // 
            // lblCapa1
            // 
            this.lblCapa1.AutoSize = true;
            this.lblCapa1.Location = new System.Drawing.Point(6, 28);
            this.lblCapa1.Name = "lblCapa1";
            this.lblCapa1.Size = new System.Drawing.Size(145, 16);
            this.lblCapa1.TabIndex = 17;
            this.lblCapa1.Text = "Neuronas en capa 1:";
            // 
            // grbEvolutivo
            // 
            this.grbEvolutivo.Controls.Add(this.numIndividuos);
            this.grbEvolutivo.Controls.Add(this.lblIndividuos);
            this.grbEvolutivo.Location = new System.Drawing.Point(27, 167);
            this.grbEvolutivo.Name = "grbEvolutivo";
            this.grbEvolutivo.Size = new System.Drawing.Size(351, 71);
            this.grbEvolutivo.TabIndex = 21;
            this.grbEvolutivo.TabStop = false;
            this.grbEvolutivo.Text = "Algoritmo Evolutivo";
            // 
            // numIndividuos
            // 
            this.numIndividuos.Location = new System.Drawing.Point(225, 26);
            this.numIndividuos.Maximum = new decimal(new int[] {
            2000,
            0,
            0,
            0});
            this.numIndividuos.Minimum = new decimal(new int[] {
            20,
            0,
            0,
            0});
            this.numIndividuos.Name = "numIndividuos";
            this.numIndividuos.Size = new System.Drawing.Size(120, 23);
            this.numIndividuos.TabIndex = 15;
            this.numIndividuos.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.numIndividuos.Value = new decimal(new int[] {
            200,
            0,
            0,
            0});
            // 
            // lblIndividuos
            // 
            this.lblIndividuos.AutoSize = true;
            this.lblIndividuos.Location = new System.Drawing.Point(6, 33);
            this.lblIndividuos.Name = "lblIndividuos";
            this.lblIndividuos.Size = new System.Drawing.Size(115, 16);
            this.lblIndividuos.TabIndex = 14;
            this.lblIndividuos.Text = "Total individuos:";
            // 
            // bgwProceso
            // 
            this.bgwProceso.WorkerReportsProgress = true;
            this.bgwProceso.DoWork += new System.ComponentModel.DoWorkEventHandler(this.Proceso);
            this.bgwProceso.ProgressChanged += new System.ComponentModel.ProgressChangedEventHandler(this.bgwProceso_ProgressChanged);
            this.bgwProceso.RunWorkerCompleted += new System.ComponentModel.RunWorkerCompletedEventHandler(this.bgwProceso_RunWorkerCompleted);
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.HeaderText = "Entrada X";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            this.dataGridViewTextBoxColumn5.ReadOnly = true;
            this.dataGridViewTextBoxColumn5.Width = 200;
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.HeaderText = "Salida Esperada Y";
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            this.dataGridViewTextBoxColumn6.ReadOnly = true;
            this.dataGridViewTextBoxColumn6.Width = 200;
            // 
            // colEvolutivo
            // 
            this.colEvolutivo.HeaderText = "Algoritmo Evolutivo";
            this.colEvolutivo.Name = "colEvolutivo";
            this.colEvolutivo.ReadOnly = true;
            this.colEvolutivo.Width = 200;
            // 
            // colDifEvolutivo
            // 
            this.colDifEvolutivo.HeaderText = "Diferencia";
            this.colDifEvolutivo.Name = "colDifEvolutivo";
            this.colDifEvolutivo.ReadOnly = true;
            this.colDifEvolutivo.Width = 200;
            // 
            // colRed
            // 
            this.colRed.HeaderText = "Red Neuronal";
            this.colRed.Name = "colRed";
            this.colRed.ReadOnly = true;
            this.colRed.Width = 200;
            // 
            // colDifRed
            // 
            this.colDifRed.HeaderText = "Diferencia";
            this.colDifRed.Name = "colDifRed";
            this.colDifRed.ReadOnly = true;
            this.colDifRed.Width = 200;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1331, 624);
            this.Controls.Add(this.tabPrincipal);
            this.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Form1";
            this.Text = "Colaborar 12. Algoritmo Evolutivo vs Red Neuronal";
            this.tabPrincipal.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chartDatos)).EndInit();
            this.tabDatos.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgDatos)).EndInit();
            this.tabConfiguracion.ResumeLayout(false);
            this.tabConfiguracion.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numSegundos)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numRegistros)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numXfin)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numXini)).EndInit();
            this.grbRed.ResumeLayout(false);
            this.grbRed.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numCapa2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numCapa1)).EndInit();
            this.grbEvolutivo.ResumeLayout(false);
            this.grbEvolutivo.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numIndividuos)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabPrincipal;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabDatos;
        private System.Windows.Forms.Button btnGenera;
        private System.Windows.Forms.DataVisualization.Charting.Chart chartDatos;
        private System.Windows.Forms.DataGridView dgDatos;
        private System.Windows.Forms.Button btnProceso;
        private System.Windows.Forms.TabPage tabConfiguracion;
        private System.Windows.Forms.GroupBox grbRed;
        private System.Windows.Forms.NumericUpDown numCapa2;
        private System.Windows.Forms.NumericUpDown numCapa1;
        private System.Windows.Forms.Label lblCapa2;
        private System.Windows.Forms.Label lblCapa1;
        private System.Windows.Forms.GroupBox grbEvolutivo;
        private System.Windows.Forms.NumericUpDown numIndividuos;
        private System.Windows.Forms.Label lblIndividuos;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.NumericUpDown numRegistros;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.NumericUpDown numXfin;
        private System.Windows.Forms.NumericUpDown numXini;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.NumericUpDown numSegundos;
        private System.Windows.Forms.Label lblMilisegundos;
        private System.ComponentModel.BackgroundWorker bgwProceso;
        private System.Windows.Forms.TextBox txtPoblacion;
        private System.Windows.Forms.Button btnDetener;
        private System.Windows.Forms.TextBox txtRedNeuronal;
        private System.Windows.Forms.Label lblRedNeuronal;
        private System.Windows.Forms.Label lblPoblacion;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private System.Windows.Forms.DataGridViewTextBoxColumn colEvolutivo;
        private System.Windows.Forms.DataGridViewTextBoxColumn colDifEvolutivo;
        private System.Windows.Forms.DataGridViewTextBoxColumn colRed;
        private System.Windows.Forms.DataGridViewTextBoxColumn colDifRed;
    }
}

