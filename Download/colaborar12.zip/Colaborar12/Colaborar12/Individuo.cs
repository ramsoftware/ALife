﻿/* Autor: Rafael Alberto Moreno Parra
 * Fecha: 13 de julio de 2022
 */
using System;

namespace Colaborar12 {
    internal class Individuo {
        public double[] Coef = new double[9];

        //Guarda en "caché" el ajuste para no tener que calcularlo continuamente
        public double Ajuste;

        //Inicializa el individuo con las Piezas, Modificadores y Operadores al azar
        public Individuo(Random Azar) {
            for (int Contador = 0; Contador < Coef.Length; Contador++)
                Coef[Contador] = Azar.NextDouble();
            Ajuste = -1;
        }

        //Mejora el individuo antes de entrar a la arena de la competición, cambiando los coeficientes 
        public void MejoraIndividuo(Random Azar, double[] Entradas, double[] Salidas) {
            int Cambiar = Azar.Next(0, Coef.Length);
            double Antes = Coef[Cambiar];
            Coef[Cambiar] += Azar.NextDouble()*0.2-0.1;

            //El cálculo del ajuste es la sumatoria de (valor calculado por el individuo - valor esperado)^2
            double NuevoAjuste = 0;
            for (int X = 0; X < Salidas.Length; X++) {
                double Diferencia = ValorSalida(Entradas[X]) - Salidas[X];
                NuevoAjuste += Diferencia * Diferencia;
                if (NuevoAjuste > Ajuste && Ajuste != -1) { //Si el cambio perjudica el ajuste anterior, retorna el valor anterior del coeficiente cambiado
                    Coef[Cambiar] = Antes;
                    return;
                }
            }

            Ajuste = NuevoAjuste;
        }

        //Calcula el ajuste del individuo con los valores de salida esperados
        public void AjusteIndividuo(double[] Entradas, double[] Salidas) {
            //Si ya había sido calculado entonces evita calcularlo de nuevo
            if (Ajuste != -1) return;

            //El cálculo del ajuste es la sumatoria de (valor calculado por el individuo - valor esperado)^2
            Ajuste = 0;
            for (int X = 0; X < Salidas.Length; X++) {
                double Diferencia = ValorSalida(Entradas[X]) - Salidas[X];
                Ajuste += Diferencia * Diferencia;
            }
        }

        //Retorna la salida dependiendo de la entrada
        public double ValorSalida(double x) {
            return (Math.Sin(Coef[0] * (1 - x) * (1 - x) * (1 - x) * (1 - x) + Coef[1] * (1 - x) * (1 - x) * (1 - x) + Coef[2] * (1 - x) * (1 - x) + Coef[3] * (1 - x) + Coef[4] + Coef[5] * x + Coef[6] * x * x + Coef[7] * x * x * x + Coef[8] * x * x * x * x) + 1) / 2;
        }
    }
}
