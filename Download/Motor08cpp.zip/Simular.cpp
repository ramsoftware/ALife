/* Autor: Rafael Alberto Moreno Parra
   Fecha: 20 de Febrero del 2000

ENGINE08. Escrito en C++ (Compilado en Visual C++ 6.0)

Objetivos:
1. Lograr mayor velocidad de procesamiento.
2. Seguir la pista de procesamiento de la simulaci�n usando archivos
3. Evitar que la aplicaci�n cuando se cierre pierda el proceso de simulaci�n.

Simulaciones Planeadas:
I. Ambiente Alterno, Incremental y Decremental
   a. Mutaci�n (50%) y Generaci�n Aleatoria (50%)  es igual a Engine05
   b. Optimizaci�n/Mutaci�n (50%) y Generaci�n Aleatoria (50%)
   c. Optimizaci�n/Adici�n (50%) y Generaci�n Aleatoria (50%)
   d. Optimizaci�n/Mutaci�nIFSETinutil (50%) y Generaci�n Aleatoria (50%)
   e. Optimizaci�n/Mutaci�n/Adici�n al tiempo (50%) y Generaci�n Aleatoria (50%)
   f. Optimizaci�n/Mutaci�n/Mutaci�nIFSETinutil al tiempo (50%) y Generaci�n Aleatoria (50%)
   g. Optimizaci�n/Adici�n/Mutaci�nIFSETinutil al tiempo (50%) y Generaci�n Aleatoria (50%)
   h. Optimizaci�n/Mutacion/Adici�n/Mutaci�nIFSETinutil al tiempo (50%) y Generaci�n Aleatoria (50%)
   i. Optimizaci�n/Mutacion/Adici�n/Mutaci�nIFSETinutil usando uno y despues el otro (50%) y Generaci�n Aleatoria (50%)


Esto se graficar� en Excel para ver el comportamiento de la simulaci�n a trav�s del tiempo.
Nuevos estudios:

  I.   Estudio de cada gen, como colabora para la adaptaci�n.
  II.  Reproducci�n.
  III. Comportamiento Sinusoidal.
  IV.Construcci�n de Ambientes (objetos, propiedades, relaciones con otros).
*/

#include <stdio.h>
#include <string.h>
#include <math.h>
#include <afx.h>
#include "Organismo.h"
#include "MasApto.h"
#include "MedioAmbiente.h"

void main(void);
void Simular(void);
void vQuitaEspacios(char *sCadena);
void vLeft(char *cad1, char *cad2, char num_letras);
void vRight(char *cad1, char *cad2, char num_letras);
void vMid(char *cad1, char *cad2, char desde, char hasta);


//Programa Principal
void main()
{
	Simular();
}


void Simular()
{
   	//Probabilidades, estos datos se leen de un archivo de inicializaci�n
	int m_iPosibIf= 50; //Posibilidad de que la instrucci�n sea IF
    int m_iPosibSet= 50; //Posibilidad de que la instrucci�n sea Asignaci�n
    int m_iPosW= 25; //Posibilidad de que la variable activa sea W
    int m_iPosX= 25; //Posibilidad de que la variable activa sea X
    int m_iPosY= 25; //Posibilidad de que la variable activa sea Y
    int m_iPosZ= 25; //Posibilidad de que la variable activa sea Z
    int m_iPosIg= 25; //Posibilidad de comparativo =
    int m_iPosMay= 25;//Posibilidad de comparativo >
    int m_iPosMen= 25;//Posibilidad de comparativo <
    int m_iPosDif= 25;//Posibilidad de comparativo !
    int m_iLongExpr= 2; //Longitud de las expresiones
    int m_iPosibX= 33; //Posibilidad de salir X
    int m_iPosibP= 33; //Posibilidad de salir Parentesis
    int m_iPosibN= 34; //Posibilidad de salir N�mero
	int m_iNumCiclos=130; //Maximo CPU
	unsigned int m_iNumIntentos=1000; //Maximo numero de intentos
	bool m_bGenRandom = true;  //�Genera 1 a N?
	int m_iMutaGenera = 50; //Probabilidad de que Mute el mejor durante la simulacion

	char sEntrada[200]="1,2,3,4,5,6,7,8,9,10,11,12,13,";
	char sSalidas[200]="-1,2,-3,4,-5,6,-7,8,-9,10,-11,12,-13,";
    char sArchResult[50]="Simular1.txt"; //Archivo donde se guarda el resultado
    MedioAmbiente objAmbiente; //El ambiente


    //Abre y estudia el archivo de inicializaci�n
	FILE *fpInicio;
	char sFrase[600], sVariable[200], sValor[200];
    int iCar;

	fpInicio = fopen("Motor08.ini", "r+t");
	if (fpInicio == NULL)
    {
		printf("Error al tratar de abrir archivo de inicializaci�n Engine08.ini\n");
		return;
    }
	while(!feof(fpInicio))
	{
		fgets(sFrase, 298, fpInicio);
		vQuitaEspacios(sFrase);

		//Extrae variables y valores
		for (iCar=0; iCar<strlen(sFrase) && sFrase[iCar]!='='; iCar++);
		vLeft(sVariable, sFrase, iCar);
		vMid(sValor, sFrase, iCar+2,strlen(sFrase)-1);

		//Clasifica variables
		if(strcmp(sVariable, "m_iPosibIf")==0) m_iPosibIf = atoi(sValor);
		if(strcmp(sVariable, "m_iPosibSet")==0) m_iPosibSet = atoi(sValor);
		if(strcmp(sVariable, "m_iPosW")==0) m_iPosW = atoi(sValor);
		if(strcmp(sVariable, "m_iPosX")==0) m_iPosX = atoi(sValor);
		if(strcmp(sVariable, "m_iPosY")==0) m_iPosY = atoi(sValor);
		if(strcmp(sVariable, "m_iPosZ")==0) m_iPosZ = atoi(sValor);
		if(strcmp(sVariable, "m_iPosIg")==0) m_iPosIg = atoi(sValor);
		if(strcmp(sVariable, "m_iPosMay")==0) m_iPosMay = atoi(sValor);
		if(strcmp(sVariable, "m_iPosMen")==0) m_iPosMen = atoi(sValor);
		if(strcmp(sVariable, "m_iPosDif")==0) m_iPosDif = atoi(sValor);
		if(strcmp(sVariable, "m_iLongExpr")==0) m_iLongExpr = atoi(sValor);
		if(strcmp(sVariable, "m_iPosibX")==0) m_iPosibX = atoi(sValor);
		if(strcmp(sVariable, "m_iPosibP")==0) m_iPosibP = atoi(sValor);
		if(strcmp(sVariable, "m_iPosibN")==0) m_iPosibN = atoi(sValor);
		if(strcmp(sVariable, "m_iNumCiclos")==0) m_iNumCiclos = atoi(sValor);
		if(strcmp(sVariable, "m_iNumIntentos")==0) m_iNumIntentos = atol(sValor);
		if(strcmp(sVariable, "m_bGenRandom")==0)
			if (strcmp(sValor, "true")==0)
				m_bGenRandom = true;
			else
				m_bGenRandom = false;
		if(strcmp(sVariable, "sEntrada")==0) strcpy(sEntrada, sValor);
		if(strcmp(sVariable, "sSalidas")==0) strcpy(sSalidas, sValor);
		if(strcmp(sVariable, "sArchResult")==0) strcpy(sArchResult, sValor);
		if(strcmp(sVariable, "m_iMutaGenera")==0) m_iMutaGenera = atoi(sValor);
	}
	fclose(fpInicio);


    //Leidos de una vez los parametros de simulaci�n, comienza a simular
	FILE *fpSimular;
	fpSimular = fopen(sArchResult, "a+t");
	fprintf(fpSimular,"ENGINE08. Optimiza el mas apto y luego muta una instrucci�n.\n");
	fprintf(fpSimular,"Serie Entrada: %s\n", sEntrada);
	fprintf(fpSimular,"Serie Salida: %s\n", sSalidas);
	fprintf(fpSimular,"Intentos: %ld\n", m_iNumIntentos);
	fprintf(fpSimular,"CPU: %d\n", m_iNumCiclos);
	fprintf(fpSimular,"Mutar al simular: %d\n", m_iMutaGenera);
	if (m_bGenRandom)
		fprintf(fpSimular,"Hay libertad de generar de 1 a N instrucciones\n\n");
	else
		fprintf(fpSimular,"Es obligatorio generar N instrucciones\n\n");
	fprintf(fpSimular,"Posibilidades:\n");
	fprintf(fpSimular,"1. Tipo de Instrucciones. If Condicional: %d, Asignacion: %d\n", m_iPosibIf, m_iPosibSet);
	fprintf(fpSimular,"2. En Instrucciones de If Condicional, el operador de comparacion es:  '==':%d, '>':%d, '<':%d, '!=':%d\n", m_iPosIg, m_iPosMay, m_iPosMen, m_iPosDif);
	fprintf(fpSimular,"3. Longitud de la expresi�n (n�mero de operadores): %d\n\n", m_iLongExpr);
	fprintf(fpSimular,"4. Construcci�n de las expresiones, posiblidad de salir X=%d, Parentesis:%d, N�meros=%d\n", m_iPosibX, m_iPosibP, m_iPosibN);
	fprintf(fpSimular,"5. Variables que se asignaran, compararan o estaran al interior de las expresiones: W=%d, X=%d, Y=%d, Z=%d\n", m_iPosW, m_iPosX, m_iPosY, m_iPosZ);
	fclose(fpSimular);

	//Variables de la simulaci�n
	int m_iNumGenes=0;  //Contador de genes(instrucciones a generar)
	bool m_bEvaluaCiclo=true; //Usada para el siguiente ciclo que aumenta genes
    unsigned int m_iContIntentos=0; //Contador de intentos
	float m_fPuesto1=(float)999999; //Variable para chequear los algoritmos mas aptos
	int iMutar=1; //Bandera para variar entre Mutaci�n y Generaci�n Espont�nea
	int iGen; //Contador, usado en el ciclo de mutaci�n.
	float fResult; //Resultado de la evaluaci�n del organismo en un item del ambiente
	float fErrOrg; //Aproximaci�n del Algoritmo (Organismo) al Ambiente
	int iNumCiclo; //Que gen mutara
	int iCont;

      //Variable que guarda el mejor algoritmo
	char m_OrganismoGen[4500]; //Mejor Algoritmo

	//Objeto que guarda el mejor objeto organismo 	
	MasApto OrgMasApto;

	//Objeto que guarda el organismo a probar en el ambiente
	Organismo OrgPrueba;
	OrgPrueba.cMuta.vIniLista(m_iPosibN, m_iPosibX, m_iPosibP);
	OrgPrueba.m_iMaxiCiclos =  m_iNumCiclos;
	OrgPrueba.vCreaADN(false, 65,
                    m_iPosibIf, m_iPosibSet,
                    m_iPosW, m_iPosX, m_iPosY, m_iPosZ, 
                    m_iPosIg, m_iPosMay, m_iPosMen, m_iPosDif,
                    m_iLongExpr, m_iPosibX, m_iPosibP, m_iPosibN);
	//================================================================

    //Deduce el ambiente
	objAmbiente.vDeshaceIO(sEntrada, 1);
	objAmbiente.vDeshaceIO(sSalidas, 2);

    //Ciclo de evaluacion de 5 a 60 instrucciones
	while(true) 
	{
		    if (m_bEvaluaCiclo)
		    {
				fpSimular = fopen(sArchResult, "a+t");
				fprintf(fpSimular,"\n\n===========================================================\n\n");
				fclose(fpSimular);

		        m_iNumGenes += 5; // Aumenta de 5 en 5 las instrucciones
		        m_bEvaluaCiclo = false;
		        m_iContIntentos = 0;
		        m_fPuesto1 = (float) 999999;
		        iMutar = 1;
				
   	            OrgPrueba.IniciaSemilla();
				OrgPrueba.vCreaADN(false, m_iNumGenes,
                                   m_iPosibIf, m_iPosibSet,
                                   m_iPosW, m_iPosX, m_iPosY, m_iPosZ, 
                                   m_iPosIg, m_iPosMay, m_iPosMen, m_iPosDif,
                                   m_iLongExpr, m_iPosibX, m_iPosibP, m_iPosibN);
                
				//Inicializa tambi�n la mutaci�n
                for (int iCopia=1; iCopia <= OrgPrueba.m_iMaxGenOrg; iCopia++)
                {
                    OrgMasApto.m_oGen[iCopia].cOperacion = OrgPrueba.m_oGen[iCopia].cOperacion;
                    OrgMasApto.m_oGen[iCopia].cTipInst = OrgPrueba.m_oGen[iCopia].cTipInst;
                    OrgMasApto.m_oGen[iCopia].cVarActiva = OrgPrueba.m_oGen[iCopia].cVarActiva;
                    OrgMasApto.m_oGen[iCopia].cVariable = OrgPrueba.m_oGen[iCopia].cVariable;
                    OrgMasApto.m_oGen[iCopia].iGotoLabel = OrgPrueba.m_oGen[iCopia].iGotoLabel;
                    strcpy(OrgMasApto.m_oGen[iCopia].sbExpresion, OrgPrueba.m_oGen[iCopia].sbExpresion);
                }
                OrgMasApto.m_iMaxGenOrg = OrgPrueba.m_iMaxGenOrg;
		    }

		    if (m_iNumGenes >= 65 ) break; //Hace hasta 60 instrucciones (genes)

			//Comienza la simulaci�n, este es el ciclo que mas CPU consume
		    while (m_iContIntentos < m_iNumIntentos)
			{
		        m_iContIntentos++; // Intentos de generaci�n

                //Escoge entre generar aleatoriamente o mutar el mas apto
				iMutar = abs(rand() % 100) + 1;
				if (iMutar <= m_iMutaGenera)
				{
					//Genera aleatoriamente el ser vivo
	                OrgPrueba.vCreaADN(m_bGenRandom, m_iNumGenes,
                                  m_iPosibIf, m_iPosibSet,
                                  m_iPosW, m_iPosX, m_iPosY, m_iPosZ, 
                                  m_iPosIg, m_iPosMay, m_iPosMen, m_iPosDif,
                                  m_iLongExpr, m_iPosibX, m_iPosibP, m_iPosibN);
				}
				else
				{
					for (int iCopia=1; iCopia <= OrgMasApto.m_iMaxGenOrg; iCopia++)
                    {
						OrgPrueba.m_oGen[iCopia].bCambiacVariable = false;
						OrgPrueba.m_oGen[iCopia].bEjecuta = false;
						OrgPrueba.m_oGen[iCopia].bIFtrue = false;
                        OrgPrueba.m_oGen[iCopia].cOperacion = OrgMasApto.m_oGen[iCopia].cOperacion;
                        OrgPrueba.m_oGen[iCopia].cTipInst = OrgMasApto.m_oGen[iCopia].cTipInst;
                        OrgPrueba.m_oGen[iCopia].cVarActiva = OrgMasApto.m_oGen[iCopia].cVarActiva;
                        OrgPrueba.m_oGen[iCopia].cVariable = OrgMasApto.m_oGen[iCopia].cVariable;
                        OrgPrueba.m_oGen[iCopia].iGotoLabel = OrgMasApto.m_oGen[iCopia].iGotoLabel;
                        strcpy(OrgPrueba.m_oGen[iCopia].sbExpresion,OrgMasApto.m_oGen[iCopia].sbExpresion);
                    }
                    OrgPrueba.m_iMaxGenOrg = OrgMasApto.m_iMaxGenOrg;

                    /* Muta un Gen al azar... */
				    iNumCiclo = abs(rand() % OrgPrueba.m_iMaxGenOrg ) + 1;
                    OrgPrueba.vHaceGen(iNumCiclo, OrgPrueba.m_iMaxGenOrg,
                                       m_iPosibIf, m_iPosibSet,
                                       m_iPosW, m_iPosX, m_iPosY, m_iPosZ, 
                                       m_iPosIg, m_iPosMay, m_iPosMen, m_iPosDif,
                                       m_iLongExpr, m_iPosibX, m_iPosibP, m_iPosibN);
                }     
                OrgPrueba.vEvaluaPrevio();
    
				fErrOrg=0;
	            for (iCont=0; iCont<objAmbiente.m_iContEntra; iCont++)
	            {
	                fResult = OrgPrueba.fEvalOrganismo((float)objAmbiente.m_iEntradas[iCont]);
	                fErrOrg += fabs(fResult-(float)objAmbiente.m_iSalidas[iCont]);
	            }

				/* Compara con el puesto anterior y si la aproximaci�n es menor reemplaza */
	            if (fErrOrg < m_fPuesto1)
	            {
	                m_fPuesto1 = fErrOrg;
                    OrgPrueba.Optimiza(); //Nuevo. Motor08. Quita instrucciones de sobra.

                    //Almacena el mejor objeto organismo
                    for (int iCopia=1; iCopia <= OrgPrueba.m_iMaxGenOrg; iCopia++)
                    {
                        OrgMasApto.m_oGen[iCopia].cOperacion = OrgPrueba.m_oGen[iCopia].cOperacion;
                        OrgMasApto.m_oGen[iCopia].cTipInst = OrgPrueba.m_oGen[iCopia].cTipInst;
                        OrgMasApto.m_oGen[iCopia].cVarActiva = OrgPrueba.m_oGen[iCopia].cVarActiva;
                        OrgMasApto.m_oGen[iCopia].cVariable = OrgPrueba.m_oGen[iCopia].cVariable;
                        OrgMasApto.m_oGen[iCopia].iGotoLabel = OrgPrueba.m_oGen[iCopia].iGotoLabel;
                        strcpy(OrgMasApto.m_oGen[iCopia].sbExpresion, OrgPrueba.m_oGen[iCopia].sbExpresion);
                    }
                    OrgMasApto.m_iMaxGenOrg = OrgPrueba.m_iMaxGenOrg;
                    
                    //Escribe el resultado a archivo
	              OrgPrueba.sDisplayADN(m_OrganismoGen);
			  fpSimular = fopen(sArchResult, "a+t");
			  fprintf(fpSimular,"Instrucciones: [%d] Intento: [%d]  Aproximacion: [%f]\n", m_iNumGenes, m_iContIntentos, fErrOrg);
			  fprintf(fpSimular,"%s\n\n",m_OrganismoGen);
			  fclose(fpSimular);
	            } // End If
	        } // End While
	        m_bEvaluaCiclo = true;
	    } // End While(true)
}

//Quita los espacios y datos no �tiles de la inicializaci�n
void vQuitaEspacios(char *sCadena)
{
	char sTemp[300];
    int iCont1, iCont2=0;

	for(iCont1=strlen(sCadena)-1; sCadena[iCont1]!=';'; iCont1--)  sCadena[iCont1]='\0';

	for(iCont1=0; iCont1<=strlen(sCadena); iCont1++)
		if(sCadena[iCont1]!=' ')
			sTemp[iCont2++]=sCadena[iCont1];

    sTemp[iCont2]='\0';
	strcpy(sCadena, sTemp);
}

// Toma las primeras cNumLetras de la cadena sCadena2 y las deposita en sCadena1
void vLeft(char *sCadena1, char *sCadena2, char cNumLetras)
{
 unsigned int iCont;
 for(iCont=0; iCont<=cNumLetras-1 && *(sCadena2+iCont); iCont++) *(sCadena1+iCont)=*(sCadena2+iCont);
 *(sCadena1+iCont)='\0';
}

// Extrae una subcadena de sCadena2 y la deposita en sCadena1
void vMid( char *sCadena1,  char *sCadena2,  char cDesde,  char cHasta)
{
 char iCont1, iCont2;
 for(iCont2=0, iCont1=cDesde-1; iCont1<=cHasta-1 && *(sCadena2+iCont1); iCont2++, iCont1++) *(sCadena1+iCont2)=*(sCadena2+iCont1);
 *(sCadena1+iCont2)='\0';
}