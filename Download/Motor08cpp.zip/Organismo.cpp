/*
* @(#)ArtificialLifeEngine.java
* 
* Es un conjunto de subrutinas que simulando la Evoluci�n de las Especies,
* puedan crear programas (codigo fuente) que se adapten a un ambiente en particular.
* Todo software tiene entradas y salidas. Las entradas son procesadas y se emite un resultado
* que son las salidas. Este proceso es implementado por un Dise�ador/Programador.
* Ahora bien, si usamos un sistema que usa principios evolutivos, este proceso puede nacer
* por si solo, esto tiene sus ventajas:
* 1. No se requiere de personal humano (programadores) para crear el proceso.
* 2. Puede disminuirse o anularse la posiblidad de errores en el proceso.
* 3. Ante nuevos requerimientos (nuevas entradas o formatos de salida) el proceso se adaptara.
* 4. Capaz de encontrar o acercarse a soluciones de problemas muy complejos.
* 
* El obst�culo:
*  Conseguir un proceso que ofrezca salidas esperadas a unas entradas, usando principios evolutivos
*  puede tardar un tiempo considerablemente alto. Con los nuevos procesadores a mayores velocidades y
*  un buen algoritmo evolutivo, el tiempo puede ser disminuido, de tal manera que podria entrar a
*  competir con programadores humanos.
*/

#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <float.h>
#include <time.h>
#include "Organismo.h"

void Organismo::IniciaSemilla()
{
	srand((unsigned)time( NULL ));
};

//Despliega como si fuera Java
void Organismo::sDisplayADN(char *sbADN)
{
	char sExprTemp1[250], sExprTemp2[250]="";
	char cEnter[4];
	strcpy(sbADN,"float fSerVivo(float X)");
    cEnter[0]= '\n';
    cEnter[1]= '\0';

	strcat(sbADN,cEnter);
	strcat(sbADN, "{");
    strcat(sbADN,cEnter);

    strcat(sbADN,"float W=0, Y=0, Z=0;");
    strcat(sbADN,cEnter);
    strcat(sbADN,cEnter);

	for (int iCont=1; iCont<=m_iMaxGenOrg; iCont++)
    {
		_itoa( iCont, sExprTemp1, 10 );
		strcat(sbADN, sExprTemp1);
		strcat(sbADN, ": ");

        //Reemplaza la expresion por la variable activa
		int iLongExpr = strlen(m_oGen[iCont].sbExpresion);
		sExprTemp2[0]='\0';
        for (int iChar=0; iChar < iLongExpr; iChar++)
        {
			char cCharAt = m_oGen[iCont].sbExpresion[iChar];
            sExprTemp1[1]='\0';
            if (cCharAt=='X' || cCharAt=='x')
				sExprTemp1[0]=m_oGen[iCont].cVarActiva;
            else
				sExprTemp1[0]=cCharAt;
   			strcat(sExprTemp2, sExprTemp1);
        }
                    
        //Organiza los if y asignaciones
        if (m_oGen[iCont].cTipInst == 'I')
        {
			sExprTemp1[0]=m_oGen[iCont].cVariable;
			strcat(sbADN, "if( ");  //if(
			strcat(sbADN, sExprTemp1);  //if ( Z
			strcat(sbADN, " ");
			sExprTemp1[0]=m_oGen[iCont].cOperacion; // if ( Z >
			strcat(sbADN, sExprTemp1);
			strcat(sbADN, " ");
			strcat(sbADN, sExprTemp2); // if (Z > 4*X*X
			strcat(sbADN, " ) goto ");
			sprintf(sExprTemp1, "%d", m_oGen[iCont].iGotoLabel);
			strcat(sbADN, sExprTemp1); // if (Z > 4*X*X ) goto 4
			strcat(sbADN, ";");
		}
        else
		{
			sExprTemp1[0]=m_oGen[iCont].cVariable;
			strcat(sbADN, sExprTemp1);
			strcat(sbADN, " = ");
			strcat(sbADN, sExprTemp2);
			strcat(sbADN, ";");
		}
        strcat(sbADN, cEnter);
    }    
    //Finaliza la expresion
	strcat(sbADN, "return Y;");
	strcat(sbADN, cEnter);
	strcat(sbADN, "}");
	strcat(sbADN, cEnter);
};

void Organismo::vCreaADN (bool bGenRandom, int iMaxGenes,
                   int iPosibIf, int iPosibSet,
                   int iPosW,  int iPosX, int iPosY, int iPosZ,
                   int iPosIg, int iPosMay, int iPosMen, int iPosDif,
                   int iLongExpr, int iPosibX, int iPosibP, int iPosibN)
{
    int iCont;

	if(bGenRandom)
		m_iMaxGenOrg = abs(rand() % iMaxGenes ) + 1; //Crea organismos entre 1 y iMaxGenes instrucciones
	else
        m_iMaxGenOrg = iMaxGenes;        
     
    for (iCont=1; iCont<=m_iMaxGenOrg; iCont++)
		vHaceGen (iCont, m_iMaxGenOrg,
                  iPosibIf, iPosibSet,
                  iPosW,  iPosX, iPosY, iPosZ,
                  iPosIg, iPosMay, iPosMen, iPosDif,
                  iLongExpr, iPosibX, iPosibP, iPosibN);
};

     /* Crea una linea de codigo fuente (la llam� Gen). El formato es:
        label, [, IF/SET, Variable, =/>/</!, (, expresion, ), Goto, Label, ]
        para mayor velocidad, se ubica en una clase el Gen */
void Organismo::vHaceGen(int iLabel, int iMaxGenes,
                   int iPosibIf, int iPosibSet,
                   int iPosW,  int iPosX, int iPosY, int iPosZ,
                   int iPosIg, int iPosMay, int iPosMen, int iPosDif,
                   int iLongExpr, int iPosibX, int iPosibP, int iPosibN)
{
	int iAleatorio;

    //Por defecto, nunca se ha ejecutado esta instruccion
    m_oGen[iLabel].bEjecuta = false;
       
    //Por defecto, siempre los if dan falso
    m_oGen[iLabel].bIFtrue = false;
        
    //Por defecto, las asignaciones nunca cambian el valor de la variable activa
    m_oGen[iLabel].bCambiacVariable = false;
        
    //Decide si es una asignaci�n(Set) o un If condicional
	iAleatorio = abs(rand() % 100) + 1;
	if (iAleatorio<=iPosibIf)
		m_oGen[iLabel].cTipInst = 'I';
	else
		m_oGen[iLabel].cTipInst = 'S';
       
    //Decide que variable usar W, X, Y, Z
   	iAleatorio = abs(rand() % 100) + 1;
	if (iAleatorio<=iPosW)
		m_oGen[iLabel].cVariable = 'W';
	else if (iAleatorio<=iPosW+iPosX)
		m_oGen[iLabel].cVariable = 'X';
    else if (iAleatorio<=iPosW+iPosX+iPosY)
		m_oGen[iLabel].cVariable = 'Y';
	else
		m_oGen[iLabel].cVariable = 'Z';
        
    //Decide si usa =, >, <, ! Estos son tenidos en cuenta si es un IF condicional
   	iAleatorio = abs(rand() % 100) + 1;
	if (iAleatorio<=iPosIg)
		m_oGen[iLabel].cOperacion = '=';
	else if (iAleatorio<=iPosIg+iPosMay)
		m_oGen[iLabel].cOperacion = '>';
    else if (iAleatorio<=iPosIg+iPosMay+iPosMen)
		m_oGen[iLabel].cOperacion = '<';
	else
		m_oGen[iLabel].cOperacion = '!';

   //Trae la expresion
    cMuta.vCrearExpresion(iLongExpr, iPosibX, iPosibP, iPosibN);
    strcpy(m_oGen[iLabel].sbExpresion,cMuta.sExpresion);
       
    //Como la trae para X, aqui la cambio a W, X, Y, Z
   	iAleatorio = abs(rand() % 100) + 1;
	if (iAleatorio<=iPosW)
		m_oGen[iLabel].cVarActiva = 'W';
	else if (iAleatorio<=iPosW+iPosX)
		m_oGen[iLabel].cVarActiva = 'X';
    else if (iAleatorio<=iPosW+iPosX+iPosY)
		m_oGen[iLabel].cVarActiva = 'Y';
	else
		m_oGen[iLabel].cVarActiva = 'Z';

    //Decide hacia que label va (entre 1 y MaxGenes) o si es el FIN, el resultado siempre sera Y
    int iNumCiclo = abs(rand() % iMaxGenes);
     m_oGen[iLabel].iGotoLabel = iNumCiclo; //Retorna 0 para FINalizar
};

    
//Por velocidad de evaluaci�n
void Organismo::vEvaluaPrevio()
{
	double dResultado;
    for (int iCont=1; iCont<=m_iMaxGenOrg; iCont++)
		dResultado = m_eEvalua[iCont].dCapturaEcuacion(m_oGen[iCont].sbExpresion, 0, 0);
};
        
    
float Organismo::fEvalOrganismo (float fValX)
{                   
	/* Viene la interpretacion, los valores X se disparan de 1 a n y se comparan con el ambiente Y */
    float fValW=0, fValY=0, fValZ=0, fValor=0, fResultado=0, fCompara=0;
    int iGenOrg=1; //# de Instrucci�n de inicio
    int iNumCiclos=0; //Contador de Ciclos
       
    while (iGenOrg!=0 && iGenOrg<=m_iMaxGenOrg)
    {
		//Coloca a TRUE la instruci�n porque se ejecuta
        m_oGen[iGenOrg].bEjecuta = true;
            
        //Aumenta el # de Ciclos
        iNumCiclos++;

		//M�ximo n�mero de ciclos que se evaluar�n del organismo, si el
        //organismo supera este n�mero de ciclos sin dar con un resultado
        //es desechado.
		if (iNumCiclos > m_iMaxiCiclos)
			return 9999999;
            
        //Que variable esta jugando dentro de la expresion
        switch (m_oGen[iGenOrg].cVarActiva)
        {
		   case 'W': fValor = fValW; break;
           case 'X': fValor = fValX; break;
           case 'Y': fValor = fValY; break;
           case 'Z': fValor = fValZ; break;
        }
            
        //Evalua la expresion
        //double dResultado = m_eEvalua.dCapturaecuacion(m_oGen[iGenOrg].sbExpresion, dValor, 0);
		fResultado = m_eEvalua[iGenOrg].dCicloEvalua(fValor, 0);
		if (m_eEvalua[iGenOrg].ERRORMATEMATICO==1 ||
			fResultado >= 9999999 || fResultado <= -9999999 )
//			||
//			fValW >= 9999999 || fValW <= -9999999 ||
//			fValX >= 9999999 || fValX <= -9999999 ||
//			fValY >= 9999999 || fValY <= -9999999 ||
//			fValZ >= 9999999 || fValZ <= -9999999)
			return 9999999;

		//Si es un SET asigna el valor a la variable del Gen
		if (m_oGen[iGenOrg].cTipInst == 'S')
		{
			m_oGen[iGenOrg].bIFtrue = true; //No es instruccion IF
		    switch(m_oGen[iGenOrg].cVariable)
		    {
				case 'W': if ( fValW != fResultado)
						  {
							m_oGen[iGenOrg].bCambiacVariable = true;
		                    fValW = fResultado;
		                  }
		                  break;
                case 'X': if ( fValX != fResultado)
		                  {
		                    m_oGen[iGenOrg].bCambiacVariable = true;
		                    fValX = fResultado;
		                  }
		                  break;
		        case 'Y': if ( fValY != fResultado)
						  {
		                    m_oGen[iGenOrg].bCambiacVariable = true;
		                    fValY = fResultado;
		                  }
		                  break;
		        case 'Z': if ( fValZ != fResultado)
		                  {
		                    m_oGen[iGenOrg].bCambiacVariable = true;
		                    fValZ = fResultado;
		                  }
		                  break;
		    }
		    iGenOrg++; //Ignora el salto en un SET
        }
        else //Es un If condicional
        {
			m_oGen[iGenOrg].bCambiacVariable = true; //En un IF siempre se coloca esta variable a TRUE
            switch(m_oGen[iGenOrg].cVariable)
		    {
				case 'W': fCompara = fValW; break;
		        case 'X': fCompara = fValX; break;
		        case 'Y': fCompara = fValY; break;
		        case 'Z': fCompara = fValZ; break;
		    }
                
            switch(m_oGen[iGenOrg].cOperacion)
            {
				case '>': if (fCompara > fResultado) 
		                  {
					          m_oGen[iGenOrg].bIFtrue = true;
		                      iGenOrg=m_oGen[iGenOrg].iGotoLabel;
		                  }
		                  else
						      iGenOrg++;
		                  break;
                case '<': if (fCompara < fResultado) 
		                  {
					          m_oGen[iGenOrg].bIFtrue = true;
		                      iGenOrg=m_oGen[iGenOrg].iGotoLabel;
		                  }
		                  else
					         iGenOrg++;
		                  break;
		        case '=': if (fCompara == fResultado) 
		                  {
					          m_oGen[iGenOrg].bIFtrue = true;
		                      iGenOrg=m_oGen[iGenOrg].iGotoLabel;
		                  }
		                  else
						      iGenOrg++;
		                  break;
                case '!': if (fCompara != fResultado) 
		                  {
					          m_oGen[iGenOrg].bIFtrue = true;
		                      iGenOrg=m_oGen[iGenOrg].iGotoLabel;
		                  }
		                  else
						      iGenOrg++;
		                  break;
		    }
		}
	 }//Fin de la evaluacion del ser vivo
	 return fValY;
};
     
     
//Esta subrutina retira los Genes (instrucciones) que no se ejecutaron durante la 
//validaci�n del ambiente
void Organismo::Optimiza()
{
	int iContGen = 0, iContGen2 = 0;

    while (iContGen < m_iMaxGenOrg)
    {
		iContGen++;
      
        //Busca la instruccion sobrante
        if (m_oGen[iContGen].bEjecuta == false)
        {
            iContGen2 = iContGen;
            
            //Borra la instruccion sobrante moviendo el resto de instrucciones
            while (iContGen2 < m_iMaxGenOrg)
            {
                m_oGen[iContGen2].bEjecuta = m_oGen[iContGen2+1].bEjecuta;
                m_oGen[iContGen2].bIFtrue = m_oGen[iContGen2+1].bIFtrue;
                m_oGen[iContGen2].bCambiacVariable = m_oGen[iContGen2+1].bCambiacVariable;
                m_oGen[iContGen2].cOperacion = m_oGen[iContGen2+1].cOperacion;
                m_oGen[iContGen2].cTipInst = m_oGen[iContGen2+1].cTipInst;
                m_oGen[iContGen2].cVarActiva = m_oGen[iContGen2+1].cVarActiva;
                m_oGen[iContGen2].cVariable = m_oGen[iContGen2+1].cVariable;
                strcpy(m_oGen[iContGen2].sbExpresion, m_oGen[iContGen2+1].sbExpresion);
                m_oGen[iContGen2].iGotoLabel = m_oGen[iContGen2+1].iGotoLabel;
                iContGen2++;
            }
            m_iMaxGenOrg--;
            
            //Actualiza los "Gotos".
            for (int iCont=1; iCont<=m_iMaxGenOrg; iCont++)
                    if (m_oGen[iCont].iGotoLabel >= iContGen )
                        m_oGen[iCont].iGotoLabel--;
            iContGen = 0; //Vuelve y arranca de nuevo 
        } // Fin If
		
      } //Fin While
   
      // Coloca el indicador para no ejecutado en FALSE para que se comporte como
      // si recien se generara el ser vivo 
      for (iContGen=1; iContGen<=m_iMaxGenOrg; iContGen++)
        m_oGen[iContGen].bEjecuta = false;
};
