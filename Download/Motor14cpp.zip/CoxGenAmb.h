/*
Autor:		Rafael Alberto Moreno Parra
URL:		http://www.geocities.com/krousky
Clase:		Conexi�n entre Dualidad y Ambiente
Lenguaje:	C++

Prop�sito:
Cuando comenc� la investigaci�n sobre Vida Artificial, estos fueron
los pasos que hice:
1. Expresi�n simple (la cual llam� Gen)
2. Conjunto de Genes (el cual llam� Organismo)
*/

class CoxGenAmb
{
public:
	unsigned int iCodAmbEntr; //C�digo �nico de Ambiente Entrada
	unsigned int iCodMasApto; //C�digo �nico de identificaci�n de Gen
	unsigned int iCodAmbSali; //C�digo �nico de Ambiente Salida
        float fError; //Error acumulado entre Orgasnismo - Ambiente
};
