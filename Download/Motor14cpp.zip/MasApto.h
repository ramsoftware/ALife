/*
Autor:		Rafael Alberto Moreno Parra
URL:		http://www.geocities.com/krousky
Clase:		MasApto
Lenguaje:	C++

Prop�sito:
Simular a la clase Organismo, salvo que esta ocupa mucho menos memoria.

M�todos:

*/
class MasApto
{
public:
	unsigned int iCodMasApto; //C�digo del mas apto
    Gen m_oGen[67]; //Genes del ser vivo
	unsigned int m_iMaxGenOrg;
	char sTextOrg[5000];
};

