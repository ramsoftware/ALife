/* Autor: Rafael Alberto Moreno Parra
   Fecha: 30 de Mayo de 2000

MOTOR13. Escrito en C++ (Compilado en Visual C++ 6.0)
Ambientes y Organismos

El ser vivo capta informaci�n de su medio ambiente mediante sus sentidos
(vista, olfato, gusto, ...), cada sentido (sensor) envia una determinada
informaci�n al organismo. Dependiendo de esta informaci�n, el organismo
reacciona (o evoluciona).

Entre mas especializado este un sensor, de mejor calidad ser� la informaci�n,
entre mas sentidos tenga un ser vivo mas informaci�n habr� del medio
ambiente.

Cuando comenc� la investigaci�n sobre Vida Artificial, estos fueron
los pasos que hice:
1. Expresi�n simple (la cual llam� Gen)
2. Conjunto de Genes (el cual llam� Organismo)
3. Ahora, Dualidad

Voy escalando cada concepto.

Estas simulaciones, servir�n para el manejo de:
1. M�ltiples y diversos datos de entrada.
2. M�ltiples y diversos datos de salida.


*/

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>

#include "Organismo.h"
#include "MasApto.h"
#include "MedioAmbiente.h"
#include "Inicializa.h"
#include "CoxGenAmb.h"

void Simular(void);
void vQuitaEspacios(char *sCadena);
void vLeft(char *cad1, char *cad2, char num_letras);
void vRight(char *cad1, char *cad2, char num_letras);
void vMid(char *cad1, char *cad2, char desde, char hasta);

#define MAXORGANISMOS 30
#define MAXAMBIENTES 10


//Programa Principal
main()
{
	Inicializa objInicializa; //Inicializa la simulaci�n
    MedioAmbiente objAmbiente[MAXAMBIENTES+1]; //Todos los ambientes
	MasApto objMasApto[MAXORGANISMOS+1]; //Los mejores organismos
	CoxGenAmb objCoxGenAmb[MAXORGANISMOS+1]; //Todas las conexiones
	Organismo objOrganismo;

    //Lee los parametros de simulaci�n
	objInicializa.vLeeArchivoIni();

    //Deduce el ambiente
	unsigned int iContAmb1; // Contador de Ambientes
	for (iContAmb1=0; iContAmb1<objInicializa.stDatVA.iNumAmbiente; iContAmb1++)
		objAmbiente[iContAmb1].vDeshaceIO(objInicializa.stDatVA.sAmbiente[iContAmb1]);

    //Inicializa el comportamiento aleatorio
	objOrganismo.IniciaSemillaT();
	objOrganismo.cMuta.vIniLista(	objInicializa.stDatVA.iPosibN,
									objInicializa.stDatVA.iPosibX,
									objInicializa.stDatVA.iPosibP);
	objOrganismo.m_iMaxiCiclos =  objInicializa.stDatVA.iNumCiclos;
	objOrganismo.vCreaADN(false, 65,
					objInicializa.stDatVA.iPosibIf,
					objInicializa.stDatVA.iPosibSet,
					objInicializa.stDatVA.iPosW,
					objInicializa.stDatVA.iPosX,
					objInicializa.stDatVA.iPosY,
					objInicializa.stDatVA.iPosZ,
					objInicializa.stDatVA.iPosIg,
					objInicializa.stDatVA.iPosMay,
					objInicializa.stDatVA.iPosMen,
					objInicializa.stDatVA.iPosDif,
					objInicializa.stDatVA.iLongExpr,
					objInicializa.stDatVA.iPosibX,
					objInicializa.stDatVA.iPosibP,
					objInicializa.stDatVA.iPosibN);

    //Informaci�n Inicial de la simulaci�n para simple expresi�n
	objOrganismo.m_oGen[1].bEjecuta = false;
	objOrganismo.m_oGen[1].cTipInst = 'S';
	objOrganismo.m_oGen[1].cVarActiva = 'X';
	objOrganismo.m_oGen[1].cVariable = 'Y';
	objOrganismo.m_oGen[1].iGotoLabel = 0;
	objOrganismo.m_iMaxGenOrg = 1;


	unsigned int iContAmbE=0; //Contador de ambientes de Entrada
	unsigned int iContAmbS=0; //Contador de ambientes de Salida
	unsigned int iConAprox=0; //Contador de aproximaci�n.
	unsigned int iContMasApto=0; //Contador de Organismos
	float fResult[40]; //Resultados del organismo con el ambiente de entrada
    float fAcumError=0; //Acumula el error (adaptaci�n) a todos los ambientes
    float fErrOrg=0; //Acumula el error (adaptacion) de un ambiente en particular
    unsigned int iMejorAmbE=0; //Mejor Ambiente de Entrada
    unsigned int iMejorAmbS=0; //Mejor Ambiente de Salida


	objInicializa.vArchResult(); //Encabezado
    	
	while(true)
	{
		//Crea el organismo. Sencillo: Solo una instrucci�n, no muta.
		objOrganismo.cMuta.vCrearExpresion(9,
		                               objInicializa.stDatVA.iPosibX,
		                               objInicializa.stDatVA.iPosibP,
									   objInicializa.stDatVA.iPosibN);
		strcpy(objOrganismo.m_oGen[1].sbExpresion,objOrganismo.cMuta.sExpresion);
        objOrganismo.vEvaluaPrevio();


		//Toma cada ambiente, lo trata como Entrada y compara con alguno que de Salida
        fAcumError = 9999999;
		for (iContAmbE=0; iContAmbE<objInicializa.stDatVA.iNumAmbiente; iContAmbE++)
		{
			//Evalua previamente el Organismo con el ambiente de Entrada
       		for (iConAprox=0; iConAprox<objAmbiente[iContAmbE].m_iContador; iConAprox++)
				fResult[iConAprox] = objOrganismo.fEvalOrganismo(objAmbiente[iContAmbE].m_fAmbiente[iConAprox]);

			//Ahora viene la comparaci�n con el ambiente de Salida
			for (iContAmbS=0; iContAmbS<objInicializa.stDatVA.iNumAmbiente; iContAmbS++)
			{
				if (iContAmbE!=iContAmbS) //Evita que el ambiente de entrada sea el mismo de salida
				{
					fErrOrg=0;
					for (iConAprox=0; iConAprox<objAmbiente[iContAmbS].m_iContador; iConAprox++)
						fErrOrg += (float) fabs(fResult[iConAprox] - objAmbiente[iContAmbS].m_fAmbiente[iConAprox]);

					//Deduce cual es el mejor ambiente de salida
					if (fErrOrg < fAcumError)
					{
						iMejorAmbE = iContAmbE;
						iMejorAmbS = iContAmbS;
						fAcumError = fErrOrg;
                   		objOrganismo.IniciaSemillaR(); //Inicializa la semilla
					}
				}
			}
		}

		//Ahora bien, ya sabe donde se adapta el organismo.
		//Se valida entonces si esta adaptacion es la que se espera.
		//y almacena los resultados.
		if (fAcumError < objInicializa.stDatVA.fMaximoError)
		{
			objOrganismo.sDisplayADN(objMasApto[iContMasApto].sTextOrg);
			objMasApto[iContMasApto].iCodMasApto = iContMasApto;
			objMasApto[iContMasApto].m_oGen[1].bEjecuta = objOrganismo.m_oGen[1].bEjecuta;
			objMasApto[iContMasApto].m_oGen[1].cOperacion = objOrganismo.m_oGen[1].cOperacion;
            objMasApto[iContMasApto].m_oGen[1].cTipInst = objOrganismo.m_oGen[1].cTipInst;
            objMasApto[iContMasApto].m_oGen[1].cVarActiva = objOrganismo.m_oGen[1].cVarActiva;
            objMasApto[iContMasApto].m_oGen[1].cVariable = objOrganismo.m_oGen[1].cVariable;
            objMasApto[iContMasApto].m_oGen[1].iGotoLabel = objOrganismo.m_oGen[1].iGotoLabel;
            strcpy(objMasApto[iContMasApto].m_oGen[1].sbExpresion, objOrganismo.m_oGen[1].sbExpresion);

			objCoxGenAmb[iContMasApto].iCodMasApto = iContMasApto;
			objCoxGenAmb[iContMasApto].iCodAmbEntr = iMejorAmbE;
			objCoxGenAmb[iContMasApto].iCodAmbSali = iMejorAmbS;
			objCoxGenAmb[iContMasApto].fError = fAcumError;

			objInicializa.vImprRelac(objMasApto[iContMasApto].sTextOrg, iMejorAmbE, iMejorAmbS, fAcumError);

			iContMasApto++;
       		objOrganismo.IniciaSemillaT(); //Inicializa la semilla
		}

		if (iContMasApto > MAXORGANISMOS) break;
	}
}







					
				




