/*
Autor:		Rafael Alberto Moreno Parra
URL:		http://www.geocities.com/krousky
Clase:		Inicializa. Motor12.
Lenguaje:	C++

Prop�sito:
Inicializa las variables para la simulaci�n

M�todos:

*/
class Inicializa {
public:

	struct stDatosSimul
	{
   		//Probabilidades, estos datos se leen de un archivo de inicializaci�n
		unsigned int iPosibIf; //Posibilidad de que la instrucci�n sea IF
		unsigned int iPosibSet; //Posibilidad de que la instrucci�n sea Asignaci�n
		unsigned int iPosW; //Posibilidad de que la variable activa sea W
		unsigned int iPosX; //Posibilidad de que la variable activa sea X
		unsigned int iPosY; //Posibilidad de que la variable activa sea Y
		unsigned int iPosZ; //Posibilidad de que la variable activa sea Z
		unsigned int iPosIg; //Posibilidad de comparativo =
		unsigned int iPosMay;//Posibilidad de comparativo >
		unsigned int iPosMen;//Posibilidad de comparativo <
		unsigned int iPosDif;//Posibilidad de comparativo !
		unsigned int iLongExpr; //Longitud de las expresiones
		unsigned int iPosibX; //Posibilidad de salir X
		unsigned int iPosibP; //Posibilidad de salir Parentesis
		unsigned int iPosibN; //Posibilidad de salir N�mero
		unsigned int iNumCiclos; //Maximo CPU
		unsigned int iNumIntentos; //Maximo numero de intentos
		unsigned int iMutaGenera; //Probabilidad de que Mute el mejor durante la simulacion
		unsigned int iGeneraSimple; //Numero de veces que se genera expresi�n simple al azar
		unsigned int iMutaSimple; //Numeero de veces que se mutara la expresi�n simple
		unsigned int iGeneraAzar; //Numero de veces que intenta al azar
		unsigned int iMutaTodoGen; //Numero de veces que muta todo el gen
		unsigned int iMutaParcGen; //Numero de veces que muta parcialmente un gen
		unsigned int iNumInstMin; //Numero de instrucciones(genes) m�nimo generado
		unsigned int iNumInstMax; //Numero de instrucciones(genes) m�ximo generado

		float fMaximoError; //M�ximo Error para acepatr organismo
		char sAmbiente[20][200]; //Ambiente
		unsigned int iNumAmbiente; //Numero de ambientes
		char sArchResult[50]; //Archivo donde se guarda el resultado
	};  

	struct stDatosSimul stDatVA; //Datos Vida Artificial
    void vLeeArchivoIni(void);
	void vArchResult(void);
    void vGrabaResult(int, char *, unsigned int, float);
	void vImprRelac(char *, unsigned int, unsigned int, float);

};
