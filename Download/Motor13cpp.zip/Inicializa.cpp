/*
Autor:		Rafael Alberto Moreno Parra
URL:		http://www.geocities.com/krousky
Clase:		Inicializa. Motor12.
Lenguaje:	C++

Prop�sito:
Inicializa las variables para la simulaci�n

M�todos:

*/

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>
#include "Inicializa.h"
#include "StringUtil.h"

//Abre y estudia el archivo de inicializaci�n
void Inicializa::vLeeArchivoIni()
{
	FILE *fpInicio;
	char sFrase[600], sVariable[200], sValor[200];
    unsigned int iCar;
	StringUtil StrUtil;
	stDatVA.iNumAmbiente = 0; //Inicializa numero de ambientes

	fpInicio = fopen("Motor13.ini", "r+t");
	if (fpInicio == NULL)
    {
		printf("Error al tratar de abrir archivo de inicializaci�n Motor11.ini\n");
		return;
    }
	while(!feof(fpInicio))
	{
		fgets(sFrase, 298, fpInicio);
		StrUtil.vQuitaEspacios(sFrase);

		//Extrae variables y valores
		for (iCar=0; iCar<strlen(sFrase) && sFrase[iCar]!='='; iCar++);
		StrUtil.vLeft(sVariable, sFrase, iCar);
		StrUtil.vMid(sValor, sFrase, iCar+2,strlen(sFrase)-1);

		//Clasifica variables
		if(strcmp(sVariable, "iPosibIf")==0) stDatVA.iPosibIf = atoi(sValor);
		if(strcmp(sVariable, "iPosibSet")==0) stDatVA.iPosibSet = atoi(sValor);
		if(strcmp(sVariable, "iPosW")==0) stDatVA.iPosW = atoi(sValor);
		if(strcmp(sVariable, "iPosX")==0) stDatVA.iPosX = atoi(sValor);
		if(strcmp(sVariable, "iPosY")==0) stDatVA.iPosY = atoi(sValor);
		if(strcmp(sVariable, "iPosZ")==0) stDatVA.iPosZ = atoi(sValor);
		if(strcmp(sVariable, "iPosIg")==0) stDatVA.iPosIg = atoi(sValor);
		if(strcmp(sVariable, "iPosMay")==0) stDatVA.iPosMay = atoi(sValor);
		if(strcmp(sVariable, "iPosMen")==0) stDatVA.iPosMen = atoi(sValor);
		if(strcmp(sVariable, "iPosDif")==0) stDatVA.iPosDif = atoi(sValor);
		if(strcmp(sVariable, "iLongExpr")==0) stDatVA.iLongExpr = atoi(sValor);
		if(strcmp(sVariable, "iPosibX")==0) stDatVA.iPosibX = atoi(sValor);
		if(strcmp(sVariable, "iPosibP")==0) stDatVA.iPosibP = atoi(sValor);
		if(strcmp(sVariable, "iPosibN")==0) stDatVA.iPosibN = atoi(sValor);
		if(strcmp(sVariable, "iNumIntentos")==0) stDatVA.iNumIntentos = atol(sValor);

		//Lee los ambientes (como son pocos el codigo lo hago f�cil), lee 14 ambientes maximo
		if(strcmp(sVariable, "sAmbiente00")==0) { strcpy(stDatVA.sAmbiente[0], sValor); stDatVA.iNumAmbiente++; }
		if(strcmp(sVariable, "sAmbiente01")==0) { strcpy(stDatVA.sAmbiente[1], sValor); stDatVA.iNumAmbiente++; }
		if(strcmp(sVariable, "sAmbiente02")==0) { strcpy(stDatVA.sAmbiente[2], sValor); stDatVA.iNumAmbiente++; }
		if(strcmp(sVariable, "sAmbiente03")==0) { strcpy(stDatVA.sAmbiente[3], sValor); stDatVA.iNumAmbiente++; }
		if(strcmp(sVariable, "sAmbiente04")==0) { strcpy(stDatVA.sAmbiente[4], sValor); stDatVA.iNumAmbiente++; }
		if(strcmp(sVariable, "sAmbiente05")==0) { strcpy(stDatVA.sAmbiente[5], sValor); stDatVA.iNumAmbiente++; }
		if(strcmp(sVariable, "sAmbiente06")==0) { strcpy(stDatVA.sAmbiente[6], sValor); stDatVA.iNumAmbiente++; }
		if(strcmp(sVariable, "sAmbiente07")==0) { strcpy(stDatVA.sAmbiente[7], sValor); stDatVA.iNumAmbiente++; }
		if(strcmp(sVariable, "sAmbiente08")==0) { strcpy(stDatVA.sAmbiente[8], sValor); stDatVA.iNumAmbiente++; }
		if(strcmp(sVariable, "sAmbiente09")==0) { strcpy(stDatVA.sAmbiente[9], sValor); stDatVA.iNumAmbiente++; }
		if(strcmp(sVariable, "sAmbiente10")==0) { strcpy(stDatVA.sAmbiente[10], sValor); stDatVA.iNumAmbiente++; }
		if(strcmp(sVariable, "sAmbiente11")==0) { strcpy(stDatVA.sAmbiente[11], sValor); stDatVA.iNumAmbiente++; }
		if(strcmp(sVariable, "sAmbiente12")==0) { strcpy(stDatVA.sAmbiente[12], sValor); stDatVA.iNumAmbiente++; }
		if(strcmp(sVariable, "sAmbiente13")==0) { strcpy(stDatVA.sAmbiente[13], sValor); stDatVA.iNumAmbiente++; }

		if(strcmp(sVariable, "sArchResult")==0) strcpy(stDatVA.sArchResult, sValor);
		if(strcmp(sVariable, "iNumCiclos")==0) stDatVA.iNumCiclos= atoi(sValor);
		if(strcmp(sVariable, "fMaximoError")==0) stDatVA.fMaximoError = (float) atof(sValor);

	}
	fclose(fpInicio);
};

//Hace el encabezado del archivo de resultados
void Inicializa::vArchResult()
{
    //Leidos de una vez los par�metros de simulaci�n, comienza a simular
	FILE *fpSimular;
	fpSimular = fopen(stDatVA.sArchResult, "a+t");
	fprintf(fpSimular,"MOTOR13. Simbiosis. Parte 1. \n");
	fprintf(fpSimular,"Ambientes. Total: [%d]\n", stDatVA.iNumAmbiente);
	for (unsigned int iContAmb=0; iContAmb<stDatVA.iNumAmbiente; iContAmb++)
		fprintf(fpSimular, "[%d] %s\n", iContAmb, stDatVA.sAmbiente[iContAmb]);

	fprintf(fpSimular,"\nPosibilidades:\n");
	fprintf(fpSimular,"1. Tipo de Instrucciones. If Condicional: %d, Asignacion: %d\n", stDatVA.iPosibIf, stDatVA.iPosibSet);
	fprintf(fpSimular,"2. En Instrucciones de If Condicional, el operador de comparacion es:  '==':%d, '>':%d, '<':%d, '!=':%d\n", stDatVA.iPosIg, stDatVA.iPosMay, stDatVA.iPosMen, stDatVA.iPosDif);
	fprintf(fpSimular,"3. Longitud de la expresi�n (n�mero de operadores): %d\n\n", stDatVA.iLongExpr);
	fprintf(fpSimular,"4. Construcci�n de las expresiones, posiblidad de salir X=%d, Parentesis:%d, N�meros=%d\n", stDatVA.iPosibX, stDatVA.iPosibP, stDatVA.iPosibN);
	fprintf(fpSimular,"5. Variables que se asignaran, compararan o estaran al interior de las expresiones: W=%d, X=%d, Y=%d, Z=%d\n", stDatVA.iPosW, stDatVA.iPosX, stDatVA.iPosY, stDatVA.iPosZ);
	fprintf(fpSimular,"\n");
	fprintf(fpSimular,"N�mero de ciclos CPU: %d\n", stDatVA.iNumCiclos);
        fprintf(fpSimular,"Error m�ximo de adaptaci�n: %f\n\n\n", stDatVA.fMaximoError);
	fclose(fpSimular);
};

void Inicializa::vGrabaResult(int iTipResult, char *sMensaje, unsigned int iContIntentos, float fErrOrg)
{
	FILE *fpSimular;
	time_t ltime;

	fpSimular = fopen(stDatVA.sArchResult, "a+t");

	if (iTipResult==1)
	{
		time( &ltime );
		fprintf(fpSimular,"Fecha: %s", ctime( &ltime ) );
	}
	else
		fprintf(fpSimular,"Intento: [%d]  Aproximaci�n: [%f]\n", iContIntentos, fErrOrg);

	fprintf(fpSimular,"%s\n", sMensaje);
	fclose(fpSimular);
};

void Inicializa::vImprRelac(char *sOrganismo, unsigned int iEntrada, unsigned int iSalida, float fError)
{
	FILE *fpSimular;

	fpSimular = fopen(stDatVA.sArchResult, "a+t");

	fprintf(fpSimular,"Ambientes Entrada: [%d] Salida: [%d]\n", iEntrada, iSalida);
        fprintf(fpSimular,"Error: %f\n", fError);
	fprintf(fpSimular,"Organismo\n%s\n\n", sOrganismo);
	fclose(fpSimular);
};
