/*
Autor:		Rafael Alberto Moreno Parra
URL:		http://www.geocities.com/krousky
Clase:		MedioAmbiente
Lenguaje:	C++

Prop�sito:
Clase de administraci�n del medio ambiente (serie num�rica)

M�todos:
vDeshaceIO: Toma la serie en cadena (string) y la lleva
            a un vector de enteros.

*/

class MedioAmbiente
{
public:
	int iCodAmbiente; //C�digo �nico de Ambiente
    float m_fAmbiente[50]; //Valores del Ambiemte
    unsigned int m_iContador; //Contador de n�mero de digitos del ambiente

    void vDeshaceIO(char *m_sSerieNum);
};