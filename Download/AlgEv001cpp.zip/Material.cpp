/*
[A-Life]: Investigaci�n sobre Vida Artificial. El Algoritmo Evolutivo.

Autor: Rafael Alberto Moreno Parra. enginelife@hotmail.com
URL:   http://www.geocities.com/krousky
Fecha: 16 de Enero de 2001

Simulaci�n:  AlgEvo001
Herramienta: Microsoft Visual C++ 6.0

Objetivo:
Dado un Universo, este esta lleno de ambientes, hay una serie de
elementos (materia) que reaccionan al estado del ambiente, una serie
de seres vivos comandados por el "algoritmo evolutivo", buscan conseguir
dichos elementos usando estrat�gias como desplazamiento, colecci�n de nuevos
elementos, etc...

*/

#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "Material.h"
#include "EvalExpr.h"
#include "Mutacion.h"


/* Suma o resta energ�a dependiendo de como es el ambiente */
signed int Material::iEnergia(float fValAmbiente)
{
	EvalExpr objEvalExpr;

	float fResult = objEvalExpr.dCapturaEcuacion(m_sEcuacion, fValAmbiente, 0);

	if (fResult <= 0 )
		return -1;
	else
		return 1;
};

void Material::vInicia(unsigned int iID, unsigned int iXmin, unsigned int iYmin, unsigned int iXmax, unsigned int iYmax)
{
	/* ID del material */
	m_iIDmat = iID;

	/* Posiciona al azar el material entre los l�mites del Universo */
	m_iPosX = rand() % (iXmax - iXmin) + iXmin;
	m_iPosY = rand() % (iYmax - iYmin) + iYmin;


	/* Al principio no esta usado por ningun organismo */
	m_iUsado = MAT_NOOCUPADO;
	

	/* Ecuaci�n que define el comportamiento del material f(x) */
	Mutacion objMuta;

	objMuta.vIniLista(33,33,0,34);
	objMuta.vCreaExpresion(33,33,0,34,10);
	strcpy(m_sEcuacion, objMuta.sExpresion);
	printf("Material [%d] m_iPosX=[%d] m_iPosY=[%d] Comportamiento [%s]\n", m_iIDmat, m_iPosX, m_iPosY, m_sEcuacion);
};


