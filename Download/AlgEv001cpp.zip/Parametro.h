/*
[A-Life]: Investigaci�n sobre Vida Artificial. El Algoritmo Evolutivo.

Autor: Rafael Alberto Moreno Parra. enginelife@hotmail.com
URL:   http://www.geocities.com/krousky
Fecha: 16 de Enero de 2001

Simulaci�n:  AlgEvo001
Herramienta: Microsoft Visual C++ 6.0

Objetivo:
Dado un Universo, este esta lleno de ambientes, hay una serie de
elementos (materia) que reaccionan al estado del ambiente, una serie
de seres vivos comandados por el "algoritmo evolutivo", buscan conseguir
dichos elementos usando estrat�gias como desplazamiento, colecci�n de nuevos
elementos, etc...

*/

// Ambientes
#define AMB_LONGEXPR 50

// Mutacion
#define MUT_LONGEXPR 130
#define MUT_TAMANOPILALISTA 101 //Representa el 100%

// Material
#define MAT_LONGEXPR 30
#define MAT_OCUPADO 1
#define MAT_NOOCUPADO 0

// Universo
#define UNI_NUMAMBIENTE 10
#define UNI_NUMMATERIAL 100
#define UNI_NUMORGANISMO 10
#define UNI_INIMINX 0
#define UNI_INIMINY 0
#define UNI_INIMAXX 200
#define UNI_INIMAXY 200

//Organismo
#define ORG_NUMMAXMAT 5 //Maximo numero de materiales
#define ORG_ESTABLE 50
#define ORG_VIVO 1
#define ORG_MUERTO 0
#define ORG_TOLMIN 10
#define ORG_TOLMAX 100


