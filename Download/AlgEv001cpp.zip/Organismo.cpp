/*
[A-Life]: Investigaci�n sobre Vida Artificial. El Algoritmo Evolutivo.

Autor: Rafael Alberto Moreno Parra. enginelife@hotmail.com
URL:   http://www.geocities.com/krousky
Fecha: 16 de Enero de 2001

Simulaci�n:  AlgEvo001
Herramienta: Microsoft Visual C++ 6.0

Objetivo:
Dado un Universo, este esta lleno de ambientes, hay una serie de
elementos (materia) que reaccionan al estado del ambiente, una serie
de seres vivos comandados por el "algoritmo evolutivo", buscan conseguir
dichos elementos usando estrat�gias como desplazamiento, colecci�n de nuevos
elementos, etc...

*/
#include <stdlib.h>

#include "Parametro.h"
#include "Organismo.h"

void Organismo::vNace()
{
	m_iEstabilidad = ORG_ESTABLE;
	m_iVivo = ORG_VIVO;
	
	m_iToleranciaMin = ORG_TOLMIN;
	m_iToleranciaMax = ORG_TOLMAX;
}