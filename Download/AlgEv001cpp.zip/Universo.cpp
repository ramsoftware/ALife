/*
[A-Life]: Investigaci�n sobre Vida Artificial. El Algoritmo Evolutivo.

Autor: Rafael Alberto Moreno Parra. enginelife@hotmail.com
URL:   http://www.geocities.com/krousky
Fecha: 16 de Enero de 2001

Simulaci�n:  AlgEvo001
Herramienta: Microsoft Visual C++ 6.0

Objetivo:
Dado un Universo, este esta lleno de ambientes, hay una serie de
elementos (materia) que reaccionan al estado del ambiente, una serie
de seres vivos comandados por el "algoritmo evolutivo", buscan conseguir
dichos elementos usando estrat�gias como desplazamiento, colecci�n de nuevos
elementos, etc...

*/
#include <stdlib.h>
#include <stdio.h>

#include "Universo.h"

//Constructor
Universo::Universo()
{
	time(&ltime1);
	m_iTotalAmb = UNI_NUMAMBIENTE;
	m_iTotalMat = UNI_NUMMATERIAL;
	m_iTotalOrg = UNI_NUMORGANISMO;
	m_iXmin = UNI_INIMINX;
	m_iYmin = UNI_INIMINY;
	m_iXmax = UNI_INIMAXX;
	m_iYmax	= UNI_INIMAXY;
}


//Inicializa la semilla dependiendo del tiempo
void Universo::IniciaSemillaT()
{
	time_t ltime2;
	do
	{
		time(&ltime2);
	}while(ltime2==ltime1);
	srand( ltime2 );
	ltime1 = ltime2;
}

//Inicializa la semilla aleatoriamente
void Universo::IniciaSemillaR()
{
	srand(rand());
};


//Genera ambientes, materiales, organismos
void Universo::BigBang(void)
{
	unsigned int iCont, iCont1, iMaterial;

	IniciaSemillaT(); // Inicia proceso aleatorio


	//Crea los ambientes
	for (iCont=0; iCont < m_iTotalAmb; iCont++)
		objAmb[iCont].vInicia(iCont, m_iXmin, m_iYmin, m_iXmax, m_iYmax);

	//Crea los materiales
	for (iCont=0; iCont < m_iTotalMat; iCont++)
		objMat[iCont].vInicia(iCont, m_iXmin, m_iYmin, m_iXmax, m_iYmax);

	//Crea los organismos (relaciones estables entre materiales)
	for (iCont=0; iCont < m_iTotalOrg; iCont++)
	{
		objOrg[iCont].vNace();

		for (iCont1=0; iCont1 < ORG_NUMMAXMAT; iCont1++) 
		{
			do
			{
				iMaterial = rand()%m_iTotalMat; 
			}while (objMat[iMaterial].m_iUsado==MAT_OCUPADO);

			objOrg[iCont].m_iIDmaterial[iCont1] = objMat[iMaterial].m_iIDmat;
			objMat[iMaterial].m_iUsado=MAT_OCUPADO;
		}
	}
}

/* Dado un punto, que valor tiene este cubierto de 0 a N ambientes */
float Universo::fValPosXY(unsigned int iPosX, unsigned int iPosY)
{
	unsigned int iCont;
	float fValor=0;

	for (iCont=0; iCont < m_iTotalAmb; iCont++)
		fValor += objAmb[iCont].fValCoord(iPosX, iPosY);

	return fValor;
};

/* Ciclo de la vida */
void Universo::vCicloVida()
{
	unsigned int iCont, iContinua;

	for(;;) // Es un ciclo infinito hasta que todos mueran
	{
		iContinua=0;
		printf("\nSobreviven: ");
		for (iCont=0; iCont < m_iTotalOrg; iCont++)
		{
			if ( objOrg[iCont].m_iVivo == ORG_VIVO )
			{
				iContinua=1;
				printf("%d,", iCont);
			}
		}
		if (iContinua==0) break;
		vEvaluaOrganismo();
	}
	printf("\n");
}




/* Evalua el Organismo */
void Universo::vEvaluaOrganismo()
{
	unsigned int iCont, iCont1, iMaterial, iPosX, iPosY;
	signed int iEnergia;
	float fValor;

	/* Toma cada organismo que a�n viva */
	for (iCont=0; iCont < m_iTotalOrg; iCont++)
	{
		if ( objOrg[iCont].m_iVivo == ORG_VIVO )
		{
			for (iCont1=0; iCont1 < ORG_NUMMAXMAT; iCont1++)
			{
				// �De que material esta hecho?
				iMaterial = objOrg[iCont].m_iIDmaterial[iCont1];

				// �Donde esta ubicado ese material?
				iPosX = objMat[iMaterial].m_iPosX;
				iPosY = objMat[iMaterial].m_iPosY;

				// �Que ambiente hay en esa ubicaci�n?
				fValor = fValPosXY(iPosX, iPosY);

				//�Como reacciona el material a ese ambiente?
				iEnergia = objMat[iMaterial].iEnergia(fValor);

				//�Como afecta esa reacci�n al organismo?
				objOrg[iCont].m_iEstabilidad += iEnergia;
			}

			// �Sobrevivir� el organismo?
			if ( objOrg[iCont].m_iEstabilidad > objOrg[iCont].m_iToleranciaMax ||
				 objOrg[iCont].m_iEstabilidad < objOrg[iCont].m_iToleranciaMin)
				objOrg[iCont].m_iVivo = ORG_MUERTO;
		}
	}
}

	



