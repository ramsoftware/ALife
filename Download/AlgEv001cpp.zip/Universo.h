/*
[A-Life]: Investigaci�n sobre Vida Artificial. El Algoritmo Evolutivo.

Autor: Rafael Alberto Moreno Parra. enginelife@hotmail.com
URL:   http://www.geocities.com/krousky
Fecha: 16 de Enero de 2001

Simulaci�n:  AlgEvo001
Herramienta: Microsoft Visual C++ 6.0

Objetivo:
Dado un Universo, este esta lleno de ambientes, hay una serie de
elementos (materia) que reaccionan al estado del ambiente, una serie
de seres vivos comandados por el "algoritmo evolutivo", buscan conseguir
dichos elementos usando estrat�gias como desplazamiento, colecci�n de nuevos
elementos, etc...

*/
#include <time.h>

#include "Ambiente.h"
#include "Material.h"
#include "Organismo.h"

/* Universo: Contenedor de los diferentes ambientes, materiales, energ�a y organismos
   Controla la generaci�n aleatoria (caos) */
class Universo
{
public: 
	/* Se definen UNI_NUMAMBIENTE ambientes primarios */
	unsigned int m_iTotalAmb;
	Ambiente objAmb[UNI_NUMAMBIENTE];

	/* Se definen UNI_NUMMATERIAL materiales */
	unsigned int m_iTotalMat;
	Material objMat[UNI_NUMMATERIAL];

	/* Se definen UNI_NUMORG organismos */
	unsigned int m_iTotalOrg;
	Organismo objOrg[UNI_NUMORGANISMO];

	/* Extremos del Universo rectangular */
	unsigned int m_iXmin, m_iYmin, m_iXmax, m_iYmax;

	//Inicia la semilla de los n�meros aleatorios
    time_t ltime1;
	void IniciaSemillaT();
	void IniciaSemillaR();

	/* Constructor */
	Universo(void);

	/* Crea ambientes, materiales y organismos al azar */
	void BigBang(void);
		
	/* Dado un punto, que valor tiene este cubierto de 0 a N ambientes */
	float fValPosXY (unsigned int iPosX, unsigned int iPosY);

	/* Ciclo de vida. Que organismo al final resiste */
	void vCicloVida(void);

	/* Evalua el Organismo */
	void vEvaluaOrganismo(void);

};
