//Aqui nace la mutacion, el ser vivo recibe esta cadena
class cMutacion {
public:
    cMutacion(); //Constructor
	void vIniSemilla(void);
    int vIniLista(int iProbN, int iProbX, int iProbP);
	void vCrearExpresion(int iLongExpr, int iPosibX, int iPosibP, int iPosibN);
    void vLlenaconNulos(char *sbCadena, int iLong);

    char sExpresion[400]; //La expresion que se genera
	long iSemilla;
    char sOperNumPar[101]; //Por velocidad: Almacena un listado de Numeros, Operadores, Variables X, Parentesis
                               //para cuando se construyan las expresiones sea muy rapido.
};