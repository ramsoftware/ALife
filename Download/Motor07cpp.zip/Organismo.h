/*
* @(#)ArtificialLifeEngine.java
* 
* Es un conjunto de subrutinas que simulando la Evoluci�n de las Especies,
* puedan crear programas (codigo fuente) que se adapten a un ambiente en particular.
* Todo software tiene entradas y salidas. Las entradas son procesadas y se emite un resultado
* que son las salidas. Este proceso es implementado por un Dise�ador/Programador.
* Ahora bien, si usamos un sistema que usa principios evolutivos, este proceso puede nacer
* por si solo, esto tiene sus ventajas:
* 1. No se requiere de personal humano (programadores) para crear el proceso.
* 2. Puede disminuirse o anularse la posiblidad de errores en el proceso.
* 3. Ante nuevos requerimientos (nuevas entradas o formatos de salida) el proceso se adaptara.
* 4. Capaz de encontrar o acercarse a soluciones de problemas muy complejos.
* 
* El obst�culo:
*  Conseguir un proceso que ofrezca salidas esperadas a unas entradas, usando principios evolutivos
*  puede tardar un tiempo considerablemente alto. Con los nuevos procesadores a mayores velocidades y
*  un buen algoritmo evolutivo, el tiempo puede ser disminuido, de tal manera que podria entrar a
*  competir con programadores humanos.
*/

#include "Gen.h"
#include "EvalExpr.h"
#include "cMutacion.h"

class Organismo
{
public:
    Gen m_oGen[67]; //Genes del ser vivo
    EvalExpr m_eEvalua[67]; //Expresiones de asignacion evaluadas previamente
	cMutacion cMuta; //Todo sobre la construcci�n aleatoria de expresiones

    int m_iMaxGenOrg; //Maximo numero de genes para el organismo
    int m_iMaxiCiclos; //Maximo numero de ciclos que se gastaran para evaluar el organismo
    
	void sDisplayADN(char *sbADN);
    void vCreaADN (bool bGenRandom, int iMaxGenes,
                   int iPosibIf, int iPosibSet,
                   int iPosW,  int iPosX, int iPosY, int iPosZ,
                   int iPosIg, int iPosMay, int iPosMen, int iPosDif,
                   int iLongExpr, int iPosibX, int iPosibP, int iPosibN);
    void vEvaluaPrevio(void);
    float fEvalOrganismo (float fValX);
    /* Crea una linea de codigo fuente (la llam� Gen). El formato es:
       label, [, IF/SET, Variable, =/>/</!, (, expresion, ), Goto, Label, ]
       para mayor velocidad, se ubica en una clase el Gen */
    void vHaceGen(int iLabel, int iMaxGenes,
                  int iPosibIf, int iPosibSet,
                  int iPosW,  int iPosX, int iPosY, int iPosZ,
                  int iPosIg, int iPosMay, int iPosMen, int iPosDif,
                  int iLongExpr, int iPosibX, int iPosibP, int iPosibN);
    //Esta subrutina retira los Genes (instrucciones) que no se ejecutaron durante la 
    //validaci�n del ambiente
    void Optimiza();

	//Inicia la semilla de los n�meros aleatorios
	void IniciaSemilla();

};