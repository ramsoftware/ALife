/* Autor: Rafael Alberto Moreno Parra
   Fecha: 09 de Febrero del 2000

ENGINE06. Escrito en C++ (Compilado en Visual C++ 6.0)

Objetivos:
1. Lograr mayor velocidad de procesamiento.
2. Seguir la pista de procesamiento de la simulaci�n usando archivos
3. Evitar que la aplicaci�n cuando se cierre pierda el proceso de simulaci�n.

Simulaciones Planeadas:
I. Ambiente Alterno, Incremental y Decremental
   a. Mutaci�n (50%) y Generaci�n Aleatoria (50%)  es igual a Engine05
   b. Optimizaci�n/Mutaci�n (50%) y Generaci�n Aleatoria (50%)
   c. Optimizaci�n/Adici�n (50%) y Generaci�n Aleatoria (50%)
   d. Optimizaci�n/Mutaci�nIFSETinutil (50%) y Generaci�n Aleatoria (50%)
   e. Optimizaci�n/Mutaci�n/Adici�n al tiempo (50%) y Generaci�n Aleatoria (50%)
   f. Optimizaci�n/Mutaci�n/Mutaci�nIFSETinutil al tiempo (50%) y Generaci�n Aleatoria (50%)
   g. Optimizaci�n/Adici�n/Mutaci�nIFSETinutil al tiempo (50%) y Generaci�n Aleatoria (50%)
   h. Optimizaci�n/Mutacion/Adici�n/Mutaci�nIFSETinutil al tiempo (50%) y Generaci�n Aleatoria (50%)
   i. Optimizaci�n/Mutacion/Adici�n/Mutaci�nIFSETinutil usando uno y despues el otro (50%) y Generaci�n Aleatoria (50%)


Esto se graficar� en Excel para ver el comportamiento de la simulaci�n a trav�s del tiempo.
Nuevos estudios:

  I.   Estudio de cada gen, como colabora para la adaptaci�n.
  II.  Reproducci�n.
  III. Comportamiento Sinusoidal.
  IV.Construcci�n de Ambientes (objetos, propiedades, relaciones con otros).
*/

#include <stdio.h>
#include <string.h>
#include <math.h>
#include <afx.h>
#include "Organismo.h"
#include "MasApto.h"
#include "MedioAmbiente.h"

void main(void);
void Simular(void);


//Programa Principal
void main()
{
    Simular();
}

void Simular()
{
    //Donde guarda los resultados
	FILE *fpSimular;

   	//Variables para simular, las cambia el usuario
	int m_iPosibIf= 50; //Posibilidad de que la instrucci�n sea IF
    int m_iPosibSet= 50; //Posibilidad de que la instrucci�n sea Asignaci�n
    int m_iPosW= 25; //Posibilidad de que la variable activa sea W
    int m_iPosX= 25; //Posibilidad de que la variable activa sea X
    int m_iPosY= 25; //Posibilidad de que la variable activa sea Y
    int m_iPosZ= 25; //Posibilidad de que la variable activa sea Z
    int m_iPosIg= 25; //Posibilidad de comparativo =
    int m_iPosMay= 25;//Posibilidad de comparativo >
    int m_iPosMen= 25;//Posibilidad de comparativo <
    int m_iPosDif= 25;//Posibilidad de comparativo !
    int m_iLongExpr= 2; //Longitud de las expresiones
    int m_iPosibX= 33; //Posibilidad de salir X
    int m_iPosibP= 33; //Posibilidad de salir Parentesis
    int m_iPosibN= 34; //Posibilidad de salir N�mero
	int m_iNumCiclos=130; //Maximo CPU
	unsigned int m_iNumIntentos=100000; //Maximo numero de intentos
	bool m_bGenRandom = true;  //�Genera 1 a N?

	MedioAmbiente objAmbiente; //El ambiente
	char sEntrada[200]="1,2,3,4,5,6,7,8,9,10,11,12,13,";
	char sSalidas[200]="-1,2,-3,4,-5,6,-7,8,-9,10,-11,12,-13,";

	fpSimular = fopen("Simular.txt", "a+t");
	//fprintf(fpSimular,"ENGINE06. Optimiza el mas apto y Muta una instrucci�n.\n");
	fprintf(fpSimular,"ENGINE05. Muta una instrucci�n.\n");
	fprintf(fpSimular,"Serie Entrada: %s\n", sEntrada);
	fprintf(fpSimular,"Serie Salida: %s\n", sSalidas);
	fprintf(fpSimular,"Intentos: %ld\n", m_iNumIntentos);
	fprintf(fpSimular,"CPU: %d\n", m_iNumCiclos);
	if (m_bGenRandom)
		fprintf(fpSimular,"Hay libertad de generar de 1 a N instrucciones\n\n");
	else
		fprintf(fpSimular,"Es obligatorio generar N instrucciones\n\n");
	fprintf(fpSimular,"Posibilidades:\n");
	fprintf(fpSimular,"1. Tipo de Instrucciones. If Condicional: %d, Asignacion: %d\n", m_iPosibIf, m_iPosibSet);
	fprintf(fpSimular,"2. En Instrucciones de If Condicional, el operador de comparacion es:  '==':%d, '>':%d, '<':%d, '!=':%d\n", m_iPosIg, m_iPosMay, m_iPosMen, m_iPosDif);
	fprintf(fpSimular,"3. Longitud de la expresi�n (n�mero de operadores): %d\n\n", m_iLongExpr);
	fprintf(fpSimular,"4. Construcci�n de las expresiones, posiblidad de salir X=%d, Parentesis:%d, N�meros=%d\n", m_iPosibX, m_iPosibP, m_iPosibN);
	fprintf(fpSimular,"5. Variables que se asignaran, compararan o estaran al interior de las expresiones: W=%d, X=%d, Y=%d, Z=%d\n", m_iPosW, m_iPosX, m_iPosY, m_iPosZ);
	fclose(fpSimular);

	//Variables de la simulaci�n
	int m_iNumGenes=0;  //Contador de genes(instrucciones a generar)
	bool m_bEvaluaCiclo=true; //Usada para el siguiente ciclo que aumenta genes
    unsigned int m_iContIntentos=0; //Contador de intentos
	float m_fPuesto1=(float)999999; //Variable para chequear los algoritmos mas aptos
	int iMutar=1; //Bandera para variar entre Mutaci�n y Generaci�n Espont�nea
	int iGen; //Contador, usado en el ciclo de mutaci�n.
	float fResult; //Resultado de la evaluaci�n del organismo en un item del ambiente
	float fErrOrg; //Aproximaci�n del Algoritmo (Organismo) al Ambiente
	int iNumCiclo; //Que gen mutara
	int iCont;


    //Variables que guardan lo mejor
	float m_fOrg05Gen; //Mejor aproximaci�n en 5 instrucciones
	char m_Org05Gen[4500]; //Mejor Algoritmo en 5 instrucciones

	float m_fOrg10Gen; //Mejor aproximaci�n en 10 instrucciones
	char m_Org10Gen[4500]; //Mejor Algoritmo en 10 instrucciones

	float m_fOrg15Gen; //Mejor aproximaci�n en 15 instrucciones
	char m_Org15Gen[4500]; //Mejor Algoritmo en 15 instrucciones
    
	float m_fOrg20Gen; //Mejor aproximaci�n en 20 instrucciones
	char m_Org20Gen[4500]; //Mejor Algoritmo en 20 instrucciones
	
	float m_fOrg25Gen; //Mejor aproximaci�n en 25 instrucciones
	char m_Org25Gen[4500]; //Mejor Algoritmo en 25 instrucciones

	float m_fOrg30Gen; //Mejor aproximaci�n en 30 instrucciones
	char m_Org30Gen[4500]; //Mejor Algoritmo en 30 instrucciones

	float m_fOrg35Gen; //Mejor aproximaci�n en 35 instrucciones
	char m_Org35Gen[4500]; //Mejor Algoritmo en 35 instrucciones

	float m_fOrg40Gen; //Mejor aproximaci�n en 40 instrucciones
	char m_Org40Gen[4500]; //Mejor Algoritmo en 40 instrucciones

	float m_fOrg45Gen; //Mejor aproximaci�n en 45 instrucciones
	char m_Org45Gen[4500]; //Mejor Algoritmo en 45 instrucciones

	float m_fOrg50Gen; //Mejor aproximaci�n en 50 instrucciones
	char m_Org50Gen[4500]; //Mejor Algoritmo en 50 instrucciones
	
	float m_fOrg55Gen; //Mejor aproximaci�n en 55 instrucciones
	char m_Org55Gen[4500]; //Mejor Algoritmo en 55 instrucciones

	float m_fOrg60Gen; //Mejor aproximaci�n en 60 instrucciones
	char m_Org60Gen[4500]; //Mejor Algoritmo en 60 instrucciones
	

	//Objeto que guarda el mejor objeto organismo 	
	MasApto OrgMasApto;

	//Objeto que guarda el organismo a probar en el ambiente
	Organismo OrgPrueba;
	OrgPrueba.cMuta.vIniLista(m_iPosibN, m_iPosibX, m_iPosibP);
	OrgPrueba.m_iMaxiCiclos =  m_iNumCiclos;
	OrgPrueba.vCreaADN(false, 65,
                    m_iPosibIf, m_iPosibSet,
                    m_iPosW, m_iPosX, m_iPosY, m_iPosZ, 
                    m_iPosIg, m_iPosMay, m_iPosMen, m_iPosDif,
                    m_iLongExpr, m_iPosibX, m_iPosibP, m_iPosibN);
	//================================================================

    //Deduce el ambiente
	objAmbiente.vDeshaceIO(sEntrada, 1);
	objAmbiente.vDeshaceIO(sSalidas, 2);

    //Ciclo de evaluacion de 5 a 60 instrucciones
	while(true) 
	{
		    if (m_bEvaluaCiclo)
		    {
				fpSimular = fopen("Simular.txt", "a+t");
				fprintf(fpSimular,"\n\n===========================================================\n\n");
				fclose(fpSimular);

		        m_iNumGenes += 5; // Aumenta de 5 en 5 las instrucciones
		        m_bEvaluaCiclo = false;
		        m_iContIntentos = 0;
		        m_fPuesto1 = (float) 999999;
		        iMutar = 1;
				
   	            OrgPrueba.IniciaSemilla();
				OrgPrueba.vCreaADN(false, m_iNumGenes,
                                   m_iPosibIf, m_iPosibSet,
                                   m_iPosW, m_iPosX, m_iPosY, m_iPosZ, 
                                   m_iPosIg, m_iPosMay, m_iPosMen, m_iPosDif,
                                   m_iLongExpr, m_iPosibX, m_iPosibP, m_iPosibN);
                
				//Inicializa tambi�n la mutaci�n
                for (int iCopia=1; iCopia <= OrgPrueba.m_iMaxGenOrg; iCopia++)
                {
                    OrgMasApto.m_oGen[iCopia].cOperacion = OrgPrueba.m_oGen[iCopia].cOperacion;
                    OrgMasApto.m_oGen[iCopia].cTipInst = OrgPrueba.m_oGen[iCopia].cTipInst;
                    OrgMasApto.m_oGen[iCopia].cVarActiva = OrgPrueba.m_oGen[iCopia].cVarActiva;
                    OrgMasApto.m_oGen[iCopia].cVariable = OrgPrueba.m_oGen[iCopia].cVariable;
                    OrgMasApto.m_oGen[iCopia].iGotoLabel = OrgPrueba.m_oGen[iCopia].iGotoLabel;
                    strcpy(OrgMasApto.m_oGen[iCopia].sbExpresion, OrgPrueba.m_oGen[iCopia].sbExpresion);
                }
                OrgMasApto.m_iMaxGenOrg = OrgPrueba.m_iMaxGenOrg;
		    }

		    if (m_iNumGenes >= 65 ) break; //Hace hasta 60 instrucciones (genes)

			//Comienza la simulaci�n, este es el ciclo que mas CPU consume
		    while (m_iContIntentos < m_iNumIntentos)
			{
		        m_iContIntentos++; // Intentos de generaci�n

                //Genera una vez, Muta la siguiente y asi sucesivamente
	            switch(iMutar)
                {
                    case 1: //Genera aleatoriamente el ser vivo
	                        OrgPrueba.vCreaADN(m_bGenRandom, m_iNumGenes,
                                  m_iPosibIf, m_iPosibSet,
                                  m_iPosW, m_iPosX, m_iPosY, m_iPosZ, 
                                  m_iPosIg, m_iPosMay, m_iPosMen, m_iPosDif,
                                  m_iLongExpr, m_iPosibX, m_iPosibP, m_iPosibN);
                            iMutar = 2;
                            break;
                    case 2: /* Muta el mejor de su especie */
                            for (int iCopia=1; iCopia <= OrgMasApto.m_iMaxGenOrg; iCopia++)
                            {
								OrgPrueba.m_oGen[iCopia].bCambiacVariable = false;
								OrgPrueba.m_oGen[iCopia].bEjecuta = false;
								OrgPrueba.m_oGen[iCopia].bIFtrue = false;
                                OrgPrueba.m_oGen[iCopia].cOperacion = OrgMasApto.m_oGen[iCopia].cOperacion;
                                OrgPrueba.m_oGen[iCopia].cTipInst = OrgMasApto.m_oGen[iCopia].cTipInst;
                                OrgPrueba.m_oGen[iCopia].cVarActiva = OrgMasApto.m_oGen[iCopia].cVarActiva;
                                OrgPrueba.m_oGen[iCopia].cVariable = OrgMasApto.m_oGen[iCopia].cVariable;
                                OrgPrueba.m_oGen[iCopia].iGotoLabel = OrgMasApto.m_oGen[iCopia].iGotoLabel;
                                strcpy(OrgPrueba.m_oGen[iCopia].sbExpresion,OrgMasApto.m_oGen[iCopia].sbExpresion);
                            }
                            OrgPrueba.m_iMaxGenOrg = OrgMasApto.m_iMaxGenOrg;

                            /* Muta un Gen al azar... */
							iNumCiclo = abs(rand() % OrgPrueba.m_iMaxGenOrg ) + 1;
                            OrgPrueba.vHaceGen(iNumCiclo, OrgPrueba.m_iMaxGenOrg,
                                            m_iPosibIf, m_iPosibSet,
                                            m_iPosW, m_iPosX, m_iPosY, m_iPosZ, 
                                            m_iPosIg, m_iPosMay, m_iPosMen, m_iPosDif,
                                            m_iLongExpr, m_iPosibX, m_iPosibP, m_iPosibN);
                            iMutar = 1;
                            break;
                }     
                OrgPrueba.vEvaluaPrevio();
    
				fErrOrg=0;
	            for (iCont=0; iCont<objAmbiente.m_iContEntra; iCont++)
	            {
	                fResult = OrgPrueba.fEvalOrganismo((float)objAmbiente.m_iEntradas[iCont]);
	                fErrOrg += fabs(fResult-(float)objAmbiente.m_iSalidas[iCont]);
	            }

				/* Compara con el puesto anterior y si la aproximaci�n es menor reemplaza */
	            if (fErrOrg < m_fPuesto1)
	            {
	                m_fPuesto1 = fErrOrg;
                    //OrgPrueba.Optimiza(); //Nuevo. Engine06. Quita instrucciones de sobra.

                    //Almacena el mejor objeto organismo
                    for (int iCopia=1; iCopia <= OrgPrueba.m_iMaxGenOrg; iCopia++)
                    {
                        OrgMasApto.m_oGen[iCopia].cOperacion = OrgPrueba.m_oGen[iCopia].cOperacion;
                        OrgMasApto.m_oGen[iCopia].cTipInst = OrgPrueba.m_oGen[iCopia].cTipInst;
                        OrgMasApto.m_oGen[iCopia].cVarActiva = OrgPrueba.m_oGen[iCopia].cVarActiva;
                        OrgMasApto.m_oGen[iCopia].cVariable = OrgPrueba.m_oGen[iCopia].cVariable;
                        OrgMasApto.m_oGen[iCopia].iGotoLabel = OrgPrueba.m_oGen[iCopia].iGotoLabel;
                        strcpy(OrgMasApto.m_oGen[iCopia].sbExpresion, OrgPrueba.m_oGen[iCopia].sbExpresion);
                    }
                    OrgMasApto.m_iMaxGenOrg = OrgPrueba.m_iMaxGenOrg;

					switch (m_iNumGenes)
	                {
	                    case 5: m_fOrg05Gen = fErrOrg;
	                            OrgPrueba.sDisplayADN(m_Org05Gen);
								fpSimular = fopen("Simular.txt", "a+t");
								fprintf(fpSimular,"======= 5 Instrucciones ======= [%d]\n", m_iContIntentos);
								fprintf(fpSimular,"Aproximaci�n: [%f]\n", m_fOrg05Gen);
								fprintf(fpSimular,"%s\n\n",m_Org05Gen);
								fclose(fpSimular);
        	                    break;
	                    case 10:m_fOrg10Gen = fErrOrg;
	                            OrgPrueba.sDisplayADN(m_Org10Gen);
								fpSimular = fopen("Simular.txt", "a+t");
								fprintf(fpSimular,"======= 10 Instrucciones ======= [%d]\n", m_iContIntentos);
								fprintf(fpSimular,"Aproximaci�n: [%f]\n", m_fOrg10Gen);
								fprintf(fpSimular,"%s\n\n",m_Org10Gen);
								fclose(fpSimular);
								break;
	                    case 15:m_fOrg15Gen = fErrOrg;	                    
								OrgPrueba.sDisplayADN(m_Org15Gen);
								fpSimular = fopen("Simular.txt", "a+t");
								fprintf(fpSimular,"======= 15 Instrucciones ======= [%d]\n", m_iContIntentos);
								fprintf(fpSimular,"Aproximaci�n: [%f]\n", m_fOrg15Gen);
								fprintf(fpSimular,"%s\n\n",m_Org15Gen);
								fclose(fpSimular);
								break;
	                    case 20:m_fOrg20Gen = fErrOrg;
	                            OrgPrueba.sDisplayADN(m_Org20Gen);
								fpSimular = fopen("Simular.txt", "a+t");
								fprintf(fpSimular,"======= 20 Instrucciones ======= [%d]\n", m_iContIntentos);
								fprintf(fpSimular,"Aproximaci�n: [%f]\n", m_fOrg20Gen);
								fprintf(fpSimular,"%s\n\n",m_Org20Gen);
								fclose(fpSimular);
								break;
	                    case 25:m_fOrg25Gen = fErrOrg;	                    
	                            OrgPrueba.sDisplayADN(m_Org25Gen);
								fpSimular = fopen("Simular.txt", "a+t");
								fprintf(fpSimular,"======= 25 Instrucciones ======= [%d]\n", m_iContIntentos);
								fprintf(fpSimular,"Aproximaci�n: [%f]\n", m_fOrg25Gen);
								fprintf(fpSimular,"%s\n\n",m_Org25Gen);
								fclose(fpSimular);
								break;
	                    case 30:m_fOrg30Gen = fErrOrg;	                    
	                            OrgPrueba.sDisplayADN(m_Org30Gen);
								fpSimular = fopen("Simular.txt", "a+t");
								fprintf(fpSimular,"======= 30 Instrucciones ======= [%d]\n", m_iContIntentos);
								fprintf(fpSimular,"Aproximaci�n: [%f]\n", m_fOrg30Gen);
								fprintf(fpSimular,"%s\n\n",m_Org30Gen);
								fclose(fpSimular);
								break;
	                    case 35:m_fOrg35Gen = fErrOrg;
	                            OrgPrueba.sDisplayADN(m_Org35Gen);
								fpSimular = fopen("Simular.txt", "a+t");
								fprintf(fpSimular,"======= 35 Instrucciones ======= [%d]\n", m_iContIntentos);
								fprintf(fpSimular,"Aproximaci�n: [%f]\n", m_fOrg35Gen);
								fprintf(fpSimular,"%s\n\n",m_Org35Gen);
								fclose(fpSimular);
								break;
	                    case 40:m_fOrg40Gen = fErrOrg;	                    
	                            OrgPrueba.sDisplayADN(m_Org40Gen);
								fpSimular = fopen("Simular.txt", "a+t");
								fprintf(fpSimular,"======= 40 Instrucciones ======= [%d]\n", m_iContIntentos);
								fprintf(fpSimular,"Aproximaci�n: [%f]\n", m_fOrg40Gen);
								fprintf(fpSimular,"%s\n\n",m_Org40Gen);
								fclose(fpSimular);
                                break;
	                    case 45:m_fOrg45Gen = fErrOrg;	                    
	                            OrgPrueba.sDisplayADN(m_Org45Gen);
								fpSimular = fopen("Simular.txt", "a+t");
								fprintf(fpSimular,"======= 45 Instrucciones ======= [%d]\n", m_iContIntentos);
								fprintf(fpSimular,"Aproximaci�n: [%f]\n", m_fOrg45Gen);
								fprintf(fpSimular,"%s\n\n",m_Org45Gen);
								fclose(fpSimular);
								break;
	                    case 50:m_fOrg50Gen = fErrOrg;
	                            OrgPrueba.sDisplayADN(m_Org50Gen);
								fpSimular = fopen("Simular.txt", "a+t");
								fprintf(fpSimular,"======= 50 Instrucciones ======= [%d]\n", m_iContIntentos);
								fprintf(fpSimular,"Aproximaci�n: [%f]\n", m_fOrg50Gen);
								fprintf(fpSimular,"%s\n\n",m_Org50Gen);
								fclose(fpSimular);
								break;
						case 55:m_fOrg55Gen = fErrOrg;	                    
	                            OrgPrueba.sDisplayADN(m_Org55Gen);
								fpSimular = fopen("Simular.txt", "a+t");
								fprintf(fpSimular,"======= 55 Instrucciones ======= [%d]\n", m_iContIntentos);
								fprintf(fpSimular,"Aproximaci�n: [%f]\n", m_fOrg55Gen);
								fprintf(fpSimular,"%s\n\n",m_Org55Gen);
								fclose(fpSimular);
								break;
	                    case 60:m_fOrg60Gen = fErrOrg;	                    
	                            OrgPrueba.sDisplayADN(m_Org60Gen);
								fpSimular = fopen("Simular.txt", "a+t");
								fprintf(fpSimular,"======= 60 Instrucciones ======= [%d]\n", m_iContIntentos);
								fprintf(fpSimular,"Aproximaci�n: [%f]\n", m_fOrg60Gen);
								fprintf(fpSimular,"%s\n\n",m_Org60Gen);
								fclose(fpSimular);
								break;
	                } //Switch
	            } // End If
	        } // End While
	        m_bEvaluaCiclo = true;
	    } // End While(true)
}