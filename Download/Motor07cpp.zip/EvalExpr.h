class EvalExpr {
public:
	float dCapturaEcuacion(char *p, float x, float y);
	float dCicloEvalua(float x, float y);
	char ERRORMATEMATICO;
	int _matherr(struct exception *a);

private:
// Variables requeridas para el EvalExpr de expresiones.
	 char m_sAcum[30][50];
	 char m_iNumAcums; // variable que cuenta el numero de acums
	 char m_sVectorNumeros[27][20][10];
	 char m_sVectorOperador[27][27];
 	 float m_AcumFloat[30];
	 char m_sFuncion[19][16];
	 	
// m_sFuncion privadas del optimizador	
	void vOptimizador(char *p);
	void vReemplazarExpr( char *p,  char *sReemplazo,
		      char desde,  char hasta);
	void vArreglaAcumn();
	void vCicloAcumn();
	void vDesintegraAcumn( char *expresion,  char indicadorp);
	float dEvaluaExpresion(char indicadorp, float x, float y);

//m_sFuncion de cadena
	void vStringtoLower(char *p);
	void vEliminaEspacios(char *p);
	void vLeft(char *cad1, char *cad2, char num_letras);
	void vRight(char *cad1, char *cad2, char num_letras);
	void vMid(char *cad1, char *cad2, char desde, char hasta);

};