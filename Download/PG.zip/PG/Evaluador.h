/* Evaluador de Expresiones escrito en C++ */
#include "NodoSimple.h"
#include "NodoDoble.h"

#define NOERRORES 0
#define DIVISIONENTRECERO 1
#define ERRORARCOSENO 2
#define ERRORARCOCOSENO 3

class Evaluador
{
public:
	//Constructor
	Evaluador();

	//Evalua la sintaxis de la expresi�n matem�tica
	int iAnalizaSintaxis(char *);

	//Recibe la expresi�n matem�tica y la analiza dej�ndola construida en un grafo.
	void vAnaliza(char *);
	
	//Evalua la expresi�n ya analizada
	float fEvaluar(void);
	
	//Libera la memoria ocupada por el grafo
	void vLiberaMemoria();
	
	//Se activa si detecta un error matematico, caso contrario tiene el valor de cero
	int ERRORMATEMATICO;

	//Las variables
	float fVariables[256];

private:
	/* 	Llegan bloques como 2+  5-  6*  7-  3*   2^  4*  5/  6+  4N y debe quedar as�:
	   2+
	   5-
	   ACUM-   6* 7N
	   ACUM+   3/ ACUM * 5/ 6N
				  2^
				  4N
	   4N
	*/
	const char *cFuncion;

	void vNuevoBloque(float, unsigned char, unsigned char, NodoSimple *);
	
	//Eval�a r�pidamente una serie de solo sumas y restas, desviandose en multiplicaciones y divisiones
	float fEvaluaSumaResta(void);

	//Eval�a r�pidamente una serie de multiplicaciones y divisiones desviandose en potencias
	float fEvaluaMultiplicaDivide(NodoSimple *);
	
	//Eval�a r�pidamente una serie de potencias
	float fEvaluaPotencia(NodoSimple *);
	
	//Libera la memoria en forma recursiva navegando todo el grafo
	void vRecursivoLiberar(NodoSimple *);

	//Lista que tendr� la expresi�n analizada por acums
	NodoSimple *Analizado;
	NodoSimple *IniAnalizado;

	//Expresi�n simple como 3 + 5 - 2 + 1.5  - 7.6 + 2.471 - 6.901 - 0.0001
	NodoSimple *objNodo;
	
	//Mantiene la pista del �ltimo sumando
	NodoSimple *objPasea;

	//Mantiene la pista del �ltimo multiplicador
	NodoSimple *NodoMultip;

	//Mantiene la pista del �ltimo n�mero de potencia
	NodoSimple *NodoPotencia;

	//Es TRUE si se activa una desviaci�n de Multiplicaci�n y Divisi�n
	int iMultipDivi;
	
	//Es TRUE si se activa una desviaci�n de potencia
	int iPotencia;
};
