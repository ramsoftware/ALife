/* Lista doblemente enlazada para evaluar una expresi�n con par�ntesis

1. Lee la expresi�n del string
2. Cada caracter es colocado en un nodo excepto espacios.
3. Todos los caracteres son convertidos autom�ticamente a min�sculas
*/

#include <stdio.h>
#include "NodoDoble.h"

NodoDoble::NodoDoble (char cLetra)
{
	this->cLetra = cLetra;
    this->FlechaI = NULL;
    this->FlechaD = NULL;
	this->iACUM = -1;
}

NodoDoble::NodoDoble(char cLetra, NodoDoble *objNodo)
{
    this->cLetra = cLetra;
    this->FlechaI = objNodo;
    this->FlechaD = NULL;
	this->iACUM = -1;
    objNodo->FlechaD = this; /* OJO a esto que es una lista doblemente enlazada */
}
