// Evaluador2.cpp: define el punto de entrada de la aplicaci�n de consola.
//

#include <string.h>

#include "Evaluador.h"
#include "Inicializa.h"

int main(void);
void vEvalua(char *, float *);

#define DTOTALISLAS 10
#define DTOTALECUACIONES 200
#define DTAMANOECUACION 300
char sbIslas[DTOTALISLAS][DTOTALECUACIONES][DTAMANOECUACION]; //10 islas, hasta 200 ecuaciones por isla, 300 tama�o maximo ecuacion: 600Kb
float fAdaptacion[DTOTALISLAS][DTOTALECUACIONES]; //10 islas, 200 ecuaciones = 2000*8= 16000bytes
float fAdaptaHija[DTOTALISLAS][DTOTALECUACIONES]; //10 islas, 200 ecuaciones = 2000*8= 16000bytes

//=============== N�mero de hijas por ciclo "Matting pool" ===========
#define DTOTALNUMHIJAS 100
char sbHijas[DTOTALISLAS][DTOTALNUMHIJAS][DTAMANOECUACION]; //10 islas, 100 hijas, 300 tama�o = 300Kb

//========== Clase de inicializaci�n ====
Inicializa objInicializa;
Evaluador objEvalua;

int main()
{
	//==============================================
	//Pantalla de bienvenida
	//==============================================
	objInicializa.vPantallaIni();

	//==============================================
	//Lee el archivo de inicializaci�n
	//==============================================
	if (objInicializa.iLeeArchivoIni() == -1)
	{
		printf("Error leyendo el archivo de inicializaci�n\n");
		return 0;
	}

	//==============================================
	//Crea las tablas de probabilidades
	//==============================================
	objInicializa.vCreaTablas();

	//================================================
	//Inicia el generador de numeros pseudo-aleatorios
	//================================================
	objInicializa.vIniciaAzar();

	//=================================================
	//Llena las islas de ecuaciones y las preevalua
	//=================================================
/*    char *sbEcuacion="4.845*2.737*(atn((8.227)*4.348)/((0.231)))-((7.696)-4.454)/2.517*tan((atn(x*2.804)))";
	float fResultado;
	vEvalua(sbEcuacion, &fResultado);
	printf("%f", fResultado);
	return 0; */

	float fAproximacion = (float) 99999999;
	unsigned int iIslas, iEcuacion;
	for(iIslas=0; iIslas<objInicializa.stDatPG.ISLAS; iIslas++)
		for(iEcuacion=0; iEcuacion<objInicializa.stDatPG.POBLACION; iEcuacion++)
		{
			objInicializa.vCreaEcuacion(sbIslas[iIslas][iEcuacion]);
			vEvalua(sbIslas[iIslas][iEcuacion], &fAdaptacion[iIslas][iEcuacion]);
			if (fAproximacion > fAdaptacion[iIslas][iEcuacion]) fAproximacion = fAdaptacion[iIslas][iEcuacion];
			//printf("[%s]=%f\n", sbIslas[iIslas][iEcuacion], fAdaptacion[iIslas][iEcuacion]);
		}
	
	//===============================================================
	//Ciclo continuo de evaluaci�n, selecci�n, reproducci�n, mutaci�n
	//===============================================================
	unsigned int iHijas;
	unsigned int iRetadorA, iRetadorB, iRetadorC;
	
	for(unsigned int iCiclo=1; iCiclo<objInicializa.stDatPG.CICLOS; iCiclo++)
	{
		if (iCiclo%100==0)	printf("Ciclo: %d Aproximacion: %f\n", iCiclo, fAproximacion);

		//==========================================================================
		//Chequea si la adaptaci�n es lo suficiente para terminar con la simulaci�n
		//==========================================================================
		if (fAproximacion<objInicializa.stDatPG.DETIENE) break;

		//=================================================================
		//Selecciona las mejores por torneo y las clona en la "matting pool"
		//=================================================================
		for(iIslas=0; iIslas<objInicializa.stDatPG.ISLAS; iIslas++)
			for (iHijas=0; iHijas<objInicializa.stDatPG.HIJAS; iHijas++)
			{
				objInicializa.vRetadores(&iRetadorA, &iRetadorB, &iRetadorC);
				//printf("%d %d %d->%f, %d->%f, %d->%f\n", iIslas, iHijas, iRetadorA, fAdaptacion[iIslas][iRetadorA], iRetadorB, fAdaptacion[iIslas][iRetadorB], iRetadorC, fAdaptacion[iIslas][iRetadorC]);

				//Chequea si el retador A es el mejor
				if (fAdaptacion[iIslas][iRetadorA]<fAdaptacion[iIslas][iRetadorB] &&
					fAdaptacion[iIslas][iRetadorA]<fAdaptacion[iIslas][iRetadorC])
					strcpy(sbHijas[iIslas][iHijas], sbIslas[iIslas][iRetadorA]);

				//Chequea si el retador B es el mejor
				else if (fAdaptacion[iIslas][iRetadorB]<fAdaptacion[iIslas][iRetadorA] &&
					fAdaptacion[iIslas][iRetadorB]<fAdaptacion[iIslas][iRetadorC])
					strcpy(sbHijas[iIslas][iHijas], sbIslas[iIslas][iRetadorB]);

				//Chequea si el retador C es el mejor
				else
					strcpy(sbHijas[iIslas][iHijas], sbIslas[iIslas][iRetadorC]);

			}

		//=================================================================
		//En la "matting pool" se muta cada ecuaci�n (ser�n las hijas)
		//=================================================================
		for(iIslas=0; iIslas<objInicializa.stDatPG.ISLAS; iIslas++)
			for (iHijas=0; iHijas<objInicializa.stDatPG.HIJAS; iHijas++)
			{
				objInicializa.vMutaEcuacion(sbHijas[iIslas][iHijas]);
				vEvalua(sbHijas[iIslas][iHijas], &fAdaptaHija[iIslas][iHijas]);
				if (fAproximacion > fAdaptaHija[iIslas][iHijas]) fAproximacion = fAdaptaHija[iIslas][iHijas];
			}

		//===========================================================================
		//La pol�tica de reemplazo (se escogen tres al azar y el peor es reemplazado)
		//===========================================================================
		for(iIslas=0; iIslas<objInicializa.stDatPG.ISLAS; iIslas++)
			for (iHijas=0; iHijas<objInicializa.stDatPG.HIJAS; iHijas++)
			{
				objInicializa.vRetadores(&iRetadorA, &iRetadorB, &iRetadorC);

				//Chequea si el retador A es el peor
				if (fAdaptacion[iIslas][iRetadorA]>fAdaptacion[iIslas][iRetadorB] &&
					fAdaptacion[iIslas][iRetadorA]>fAdaptacion[iIslas][iRetadorC])
				{
					strcpy(sbIslas[iIslas][iRetadorA], sbHijas[iIslas][iHijas]);
					fAdaptacion[iIslas][iRetadorA] = fAdaptaHija[iIslas][iHijas];
				}
					
				//Chequea si el retador B es el peor
				else if (fAdaptacion[iIslas][iRetadorB]>fAdaptacion[iIslas][iRetadorA] &&
					fAdaptacion[iIslas][iRetadorB]>fAdaptacion[iIslas][iRetadorC])
				{
					strcpy(sbIslas[iIslas][iRetadorB], sbHijas[iIslas][iHijas]);
					fAdaptacion[iIslas][iRetadorB] = fAdaptaHija[iIslas][iHijas];
				}

				//Chequea si el retador C es el peor
				else 
				{
					strcpy(sbIslas[iIslas][iRetadorC], sbHijas[iIslas][iHijas]);
					fAdaptacion[iIslas][iRetadorC] = fAdaptaHija[iIslas][iHijas];
				}
			}
	}

	//=========================================================================
	//Imprime la mejor ecuaci�n de cada isla junto con su valor de aproximacion
	//=========================================================================
	printf("\n\n");
	float fMejorAdaptacion; //Debe tender a cero
	char sbMejorEcuacion[DTAMANOECUACION];
	for(iIslas=0; iIslas < objInicializa.stDatPG.ISLAS; iIslas++)
	{
		fMejorAdaptacion = fAdaptacion[iIslas][0];
		strcpy(sbMejorEcuacion, sbIslas[iIslas][0]);
		for(iEcuacion=1; iEcuacion < objInicializa.stDatPG.POBLACION; iEcuacion++)
				if (fAdaptacion[iIslas][iEcuacion] < fMejorAdaptacion)
				{
					fMejorAdaptacion = fAdaptacion[iIslas][iEcuacion];
					strcpy(sbMejorEcuacion, sbIslas[iIslas][iEcuacion]);
				}

		//Imprime la mejor ecuaci�n por isla y la lista de n�meros para ser usada en Excel 
		printf("Isla:[%d] Ecuacion:[Y=%s] Adaptacion:[%f]\n\n", iIslas, sbMejorEcuacion, fMejorAdaptacion);
	}
	printf("Mejor aproximacion: [%f]\n\n\n", fAproximacion);

	//Imprime el resto de ecuaciones por isla y su adaptaci�n
	for(iIslas=0; iIslas < objInicializa.stDatPG.ISLAS; iIslas++)
	{
		printf("Isla: [%d]\n", iIslas);
		for(iEcuacion=0; iEcuacion < objInicializa.stDatPG.POBLACION; iEcuacion++)
			printf("[Y=%s]\t[%f]\n", sbIslas[iIslas][iEcuacion], fAdaptacion[iIslas][iEcuacion]);
		printf("\n\n");
	}

	return 0;
}

//El criterio de evaluaci�n es diferencia absoluta que tiene mejor desempe�o que
//la evaluaci�n de Pearson y es m�s r�pida.
void vEvalua(char *sbEcuacion, float *fAdapta)
{
	unsigned int iCont;
	float fAcumula=0, fDiferencia, fValor;

	//Interpreta la ecuaci�n
	objEvalua.vAnaliza(sbEcuacion);

	//Maxima velocidad de evaluaci�n
	for(iCont=0; iCont<objInicializa.stDatPG.NUMENTRADA; iCont++)
	{
		objEvalua.fVariables['x'] = objInicializa.stDatPG.fENTRADA[iCont];
		fValor = objEvalua.fEvaluar();
//		printf("%f  %f  %f\n", objInicializa.stDatPG.fENTRADA[iCont], fValor, objInicializa.stDatPG.fSALIDA[iCont]);
		fDiferencia = fValor - objInicializa.stDatPG.fSALIDA[iCont];
		if (fDiferencia > 0)
			fAcumula+=fDiferencia;
		else
			fAcumula-=fDiferencia;
	}
	*fAdapta=fAcumula;

	objEvalua.vLiberaMemoria();
}

