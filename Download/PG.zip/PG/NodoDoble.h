/* Lista doblemente enlazada para evaluar una expresi�n con par�ntesis

1. Lee la expresi�n del string
2. Cada caracter es colocado en un nodo excepto espacios.
3. Todos los caracteres son convertidos autom�ticamente a min�sculas
*/
class NodoDoble
{
public:
	int iACUM;
	char cLetra;
	NodoDoble *FlechaI;
	NodoDoble *FlechaD;

    NodoDoble(char cLetra);
    NodoDoble(char cLetra, NodoDoble *objNodo);
};