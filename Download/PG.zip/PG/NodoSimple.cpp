/* Lista simplemente enlazada para evaluar una expresi�n muy simple (sin par�ntesis).

Su funcionamiento es as�:
Esta expresi�n 4+5-2*3/4*6+7+3-8/2*5-4 se convierte a esto
4+
5-
ACUM+ (2* 3/ 4* 6N)
7+
3-
ACUM- (8/ 2* 5N)
4N

De esa manera resolver la expresi�n simple es solo ir de arriba a abajo con desviaciones
a la derecha cuando encuentra multiplicaciones y divisiones, y desviaciones
oblicuas cuando encuentre potencias */

#include <stdio.h>
#include "NodoSimple.h"

//Constructor 1 (suma y resta)
NodoSimple::NodoSimple(float fNumero, unsigned char cOperador)	
{
	this->cVariable = 0;
	this->fNumero = fNumero;
	this->cOperador = cOperador;
	this->Abajo = NULL;
	this->Derecha = NULL;
	this->Potencia = NULL;
	this->objACUM = NULL;
	this->iFuncion = 0;
}

//Constructor 2 (suma y resta)
NodoSimple::NodoSimple(unsigned char cVariable, unsigned char cOperador)	
{
	this->cVariable = cVariable;
	this->fNumero = 0;
	this->cOperador = cOperador;
	this->Abajo = NULL;
	this->Derecha = NULL;
	this->Potencia = NULL;
	this->objACUM = NULL;
	this->iFuncion = 0;
}

//Constructor 3 (Nodo ACUM) de lista analizada
NodoSimple::NodoSimple()	
{
	this->cVariable = 0;
	this->fNumero = 0;
	this->cOperador = 0;
	this->Abajo = NULL;
	this->Derecha = NULL;
	this->Potencia = NULL;
	this->objACUM = NULL;
	this->iFuncion = 0;
}

//Constructor 4 (Nodo ACUM) de lista analizada
NodoSimple::NodoSimple(NodoSimple *objACUM)	
{
	this->cVariable = 0;
	this->fNumero = 0;
	this->cOperador = 0;
	this->Abajo = NULL;
	this->Derecha = NULL;
	this->Potencia = NULL;
	this->objACUM = NULL;
	this->Arriba = objACUM;
	objACUM->Abajo = this;
	this->iFuncion = 0;
}

/* Nodo de desviaci�n */
NodoSimple::NodoSimple(NodoSimple *objACUM, unsigned char cOperador)
{
	this->cVariable = 0;
	this->fNumero = 0;
	this->cOperador = cOperador;
	this->Abajo = NULL;
	this->Derecha = NULL;
	this->Potencia = NULL;
	this->objACUM = objACUM;
	this->iFuncion = 0;
}