/*
Autor:		Rafael Alberto Moreno Parra
URL:		http://darwin.50webs.com
Clase:		Inicializa.
Lenguaje:	C++

Prop�sito:
Inicializa las variables para la simulaci�n

M�todos:

*/
#include "Aleatorio.h"

class Inicializa {
public:
	int iValor;

	struct stDatosSimul
	{
		//Entradas y salidas
		unsigned int NUMENTRADA;
		char sENTRADA[400];
		char sSALIDA[400];

		unsigned int ISLAS; //Cuantas islas existir�n 
		unsigned int POBLACION; //Tama�o de la poblaci�n
		unsigned int HIJAS; //Tama�o de la "matting pool"

		unsigned int TAMEXPRESION; //Tama�o m�ximo de la expresi�n algebraica
		unsigned int CICLOS; //Cuantos ciclos se evaluar�n m�ximo hasta detenerse si no se cumple DETIENE
		float DETIENE; //Si el error esta por debajo de este dato, se detiene la simulaci�n

		//1. Tabla I: Se utiliza despu�s de vacio, par�ntesis que abre, funci�n, operador
		unsigned int T1FUNCION;
		unsigned int T1PARENTE;
		unsigned int T1VARIABX;
		unsigned int T1NUMEROS;

		//2. Tabla II: Se utiliza despu�s de X y par�ntesis que cierra.
		unsigned int T2OPERADO;
		unsigned int T2PARENTE;

		//Entradas y salidas
		float fENTRADA[100];
		float fSALIDA[100];
	};  
	 //Datos Programaci�n Gen�tica (inicializaci�n)
	struct stDatosSimul stDatPG;

	//Objeto que administra los n�meros aleatorios
	Aleatorio objAzar;


	/* Crea las tablas de probabilidades para formar las ecuaciones
		Son tres(3) tablas:
		1. Tabla I: Se utiliza despu�s de vacio, par�ntesis que abre, funci�n, operador
		2. Tabla II: Se utiliza despu�s de (0.01 a 0.99) y par�ntesis que cierra. */
	char sbTabla1[100]; //Como debe sumar 100% por la probabilidad
	char sbTabla2[100];

	void vPantallaIni(void);
	void vIniciaAzar(void);
    int iLeeArchivoIni(void);
	void vDeshaceIO(char *m_sSerieNum, int iEntraSale);
	void vCreaTablas(void);
	void vCreaEcuacion(char *sbEcuacion);
	void vRetadores(unsigned int *iRetadorA, unsigned int *iRetadorB, unsigned int *iRetadorC);
	void vMutaEcuacion(char *sbEcuacion);
};
