/*
Autor:		Rafael Alberto Moreno Parra
URL:		http://darwin.50webs.com
Clase:		Inicializa.
Lenguaje:	C++

Prop�sito:
Inicializa las variables para la simulaci�n

*/
#include "Inicializa.h"
#include "StringUtil.h"
#include <string.h>
#include <stdlib.h>
#include <time.h>

#define EXPR_VACIO 0
#define EXPR_FUNCION 1
#define EXPR_VARIABLE 3
#define EXPR_PARENTESISABRE 4
#define EXPR_NUMERO 5
#define EXPR_OPERADOR 6
#define EXPR_PARENTESISCIER 7

//Pantalla inicial
void Inicializa::vPantallaIni()
{
	printf("Programaci�n Gen�tica\n\n");
	printf("Autor: Rafael Alberto Moreno Parra\n");
	printf("Fecha: 21 de Abril de 2007\n");
	printf("E-mail: enginelife@hotmail.com\n");
	printf("http://darwin.50webs.com\n\n");
}

//Inicializa la semilla de n�meros aleatorios
void Inicializa::vIniciaAzar()
{
	time_t objTiempo;
	time(&objTiempo);
	objAzar.sgenrand(objTiempo);
}

//Abre y estudia el archivo de inicializaci�n
int Inicializa::iLeeArchivoIni()
{
	FILE *fpInicio;
	char sFrase[600], sVariable[200], sValor[200];
    unsigned int iCar;
	StringUtil StrUtil;

	fpInicio = fopen("Inicializa.ini", "r+t");
	if (fpInicio == NULL)
    {
		printf("Error al tratar de abrir archivo de inicializaci�n Inicializa.ini\n");
		return -1;
    }
	while(!feof(fpInicio))
	{
		fgets(sFrase, 400, fpInicio);
		StrUtil.vQuitaEspacios(sFrase);

		//Extrae variables y valores
		for (iCar=0; iCar<strlen(sFrase) && sFrase[iCar]!='='; iCar++);
		StrUtil.vLeft(sVariable, sFrase, iCar);
		StrUtil.vMid(sValor, sFrase, iCar+2,strlen(sFrase));

		//Clasifica variables
		if(strcmp(sVariable, "ENTRADA")==0) strcpy(stDatPG.sENTRADA, sValor);
		if(strcmp(sVariable, "SALIDA")==0) strcpy(stDatPG.sSALIDA, sValor);
		if(strcmp(sVariable, "ISLAS")==0) stDatPG.ISLAS = atoi(sValor);
		if(strcmp(sVariable, "POBLACION")==0) stDatPG.POBLACION = atoi(sValor);
		if(strcmp(sVariable, "HIJAS")==0) stDatPG.HIJAS = atoi(sValor);
		if(strcmp(sVariable, "TAMEXPRESION")==0) stDatPG.TAMEXPRESION = atoi(sValor);
		if(strcmp(sVariable, "CICLOS")==0) stDatPG.CICLOS = atoi(sValor);
		if(strcmp(sVariable, "DETIENE")==0) stDatPG.DETIENE = atof(sValor);
		if(strcmp(sVariable, "T1FUNCION")==0) stDatPG.T1FUNCION = atoi(sValor);
		if(strcmp(sVariable, "T1PARENTE")==0) stDatPG.T1PARENTE = atoi(sValor);
		if(strcmp(sVariable, "T1VARIABX")==0) stDatPG.T1VARIABX = atoi(sValor);
		if(strcmp(sVariable, "T1NUMEROS")==0) stDatPG.T1NUMEROS = atoi(sValor);
		if(strcmp(sVariable, "T2OPERADO")==0) stDatPG.T2OPERADO = atoi(sValor);
		if(strcmp(sVariable, "T2PARENTE")==0) stDatPG.T2PARENTE = atoi(sValor);
	}
	
	fclose(fpInicio);

	//Deshace las entradas en una lista de n�meros reales
	vDeshaceIO(stDatPG.sENTRADA, 1);
	vDeshaceIO(stDatPG.sSALIDA, 2);
	printf("Valores de entrada\n");
	for (int iCont=0; iCont<stDatPG.NUMENTRADA; iCont++)
		printf("[%f] ", stDatPG.fENTRADA[iCont]);
	printf("\nValores de salida\n");
	for (int iCont=0; iCont<stDatPG.NUMENTRADA; iCont++)
		printf("[%f] ", stDatPG.fSALIDA[iCont]);
	printf("\nstDatPG.ISLAS=%d\n", stDatPG.ISLAS);
	printf("stDatPG.POBLACION=%d\n", stDatPG.POBLACION);
	printf("stDatPG.HIJAS=%d\n", stDatPG.HIJAS);
	printf("stDatPG.TAMEXPRESION=%d\n", stDatPG.TAMEXPRESION);
	printf("stDatPG.CICLOS=%d\n", stDatPG.CICLOS);
	printf("stDatPG.DETIENE=%f\n", stDatPG.DETIENE);
	printf("stDatPG.T1FUNCION=%d\n", stDatPG.T1FUNCION);
	printf("stDatPG.T1PARENTE=%d\n", stDatPG.T1PARENTE);
	printf("stDatPG.T1VARIABX=%d\n", stDatPG.T1VARIABX);
	printf("stDatPG.T1NUMEROS=%d\n", stDatPG.T1NUMEROS);
	printf("stDatPG.T2OPERADO=%d\n", stDatPG.T2OPERADO);
	printf("stDatPG.T2PARENTE=%d\n", stDatPG.T2PARENTE);
	return 0;
}

//Deshace la cadena de datos de entrada y salida
void Inicializa::vDeshaceIO(char *m_sSerieNum, int iEntraSale)
{
		char sAcum[30];
		unsigned int iProgreso=0, iCont;
		int iEntra=0, iSale=0;
		
		// Ahora deshace la expresion en un arreglo de n�meros reales
		for(iCont=0; iCont<=strlen(m_sSerieNum); iCont++)
		{
			if(m_sSerieNum[iCont] != ',')
			{
				sAcum[iProgreso++] = m_sSerieNum[iCont];
				sAcum[iProgreso]='\0';
			}
			else
				if(strlen(sAcum)>0)
				{
				    switch(iEntraSale)
				    {
				        case 1:
					        stDatPG.fENTRADA[iEntra++]=atof(sAcum);
							stDatPG.NUMENTRADA=iEntra;
					        break;
					    case 2: 
					        stDatPG.fSALIDA[iSale++]=atof(sAcum);
							stDatPG.NUMENTRADA=iSale;
					        break;
					}
					iProgreso=0;
				}
		} // Fin For
} // Fin DeshaceIO

// Crea las tablas de probabilidades para formar las ecuaciones
//Son tres(3) tablas:
//1. Tabla I: Se utiliza despu�s de vacio, par�ntesis que abre, funci�n, operador
//2. Tabla II: Se utiliza despu�s de (0.01 a 0.99) y par�ntesis que cierra.
//3. Tabla III: Se utiliza despu�s de X y (1..9)
void Inicializa::vCreaTablas()
{
	unsigned int iCont, iFuncion=0; 

	for (iCont=0; iCont<stDatPG.T1FUNCION; iCont++)
	{
		switch(iFuncion)
		{
			case 0: sbTabla1[iCont]='A'; break; //Seno
			case 1: sbTabla1[iCont]='B'; break; //Coseno
			case 2: sbTabla1[iCont]='C'; break; //Tangente
			case 3: sbTabla1[iCont]='D'; break; //Absoluto
			case 4: sbTabla1[iCont]='E'; break; //Arcoseno
			case 5: sbTabla1[iCont]='F'; break; //Arcocoseno
			case 6: sbTabla1[iCont]='G'; break; //Arcotangente
		}
		iFuncion++;
		if (iFuncion==7) iFuncion=0;
	}
	
	//for (iCont=stDatPG.T1FUNCION; iCont<stDatPG.T1FUNCION+stDatPG.T1DECIMAL; iCont++) sbTabla1[iCont]='W';
	for (iCont=stDatPG.T1FUNCION; iCont<stDatPG.T1FUNCION+stDatPG.T1PARENTE; iCont++) sbTabla1[iCont]='X';
	for (iCont=stDatPG.T1FUNCION+stDatPG.T1PARENTE; iCont<stDatPG.T1FUNCION+stDatPG.T1PARENTE+stDatPG.T1VARIABX; iCont++) sbTabla1[iCont]='Y';
	for (iCont=stDatPG.T1FUNCION+stDatPG.T1PARENTE+stDatPG.T1VARIABX; iCont<stDatPG.T1FUNCION+stDatPG.T1PARENTE+stDatPG.T1VARIABX+stDatPG.T1NUMEROS; iCont++) sbTabla1[iCont]='Z';

	for (iCont=0; iCont<stDatPG.T2OPERADO; iCont++) sbTabla2[iCont]='O';
	for (iCont=stDatPG.T2OPERADO; iCont<stDatPG.T2OPERADO+stDatPG.T2PARENTE; iCont++) sbTabla2[iCont]='P';
}

//Crea una ecuaci�n al azar
void Inicializa::vCreaEcuacion(char *sbEcuacion)
{
	unsigned int iTamano=0, iParentesis=0, iAnterior=0, iNumeroAzarP, iNumeroAzarS;
	bool bTieneVarX=false;
	char sbTemporal[30];

	do
	{
		//Inicializa todo
		iAnterior=0;
		iTamano=0;
		bTieneVarX=false;
		sbEcuacion[0]='\0';

		while(iTamano<=stDatPG.TAMEXPRESION || iAnterior==1 || iAnterior==6 || iAnterior==4 || bTieneVarX==false)
		{
			iNumeroAzarP = objAzar.genrand()%100;

			//Si es vacio, funcion, parentesis abre, u operador esto debe seguir
			if (iAnterior==0 || iAnterior==1 || iAnterior==4 || iAnterior==6)
			{
				if (sbTabla1[iNumeroAzarP]=='A') { strcat(sbEcuacion, "sen("); iAnterior=1; iTamano+=4; iParentesis++; }
				if (sbTabla1[iNumeroAzarP]=='B') { strcat(sbEcuacion, "cos("); iAnterior=1; iTamano+=4; iParentesis++; }
				if (sbTabla1[iNumeroAzarP]=='C') { strcat(sbEcuacion, "tan("); iAnterior=1; iTamano+=4; iParentesis++; }
				if (sbTabla1[iNumeroAzarP]=='D') { strcat(sbEcuacion, "abs("); iAnterior=1; iTamano+=4; iParentesis++; }
				if (sbTabla1[iNumeroAzarP]=='E') { strcat(sbEcuacion, "asn("); iAnterior=1; iTamano+=4; iParentesis++; }
				if (sbTabla1[iNumeroAzarP]=='F') { strcat(sbEcuacion, "acs("); iAnterior=1; iTamano+=4; iParentesis++; }
				if (sbTabla1[iNumeroAzarP]=='G') { strcat(sbEcuacion, "atn("); iAnterior=1; iTamano+=4; iParentesis++; }
				if (sbTabla1[iNumeroAzarP]=='X') { strcat(sbEcuacion, "x"); iAnterior=3; bTieneVarX=true; iTamano++; }
				if (sbTabla1[iNumeroAzarP]=='Y') { strcat(sbEcuacion, "("); iAnterior=4; iTamano++; iParentesis++; }
				if (sbTabla1[iNumeroAzarP]=='Z') //Un numero
				{
					float fNuevoNumero;
					do
					{
						fNuevoNumero = (float) objAzar.genrand()/objAzar.genrand();
					}while(fNuevoNumero==0 || fNuevoNumero < -100000 || fNuevoNumero >100000);
					sprintf(sbTemporal, "%5.3f", fNuevoNumero);
					strcat(sbEcuacion, sbTemporal);
					iAnterior=5;
					iTamano+=strlen(sbTemporal);
				}
			}

			//Si es X, numero o parentesis que cierra
			if (iAnterior==3 || iAnterior==5 || iAnterior==7)
			{
				if (sbTabla2[iNumeroAzarP]=='O') //Un operador
				{
					iNumeroAzarS = objAzar.genrand()%4;
					switch(iNumeroAzarS)
					{
						case 0: strcat(sbEcuacion, "+"); break;
						case 1: strcat(sbEcuacion, "-"); break;
						case 2: strcat(sbEcuacion, "*"); break;
						case 3: strcat(sbEcuacion, "/"); break;
					}
					iAnterior=6;
					iTamano++;
				}
				if (sbTabla2[iNumeroAzarP]=='P' && iParentesis>0)
				{ 
					strcat(sbEcuacion, ")");
					iAnterior=7;
					iTamano++;
					iParentesis--;
				}
			}
		}

		while(iParentesis>0)
		{
			strcat(sbEcuacion, ")");
			iParentesis--;
			iTamano++;
		}

	}while (iTamano>stDatPG.TAMEXPRESION+20); //Evita que la expresi�n se desborde.
	//printf("iTamano=%d\n", iTamano);
}

//Devuelve tres retadores diferentes
void Inicializa::vRetadores(unsigned int *iRetadorA, unsigned int *iRetadorB, unsigned int *iRetadorC)
{
	do
	{
		*iRetadorA = objAzar.genrand()%stDatPG.POBLACION;
		*iRetadorB = objAzar.genrand()%stDatPG.POBLACION;
		*iRetadorC = objAzar.genrand()%stDatPG.POBLACION;
	}while (*iRetadorA==*iRetadorB || *iRetadorA==*iRetadorC || *iRetadorB==*iRetadorC);
}

//Muta la ecuaci�n (n�meros y operadores) en alg�n lugar de esta
void Inicializa::vMutaEcuacion(char *sbEcuacion)
{
	int iPos; //Posici�n a mutar
	char cLetra; //Que hay en esa posici�n
	char cReemplazo='+'; //Que reemplaza a un operador
	
	int iTamanoEcuacion = strlen(sbEcuacion);

	//Busca una posici�n mutable (no par�ntesis, ni punto decimal)
	do
	{
		iPos = objAzar.genrand()%iTamanoEcuacion;
		cLetra = sbEcuacion[iPos];
	}while(cLetra==')' || cLetra=='(' || cLetra=='.' || cLetra=='x');

	//Si es una funci�n la reemplazo por otra funci�n
	if (cLetra >='a' && cLetra<='z')
	{
		for (;iPos>=0;iPos--)
			if (sbEcuacion[iPos]<'a' || sbEcuacion[iPos]>'z')
				break;
		iPos++;
		char cSegundaLetra = sbEcuacion[iPos+1];
		do
		{
			switch(objAzar.genrand()%7)
			{
				case 0: sbEcuacion[iPos]='s'; sbEcuacion[iPos+1]='e'; sbEcuacion[iPos+2]='n'; break;
				case 1: sbEcuacion[iPos]='c'; sbEcuacion[iPos+1]='o'; sbEcuacion[iPos+2]='s'; break;
				case 2: sbEcuacion[iPos]='t'; sbEcuacion[iPos+1]='a'; sbEcuacion[iPos+2]='n'; break;
				case 3: sbEcuacion[iPos]='a'; sbEcuacion[iPos+1]='b'; sbEcuacion[iPos+2]='s'; break;
				case 4: sbEcuacion[iPos]='a'; sbEcuacion[iPos+1]='s'; sbEcuacion[iPos+2]='n'; break;
				case 5: sbEcuacion[iPos]='a'; sbEcuacion[iPos+1]='c'; sbEcuacion[iPos+2]='s'; break;
				case 6: sbEcuacion[iPos]='a'; sbEcuacion[iPos+1]='t'; sbEcuacion[iPos+2]='n'; break;
			}
		}while(cSegundaLetra==sbEcuacion[iPos+1]);
	}

	//Si es un operador lo reemplazo por otro operador
	else if (cLetra=='+' || cLetra=='-' || cLetra=='*' || cLetra=='/')
	{
		int iOperador;
		do
		{
			iOperador = objAzar.genrand()%4;
			switch(iOperador)
			{
				case 0: cReemplazo='+'; break;
				case 1: cReemplazo='-'; break;
				case 2: cReemplazo='*'; break;
				case 3: cReemplazo='/'; break;
			}
		}while(cLetra==cReemplazo);
		sbEcuacion[iPos]=cReemplazo;
	}

	//Si es un numero lo reemplazo por otro numero
	else if (cLetra>='0' && cLetra<='9')
	{
		do
		{
			cReemplazo = (char)(objAzar.genrand()%('9'-'0')+'0');
		}while(cLetra==cReemplazo);
		sbEcuacion[iPos]=cReemplazo;
	}
}

