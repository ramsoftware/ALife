/* AUTOR: RAFAEL ABERTO MORENO PARRA
   Evaluador de expresiones en Visual C++.	08 de Septiembre de 2007. Beta 2.
*/

#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h> //Chequeo de sintaxis

#include "Evaluador.h"

/* Ver:
http://codeplusplus.blogspot.com/2007/09/char-pointer-versus-char-array.html 
*/

//Constructor
Evaluador::Evaluador()
{
	//Las funciones ser�n siempre de tres letras
	cFuncion = "sinsencostanabsasnacsatnlogceiexpsqrrcb";
}

//Deshace la expresi�n algebraica con par�ntesis en una lista doblemente enlazada
void Evaluador::vAnaliza(char *sExpresion)
{
	//Reemplazo de la funci�n ATOF de C, para hacer m�s r�pida la conversi�n de cadena a n�mero
	long double fValor=0L;
	long double iDecimal=0L;
	long double iFraccion=0L;
	long double dDivide=1L;
	bool bPunto=false;

	//Manejo de funciones
	unsigned int iFuncion;

	//Manejo de subexpresiones
	char cVariable;
	unsigned int iACUM;
	int iACUMULADO=1;
	NodoSimple *objACUMULADOR=NULL;

	//Para a�adir nodos a la lista doblemente enlazada. Empieza con par�ntesis que abre.
	NodoDoble *objListaDoble=new NodoDoble('(');

	//Queda la expresi�n en una lista doblemente enlazada donde cada Nodo tiene un caracter
	char *cLetra = sExpresion;
	while(*cLetra)
	{
		if(*cLetra!=' ') //Quita autom�ticamente los espacios
		{
			//Adiciona Nodos a la lista doblemente enlazada
			if(*cLetra>='A' && *cLetra<='Z') //Vuelve a min�sculas
				objListaDoble = new NodoDoble(*cLetra+32, objListaDoble);
			else
				objListaDoble = new NodoDoble(*cLetra, objListaDoble);
		}
		cLetra++;
	}
	objListaDoble = new NodoDoble(')', objListaDoble); //Termina la expresi�n con par�ntesis que cierra
	
	//==========================================
	//Inicializa la lista de expresi�n analizada
	//==========================================
	Analizado = NULL;
	IniAnalizado = NULL;

	//Deshace en subexpresiones ACUM
	NodoDoble *objFin, *objIni, *objBorra, *objTemp;
	while(objListaDoble!=NULL)
	{
		//Extrae la subcadena entre par�ntesis, si encuentra el par�ntesis que abre
		if (objListaDoble->cLetra=='(')
		{
			//Coloca una marca donde esta el par�ntesis que abre
			objIni = objListaDoble;

			//Busca el par�ntesis que cierra, de esa manera extrae lo interior
			while(objListaDoble->cLetra!=')')
				objListaDoble = objListaDoble->FlechaD;

			//Pone una marca donde est� el par�ntesis que cierra
			objFin = objListaDoble;

			// ============================================================================
			// An�lisis de una expresi�n simple
			// ============================================================================

			//Adiciona un nodo a la lista con expresi�n analizada
			if (Analizado == NULL)
			{
				Analizado = new NodoSimple();
				IniAnalizado = Analizado;
			}
			else
				Analizado = new NodoSimple(Analizado);

			//Inicializa para evaluar la expresi�n simple
			objNodo = new NodoSimple( (float)0, '+');
			objPasea = objNodo;
			iMultipDivi = 0; //Desviaci�n multiplicaci�n falsa
			iPotencia = 0; //Desviaci�n potencia falsa

			//Si tiene un - al inicio entonces lo convierte a 0-
			bool bNegativoInicio = false;
			if (objIni->FlechaD->cLetra=='-')
				bNegativoInicio = true; //Tiene en cuenta que hay un - al inicio

			//Env�a a analizar la subexpresi�n entre par�ntesis
			NodoDoble *objExtrae = objIni;
			while(objExtrae->FlechaD!=objFin)
			{
				//Empieza a traer caracter por caracter desde el par�ntesis (
				objExtrae = objExtrae->FlechaD;

				//Si es un ACUM entonces crea la referencia a ese bloque
				if (objExtrae->iACUM >= 0)
				{
					//Busca el ACUM a referir
					iACUM=1;
					objACUMULADOR = IniAnalizado;
					while(iACUM < objExtrae->iACUM)
					{
						objACUMULADOR = objACUMULADOR->Abajo;
						iACUM++;
					}
				}

				//Si son n�meros entonces los va acumulando en un "string"
				else if ( (objExtrae->cLetra >= '0' && objExtrae->cLetra <= '9' ) || objExtrae->cLetra=='.')
				{
					if (objExtrae->cLetra=='.')
						bPunto = true;
					else
						if(bPunto==false)
							iDecimal = iDecimal * 10 + objExtrae->cLetra-48;
						else
						{	
							iFraccion = iFraccion * 10 + objExtrae->cLetra-48;
							dDivide *=10L;
						}

					cVariable=0; //No es variable
					objACUMULADOR = NULL; //No es acumulador
				}
				else if (objExtrae->cLetra>='a' && objExtrae->cLetra<='z')
				{
					objACUMULADOR = NULL; //No es acumulador
					cVariable = objExtrae->cLetra;
				}
				else //Es +, -, *, /, ^ entonces crea un nuevo bloque de "numero operador" o "variable operador" o "acumulado operador"
				{
					fValor = iDecimal + iFraccion/dDivide;
					iDecimal=iFraccion=0L;
					dDivide=1L;
					bPunto=false;
					if (bNegativoInicio)
					{
						vNuevoBloque(0, '-', 0, NULL);
						bNegativoInicio = false;
					}
					else
						vNuevoBloque((float)fValor, objExtrae->cLetra, cVariable, objACUMULADOR);
					objACUMULADOR=NULL;
				}
			}

			//El �ltimo operando, la expresi�n debe terminar en "+0N"
			fValor = iDecimal + iFraccion/dDivide;
			iDecimal=iFraccion=0L;
			dDivide=1L;
			bPunto=false;
			vNuevoBloque((float)fValor, '+', cVariable, objACUMULADOR);
			vNuevoBloque(0, 'N', 0, NULL);

			//Coloca en la lista de expresi�n analizada
			Analizado->Derecha = objNodo;
			
			//Es un ACUM y lo marca con un c�digo ascendente
			objIni->iACUM = iACUMULADO++;

			//Borra la subexpresion de la lista doblemente enlazada (incluye liberar la memoria)
			objBorra = objIni->FlechaD;
			while(objBorra!=objFin)
			{
				objTemp = objBorra->FlechaD;
				delete(objBorra);
				objBorra = objTemp;
			}
			objIni->FlechaD = objFin->FlechaD;
			delete(objFin);

			if (objIni->FlechaI==NULL)
			{
				delete(objIni);
				break;
			}

			//Chequea si las tres letras anteriores corresponden a una funci�n conocida
			if (objIni->FlechaI->cLetra>='a' && objIni->FlechaI->cLetra<='z')
			{
				//Retrocede tres letras
				objIni=objIni->FlechaI->FlechaI->FlechaI;
				
				const char *cPaseaFuncion = cFuncion;
				iFuncion=1;
				while (cPaseaFuncion)
				{
					if (objIni->cLetra == *cPaseaFuncion && 
					    objIni->FlechaD->cLetra == *(cPaseaFuncion+1) &&
					    objIni->FlechaD->FlechaD->cLetra == *(cPaseaFuncion+2))
					{
						objNodo = new NodoSimple();
						objNodo->iFuncion = iFuncion;
						Analizado = new NodoSimple(Analizado);
						Analizado->Derecha = objNodo;
						break;
					}
					cPaseaFuncion+=3; iFuncion++;
				}

				//Borra los nodos sobrantes
				objTemp=objIni->FlechaD->FlechaD->FlechaD->FlechaD;
				delete(objIni->FlechaD->FlechaD->FlechaD);
				delete(objIni->FlechaD->FlechaD);
				delete(objIni->FlechaD);
				objIni->FlechaD = objTemp;
				objIni->iACUM = iACUMULADO++;
			}

			//Restaura para evaluar siguiente par�ntesis
			objListaDoble=objIni->FlechaI;
		}
		else
			objListaDoble=objListaDoble->FlechaI;
	}
}

void Evaluador::vNuevoBloque(float fValor, unsigned char cOperador, unsigned char cVariable, NodoSimple *objACUM)
{
/* 	Llegan bloques como 2+  5-  6*  7-  3*   2^  4*  5/  6+  4N y debe quedar as�:
	   2+
	   5-
	   ACUM-   6* 7N
	   ACUM+   3/ ACUM * 5/ 6N
				  2^
				  4N
	   4N
   */

	//Creo el nuevo bloque a agregar a la expresi�n simple
	NodoSimple *objNuevoBloque;
	if (objACUM==NULL)
	{
		if (cVariable==0)
			objNuevoBloque = new NodoSimple(fValor, cOperador);
		else
			objNuevoBloque = new NodoSimple(cVariable, cOperador);
	}
	else
		objNuevoBloque = new NodoSimple(objACUM, cOperador);

	//Si el operador es una suma o resta agrega el nuevo nodo
	if ((cOperador == '+' || cOperador == '-' || cOperador == 'N') && iMultipDivi==0)
	{
		objPasea->Abajo = objNuevoBloque;
		objPasea = objPasea->Abajo;
	}
	else //es una multiplicaci�n o divisi�n o potencia
	{
		//Es la primera vez que sale * / ^
		if (iMultipDivi==0)
		{
			//Se ha creado una desviaci�n
			iMultipDivi = 1;

			//Crea un nodo ACUM multiplicador
			NodoMultip = new NodoSimple( (float)0, 'A');

			//La lista agrega a ACUM
			objPasea->Abajo = NodoMultip;

			//Se posa en ACUM
			objPasea = objPasea->Abajo;

			//Si es una potencia
			if (cOperador == '^')
			{
				iPotencia = 1;

				//Agrega por defecto un 1*
				NodoSimple *NodoMultiplica = new NodoSimple((float)1, '*');

				//Agrega el 1* al ACUM
				NodoMultip->Derecha = NodoMultiplica;

				//Crea un ACUMP (acumulador de potencia)
				NodoPotencia = new NodoSimple((float)0, 'B');

				//Agrega el ACUMP a la multiplicaci�n
				NodoMultiplica->Derecha = NodoPotencia;

				//Mueve NodoMultip hacia ACUMP
				NodoMultip = NodoPotencia;

				//ACUMP apunta al nuevo bloque
				NodoPotencia->Potencia = objNuevoBloque;

				//ACUMP se mueve a la �ltima potencia
				NodoPotencia = NodoPotencia->Potencia;
			}
			else
			{
				//ACUM apunta a la derecha (para multiplicar y dividir)
				NodoMultip->Derecha = objNuevoBloque;
				NodoMultip = NodoMultip->Derecha;
			}
		}
		else //Ya hab�a salido * / ^
		{
			//Si venia de una potencia por ejemplo:  5^4
			if (iPotencia == 1)
			{
				//Agrega el potenciador, ejemplo: en 5^4 es decir ^4
				NodoPotencia->Potencia = objNuevoBloque;
				NodoPotencia = NodoPotencia->Potencia;

				//Si lo que sigue no es una potencia entonces cierra la lista de potencias
				if (cOperador != '^')
				{
					iPotencia=0;
					NodoPotencia->cOperador = 'N';
					if (cOperador=='*' || cOperador=='/')
						NodoMultip->cOperador = cOperador;
					else //Es una suma o una resta
					{
						NodoMultip->cOperador = '*';
						objNuevoBloque = new NodoSimple((float)1, 'N');
						NodoMultip->Derecha = objNuevoBloque;
						objPasea->cOperador = cOperador;
						iMultipDivi = 0;
					}
				}
			}
			else
			{
				if (cOperador == '^')
				{
					iPotencia = 0;

					//Crea un ACUMP (acumulador de potencia)
					NodoPotencia = new NodoSimple((float)0, 'B');

					//Agrega el ACUMP a la multiplicaci�n
					NodoMultip->Derecha = NodoPotencia;

					//Mueve NodoMultip hacia ACUMP
					NodoMultip = NodoPotencia;

					//ACUMP apunta al nuevo bloque
					NodoPotencia->Potencia = objNuevoBloque;

					//ACUMP se mueve a la �ltima potencia
					NodoPotencia = NodoPotencia->Potencia;
				}
				else
				{
					//Va hasta el �ltimo bloque de la derecha
					NodoMultip->Derecha = objNuevoBloque;
					NodoMultip = NodoMultip->Derecha;
				}

				//Si el nuevo bloque es numero+ o numero- entonces termina el enlace derecho
				if (cOperador == '+' || cOperador == '-')
				{
					iMultipDivi = 0;
					objNuevoBloque->cOperador = 'N';
					objPasea->cOperador = cOperador;
				}
			}
		}
	}
}


//============================================
//Evalua r�pidamente la expresi�n ya analizada
//============================================
float Evaluador::fEvaluar()
{
	ERRORMATEMATICO = NOERRORES;
	float fValor;
	NodoSimple *objNavegar;
	objNavegar = IniAnalizado;
	while(true)
	{
		if (objNavegar->Derecha!=NULL)
		{
			objNodo = objNavegar->Derecha;
			if (objNodo->iFuncion==0)
			{
				fValor = objNavegar->fNumero = fEvaluaSumaResta();
				if (ERRORMATEMATICO!=0) return 0;
			}
			else //Evalua la funci�n
			{
				switch(objNodo->iFuncion)
				{
					case 1:
					case 2: //Seno
						objNavegar->fNumero = sin(fValor);
						break;
					case 3: //Coseno
						objNavegar->fNumero = cos(fValor);
						break;
					case 4: //Tangente
						objNavegar->fNumero = tan(fValor);
						break;
					case 5: //valor absoluto
						if (fValor<0)
							objNavegar->fNumero = (float) -fValor;
						else
							objNavegar->fNumero = (float) fValor;
						break;
					case 6: //arcoseno
						if (fValor >= -1 && fValor <= 1)
							objNavegar->fNumero = (float) asin(fValor);
						else
						{	
							objNavegar->fNumero = 0;
							ERRORMATEMATICO = ERRORARCOSENO;
							return 0;
						}
						break;
					case 7: //arcocoseno
						if (fValor >= -1 && fValor <= 1)
							objNavegar->fNumero = (float) acos(fValor);
						else
						{
							objNavegar->fNumero = 0;
							ERRORMATEMATICO = ERRORARCOCOSENO;
							return 0;
						}
						break;
					case 8: //arcotangente
						objNavegar->fNumero = (float) atan(fValor);
						break;
					case 9: //Logaritmo
						objNavegar->fNumero = (float) log(fValor);
						break;
					case 10: //Valor techo
						objNavegar->fNumero = (float) ceil(fValor);
						break;
					case 11: //Exponencial
						objNavegar->fNumero = (float) exp(fValor);
						break;
					case 12: //Raiz Cuadrada
						objNavegar->fNumero = (float) sqrt(fValor);
						break;
					case 13: //Raiz Cubica
						objNavegar->fNumero = (float) pow(fValor, (float) 1/3);
						break;
				}
			}
		}

		//Condici�n de salida
		if (objNavegar->Abajo!=NULL)
			objNavegar=objNavegar->Abajo;
		else
			break;
	}
	return objNavegar->fNumero;
}

//Eval�a r�pidamente una serie de solo sumas y restas
float Evaluador::fEvaluaSumaResta()
{
	float fTotal = objNodo->fNumero;
	char cOperador = objNodo->cOperador;
	while (cOperador!='N')
	{
    	objNodo = objNodo->Abajo; //Pasa al siguiente operador

		//Si detecta una desviaci�n (multiplicaci�n y divisi�n)
		if (objNodo->Derecha!=NULL)
			objNodo->fNumero = fEvaluaMultiplicaDivide(objNodo);
    	
		//Suma o resta
		if (cOperador == '+')
			if (objNodo->objACUM!=NULL)
				fTotal += objNodo->objACUM->fNumero;
			else if (objNodo->cVariable==0)
 				fTotal += objNodo->fNumero;
			else
				fTotal += fVariables[objNodo->cVariable];
    	else
			if (objNodo->objACUM!=NULL)
				fTotal -= objNodo->objACUM->fNumero;
			else if (objNodo->cVariable==0)
 				fTotal -= objNodo->fNumero;
			else
				fTotal -= fVariables[objNodo->cVariable];
 		cOperador = objNodo->cOperador;
	}
	return fTotal;
}

//Eval�a r�pidamente una serie de solo multiplicaciones y divisiones
float Evaluador::fEvaluaMultiplicaDivide(NodoSimple *objMultiDivi)
{
	//Se desplaza a la derecha para calcular multiplicaciones y divisiones 
   	objMultiDivi = objMultiDivi->Derecha;

	//Trae el primer operador
	float fTotal;
	if (objMultiDivi->objACUM!=NULL)
		fTotal = objMultiDivi->objACUM->fNumero;
	else if (objMultiDivi->cVariable==0)
		fTotal = objMultiDivi->fNumero;
	else
		fTotal = fVariables[objMultiDivi->cVariable];

	char cOperador = objMultiDivi->cOperador;
	while (cOperador!='N')
	{
    	objMultiDivi = objMultiDivi->Derecha;

		//Si detecta una desviaci�n (potencias)
		if (objMultiDivi->Potencia!=NULL)
			objMultiDivi->fNumero = fEvaluaPotencia(objMultiDivi);

    	if (cOperador == '*')
			if (objMultiDivi->objACUM!=NULL)
				fTotal *= objMultiDivi->objACUM->fNumero;
			else if (objMultiDivi->cVariable==0)
 				fTotal *= objMultiDivi->fNumero;
			else
				fTotal *= fVariables[objMultiDivi->cVariable];
    	else
			if (objMultiDivi->objACUM!=NULL)
				if (objMultiDivi->objACUM->fNumero!=0)
 					fTotal /= objMultiDivi->objACUM->fNumero;
				else
					ERRORMATEMATICO = DIVISIONENTRECERO;
			else if (objMultiDivi->cVariable==0)
				if (objMultiDivi->fNumero!=0)
 					fTotal /= objMultiDivi->fNumero;
				else
					ERRORMATEMATICO = DIVISIONENTRECERO;
			else
				if (fVariables[objMultiDivi->cVariable]!=0)
					fTotal /= fVariables[objMultiDivi->cVariable];
				else 
					ERRORMATEMATICO = DIVISIONENTRECERO;
 		cOperador = objMultiDivi->cOperador;
	}
	return fTotal;
}

//Eval�a r�pidamente una serie de potencias
float Evaluador::fEvaluaPotencia(NodoSimple *objPotencia)
{
	//Se desplaza a la diagonal para calcular potencias
   	objPotencia = objPotencia->Potencia;

	//Trae el primer operador
	float fTotal;
	if (objPotencia->objACUM!=NULL)
		fTotal = objPotencia->objACUM->fNumero;
	else if (objPotencia->cVariable==0)
		fTotal = objPotencia->fNumero;
	else
		fTotal = fVariables[objPotencia->cVariable];

	char cOperador = objPotencia->cOperador;
	while (cOperador!='N')
	{
    	objPotencia = objPotencia->Potencia;
		if (objPotencia->objACUM!=NULL)
			fTotal = pow(fTotal, objPotencia->objACUM->fNumero);
		else if (objPotencia->cVariable==0)
			fTotal = pow(fTotal, objPotencia->fNumero);
		else
			fTotal = pow(fTotal, fVariables[objPotencia->cVariable]);
 		cOperador = objPotencia->cOperador;
	}
	return fTotal;
}

//Libera la memoria ocupada por el grafo
void Evaluador::vLiberaMemoria()
{
	vRecursivoLiberar(IniAnalizado);
}

//En forma recursiva pasea por todo el grafo liberando cada nodo
void Evaluador::vRecursivoLiberar(NodoSimple *objLibera)
{
	if (objLibera->Potencia!=NULL) vRecursivoLiberar(objLibera->Potencia);
	if (objLibera->Derecha!=NULL) vRecursivoLiberar(objLibera->Derecha);
	if (objLibera->Abajo!=NULL) vRecursivoLiberar(objLibera->Abajo);
	delete(objLibera);
}

/* Evalua la sintaxis de la expresi�n. Retorna un entero que identifica los tipos de error
0: Expresi�n correcta
*1: Dos o m�s signos est�n seguidos.  Ejemplo: 2++4, 5-*3
*2: Un signo seguido de un par�ntesis que cierra.  Ejemplo: 2-(4+)-7
*3: Un parentesis que abre seguido de un signo. Ejemplo: 2-(*3)
*4: Que empiece con signo +, *, / . Ejemplo: /12-5*2 ,  *17-4
*5: Que termine con signo . Ejemplo:  12-67*  2/3-
*6: Que los par�ntesis est�n desbalanceados. Ejemplo:  3-(2*4))
*7: Que haya par�ntesis vac�o. Ejemplo:  2-()*3
*8: As� est�n balanceados los par�ntesis no corresponde el que abre con el que cierra. Ejemplo: 2+3)-2*(4
*9: Un par�ntesis que cierra seguido de un n�mero. Ejemplo: (12-4)7-1
*10: Un n�mero seguido de un par�ntesis que abre. Ejemplo: 7-2(5-6)
*11: Doble punto en un n�mero de tipo real. Ejemplo: 3-2..4+1   7-6.46.1+2
*12: Funci�n inexistente:  Ejemplo: xyz(45)
*13: Funci�n no seguida de par�ntesis. Ejemplo: 2-sen5
*14: Funci�n seguida de par�ntesis que cierra. Ejemplo: 17-(sen)+78
*15: Antes de la funci�n no hay signo o parentesis que abre. Ejemplo: 12cos(3)
*16: Las variables solo son de una sola letra, no debe haber dos letras seguidas. Ejemplo: 3-xy+2*ab
*17: Una variable seguida de un par�ntesis que abre. Ejemplo: 7-x(5-6)
*18: Un par�ntesis que cierra seguido de una variable. Ejemplo: (12-4)y-1
*19: Una variable seguida de un punto. Ejemplo: 4-z.1+3
*20: Un punto seguido de una variable. Ejemplo: 7-2.p+1
*21: Un n�mero antes o despu�s de una variable. Ejemplo: 3x+1  x21+4  . Nota: Algebraicamente es aceptable 3x+1 pero entonces vuelve mas complejo un evaluador porque debe saber que 3x+1 es en realidad 3*x+1
*22: Hayan caracteres extra�os.  4+@-1
*23: Que haya divisi�n entre cero  4/0+1  12/0.0+1

*/
int Evaluador::iAnalizaSintaxis(char *sExpresion)
{
	int iTamanoExpresion = strlen(sExpresion);

	//Saca una copia de la expresi�n del usuario en otra variable y as� poder trabajar esa variable
	//Retira los espacios y vuelve a min�sculas toda la expresi�n
	char *sNueva = (char *) malloc(iTamanoExpresion*sizeof(char)+ 6);
	int iAvance=0;
	for (int iLetra=0; iLetra<iTamanoExpresion; iLetra++)
	{
		if (sExpresion[iLetra]!=' ')
			if(sExpresion[iLetra]>='A' && sExpresion[iLetra]<='Z') //Vuelve a min�sculas
				sNueva[iAvance++]=sExpresion[iLetra]+32;
			else
				sNueva[iAvance++]=sExpresion[iLetra];
	}
	sNueva[iAvance]='\0';
	sNueva[iAvance+1]='\0';
	sNueva[iAvance+2]='\0';
	sNueva[iAvance+3]='\0';
	sNueva[iAvance+4]='\0';

	//Chequea la sintaxis
	int iCont=0;
	if (sNueva[0]=='^' || sNueva[0]== '*' || sNueva[0]=='+' || sNueva[0]=='/') { free(sNueva); return 4; }

	int iParentesis=0;
	int iPunto=0;
	for(iCont=0; *(sNueva+iCont); iCont++)
	{
		if (iCont>0)
			if (sNueva[iCont]>='a' && sNueva[iCont]<='z')
				if (sNueva[iCont+1]>='a' && sNueva[iCont+1]<='z')
					if (sNueva[iCont+2]>='a' && sNueva[iCont+2]<='z')
						if (sNueva[iCont-1]!='(' && sNueva[iCont-1]!='+' && sNueva[iCont-1]!='-' && sNueva[iCont-1]!='*' && sNueva[iCont-1]!='/' && sNueva[iCont-1]!='^')
						{ free(sNueva); return 15; }

		if (sNueva[iCont]>='a' && sNueva[iCont]<='z')
			if (sNueva[iCont+1]>='a' && sNueva[iCont+1]<='z')
				if (sNueva[iCont+2]>='a' && sNueva[iCont+2]<='z')
					if (sNueva[iCont+3]!='(')
					{ free(sNueva); return 13; }

		if (sNueva[iCont]>='a' && sNueva[iCont]<='z')
			if (sNueva[iCont+1]>='a' && sNueva[iCont+1]<='z')
				if (sNueva[iCont+2]>='a' && sNueva[iCont+2]<='z')
					if (sNueva[iCont+3]==')')
					{ free(sNueva); return 14; }

		if (sNueva[iCont]>='a' && sNueva[iCont]<='z')
			if (sNueva[iCont+1]=='.')
			{  free(sNueva); return 19; }

		bool bNoExiste=true;
		if (sNueva[iCont]>='a' && sNueva[iCont]<='z')
			if (sNueva[iCont+1]>='a' && sNueva[iCont+1]<='z')
				if (sNueva[iCont+2]>='a' && sNueva[iCont+2]<='z')
					if (sNueva[iCont+3]=='(')
					{
						for (int iPosible=0; *(cFuncion+iPosible); iPosible++)
							if ( cFuncion[iPosible]==sNueva[iCont] && cFuncion[iPosible+1]==sNueva[iCont+1] && cFuncion[iPosible+2]==sNueva[iCont+2])
								bNoExiste=false;
						if (bNoExiste)
						{  free(sNueva); return 12; }
					}

		if (sNueva[iCont]=='.')
			if (sNueva[iCont+1]>='a' && sNueva[iCont+1]<='z')
			{  free(sNueva); return 20; }

		if (sNueva[iCont]==')')
			if (sNueva[iCont+1]>='a' && sNueva[iCont+1]<='z')
			{  free(sNueva); return 18; }

		if (sNueva[iCont]=='+' || sNueva[iCont]== '-' || sNueva[iCont]=='*' || sNueva[iCont]=='/' || sNueva[iCont]=='^')
			if (sNueva[iCont+1]=='+' || sNueva[iCont+1]== '-' || sNueva[iCont+1]=='*' || sNueva[iCont+1]=='/' || sNueva[iCont+1]=='^')
			{  free(sNueva); return 1; }

		if (sNueva[iCont]=='+' || sNueva[iCont]== '-' || sNueva[iCont]=='*' || sNueva[iCont]=='/' || sNueva[iCont]=='^')
			if( sNueva[iCont+1]==')')
			{  free(sNueva); return 2; }

		if (sNueva[iCont]=='(')
			if (sNueva[iCont+1]=='+' || sNueva[iCont+1]=='*' || sNueva[iCont+1]=='/' || sNueva[iCont+1]=='^')
			{  free(sNueva); return 3; }

		if (sNueva[iCont]=='(' && sNueva[iCont+1]==')')
		{  free(sNueva); return 7; }

		if (sNueva[iCont+1]>='0' && sNueva[iCont+1]<='9' && sNueva[iCont]==')')
		{  free(sNueva); return 9; }

		if (sNueva[iCont]>='0' && sNueva[iCont]<='9' && sNueva[iCont+1]=='(')
		{  free(sNueva); return 10; }

		if( sNueva[iCont]=='(' ) iParentesis++;
		if( sNueva[iCont]==')' ) iParentesis--;
		if (iParentesis<0)
		{  free(sNueva); return 8; }

		if (sNueva[iCont]=='+' || sNueva[iCont]== '-' || sNueva[iCont]=='*' || sNueva[iCont]=='/' || sNueva[iCont]=='^')
			iPunto=0;

		if (sNueva[iCont]=='.') iPunto++;
		if (iPunto>1)
		{  free(sNueva); return 11; }

	}
	if(iParentesis) {  free(sNueva); return 6; }
	if (sNueva[iCont-1]=='^' || sNueva[iCont-1]=='-' || sNueva[iCont-1]== '*' || sNueva[iCont-1]=='+' || sNueva[iCont-1]=='/')
	{  free(sNueva); return 5; }

	//Chequea las funciones, va de atr�s hacia adelante buscando un ( y luego extrae las tres letras
	iTamanoExpresion = strlen(sNueva);
	char cLetraA, cLetraB, cLetraC;
	for(iCont=iTamanoExpresion; iCont>=3; iCont--)
	{
		if (sNueva[iCont]=='(')
		{
			cLetraA = sNueva[iCont-3];
			cLetraB = sNueva[iCont-2];
			cLetraC = sNueva[iCont-1];

			//Busca esas tres letras en cFuncion
			for (int iLetra=0; iLetra<strlen(cFuncion)-3; iLetra++)
				if (cLetraA==cFuncion[iLetra] && cLetraB==cFuncion[iLetra+1] && cLetraC==cFuncion[iLetra+2])
				{
					sNueva[iCont-3]='0';
					sNueva[iCont-2]='0';
					sNueva[iCont-1]='+';
				}
		}
	}

	//Chequea si quedan dos o mas variables seguidas
	for(iCont=0; *(sNueva+iCont); iCont++)
	{
		if (sNueva[iCont]>='a' && sNueva[iCont]<='z')
				if (sNueva[iCont+1]>='a' && sNueva[iCont+1]<='z')
				{ free(sNueva); return 16; }

		if (sNueva[iCont]>='a' && sNueva[iCont]<='z')
				if (sNueva[iCont+1]=='(')
				{ free(sNueva); return 17; }

		if (sNueva[iCont]>='a' && sNueva[iCont]<='z')
				if (sNueva[iCont+1]>='0' && sNueva[iCont+1]<='9')
					{ free(sNueva); return 21; }

		if (sNueva[iCont]>='0' && sNueva[iCont]<='9')
				if (sNueva[iCont+1]>='a' && sNueva[iCont+1]<='z')
					{ free(sNueva); return 21; }

		bool bDivideCero = true;
		if (sNueva[iCont]=='/')
		{
			for (int iDivide=iCont+1; *(sNueva+iDivide); iDivide++)
			{
				if (sNueva[iDivide]>='1' && sNueva[iDivide]<='9') { bDivideCero=false; break; }
				if (sNueva[iDivide]>='a' && sNueva[iDivide]<='z') { bDivideCero=false; break; }
				if (sNueva[iDivide]=='+' || sNueva[iDivide]=='-' || sNueva[iDivide]=='*' || sNueva[iDivide]=='/' || sNueva[iDivide]==')' || sNueva[iDivide]=='(') break; 
			}
			if (bDivideCero)
				{ free(sNueva); return 23; }
		}
	}

	//Chequea si hay caracteres extra�os
	for(iCont=0; *(sNueva+iCont); iCont++)
	{
		if (sNueva[iCont]>='0' && sNueva[iCont]<='9') sNueva[iCont]='.';
		if (sNueva[iCont]>='a' && sNueva[iCont]<='z') sNueva[iCont]='.';
		if (sNueva[iCont]=='+' || sNueva[iCont]=='-' || sNueva[iCont]=='*' || sNueva[iCont]=='/' || sNueva[iCont]=='^') sNueva[iCont]='.';
		if (sNueva[iCont]=='(' || sNueva[iCont]==')') sNueva[iCont]='.';
	}

	for(iCont=0; *(sNueva+iCont); iCont++)
		if (sNueva[iCont]!='.')
		{ free(sNueva); return 22; } 
	
	return 0;
}

