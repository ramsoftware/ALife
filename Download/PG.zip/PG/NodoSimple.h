/* Lista simplemente enlazada para evaluar una expresi�n muy simple (sin par�ntesis).

Su funcionamiento es as�:
Esta expresi�n 4+5-2*3/4*6+7+3-8/2*5-4 se convierte a esto
4+
5-
ACUM+ (2* 3/ 4* 6N)
7+
3-
ACUM- (8/ 2* 5N)
4N

De esa manera resolver la expresi�n simple es solo ir de arriba a abajo con desviaciones
a la derecha cuando encuentra multiplicaciones y divisiones */

class NodoSimple
{
public:
	unsigned int iFuncion; //Si es una funci�n
	unsigned char cVariable;  //Que variable es de la expresion simple
    float fNumero;  //Numero en la expresion simple
    unsigned char cOperador; //Operador en la expresi�n simple

	//Expresi�n simple todo es suma y resta 
	NodoSimple *Abajo;

	//Desviaci�n derecha multiplica/divide
	NodoSimple *Derecha;

	//Desviaci�n potencia
	NodoSimple *Potencia;

	//Lista de expresi�n analizada (los ACUMs)
	NodoSimple *Arriba;

	//Expresi�n simple apunta a un operador que es un ACUMULADOR
	NodoSimple *objACUM;

    //Constructor 1
    NodoSimple(float fNumero, unsigned char cOperador);

	//Constructor 2
	NodoSimple(unsigned char cVariable, unsigned char cOperador);

	//Constructor 3
	NodoSimple(void);

	//Constructor 4
	NodoSimple(NodoSimple *);

	//Constructor 5
	NodoSimple(NodoSimple *, unsigned char cOperador);
};
