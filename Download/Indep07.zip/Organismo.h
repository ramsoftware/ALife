/* Clase Organismo

Exones: son las porciones de ADN con un c�digo funcional.
Se ha argumentado que los exones podr�an ser antiguos "minigenes"
que en un principio codificaban peque�as secuencias funcionales
de amino�cidos. Seg�n esta hip�tesis, las prote�nas modernas
habr�an surgido por agregaci�n de varias de estas secuencias
amino�cidos.

Intrones: En muchos organismos, una cantidad sorprendentemente grande
del ADN no parece intervenir activamente en la codificaci�n de
proteinas. Esta proporci�n var�a seg�n las especies: por ejemplo del 
9% al 27% en humanos, 75% en nematodos, 67% en moscas de la fruta,
99% en peces pulmonados. Parte de este ADN no codificador esta formado
por intrones.

Esta clase representar�a un exon o intron porque es en si una
instrucci�n completa del algoritmo gen�tico.

En el ADN de cualquier ser vivo se encuentra cuatro(4) tipos de bases
nitrogenadas que forman los nucle�tidos:
Adenina (A)
Timina (T)
Citosina (C)
Guanina (G)

Cada pelda�o de la escalera del ADN esta formado por la uni�n de dos
bases, la pareja es as�:
Adenina con Timina
Citosina con Guanina

Los nucle�tidos A, T, C, G son como las letras de un alfabeto gen�tico,
con el que se ha elaborado un lenguaje para la informaci�n gen�tica.
Este lenguaje esta formado exclusivamente por tres palabras de tres
letras: AAA, CGT, TCC, etc.. Esto es lo que se conoce como c�digo de
tripletes. En �ltimo t�rmino, cada uno de estos tripletes equivale,
en t�rminos de producci�n, a un amino�cido concreto. Los amino�cidos
son las unidades estructurales de las prote�nas; las prote�nas forman
el cuerpo de los organismos, y tambi�n son prote�nas las enzimas y
hormonas responsables de su funcionamiento.

Autor:		Rafael Alberto Moreno Parra
URL:		http://www.geocities.com/krousky
Clase:		Organismo
Lenguaje:	C++
Fecha:		01 de Julio de 2002

*/

#include <time.h>
#include "Aleatorio.h"

class Organismo {
private:
	struct stTriplete
	{
		bool bEjecuta; /* Se coloca a TRUE si la instruccion es ejecutada */
		unsigned int iInstruccion; /* C�digo de la Instrucci�n IF_Mayor, IF_Menor, SET o una funcion */
		unsigned int iVariable; /* Variable para asignarse o para comparaci�n */
		bool bEsVariable1; /* iOperando1 es una variable o un numero */
		unsigned int iOperando1; /* Variable o numero 1 en la expresi�n */
		bool bEsVariable2; /* iOperando2 es una variable o un numero */
		unsigned int iOperando2; /* Variable o numero 1 en la expresi�n */
		unsigned char cOperador; /* + - por dividido */
		unsigned int iGotoLabel; /* Hacia que instrucci�n ir� */
	}; /* 1bit + 4bytes + 4bytes + 1bit + 4bytes + 1bit + 4bytes + 1byte + 4 bytes = 22 bytes */
	/* Nota: El anterior consumia 86 bytes por instrucci�n */

	bool m_bGenRandom; //N�mero de Genes fijos o aleatorio
	unsigned int m_iMinInstr; //Minimo numero de intrucciones
	unsigned int m_iMaxInstr; //Maximo numero de intrucciones
	unsigned int m_iTotalFuncion; //Total Funciones del ambiente
    unsigned int m_iTotalVariables; //Total Variables del Organismo
  	unsigned int m_iMaxiCiclos; //Maximos ciclos para evaluar organismo
	unsigned int m_iProbabIF; //Probabilidad IF
	unsigned int m_iProbabFN; //Probabilidad Funcion
	unsigned int m_iProbaVar; //Probabilidad de usar Variables

public:
    //Constructor
	Organismo();

	//Inicia la semilla de los n�meros aleatorios (tiempo)
	Aleatorio objAzar;
	void IniciaSemilla(unsigned long int iSemilla);
	
	//Fija las probabilidades en la estructura
	void vInicio (bool bGenRandom,
				  unsigned int iMinInstr,
				  unsigned int iMaxInstr,
                  unsigned int iTotalFuncion,
				  unsigned int iTotalVariable,
  				  unsigned int iMaxiCiclos,
				  unsigned int iProbabIF,
				  unsigned int iProbabFN,
				  unsigned int iProbaVar);

	//Crea el Organismo
    void vCreaADN();
    void vHaceGen(unsigned int iLabel);
	void vMutaGen();


	//Muestra como esta armado el Organismo
	void sDisplayADN(char *sbADN);

	//Ejecuta el Organismo
	int iEvalOrganismo (unsigned int *iOrgGenInst, unsigned int *iFuncion);
	int iVariable[70]; // Hasta 70 variables

	struct stTriplete m_oTriplete[5000]; //Hasta 5000 instrucciones
	unsigned int m_iMaxGenOrg; //Maximo numero de intrucciones real
	unsigned int iPuntAdapta; //Adaptaci�n ser vivo

	int _matherr(struct exception *a);
};
