class MasApto
{
public:
    Gen m_oGen[67]; //Genes del ser vivo
	int m_iMaxGenOrg;
};

