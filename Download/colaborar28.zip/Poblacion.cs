﻿namespace colaborar28 {
    internal class Poblacion {
        public List<Individuo> individuos;

        public Poblacion(Random Azar, int TotalIndividuos, int TotalSumandos, int MaxColumnasMatriz) {
            individuos = new List<Individuo>();
            for (int indiv=0; indiv < TotalIndividuos; indiv++) {
                individuos.Add(new Individuo(Azar, TotalSumandos, MaxColumnasMatriz));
            }
        }
        public void Proceso(Random Azar, Ambiente ambiente, Matriz matriz, int CiclosAjustarIndividuo) {
            for (int cont = 0; cont < individuos.Count; cont++) {
                individuos[cont].Ajusta(Azar, ambiente, matriz, CiclosAjustarIndividuo);
            }
        }
    }
}
