﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace colaborar28 {
    internal class Matriz {
        public List<Columna> columna;

        public Matriz() {
            columna = new List<Columna>();
        }

        //Genera la matriz de sumandos, cada columna es un sumando y cada fila es un dato del ambiente
        public void Genera(Random Azar, int MaxColumnas, List<Datos> dato) {
            for (int cont = 0; cont < MaxColumnas; cont++)
                columna.Add(new Columna(Azar, dato));

            /*Console.WriteLine("\r\nMatriz de Sumandos");
            for (int fila = 0;  fila < dato.Count; fila++) {
                for (int col = 0; col < MaxColumnas; col++) {
                    Console.Write(columna[col].Valores[fila] + ";");
                }
                Console.WriteLine(" ");
            }*/
        }

        //Dada determinadas columnas, hace la suma de los valores en la Fila en particular
        public int SumaFilas(int Fila, List<int> Columnas) {
            int Total = 0;
            for (int cont = 0; cont < Columnas.Count; cont++) {
                Total += columna[Columnas[cont]].Valores[Fila];
            }
            return Total;
        }
    }
}
