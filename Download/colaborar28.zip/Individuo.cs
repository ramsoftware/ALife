﻿
namespace colaborar28 {
    internal class Individuo {
        public List<int> ListaSuma;
        private int QueSumandoCambia, QueValorTenia;
        public int Ajuste; //Mantiene la distancia del individuo al ambiente, entre más cercano a cero, es mejor

        //Cuantos sumandos a+b+c+..... tendrá el individuo
        //El máximo número de columnas que tendrá la matriz
        public Individuo(Random Azar, int TotalSumandos, int MaxColumnas) {
            ListaSuma = new List<int>();
            Ajuste = int.MaxValue;

            for (int cont = 1; cont <= TotalSumandos; cont++)
                ListaSuma.Add(Azar.Next(MaxColumnas));
        }

        private void CambiaIndividuo(Random Azar, Matriz matriz) {
            QueSumandoCambia = Azar.Next(ListaSuma.Count);
            QueValorTenia    = ListaSuma[QueSumandoCambia];
            ListaSuma[QueSumandoCambia] = Azar.Next(matriz.columna.Count);
        }

        private void RestauraIndividuo() {
            ListaSuma[QueSumandoCambia] = QueValorTenia;
        }

        public void Ajusta(Random Azar, Ambiente ambiente, Matriz matriz, int CiclosAjustarIndividuo) {
            Ajuste = int.MaxValue;
            for (int ciclos = 1; ciclos <= CiclosAjustarIndividuo; ciclos++) {

                //Hace el cambio de la expresión de sumandos
                CambiaIndividuo(Azar, matriz);

                //Determina la diferencia entre ambiente e individuo
                int Diferencia = 0;
                for (int dato = 0; dato < ambiente.datos.Count; dato++) {
                    int ValorIndividuo = matriz.SumaFilas(dato, ListaSuma);
                    int ValorAmbiente = ambiente.datos[dato].valorYint;
                    Diferencia += Math.Abs(ValorIndividuo - ValorAmbiente);
                }

                //Si el nuevo cambio funciona se actualiza la mínima diferencia
                if (Diferencia <= Ajuste)
                    Ajuste = Diferencia;
                else //Si el nuevo cambio empeoró, se restaura el anterior sumando
                    RestauraIndividuo();
            }
        }
    }
}
