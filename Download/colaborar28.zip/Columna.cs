﻿namespace colaborar28 {
    internal class Columna {
        public double valA, valB, valC;
        public List<int> Valores;

        public Columna(Random Azar, List<Datos> datos) {
            int Limite = 2;
            valA = Limite * Azar.NextDouble() - Limite * Azar.NextDouble();
            valB = Limite * Azar.NextDouble() - Limite * Azar.NextDouble();
            valC = Limite * Azar.NextDouble() - Limite * Azar.NextDouble();

            Valores = new List<int>();
            for (int cont = 0; cont < datos.Count; cont++) {
                double Y= valC * Math.Cos((valA * datos[cont].valorXint + valB) * Math.PI / 180);
                Valores.Add((int)Math.Truncate(Y * 100));
            }
        }
    }
}
