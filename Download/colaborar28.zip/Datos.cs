﻿namespace colaborar28 {
    internal class Datos {

        //Valores originales
        public double valorXoriginal;
        public double valorYoriginal;

        //Valores normalizados
        public double valorXn;
        public double valorYn;

        //Valores en enteros
        public int valorXint;
        public int valorYint;

        public void Normaliza(double MinX, double MaxX, double MinY, double MaxY) {
            valorXn = (valorXoriginal - MinX) / (MaxX - MinX);
            valorYn = (valorYoriginal - MinY) / (MaxY - MinY);
        }

        public Datos(double valorX, List<double> Coeficientes) {
            valorXoriginal = valorX;
            for (int cont=0; cont < Coeficientes.Count; cont+=3) {
                valorYoriginal += Coeficientes[cont] * Math.Sin((Coeficientes[cont + 1] * valorXoriginal + Coeficientes[cont + 2])*Math.PI/180);
            }
        }

        public void ValorEntero(int Factor) {
            valorXint = (int)Math.Truncate(valorXn * Factor);
            valorYint = (int)Math.Truncate(valorYn * Factor) - Factor/2;
        }
    }
}
