﻿namespace colaborar28 {
    internal class Ambiente {
        public List<Datos> datos = new List<Datos>();

        //Genera una serie de datos para hacer pruebas
        //Usando la expresión
        //Y = a * seno(b * X + c) + d * seno(e * X + f) + g * seno(h * X + i) + .....
        //Los coeficientes a, b, c, d, e, f son generados al azar entre -1 y 1
        //X empieza desde un valor aletorio entre 0 y 1, y va aumentando de 0 a 1
        public void Genera(Random Azar, int NumeroCurvas, int NumValores) {
            //Coeficientes de las curvas
            List<double> Coef = new List<double>();
            for (int cont = 0; cont < NumeroCurvas; cont++) {
                Coef.Add(Azar.NextDouble());
                Coef.Add(Azar.NextDouble());
                Coef.Add(Azar.NextDouble());
            }

            Console.WriteLine("\r\n\r\nAmbiente: Coeficientes de la ecuación que lo genera");
            for (int cont = 0; cont < NumeroCurvas; cont+=3) {
                Console.WriteLine(Coef[cont] + ";" + Coef[cont+1] + ";" + Coef[cont+2]);
            }

            //Genera los datos de la curva
            double TopeX = 0;
            for (int cont = 0; cont < NumValores; cont++) {
                TopeX += Azar.NextDouble();
                datos.Add(new Datos(TopeX, Coef));
            }

            //Determina máximos y mínimos
            double MinX = Double.MaxValue;
            double MaxX = Double.MinValue;
            double MinY = Double.MaxValue;
            double MaxY = Double.MinValue;
            for (int cont = 0; cont < datos.Count; cont++) {
                if (datos[cont].valorXoriginal < MinX) MinX = datos[cont].valorXoriginal;
                if (datos[cont].valorXoriginal > MaxX) MaxX = datos[cont].valorXoriginal;
                if (datos[cont].valorYoriginal < MinY) MinY = datos[cont].valorYoriginal;
                if (datos[cont].valorYoriginal > MaxY) MaxY = datos[cont].valorYoriginal;
            }

            //Normaliza quedando el valor entre 0 y 1
            for (int cont = 0; cont < datos.Count; cont++)
                datos[cont].Normaliza(MinX, MaxX, MinY, MaxY);

            //Convierte a enteros multiplicando por 1000 los valores normalizados
            for (int cont = 0; cont < datos.Count; cont++)
                datos[cont].ValorEntero(1000);

            //Se eliminan los valores repetidos en X
            Console.WriteLine("\r\nAmbiente: Tamaño original de datos es " + datos.Count);
            int Posicion = 0;
            while (Posicion < datos.Count - 1) {
                int PosibleRepite = Posicion;
                while (datos[PosibleRepite].valorXint == datos[PosibleRepite + 1].valorXint)
                    datos.RemoveAt(PosibleRepite + 1);
                Posicion++;
            }
            Console.WriteLine("Ambiente: Tamaño quitando repetidos es " + datos.Count);

            //Imprime el ambiente
            /*Console.WriteLine("\r\nXorig; Yorig; Xnorm; Ynorm; Xint; Yint");
            for (int cont = 0; cont < datos.Count; cont++) {
                Console.WriteLine(
                    datos[cont].valorXoriginal + ";" +
                    datos[cont].valorYoriginal + ";" +
                    datos[cont].valorXn + ";" +
                    datos[cont].valorYn + ";" +
                    datos[cont].valorXint + ";" +
                    datos[cont].valorYint);
            }*/
        }
    }
}
