﻿
namespace colaborar28 {
    internal class Program {

        static void Main() {
            Random Azar = new Random();
            for (int simula = 1; simula <= 5; simula++)
                Simulacion(Azar);
        }

        static void Simulacion(Random Azar) {
            //El ambiente
            Ambiente ambiente = new Ambiente();
            int NumeroCurvas = 20; //Número de curvas de tipo Y=a*seno(b*X+c) que crearán el ambiente
            int NumeroDatos = 2000; //Cuántos datos generará el ambiente
            ambiente.Genera(Azar, NumeroCurvas, NumeroDatos);

            //Genera una matriz donde cada columna es un conjunto de valores que servirán para sumar
            int MaxColumnasMatriz = 200;
            Matriz matriz = new Matriz();
            matriz.Genera(Azar, MaxColumnasMatriz, ambiente.datos);

            //El proceso para hallar el mejor individuo
            int TotalSumandos = 20;
            int TotalIndividuos = 20;
            int CiclosAjustarIndividuo = 100000;
            Poblacion poblacion = new Poblacion(Azar, TotalIndividuos, TotalSumandos, MaxColumnasMatriz);
            poblacion.Proceso(Azar, ambiente, matriz, CiclosAjustarIndividuo);

            //Deduce el mejor individuo
            int MejorIndividuo = -1;
            int MejorAjuste = int.MaxValue;
            for (int indiv = 0; indiv < poblacion.individuos.Count; indiv++) {
                if (poblacion.individuos[indiv].Ajuste < MejorAjuste) {
                    MejorAjuste = poblacion.individuos[indiv].Ajuste;
                    MejorIndividuo = indiv;
                }
            }

            //Imprime el ambiente y el mejor individuo
            Console.WriteLine("\r\nXint;Yint;Individuo");
            for (int dato = 0; dato < ambiente.datos.Count; dato++) {
                int Total = 0;
                for (int sumandos = 0; sumandos < poblacion.individuos[MejorIndividuo].ListaSuma.Count; sumandos++) {
                    int QueSuma = poblacion.individuos[MejorIndividuo].ListaSuma[sumandos];
                    Total += matriz.columna[QueSuma].Valores[dato];
                }
                Console.WriteLine(ambiente.datos[dato].valorXint + ";" + ambiente.datos[dato].valorYint + ";" + Total);
            }
        }
    }
}