/*
* @(#)Motor de Vida Artificial
* 
* Es un conjunto de subrutinas que simulando la Evoluci�n de las Especies,
* puedan crear programas (codigo fuente) que se adapten a un ambiente en particular.
* Todo software tiene entradas y salidas. Las entradas son procesadas y se emite un resultado
* que son las salidas. Este proceso es implementado por un Dise�ador/Programador.
* Ahora bien, si usamos un sistema que usa principios evolutivos, este proceso puede nacer
* por si solo, esto tiene sus ventajas:
* 1. No se requiere de personal humano (programadores) para crear el proceso.
* 2. Puede disminuirse o anularse la posiblidad de errores en el proceso.
* 3. Ante nuevos requerimientos (nuevas entradas o formatos de salida) el proceso se adaptara.
* 4. Capaz de encontrar o acercarse a soluciones de problemas muy complejos.
* 
* El obst�culo:
*  Conseguir un proceso que ofrezca salidas esperadas a unas entradas, usando principios evolutivos
*  puede tardar un tiempo considerablemente alto. Con los nuevos procesadores a mayores velocidades y
*  un buen algoritmo evolutivo, el tiempo puede ser disminuido, de tal manera que podria entrar a
*  competir con programadores humanos.
*/

import java.util.*;

class Organismo
{
    Gen oGen[] = new Gen[80]; //Genes del ser vivo
    EvalExpr eEvalua[] = new EvalExpr[80]; //Expresiones de asignacion evaludas previamente
    int iMaxGenOrg; //Maximo numero de genes para el organismo
    int iMaxiCiclos; //Maximo numero de ciclos que se gastaran para evaluar el organismo 
    
    public String sDisplayADN()
    {
        char cEnter = '\n';
        String sbADN="float fSerVivo(float X)" + cEnter + "{" + cEnter + "float W=0, Y=0, Z=0;" + cEnter + cEnter;
        for (int iCont=1; iCont<=iMaxGenOrg; iCont++)
        {
            sbADN += String.valueOf(iCont) + ": ";

            //Reemplaza la expresion por la variable activa
            String sbTmp = "";
            for (int iChar=0; iChar < oGen[iCont].sbExpresion.length(); iChar++)
                if (oGen[iCont].sbExpresion.charAt(iChar)=='X')
                    sbTmp += oGen[iCont].cVarActiva;
                else
                    sbTmp += oGen[iCont].sbExpresion.charAt(iChar);
                    
            //Organiza los if y asignaciones
            if (oGen[iCont].cTipInst == 'I')
                sbADN += "if( " + oGen[iCont].cVariable + " " + oGen[iCont].cOperacion + " " + oGen[iCont].sbExpresion + " ) goto " + String.valueOf(oGen[iCont].iGotoLabel) + ";" + cEnter;
            else                
                sbADN += oGen[iCont].cVariable + " = " + oGen[iCont].sbExpresion + ";" + cEnter;
        }    
        //Finaliza la expresion
        sbADN += "return Y;" + cEnter + "}";
                
        return sbADN;
    }

    public void vCreaADN (int iMaxGenes, int iMaxCicl)
    {
        int iCont, iCont1, iCont2, iCont3, iCont4;
               
        iMaxGenOrg = iMaxGenes;
        iMaxiCiclos = iMaxCicl;
        
        //Crea los genes
        for (iCont=1; iCont<=iMaxGenes; iCont++)
            oGen[iCont] = new Gen();
            
        for (iCont=1; iCont<=iMaxGenes; iCont++)
           vHaceGen ( iCont, iMaxGenes,
                       50, 50,
                       25, 25, 25, 25,
                       25, 25, 25, 25,
                        10, 30, 10, 60);
        
        //Evalua previamente las expresiones de asignacion para dar mayor velocidad
        for (iCont=1; iCont<=iMaxGenes; iCont++)
            eEvalua[iCont] = new EvalExpr();

        double dResultado;
        for (iCont=1; iCont<=iMaxGenes; iCont++)
           dResultado = eEvalua[iCont].dCapturaecuacion(oGen[iCont].sbExpresion, 0, 0);            
        
    }
    
    public float fEvalOrganismo (float fValX)
    {                   
        /* Viene la interpretacion, los valores X se disparan de 1 a n y se comparan con el ambiente Y */
        float fValW=0, fValY=0, fValZ=0, fValor=0, fResultado=0;
        int iGenOrg=1;
        int iNumCiclos=0; //Contador de Ciclos
        while (iGenOrg!=0 && iGenOrg<=iMaxGenOrg && iNumCiclos <= iMaxiCiclos)
        {
             // Aumenta el # de Ciclos
             iNumCiclos++;
            
             //Que variable esta jugando dentro de la expresion
             switch (oGen[iGenOrg].cVarActiva)
             {
                case 'W': fValor = fValW; break;
                case 'X': fValor = fValX; break;
                case 'Y': fValor = fValY; break;
                case 'Z': fValor = fValZ; break;
             }
            
             //Evalua la expresion
             //double dResultado = eEvalua.dCapturaecuacion(oGen[iGenOrg].sbExpresion, dValor, 0);
		     fResultado = (float) eEvalua[iGenOrg].CicloEvalua((double)fValor, 0);

		     //Si es un SET asigna el valor a la variable del Gen
		     if (oGen[iGenOrg].cTipInst == 'S')
		     {
		        switch(oGen[iGenOrg].cVariable)
		        {
		            case 'W': fValW = fResultado; break;
		            case 'X': fValX = fResultado; break;
		            case 'Y': fValY = fResultado; break;
		            case 'Z': fValZ = fResultado; break;
		        }
		        iGenOrg++; //Ignora el salto en un SET
             }
             else //Es un If condicional
             {
                switch(oGen[iGenOrg].cOperacion)
                {
                    case '>':
                        switch(oGen[iGenOrg].cVariable)
		                {
		                    case 'W': if (fValW > fResultado) iGenOrg=oGen[iGenOrg].iGotoLabel; else iGenOrg++; break;
		                    case 'X': if (fValX > fResultado) iGenOrg=oGen[iGenOrg].iGotoLabel; else iGenOrg++; break;
		                    case 'Y': if (fValY > fResultado) iGenOrg=oGen[iGenOrg].iGotoLabel; else iGenOrg++; break;
		                    case 'Z': if (fValZ > fResultado) iGenOrg=oGen[iGenOrg].iGotoLabel; else iGenOrg++; break;
		                }
		                break;
                    case '<':
                        switch(oGen[iGenOrg].cVariable)
		                {
		                    case 'W': if (fValW < fResultado) iGenOrg=oGen[iGenOrg].iGotoLabel; else iGenOrg++; break;
		                    case 'X': if (fValX < fResultado) iGenOrg=oGen[iGenOrg].iGotoLabel; else iGenOrg++; break;
		                    case 'Y': if (fValY < fResultado) iGenOrg=oGen[iGenOrg].iGotoLabel; else iGenOrg++; break;
		                    case 'Z': if (fValZ < fResultado) iGenOrg=oGen[iGenOrg].iGotoLabel; else iGenOrg++; break;
		                }
		                break;
                    case '=':
                        switch(oGen[iGenOrg].cVariable)
		                {
		                    case 'W': if (fValW == fResultado) iGenOrg=oGen[iGenOrg].iGotoLabel; else iGenOrg++; break;
		                    case 'X': if (fValX == fResultado) iGenOrg=oGen[iGenOrg].iGotoLabel; else iGenOrg++; break;
		                    case 'Y': if (fValY == fResultado) iGenOrg=oGen[iGenOrg].iGotoLabel; else iGenOrg++; break;
		                    case 'Z': if (fValZ == fResultado) iGenOrg=oGen[iGenOrg].iGotoLabel; else iGenOrg++; break;
		                }
		                break;
                    case '!':
                        switch(oGen[iGenOrg].cVariable)
		                {
		                    case 'W': if (fValW != fResultado) iGenOrg=oGen[iGenOrg].iGotoLabel; else iGenOrg++; break;
		                    case 'X': if (fValX != fResultado) iGenOrg=oGen[iGenOrg].iGotoLabel; else iGenOrg++; break;
		                    case 'Y': if (fValY != fResultado) iGenOrg=oGen[iGenOrg].iGotoLabel; else iGenOrg++; break;
		                    case 'Z': if (fValZ != fResultado) iGenOrg=oGen[iGenOrg].iGotoLabel; else iGenOrg++; break;
		                }
		                break;
		        }
		     }
		} //Fin de la evaluacion del ser vivo
		return fValY;
     }
     
     /* Crea una linea de codigo fuente (la llam� Gen). El formato es:
        label, [, IF/SET, Variable, =/>/</!, (, expresion, ), Goto, Label, ]
        para mayor velocidad, se ubica en una clase el Gen */
     void vHaceGen(int iLabel, int iMaxGenes,
                   int iPosibIf, int iPosibSet,
                   int iPosW,  int iPosX, int iPosY, int iPosZ,
                   int iPosIg, int iPosMay, int iPosMen, int iPosDif,
                   int iLongExpr, int iPosibX, int iPosibP, int iPosibN)
     {
        char cVar, cOper;

        //Clase que maneja los valores aleatorios
        cMutacion cMuta = new cMutacion();
		cMuta.mAleat = new Random(System.currentTimeMillis());
        
        //Decide si es una asignaci�n(Set) o un If condicional
        cOper = cMuta.cRandomElem(iPosibIf, iPosibSet, 0, 0);
        if (cOper == 'X') oGen[iLabel].cTipInst = 'I';
        else oGen[iLabel].cTipInst = 'S';
       
        //Decide que variable usar W, X, Y, Z
        cVar = cMuta.cRandomElem(iPosW, iPosX, iPosY, iPosZ);
        if (cVar == 'X') oGen[iLabel].cVariable = 'W';
        else if (cVar == '(') oGen[iLabel].cVariable = 'X';
        else if (Character.isDigit(cVar)) oGen[iLabel].cVariable = 'Z';
        else oGen[iLabel].cVariable = 'Y';
        
        //Decide si usa =, >, <, ! Estos son tenidos en cuenta si es un IF condicional
        cVar = cMuta.cRandomElem(iPosIg, iPosMay, iPosMen, iPosDif);
        if (cVar == 'X') oGen[iLabel].cOperacion = '=';
        else if (cVar == '(') oGen[iLabel].cOperacion = '>';
        else if (Character.isDigit(cVar)) oGen[iLabel].cOperacion = '!';
        else oGen[iLabel].cOperacion = '<';
        
        //Trae la expresion
        cMuta.vCrearExpresion(iLongExpr, iPosibX, iPosibP, iPosibN);
        oGen[iLabel].sbExpresion = cMuta.sAcum;
        
        //Como la trae para X, aqui la cambio a W, X, Y, Z
        char cCambia;
        cVar = cMuta.cRandomElem(iPosW, iPosX, iPosY, iPosZ);
        if (cVar == 'X') oGen[iLabel].cVarActiva = 'W';
        else if (cVar == '(') oGen[iLabel].cVarActiva = 'X';
        else if (Character.isDigit(cVar)) oGen[iLabel].cVarActiva = 'Z';
        else oGen[iLabel].cVarActiva = 'Y';
        
        
        //Decide hacia que label va (entre 0 y MaxGenes) o si es el FIN, el resultado siempre sera Y
		int iNumAleat=1000001;
		int iMultip=10000;
		Random mAleat = new Random();
        while (iNumAleat>1000000 || iNumAleat==0)
		{
			iNumAleat = mAleat.nextInt();
			if (iNumAleat < 0) iNumAleat*=-1;
		}
        int iInterv = 1000000 / (iMaxGenes + 1);
        int iNumCiclo=1;
        while (iNumAleat>iNumCiclo*iInterv) iNumCiclo++;
        iNumCiclo--;
        oGen[iLabel].iGotoLabel = iNumCiclo; //Retorna 0 para FINalizar
     }
}
