﻿/* Autor: Rafael Alberto Moreno Parra
 * Fecha: 13 de julio de 2022
 */

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Windows.Forms;

namespace Colaborar13 {
    public partial class Form1 : Form {
        Random Azar;

        //Los datos generados para el dataset.
        GeneradorDatos ConjuntoDatos;

        //Para manejar la red neuronal
        List<Perceptron> RedNeuronal;
        double MejorRedAjuste;
        int MejorRedNeuronal;

        //Para manejar el algoritmo evolutivo
        List<Individuo> Individuos;
        double MejorIndividuoAjuste;
        int MejorIndividuo;
        
        //Para mantener el proceso en ejecución
        bool MantenerProceso;
        int CicloEjecutado;

        public Form1() {
            InitializeComponent();
            Azar = new Random();
            RedNeuronal = new List<Perceptron>();
            Individuos = new List<Individuo>();
        }

        private void LlenaGridChart() {
            //Llena el GridView con los datos
            dgDatos.Rows.Clear();
            dgDatos.Refresh();

            for (int Num = 0; Num < ConjuntoDatos.Entradas.Length; Num++) {
                var nuevaFila = dgDatos.Rows.Add();
                dgDatos.Columns[0].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                dgDatos.Columns[1].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;

                dgDatos.Rows[nuevaFila].Cells[0].Value = ConjuntoDatos.Entradas[Num];
                dgDatos.Rows[nuevaFila].Cells[1].Value = ConjuntoDatos.Salidas[Num];
            }

            //Inicializa las series de datos, algoritmo evolutivo y red neuronal
            chartDatos.Series[0].Points.Clear();
            chartDatos.Series[1].Points.Clear();
            chartDatos.Series[2].Points.Clear();

            //Muestra los datos generados en el Chart
            chartDatos.ChartAreas[0].AxisX.MajorGrid.Enabled = false;
            chartDatos.ChartAreas[0].AxisY.MajorGrid.Enabled = false;
            chartDatos.ChartAreas[0].AxisY.Maximum = 1;

            chartDatos.ChartAreas[0].AxisX.Minimum = 0;
            chartDatos.ChartAreas[0].AxisX.Maximum = 1;
            chartDatos.ChartAreas[0].AxisX.Interval = 0.1;

            for (int Num = 0; Num < ConjuntoDatos.Entradas.Length; Num++)
                chartDatos.Series[0].Points.AddXY(ConjuntoDatos.Entradas[Num], ConjuntoDatos.Salidas[Num]);

            //Si el algoritmo evolutivo ha sido activado
            if (Individuos.Count > 0) {

                //El algoritmo evolutivo
                dgDatos.Columns[2].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                dgDatos.Columns[3].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;

                //Muestra en el grid la salida del algoritmo evolutivo
                for (int Num = 0; Num < ConjuntoDatos.Salidas.Length; Num++) {
                    double SalidaEvolutivo = Individuos[MejorIndividuo].ValorSalida(ConjuntoDatos.Entradas[Num]);
                    dgDatos.Rows[Num].Cells[2].Value = SalidaEvolutivo;

                    //Pone la diferencia
                    dgDatos.Rows[Num].Cells[3].Value = (ConjuntoDatos.Salidas[Num] - SalidaEvolutivo) * (ConjuntoDatos.Salidas[Num] - SalidaEvolutivo);

                    //Pone en el chart
                    chartDatos.Series[2].Points.AddXY(ConjuntoDatos.Entradas[Num], SalidaEvolutivo);
                }
            }

            //Si la red neuronal ha sido activada
            if (RedNeuronal.Count > 0) {

                //La red neuronal
                dgDatos.Columns[4].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                dgDatos.Columns[5].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;

                //Estas serán las entradas y salidas externas al perceptrón
                double[] Entradas = new double[1];

                //Muestra en el grid la salida del algoritmo evolutivo
                for (int Num = 0; Num < ConjuntoDatos.Salidas.Length; Num++) {
                    
                    //Entrada
                    Entradas[0] = ConjuntoDatos.Entradas[Num];
                    RedNeuronal[MejorRedNeuronal].CalculaSalidaRed(Entradas);
                    double SalidaRed = RedNeuronal[MejorRedNeuronal].Capas[2].Salidas[0];
                    dgDatos.Rows[Num].Cells[4].Value = SalidaRed;

                    //Pone la diferencia
                    dgDatos.Rows[Num].Cells[5].Value = (ConjuntoDatos.Salidas[Num] - SalidaRed) * (ConjuntoDatos.Salidas[Num] - SalidaRed);

                    //Pone en el chart
                    chartDatos.Series[1].Points.AddXY(ConjuntoDatos.Entradas[Num], SalidaRed);
                }
            }
        }

        private void btnGenera_Click(object sender, EventArgs e) {
            //Prepara el generador de datos
            ConjuntoDatos = new GeneradorDatos();
            Individuos.Clear();
            RedNeuronal.Clear();

            //Genera el dataset en forma aleatoria
            ConjuntoDatos.GeneraEcuacion(Azar, Convert.ToDouble(numXini.Value), Convert.ToDouble(numXfin.Value), Convert.ToInt32(numRegistros.Value));

            //Llena el gridview y el chart
            LlenaGridChart();

            //Habilita el proceso
            btnProceso.Enabled = true;
            txtCiclo.Text = "";
        }

        private void btnProceso_Click(object sender, EventArgs e) {
            btnGenera.Enabled = false;
            btnProceso.Enabled =false;
            btnDetener.Enabled = true;

            if (bgwProceso.IsBusy != true) {

                //Si el hilo no está trabajando
                bgwProceso.RunWorkerAsync();
            }
        }

        private void Proceso(object sender, DoWorkEventArgs e) {
            //Inicializa la red neuronal y los individuos
            RedNeuronal.Clear();
            Individuos.Clear();

            //Configurando la red neuronal
            int NumeroEntradas = 1; //Número de entradas
            int TotalNeuronasCapaOculta1 = Convert.ToInt32(numCapa1.Value);
            int TotalNeuronasCapaOculta2 = Convert.ToInt32(numCapa2.Value);
            int TotalNeuronasCapaSalida = 1; //Total neuronas en la capa de salida
            for (int Contador = 0; Contador < Convert.ToInt32(numRedes.Value); Contador++)
                RedNeuronal.Add(new Perceptron(Azar, NumeroEntradas, TotalNeuronasCapaOculta1, TotalNeuronasCapaOculta2, TotalNeuronasCapaSalida));
            int RedEvalua = 0;
            double[] EntradaRed = new double[1]; //Estas serán las entradas al perceptrón
            double[] SalidaRedEsperada = new double[1]; //Estas serán las salidas externas al perceptrón

            //Configurando la población del algoritmo evolutivo
            int NumIndividuos = Convert.ToInt32(numIndividuos.Value);
            for (int Contador = 0; Contador < NumIndividuos; Contador++)
                Individuos.Add(new Individuo(Azar, Contador + 1));

            //Llama al algoritmo evolutivo y a la red neuronal
            MantenerProceso = true;
            CicloEjecutado = 0;
            while (MantenerProceso) {

                //===================
                //Algoritmo evolutivo
                //===================
                for (int Cont = 0; Cont < Individuos.Count; Cont++) {
                    Individuos[Cont].MejoraIndividuo(Azar, ConjuntoDatos.Entradas, ConjuntoDatos.Salidas);
                }

                //===================                
                //Red neuronal
                //===================
                for (int Num = 0; Num < ConjuntoDatos.Salidas.Length; Num++) {
                    //Entradas y salidas esperadas
                    EntradaRed[0] = ConjuntoDatos.Entradas[Num];
                    SalidaRedEsperada[0] = ConjuntoDatos.Salidas[Num];

                    //Primero calcula la salida del perceptrón con esas entradas
                    RedNeuronal[RedEvalua].CalculaSalidaRed(EntradaRed);

                    //Luego entrena el perceptrón para ajustar los pesos y umbrales
                    RedNeuronal[RedEvalua].Entrena(EntradaRed, SalidaRedEsperada);
                }
                if (++RedEvalua >= RedNeuronal.Count) RedEvalua = 0;

                CicloEjecutado++;
                bgwProceso.ReportProgress(0);
            }
        }

        //Nuestra cuantas poblaciones y cuantas redes neuronales han sido generadas.
        private void bgwProceso_ProgressChanged(object sender, ProgressChangedEventArgs e) {
            txtCiclo.Text = Convert.ToString(CicloEjecutado);
        }

        private void bgwProceso_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e) {
            //Cada individuo pasa por la validación
            for (int Contador = 0; Contador < Individuos.Count; Contador++) {
                Individuos[Contador].Ajuste = -1;
                Individuos[Contador].AjusteIndividuo(ConjuntoDatos.ValidaEntra, ConjuntoDatos.ValidaSale);
            }

            //Busca el mejor
            MejorIndividuoAjuste = double.MaxValue;
            MejorIndividuo = -1;
            for (int Contador = 0; Contador < Individuos.Count; Contador++) {
                if(Individuos[Contador].Ajuste < MejorIndividuoAjuste) {
                    MejorIndividuoAjuste = Individuos[Contador].Ajuste;
                    MejorIndividuo = Contador;
                }
            }

            //Se evalúa cada red neuronal con los datos de validación.
            //La que se acerque más a esos datos es la que se muestra.
            MejorRedAjuste = double.MaxValue;
            MejorRedNeuronal = -1;
            for (int Cont = 0; Cont < RedNeuronal.Count; Cont++) {
                double AjusteRed = RedNeuronal[Cont].Ajuste(ConjuntoDatos.ValidaEntra, ConjuntoDatos.ValidaSale);
                if (AjusteRed < MejorRedAjuste) {
                    MejorRedAjuste = AjusteRed;
                    MejorRedNeuronal = Cont;
                }
            }

            //Llena el gridview y el chart
            LlenaGridChart();
        }

        private void btnDetener_Click(object sender, EventArgs e) {
            btnGenera.Enabled = true;
            btnDetener.Enabled = false;
            btnProceso.Enabled = true;
            MantenerProceso = false;
        }
    }
}
