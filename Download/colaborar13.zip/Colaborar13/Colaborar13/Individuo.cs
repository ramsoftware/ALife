﻿/* Autor: Rafael Alberto Moreno Parra
 * Fecha: 07 de agosto de 2022
 * 
 * En el anterior programa se desarrolló un software gráfico que compara un algoritmo evolutivo contra una red neuronal (perceptrón multicapa). A partir de allí hubo varios cambios:
 * 1. Se mejora el algoritmo evolutivo, en vez de una larga ecuación polinómica dentro de la operación trigonométrica seno, ahora es la sumatoria de varias operaciones trigonométricas seno y su posterior normalización. Además se retira el concepto de competencia y ahora es un conjunto de individuos que van mejorando su ajuste poco a poco.
 * 2. Se mejora la interfaz gráfica, haciéndola más sencilla de entender y controlar.
 * 3. Si se maximiza la ventana, el gráfico estadístico también se maximiza.
 * Modo de operación:
 *  1. El botón "Generar dataset" lo que hace es generar una serie de datos de entrenamiento y una serie de datos de validación. Esos datos nacen de una función generada al azar.
 *  2. El botón de "Procesar" lanza un hilo de ejecución que ejecuta la red neuronal y el algoritmo evolutivo. Una vez lanzado, es dejar pasar el tiempo, el programa va mostrando los ciclos. Entre más tiempo se deje ejecutar el programa mejor.
 *  3. El botón "Detener" lo que hace es finalizar el proceso inmediatamente.
 * Una vez se detiene el proceso, se muestra por pantalla las curvas obtenidas por ambos procedimientos. Se muestra la mejor red neuronal que se ajuste a los datos de validación, sucede lo mismo con el algoritmo evolutivo.
 * 
 *  Este nuevo programa ha generado una bifurcación en el desarrollo de esta investigación sobre colaboración. En una rama se seguirá desarrollando como herramienta de análisis de datos tanto el algoritmo evolutivo como la red neuronal (para una investigación que sigo en la universidad). La segunda rama, propiamente de vida artificial, se enfocará en el algoritmo evolutivo (se abandona la red neuronal) y los comportamientos cíclicos de los ambientes, algo que no estaba contemplado previamente. 
 */

using System;

namespace Colaborar13 {
    internal class Individuo {
        public double[] Coef = new double[9];

        //Guarda en "caché" el ajuste para no tener que calcularlo continuamente
        public double Ajuste;

        //Inicializa el individuo con las Piezas, Modificadores y Operadores al azar
        public Individuo(Random Azar, int Multiplica) {
            for (int Contador = 0; Contador < Coef.Length; Contador++)
                Coef[Contador] = Azar.NextDouble()*Multiplica;
            Ajuste = -1;
        }

        //Mejora el individuo antes de entrar a la arena de la competición, cambiando los coeficientes 
        public void MejoraIndividuo(Random Azar, double[] Entradas, double[] Salidas) {
            int Cambiar = Azar.Next(0, Coef.Length);
            double Antes = Coef[Cambiar];
            Coef[Cambiar] += (Azar.NextDouble()*2-1);

            //El cálculo del ajuste es la sumatoria de (valor calculado por el individuo - valor esperado)^2
            double NuevoAjuste = 0;
            for (int X = 0; X < Salidas.Length; X++) {
                double Diferencia = ValorSalida(Entradas[X]) - Salidas[X];
                NuevoAjuste += Diferencia * Diferencia;
                if (NuevoAjuste > Ajuste && Ajuste != -1) { //Si el cambio perjudica el ajuste anterior, retorna el valor anterior del coeficiente cambiado
                    Coef[Cambiar] = Antes;
                    return;
                }
            }

            Ajuste = NuevoAjuste;
        }

        //Calcula el ajuste del individuo con los valores de salida esperados
        public void AjusteIndividuo(double[] Entradas, double[] Salidas) {
            //Si ya había sido calculado entonces evita calcularlo de nuevo
            if (Ajuste != -1) return;

            //El cálculo del ajuste es la sumatoria de (valor calculado por el individuo - valor esperado)^2
            Ajuste = 0;
            for (int X = 0; X < Salidas.Length; X++) {
                double Diferencia = ValorSalida(Entradas[X]) - Salidas[X];
                Ajuste += Diferencia * Diferencia;
            }
        }

        //Retorna la salida dependiendo de la entrada
        public double ValorSalida(double x) {
            return (Math.Sin(
                Math.Sin(Coef[0] * x * x + Coef[1] * x + Coef[2])+
                Math.Sin(Coef[3] * x * x + Coef[4] * x + Coef[5])+
                Math.Sin(Coef[6] * x * x + Coef[7] * x + Coef[8])
                ) + 1) / 2;
        }
    }
}
