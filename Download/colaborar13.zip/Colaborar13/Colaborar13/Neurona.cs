﻿/* Autor: Rafael Alberto Moreno Parra
 * Fecha: 07 de agosto de 2022
 * 
 * En el anterior programa se desarrolló un software gráfico que compara un algoritmo evolutivo contra una red neuronal (perceptrón multicapa). A partir de allí hubo varios cambios:
 * 1. Se mejora el algoritmo evolutivo, en vez de una larga ecuación polinómica dentro de la operación trigonométrica seno, ahora es la sumatoria de varias operaciones trigonométricas seno y su posterior normalización. Además se retira el concepto de competencia y ahora es un conjunto de individuos que van mejorando su ajuste poco a poco.
 * 2. Se mejora la interfaz gráfica, haciéndola más sencilla de entender y controlar.
 * 3. Si se maximiza la ventana, el gráfico estadístico también se maximiza.
 * Modo de operación:
 *  1. El botón "Generar dataset" lo que hace es generar una serie de datos de entrenamiento y una serie de datos de validación. Esos datos nacen de una función generada al azar.
 *  2. El botón de "Procesar" lanza un hilo de ejecución que ejecuta la red neuronal y el algoritmo evolutivo. Una vez lanzado, es dejar pasar el tiempo, el programa va mostrando los ciclos. Entre más tiempo se deje ejecutar el programa mejor.
 *  3. El botón "Detener" lo que hace es finalizar el proceso inmediatamente.
 * Una vez se detiene el proceso, se muestra por pantalla las curvas obtenidas por ambos procedimientos. Se muestra la mejor red neuronal que se ajuste a los datos de validación, sucede lo mismo con el algoritmo evolutivo.
 * 
 *  Este nuevo programa ha generado una bifurcación en el desarrollo de esta investigación sobre colaboración. En una rama se seguirá desarrollando como herramienta de análisis de datos tanto el algoritmo evolutivo como la red neuronal (para una investigación que sigo en la universidad). La segunda rama, propiamente de vida artificial, se enfocará en el algoritmo evolutivo (se abandona la red neuronal) y los comportamientos cíclicos de los ambientes, algo que no estaba contemplado previamente. 
 */

using System;

namespace Colaborar13 {
	internal class Neurona {
		private readonly int TOTALENTRADAS;
		public double[] Pesos; //Los pesos para cada entrada
		public double[] NuevosPesos; //Nuevos pesos dados por el algoritmo de "backpropagation"
		public double Umbral; //El peso del umbral
		public double NuevoUmbral; //Nuevo umbral dado por el algoritmo de "backpropagation"

		//Inicializa los pesos y umbral con un valor al azar
		public Neurona(Random Azar, int TotalEntradas) {
            TOTALENTRADAS = TotalEntradas;
			Pesos = new double[TOTALENTRADAS];
			NuevosPesos = new double[TOTALENTRADAS];
			for (int Contador = 0; Contador < TotalEntradas; Contador++) 
				Pesos[Contador] = Azar.NextDouble();
			Umbral = Azar.NextDouble();
			NuevoUmbral = 0;
		}

		//Calcula la salida de la neurona dependiendo de las entradas
		public double CalculaSalida(double[] Entradas) {
			double Valor = 0;
			for (int Contador = 0; Contador < TOTALENTRADAS; Contador++) 
				Valor += Entradas[Contador] * Pesos[Contador];
			Valor += Umbral;
			return 1 / (1 + Math.Exp(-Valor));
		}

		//Reemplaza viejos pesos por nuevos
		public void Actualiza() {
			for (int Contador = 0; Contador < TOTALENTRADAS; Contador++) 
				Pesos[Contador] = NuevosPesos[Contador];
			Umbral = NuevoUmbral;
		}
	}
}
