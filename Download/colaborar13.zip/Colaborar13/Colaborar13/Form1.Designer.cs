﻿namespace Colaborar13 {
    partial class Form1 {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing) {
            if (disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent() {
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea1 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend1 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series1 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.Series series2 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.Series series3 = new System.Windows.Forms.DataVisualization.Charting.Series();
            this.tabPrincipal = new System.Windows.Forms.TabControl();
            this.tabGenerar = new System.Windows.Forms.TabPage();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.txtCiclo = new System.Windows.Forms.TextBox();
            this.btnDetener = new System.Windows.Forms.Button();
            this.btnProceso = new System.Windows.Forms.Button();
            this.btnGenera = new System.Windows.Forms.Button();
            this.chartDatos = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.tabDatos = new System.Windows.Forms.TabPage();
            this.dgDatos = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colEvolutivo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colDifEvolutivo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colRed = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colDifRed = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tabConfiguracion = new System.Windows.Forms.TabPage();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.numRegistros = new System.Windows.Forms.NumericUpDown();
            this.lblNumRegistros = new System.Windows.Forms.Label();
            this.numXfin = new System.Windows.Forms.NumericUpDown();
            this.numXini = new System.Windows.Forms.NumericUpDown();
            this.lblXfin = new System.Windows.Forms.Label();
            this.lblXini = new System.Windows.Forms.Label();
            this.grbRed = new System.Windows.Forms.GroupBox();
            this.numRedes = new System.Windows.Forms.NumericUpDown();
            this.lblRedes = new System.Windows.Forms.Label();
            this.numCapa2 = new System.Windows.Forms.NumericUpDown();
            this.numCapa1 = new System.Windows.Forms.NumericUpDown();
            this.lblCapa2 = new System.Windows.Forms.Label();
            this.lblCapa1 = new System.Windows.Forms.Label();
            this.grbEvolutivo = new System.Windows.Forms.GroupBox();
            this.numIndividuos = new System.Windows.Forms.NumericUpDown();
            this.lblIndividuos = new System.Windows.Forms.Label();
            this.bgwProceso = new System.ComponentModel.BackgroundWorker();
            this.tabPrincipal.SuspendLayout();
            this.tabGenerar.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chartDatos)).BeginInit();
            this.tabDatos.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgDatos)).BeginInit();
            this.tabConfiguracion.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numRegistros)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numXfin)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numXini)).BeginInit();
            this.grbRed.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numRedes)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numCapa2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numCapa1)).BeginInit();
            this.grbEvolutivo.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numIndividuos)).BeginInit();
            this.SuspendLayout();
            // 
            // tabPrincipal
            // 
            this.tabPrincipal.Controls.Add(this.tabGenerar);
            this.tabPrincipal.Controls.Add(this.tabDatos);
            this.tabPrincipal.Controls.Add(this.tabConfiguracion);
            this.tabPrincipal.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabPrincipal.Location = new System.Drawing.Point(0, 0);
            this.tabPrincipal.Margin = new System.Windows.Forms.Padding(4);
            this.tabPrincipal.Name = "tabPrincipal";
            this.tabPrincipal.SelectedIndex = 0;
            this.tabPrincipal.Size = new System.Drawing.Size(1331, 624);
            this.tabPrincipal.TabIndex = 0;
            // 
            // tabGenerar
            // 
            this.tabGenerar.Controls.Add(this.splitContainer1);
            this.tabGenerar.Location = new System.Drawing.Point(4, 25);
            this.tabGenerar.Name = "tabGenerar";
            this.tabGenerar.Padding = new System.Windows.Forms.Padding(3);
            this.tabGenerar.Size = new System.Drawing.Size(1323, 595);
            this.tabGenerar.TabIndex = 3;
            this.tabGenerar.Text = "Generación y Proceso";
            this.tabGenerar.UseVisualStyleBackColor = true;
            // 
            // splitContainer1
            // 
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.Location = new System.Drawing.Point(3, 3);
            this.splitContainer1.Name = "splitContainer1";
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.txtCiclo);
            this.splitContainer1.Panel1.Controls.Add(this.btnDetener);
            this.splitContainer1.Panel1.Controls.Add(this.btnProceso);
            this.splitContainer1.Panel1.Controls.Add(this.btnGenera);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.chartDatos);
            this.splitContainer1.Size = new System.Drawing.Size(1317, 589);
            this.splitContainer1.SplitterDistance = 158;
            this.splitContainer1.TabIndex = 0;
            // 
            // txtCiclo
            // 
            this.txtCiclo.Location = new System.Drawing.Point(9, 125);
            this.txtCiclo.Name = "txtCiclo";
            this.txtCiclo.ReadOnly = true;
            this.txtCiclo.Size = new System.Drawing.Size(137, 23);
            this.txtCiclo.TabIndex = 31;
            this.txtCiclo.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // btnDetener
            // 
            this.btnDetener.Enabled = false;
            this.btnDetener.Location = new System.Drawing.Point(4, 297);
            this.btnDetener.Name = "btnDetener";
            this.btnDetener.Size = new System.Drawing.Size(143, 36);
            this.btnDetener.TabIndex = 30;
            this.btnDetener.Text = "Detener";
            this.btnDetener.UseVisualStyleBackColor = true;
            this.btnDetener.Click += new System.EventHandler(this.btnDetener_Click);
            // 
            // btnProceso
            // 
            this.btnProceso.Enabled = false;
            this.btnProceso.Location = new System.Drawing.Point(4, 68);
            this.btnProceso.Name = "btnProceso";
            this.btnProceso.Size = new System.Drawing.Size(144, 39);
            this.btnProceso.TabIndex = 29;
            this.btnProceso.Text = "Procesar";
            this.btnProceso.UseVisualStyleBackColor = true;
            this.btnProceso.Click += new System.EventHandler(this.btnProceso_Click);
            // 
            // btnGenera
            // 
            this.btnGenera.Location = new System.Drawing.Point(5, 13);
            this.btnGenera.Name = "btnGenera";
            this.btnGenera.Size = new System.Drawing.Size(143, 39);
            this.btnGenera.TabIndex = 28;
            this.btnGenera.Text = "Generar dataset";
            this.btnGenera.UseVisualStyleBackColor = true;
            this.btnGenera.Click += new System.EventHandler(this.btnGenera_Click);
            // 
            // chartDatos
            // 
            chartArea1.Name = "ChartArea1";
            this.chartDatos.ChartAreas.Add(chartArea1);
            this.chartDatos.Dock = System.Windows.Forms.DockStyle.Fill;
            legend1.Name = "Legend1";
            this.chartDatos.Legends.Add(legend1);
            this.chartDatos.Location = new System.Drawing.Point(0, 0);
            this.chartDatos.Name = "chartDatos";
            series1.ChartArea = "ChartArea1";
            series1.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
            series1.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            series1.Legend = "Legend1";
            series1.Name = "Datos";
            series1.XValueType = System.Windows.Forms.DataVisualization.Charting.ChartValueType.Single;
            series1.YValueType = System.Windows.Forms.DataVisualization.Charting.ChartValueType.Single;
            series2.ChartArea = "ChartArea1";
            series2.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
            series2.Legend = "Legend1";
            series2.Name = "Red Neuronal";
            series3.ChartArea = "ChartArea1";
            series3.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
            series3.Legend = "Legend1";
            series3.Name = "Evolutivo";
            this.chartDatos.Series.Add(series1);
            this.chartDatos.Series.Add(series2);
            this.chartDatos.Series.Add(series3);
            this.chartDatos.Size = new System.Drawing.Size(1155, 589);
            this.chartDatos.TabIndex = 12;
            // 
            // tabDatos
            // 
            this.tabDatos.Controls.Add(this.dgDatos);
            this.tabDatos.Location = new System.Drawing.Point(4, 25);
            this.tabDatos.Margin = new System.Windows.Forms.Padding(4);
            this.tabDatos.Name = "tabDatos";
            this.tabDatos.Padding = new System.Windows.Forms.Padding(4);
            this.tabDatos.Size = new System.Drawing.Size(1323, 595);
            this.tabDatos.TabIndex = 1;
            this.tabDatos.Text = "Datos y Resultados";
            this.tabDatos.UseVisualStyleBackColor = true;
            // 
            // dgDatos
            // 
            this.dgDatos.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgDatos.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn5,
            this.dataGridViewTextBoxColumn6,
            this.colEvolutivo,
            this.colDifEvolutivo,
            this.colRed,
            this.colDifRed});
            this.dgDatos.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgDatos.Location = new System.Drawing.Point(4, 4);
            this.dgDatos.Name = "dgDatos";
            this.dgDatos.ReadOnly = true;
            this.dgDatos.Size = new System.Drawing.Size(1315, 587);
            this.dgDatos.TabIndex = 11;
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.HeaderText = "Entrada X";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            this.dataGridViewTextBoxColumn5.ReadOnly = true;
            this.dataGridViewTextBoxColumn5.Width = 200;
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.HeaderText = "Salida Esperada Y";
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            this.dataGridViewTextBoxColumn6.ReadOnly = true;
            this.dataGridViewTextBoxColumn6.Width = 200;
            // 
            // colEvolutivo
            // 
            this.colEvolutivo.HeaderText = "Algoritmo Evolutivo";
            this.colEvolutivo.Name = "colEvolutivo";
            this.colEvolutivo.ReadOnly = true;
            this.colEvolutivo.Width = 200;
            // 
            // colDifEvolutivo
            // 
            this.colDifEvolutivo.HeaderText = "Diferencia";
            this.colDifEvolutivo.Name = "colDifEvolutivo";
            this.colDifEvolutivo.ReadOnly = true;
            this.colDifEvolutivo.Width = 200;
            // 
            // colRed
            // 
            this.colRed.HeaderText = "Red Neuronal";
            this.colRed.Name = "colRed";
            this.colRed.ReadOnly = true;
            this.colRed.Width = 200;
            // 
            // colDifRed
            // 
            this.colDifRed.HeaderText = "Diferencia";
            this.colDifRed.Name = "colDifRed";
            this.colDifRed.ReadOnly = true;
            this.colDifRed.Width = 200;
            // 
            // tabConfiguracion
            // 
            this.tabConfiguracion.Controls.Add(this.groupBox1);
            this.tabConfiguracion.Controls.Add(this.grbRed);
            this.tabConfiguracion.Controls.Add(this.grbEvolutivo);
            this.tabConfiguracion.Location = new System.Drawing.Point(4, 25);
            this.tabConfiguracion.Name = "tabConfiguracion";
            this.tabConfiguracion.Padding = new System.Windows.Forms.Padding(3);
            this.tabConfiguracion.Size = new System.Drawing.Size(1323, 595);
            this.tabConfiguracion.TabIndex = 2;
            this.tabConfiguracion.Text = "Configuración";
            this.tabConfiguracion.UseVisualStyleBackColor = true;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.numRegistros);
            this.groupBox1.Controls.Add(this.lblNumRegistros);
            this.groupBox1.Controls.Add(this.numXfin);
            this.groupBox1.Controls.Add(this.numXini);
            this.groupBox1.Controls.Add(this.lblXfin);
            this.groupBox1.Controls.Add(this.lblXini);
            this.groupBox1.Location = new System.Drawing.Point(27, 6);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(351, 143);
            this.groupBox1.TabIndex = 25;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Generador de datos";
            // 
            // numRegistros
            // 
            this.numRegistros.Location = new System.Drawing.Point(225, 99);
            this.numRegistros.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.numRegistros.Minimum = new decimal(new int[] {
            100,
            0,
            0,
            0});
            this.numRegistros.Name = "numRegistros";
            this.numRegistros.Size = new System.Drawing.Size(120, 23);
            this.numRegistros.TabIndex = 24;
            this.numRegistros.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.numRegistros.Value = new decimal(new int[] {
            100,
            0,
            0,
            0});
            // 
            // lblNumRegistros
            // 
            this.lblNumRegistros.AutoSize = true;
            this.lblNumRegistros.Location = new System.Drawing.Point(6, 101);
            this.lblNumRegistros.Name = "lblNumRegistros";
            this.lblNumRegistros.Size = new System.Drawing.Size(207, 16);
            this.lblNumRegistros.TabIndex = 23;
            this.lblNumRegistros.Text = "Número de registros a generar";
            // 
            // numXfin
            // 
            this.numXfin.Location = new System.Drawing.Point(225, 64);
            this.numXfin.Maximum = new decimal(new int[] {
            5,
            0,
            0,
            0});
            this.numXfin.Name = "numXfin";
            this.numXfin.Size = new System.Drawing.Size(120, 23);
            this.numXfin.TabIndex = 22;
            this.numXfin.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.numXfin.Value = new decimal(new int[] {
            2,
            0,
            0,
            0});
            // 
            // numXini
            // 
            this.numXini.Location = new System.Drawing.Point(225, 33);
            this.numXini.Maximum = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.numXini.Minimum = new decimal(new int[] {
            5,
            0,
            0,
            -2147483648});
            this.numXini.Name = "numXini";
            this.numXini.Size = new System.Drawing.Size(120, 23);
            this.numXini.TabIndex = 19;
            this.numXini.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.numXini.Value = new decimal(new int[] {
            2,
            0,
            0,
            -2147483648});
            // 
            // lblXfin
            // 
            this.lblXfin.AutoSize = true;
            this.lblXfin.Location = new System.Drawing.Point(6, 71);
            this.lblXfin.Name = "lblXfin";
            this.lblXfin.Size = new System.Drawing.Size(127, 16);
            this.lblXfin.TabIndex = 18;
            this.lblXfin.Text = "Valor máximo de X";
            // 
            // lblXini
            // 
            this.lblXini.AutoSize = true;
            this.lblXini.Location = new System.Drawing.Point(6, 35);
            this.lblXini.Name = "lblXini";
            this.lblXini.Size = new System.Drawing.Size(123, 16);
            this.lblXini.TabIndex = 17;
            this.lblXini.Text = "Valor mínimo de X";
            // 
            // grbRed
            // 
            this.grbRed.Controls.Add(this.numRedes);
            this.grbRed.Controls.Add(this.lblRedes);
            this.grbRed.Controls.Add(this.numCapa2);
            this.grbRed.Controls.Add(this.numCapa1);
            this.grbRed.Controls.Add(this.lblCapa2);
            this.grbRed.Controls.Add(this.lblCapa1);
            this.grbRed.Location = new System.Drawing.Point(27, 261);
            this.grbRed.Name = "grbRed";
            this.grbRed.Size = new System.Drawing.Size(351, 127);
            this.grbRed.TabIndex = 22;
            this.grbRed.TabStop = false;
            this.grbRed.Text = "Red Neuronal";
            // 
            // numRedes
            // 
            this.numRedes.Location = new System.Drawing.Point(225, 27);
            this.numRedes.Maximum = new decimal(new int[] {
            2000,
            0,
            0,
            0});
            this.numRedes.Minimum = new decimal(new int[] {
            3,
            0,
            0,
            0});
            this.numRedes.Name = "numRedes";
            this.numRedes.Size = new System.Drawing.Size(120, 23);
            this.numRedes.TabIndex = 16;
            this.numRedes.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.numRedes.Value = new decimal(new int[] {
            5,
            0,
            0,
            0});
            // 
            // lblRedes
            // 
            this.lblRedes.AutoSize = true;
            this.lblRedes.Location = new System.Drawing.Point(6, 34);
            this.lblRedes.Name = "lblRedes";
            this.lblRedes.Size = new System.Drawing.Size(87, 16);
            this.lblRedes.TabIndex = 16;
            this.lblRedes.Text = "Total redes:";
            // 
            // numCapa2
            // 
            this.numCapa2.Location = new System.Drawing.Point(225, 87);
            this.numCapa2.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numCapa2.Name = "numCapa2";
            this.numCapa2.Size = new System.Drawing.Size(120, 23);
            this.numCapa2.TabIndex = 22;
            this.numCapa2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.numCapa2.Value = new decimal(new int[] {
            5,
            0,
            0,
            0});
            // 
            // numCapa1
            // 
            this.numCapa1.Location = new System.Drawing.Point(225, 58);
            this.numCapa1.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numCapa1.Name = "numCapa1";
            this.numCapa1.Size = new System.Drawing.Size(120, 23);
            this.numCapa1.TabIndex = 19;
            this.numCapa1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.numCapa1.Value = new decimal(new int[] {
            5,
            0,
            0,
            0});
            // 
            // lblCapa2
            // 
            this.lblCapa2.AutoSize = true;
            this.lblCapa2.Location = new System.Drawing.Point(6, 87);
            this.lblCapa2.Name = "lblCapa2";
            this.lblCapa2.Size = new System.Drawing.Size(145, 16);
            this.lblCapa2.TabIndex = 18;
            this.lblCapa2.Text = "Neuronas en capa 2:";
            // 
            // lblCapa1
            // 
            this.lblCapa1.AutoSize = true;
            this.lblCapa1.Location = new System.Drawing.Point(6, 58);
            this.lblCapa1.Name = "lblCapa1";
            this.lblCapa1.Size = new System.Drawing.Size(145, 16);
            this.lblCapa1.TabIndex = 17;
            this.lblCapa1.Text = "Neuronas en capa 1:";
            // 
            // grbEvolutivo
            // 
            this.grbEvolutivo.Controls.Add(this.numIndividuos);
            this.grbEvolutivo.Controls.Add(this.lblIndividuos);
            this.grbEvolutivo.Location = new System.Drawing.Point(27, 167);
            this.grbEvolutivo.Name = "grbEvolutivo";
            this.grbEvolutivo.Size = new System.Drawing.Size(351, 71);
            this.grbEvolutivo.TabIndex = 21;
            this.grbEvolutivo.TabStop = false;
            this.grbEvolutivo.Text = "Algoritmo Evolutivo";
            // 
            // numIndividuos
            // 
            this.numIndividuos.Location = new System.Drawing.Point(225, 26);
            this.numIndividuos.Maximum = new decimal(new int[] {
            2000,
            0,
            0,
            0});
            this.numIndividuos.Minimum = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.numIndividuos.Name = "numIndividuos";
            this.numIndividuos.Size = new System.Drawing.Size(120, 23);
            this.numIndividuos.TabIndex = 15;
            this.numIndividuos.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.numIndividuos.Value = new decimal(new int[] {
            15,
            0,
            0,
            0});
            // 
            // lblIndividuos
            // 
            this.lblIndividuos.AutoSize = true;
            this.lblIndividuos.Location = new System.Drawing.Point(6, 33);
            this.lblIndividuos.Name = "lblIndividuos";
            this.lblIndividuos.Size = new System.Drawing.Size(115, 16);
            this.lblIndividuos.TabIndex = 14;
            this.lblIndividuos.Text = "Total individuos:";
            // 
            // bgwProceso
            // 
            this.bgwProceso.WorkerReportsProgress = true;
            this.bgwProceso.DoWork += new System.ComponentModel.DoWorkEventHandler(this.Proceso);
            this.bgwProceso.ProgressChanged += new System.ComponentModel.ProgressChangedEventHandler(this.bgwProceso_ProgressChanged);
            this.bgwProceso.RunWorkerCompleted += new System.ComponentModel.RunWorkerCompletedEventHandler(this.bgwProceso_RunWorkerCompleted);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1331, 624);
            this.Controls.Add(this.tabPrincipal);
            this.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Form1";
            this.Text = "Colaborar 13. Nuevo algoritmo evolutivo vs Red neuronal";
            this.tabPrincipal.ResumeLayout(false);
            this.tabGenerar.ResumeLayout(false);
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel1.PerformLayout();
            this.splitContainer1.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.chartDatos)).EndInit();
            this.tabDatos.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgDatos)).EndInit();
            this.tabConfiguracion.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numRegistros)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numXfin)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numXini)).EndInit();
            this.grbRed.ResumeLayout(false);
            this.grbRed.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numRedes)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numCapa2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numCapa1)).EndInit();
            this.grbEvolutivo.ResumeLayout(false);
            this.grbEvolutivo.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numIndividuos)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabPrincipal;
        private System.Windows.Forms.TabPage tabDatos;
        private System.Windows.Forms.DataGridView dgDatos;
        private System.Windows.Forms.TabPage tabConfiguracion;
        private System.Windows.Forms.GroupBox grbRed;
        private System.Windows.Forms.NumericUpDown numCapa2;
        private System.Windows.Forms.NumericUpDown numCapa1;
        private System.Windows.Forms.Label lblCapa2;
        private System.Windows.Forms.Label lblCapa1;
        private System.Windows.Forms.GroupBox grbEvolutivo;
        private System.Windows.Forms.NumericUpDown numIndividuos;
        private System.Windows.Forms.Label lblIndividuos;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.NumericUpDown numRegistros;
        private System.Windows.Forms.Label lblNumRegistros;
        private System.Windows.Forms.NumericUpDown numXfin;
        private System.Windows.Forms.NumericUpDown numXini;
        private System.Windows.Forms.Label lblXfin;
        private System.Windows.Forms.Label lblXini;
        private System.ComponentModel.BackgroundWorker bgwProceso;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private System.Windows.Forms.DataGridViewTextBoxColumn colEvolutivo;
        private System.Windows.Forms.DataGridViewTextBoxColumn colDifEvolutivo;
        private System.Windows.Forms.DataGridViewTextBoxColumn colRed;
        private System.Windows.Forms.DataGridViewTextBoxColumn colDifRed;
        private System.Windows.Forms.NumericUpDown numRedes;
        private System.Windows.Forms.Label lblRedes;
        private System.Windows.Forms.TabPage tabGenerar;
        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.TextBox txtCiclo;
        private System.Windows.Forms.Button btnDetener;
        private System.Windows.Forms.Button btnProceso;
        private System.Windows.Forms.Button btnGenera;
        private System.Windows.Forms.DataVisualization.Charting.Chart chartDatos;
    }
}

