//==========================================================================================
/* Esta simulaci�n consiste en generar una serie de organismos al azar y ver cual mejor se
   adapta dada las entradas y salidas.

   Los organismos se componen de N isntrucciones.
   Cada instrucci�n se compone de un Tipo de Instrucci�n y tres posiciones de memoria.
   Los tipos de instrucci�n son

		Suma [iPos1] = [iPos2] + [iPos3];
		Resta [iPos1] = [iPos2] - [iPos3];
		Multiplicaci�n [iPos1] = [iPos2] * [iPos3];
		Divisi�n [iPos1] = [iPos2] / [iPos3];

		Donde iPos1, iPos2, iPos3 indican posiciones de memoria.
		
		Estan las instrucciones de IF condicional

		Si [iPos1]>[iPos2] Goto iPos3
		Si [iPos1]>=[iPos2] Goto iPos3
		Si [iPos1]<[iPos2] Goto iPos3
		Si [iPos1]<=[iPos2] Goto iPos3
		Si [iPos1]==[iPos2] Goto iPos3
		Si [iPos1]!=[iPos2] Goto iPos3

	El valor de la posici�n de memoria va de 0 a 255.
	Teniendo tipo de instrucci�n (0 a 255), posici�n 1 (0 a 255), posici�n 2 (0 a 255), posici�n 3 (0 a 255)
	Son 4 bytes, que juntos es un entero en una plataforma de 32 bits. Una instrucci�n completa se empaqueta en un
	n�mero entero.

	Las instrucciones de cada organismo son n�meros enteros que se trabajan as�:

	Para empaquetar:
	iInstruccion = (iTipoInstruccion << 24) + (iPos1 << 16) + (iPos2 << 8) + iPos3;

	Para desempaquetar:

	int iTipo = ((iInstruccion >> 24) & 0xFF);
	int iPos1 = ((iInstruccion >> 16) & 0xFF);
	int iPos2 = ((iInstruccion >> 8) & 0xFF);
	int iPos3 = (iInstruccion & 0xFF);

	Esta simulaci�n trabaja el concepto de poblaci�n:
	1. Se genera un organismo con N instrucciones
	2. Se prueba en ese organismo como procesa las entradas y salidas
	3. Si su proceso esta por debajo de un rango m�ximo entonces se almacena
	   en una posici�n al azar de un arreglo unidimensional.
    4. Si esa posici�n ya estaba ocupada por otro organismo entonces se comparan los
	   dos y se selecciona el mejor.
	5. Si esa posici�n estaba desocupada entonces simplemente se guarda all� el organismo.

*/
//==========================================================================================

#include <math.h>
#include <stdio.h>
#include <time.h>
#include <malloc.h>
#include <string.h>
#include <stdlib.h>

#include "Aleatorio.h"  //El generador de n�meros pseudo-aleatorios
#include "Inicializa.h" //Acceso al archivo plano


//=============== Los Organismos ==========================
unsigned int **iOrganismo;

//========= Marca que parte del ambiente tiene organismo =======
bool *bOrganismo;

//========= Valores que almacena cada variable del organismo ====
float **fVarOrganismo;
float *fAdaptacion;

//========= Valores de entrada y salida ====
float *fEntrada, *fSalida;


//========== Clase de inicializacion ====
Inicializa objInicializa; //Lee el archivo de inicializaci�n


void main(void);
bool bInterpretaOrganismo(unsigned int, int);
void vDeshaceIO(char *, int);

// ===========================================================
// INICIO
// ===========================================================
void main()
{
	printf("Poblacion 03: Mejora uso de poblaciones\n\n");
	printf("Autor: Rafael Alberto Moreno Parra\n");
	printf("Fecha: 01 de Enero de 2007\n");
	printf("E-mail: enginelife@hotmail.com\n");
	printf("http://darwin.50webs.com\n\n");

	//==============================================
	//Archivo plano
	//==============================================
	int iError = objInicializa.iLeeArchivoIni(); //Archivo de Inicializaci�n
	if (iError == -1)
	{
		printf("Un error ocurri� al inicializar la simulaci�n\n");
		return;
	}

	printf("Cuantos organismos tendr� el ambiente al tiempo: %d\n\n", objInicializa.stDatVA.NUMORGANISMOS);
	printf("Probabilidad de que la instrucci�n sea una operaci�n b�sica: suma, resta, multiplicaci�n, divisi�n: %d\n", objInicializa.stDatVA.PROBABLEBASICO);
	printf("Probabilidad de que la instrucci�n sea una funci�n: seno, coseno, tangente, valor absoluto, logaritmo, exponencial, raiz cuadrada: %d\n", objInicializa.stDatVA.PROBABLEFUNCION);
	printf("N�mero m�ximo de instrucciones por organismos: %d\n", objInicializa.stDatVA.MAXINSTRUCCIONES);
	printf("N�mero de variables usadas: %d\n", objInicializa.stDatVA.NUMVARIABLES);
	printf("Cuantos organismos va a generar: %d\n", objInicializa.stDatVA.TOTALSIMULACION);
	printf("Cuantas instrucciones del algoritmo genetico ejecutar� antes de ser desechado: %d\n", objInicializa.stDatVA.MAXIMOINTERPRETA);
	printf("M�xima Tolerancia permitida para que el algoritmo generico sea considerado: %d\n", objInicializa.stDatVA.MAXTOLERANCIA);

	//====================================================================
	//Inicia el generador de numeros pseudo-aleatorios con el reloj del PC
	//====================================================================
	Aleatorio objAzar;
	time_t objTiempo;
	time(&objTiempo);
	objAzar.sgenrand(objTiempo);

	//======================================================
	//Inicializa las entradas y salidas
	//======================================================
	fEntrada = (float *) malloc(objInicializa.stDatVA.ENTRADAS*sizeof(float));
	fSalida = (float *) malloc(objInicializa.stDatVA.ENTRADAS*sizeof(float));
	vDeshaceIO(objInicializa.stDatVA.sEntrada, 1);
	vDeshaceIO(objInicializa.stDatVA.sSalidas, 2);

	//Muestra entradas y salidas
	unsigned int iPrueba;
	printf("Entradas son: ");
	for (iPrueba=0; iPrueba<objInicializa.stDatVA.ENTRADAS; iPrueba++)
		printf("%f, ", fEntrada[iPrueba]);

	printf("\nSalidas son: ");
	for (iPrueba=0; iPrueba<objInicializa.stDatVA.ENTRADAS; iPrueba++)
		printf("%f, ", fSalida[iPrueba]);
	printf("\n");

	
	//Inicializa el arreglo donde se guardan los organismos mas aptos
	fAdaptacion = (float *) malloc(objInicializa.stDatVA.NUMORGANISMOS*sizeof(float));
	bOrganismo = (bool *)  malloc(objInicializa.stDatVA.NUMORGANISMOS*sizeof(bool));
	iOrganismo = (unsigned int **) malloc((objInicializa.stDatVA.NUMORGANISMOS)*sizeof(int));
	fVarOrganismo = (float **) malloc((objInicializa.stDatVA.NUMORGANISMOS)*sizeof(float));

	//Inicializa o asigna memoria con valores a cero donde se guardar�n los organismos mas aptos
	unsigned int iOrgParticular, iOrgInstruccion;
	for (iOrgParticular=0; iOrgParticular<objInicializa.stDatVA.NUMORGANISMOS; iOrgParticular++)
	{
		iOrganismo[iOrgParticular] = (unsigned int *) malloc((objInicializa.stDatVA.MAXINSTRUCCIONES+2)*sizeof(int));
		fVarOrganismo[iOrgParticular] = (float *) malloc((objInicializa.stDatVA.MAXINSTRUCCIONES+2)*sizeof(float));
		
		fAdaptacion[iOrgParticular]=0;
		bOrganismo[iOrgParticular]=false;
		for (iOrgInstruccion=0; iOrgInstruccion<objInicializa.stDatVA.MAXINSTRUCCIONES+2; iOrgInstruccion++)
			iOrganismo[iOrgParticular][iOrgInstruccion]=0;
	}

	//Ciclo de generar los organismos
	unsigned int iCont, iPosAmbiente, iMuta;
	float fDiferencia, fAdapta;

	//Empieza la simulaci�n
	for(unsigned int iSimula=0; iSimula<objInicializa.stDatVA.TOTALSIMULACION; iSimula++)
	{
		if (iSimula%7000==0) printf("Progreso=%d\n", iSimula);

		//Busca una posici�n del ambiente al azar
		iPosAmbiente = objAzar.genrand()%(objInicializa.stDatVA.NUMORGANISMOS-1)+1;
		
		//Si esa posici�n no ten�a ning�n organismo entonces genera al azar la criatura
		unsigned int iValorAzar, iTipoInst, iPos1, iPos2, iPos3, iEligeInst;
		if (bOrganismo[iPosAmbiente]==false)
		{
			//Genera al azar las instrucciones
			
			/* Depende de la Prob que tenga los tipos de instrucciones
			   Prob A: + - * / % ^
			   Prob B: sin, cos, tan, log, sqr
			   Prob C: >=, <=, ==, !=, >, < */
			for (iCont=0; iCont < objInicializa.stDatVA.MAXINSTRUCCIONES; iCont++)
			{
				iValorAzar = objAzar.genrand();
				//if (iValorAzar < 0) iValorAzar = -iValorAzar;
				iEligeInst = iValorAzar % 100;
				if (iEligeInst < objInicializa.stDatVA.PROBABLEBASICO)
					iTipoInst = iValorAzar % 4;
				else if (iEligeInst >= objInicializa.stDatVA.PROBABLEBASICO && iEligeInst < (objInicializa.stDatVA.PROBABLEBASICO+objInicializa.stDatVA.PROBABLEFUNCION))
					iTipoInst = iValorAzar % 7 + 4;
				else 
					iTipoInst = iValorAzar % 6 + 11;

				iPos1 = ((iValorAzar >> 16) & 0xFF)% objInicializa.stDatVA.NUMVARIABLES;
				iPos2 = ((iValorAzar >> 8) & 0xFF) % objInicializa.stDatVA.NUMVARIABLES;
				iPos3 = (iValorAzar & 0xFF);
				iOrganismo[iPosAmbiente][iCont]=(iTipoInst << 24) + (iPos1 << 16) + (iPos2 << 8) + iPos3;
			}
		}
		else //Ya hab�a un organismo all�
		{
			//Reproduce el organismo que estaba all� y env�a el hijo a la posici�n cero
			for (iCont=0; iCont<objInicializa.stDatVA.MAXINSTRUCCIONES; iCont++)
				iOrganismo[0][iCont] = iOrganismo[iPosAmbiente][iCont];

			//Modifica alguna parte de este hijo
			iMuta = (unsigned int) objAzar.genrand()%objInicializa.stDatVA.MAXINSTRUCCIONES;

			iValorAzar = objAzar.genrand();
			if (iValorAzar < 0) iValorAzar = -iValorAzar;
			iEligeInst = iValorAzar % 100;
			if (iEligeInst < objInicializa.stDatVA.PROBABLEBASICO)
				iTipoInst = iValorAzar % 4;
			else if (iEligeInst >= objInicializa.stDatVA.PROBABLEBASICO && iEligeInst < (objInicializa.stDatVA.PROBABLEBASICO+objInicializa.stDatVA.PROBABLEFUNCION))
				iTipoInst = iValorAzar % 7 + 4;
			else 
				iTipoInst = iValorAzar % 6 + 11;

			iPos1 = ((iValorAzar >> 16) & 0xFF)% objInicializa.stDatVA.NUMVARIABLES;
			iPos2 = ((iValorAzar >> 8) & 0xFF) % objInicializa.stDatVA.NUMVARIABLES;
			iPos3 = (iValorAzar & 0xFF);
			iOrganismo[0][iMuta]=(iTipoInst << 24) + (iPos1 << 16) + (iPos2 << 8) + iPos3;

			//Trabaja sobre ese organismo
			iPosAmbiente = 0;
		}

		//Enfrenta el organismo con la entrada y la salida
		fAdapta=0;
		for (iCont=0; iCont<objInicializa.stDatVA.ENTRADAS; iCont++)
		{
			if (bInterpretaOrganismo(iPosAmbiente, fEntrada[iCont])==false)
			{
				fAdapta = (float)objInicializa.stDatVA.MAXTOLERANCIA + 50;
				break;
			}
			fDiferencia = fSalida[iCont]-fVarOrganismo[iPosAmbiente][1];
			if (fDiferencia<0)
				fAdapta-=fDiferencia;
			else
				fAdapta+=fDiferencia;
		}

		//Pregunta si al menos paso por debajo del umbral permitido
		if (fAdapta <= objInicializa.stDatVA.MAXTOLERANCIA)
		{
			bOrganismo[iPosAmbiente]=true; //Ahora si hay un organismo
			fAdaptacion[iPosAmbiente]=fAdapta;

			//Si fue una mutaci�n
			if (iPosAmbiente == 0)
			{
				//Busca algun lugar donde mudarse
				iCont = objAzar.genrand()%(objInicializa.stDatVA.NUMORGANISMOS-1)+1;

				//Si el nuevo organismo es mejor que el viejo entonces lo reemplaza
				if (fAdapta < fAdaptacion[iCont] || bOrganismo[iCont]==false)
				{
					bOrganismo[iCont]=true;
					for (unsigned int iCont2=0; iCont2<objInicializa.stDatVA.MAXINSTRUCCIONES; iCont2++)
						iOrganismo[iCont][iCont2]=iOrganismo[0][iCont2];
					fAdaptacion[iCont]=fAdapta;
				}
			}
		}
	}


	//Muestra los organismos que sobrevivieron a la selecci�n
	unsigned int iImprime;
	for(iCont=1; iCont<objInicializa.stDatVA.NUMORGANISMOS;iCont++)
		if (bOrganismo[iCont]==true)
		{
			printf("\n\n// Organismo=%d se adapta=%f\n", iCont, fAdaptacion[iCont]);
			printf("#include <stdio.h>\n");
			printf("#include <math.h>\n");
			printf("void main(void);\n");
			printf("void main()\n");
			printf("{\n");
			printf("float V0=0, V1=0, V2=0, V3=0, V4=0;\n");
			printf("float fError=0, fEntrada[%d], fSalida[%d];\n",objInicializa.stDatVA.ENTRADAS,objInicializa.stDatVA.ENTRADAS); 
			for (iImprime=0; iImprime<objInicializa.stDatVA.ENTRADAS; iImprime++)
				printf("fEntrada[%d]=%f;\n", iImprime, fEntrada[iImprime]);
			for (iImprime=0; iImprime<objInicializa.stDatVA.ENTRADAS; iImprime++)
				printf("fSalida[%d]=%f;\n", iImprime, fSalida[iImprime]);
			printf("for (int iCont=0; iCont<%d; iCont++)\n", objInicializa.stDatVA.ENTRADAS);
			printf("{\n");
			printf("V0=fEntrada[iCont];\n");
			printf("V1=0;\n");
			printf("V2=0;\n");
			printf("V3=0;\n");
			printf("V4=0;\n");
			printf("//Codigo generado por el algoritmo genetico\n");

			for (unsigned int iCont2=0; iCont2<objInicializa.stDatVA.MAXINSTRUCCIONES; iCont2++)
			{
				printf("a%d: ", iCont2);
				unsigned int iLinea = iOrganismo[iCont][iCont2];
				unsigned int iPos0 = ((iLinea >> 24) & 0xFF);
				unsigned int iPos1 = ((iLinea >> 16) & 0xFF);
				unsigned int iPos2 = ((iLinea >> 8) & 0xFF);
				unsigned int iPos3 = 0;

				if (iPos0<=10)
					iPos3 = (iLinea & 0xFF) % objInicializa.stDatVA.NUMVARIABLES;
				else
					iPos3 = (iLinea & 0xFF) % objInicializa.stDatVA.MAXINSTRUCCIONES;

				//Interpreta la l�nea de c�digo
				switch(iPos0)
				{
					case 0:	printf("V%d = V%d + V%d;\n", iPos1, iPos2, iPos3); break;
					case 1:	printf("V%d = V%d - V%d;\n", iPos1, iPos2, iPos3); break;
					case 2:	printf("V%d = V%d * V%d;\n", iPos1, iPos2, iPos3); break;
					case 3: printf("V%d = V%d / V%d;\n", iPos1, iPos2, iPos3); break;
					case 4: printf("V%d = sin(V%d);\n", iPos1, iPos2); break;
					case 5: printf("V%d = cos(V%d);\n", iPos1, iPos2); break;
					case 6: printf("V%d = tan(V%d);\n", iPos1, iPos2); break;
					case 7: printf("V%d = abs(V%d);\n", iPos1, iPos2); break;
					case 8: printf("V%d = log(V%d);\n", iPos1, iPos2); break;
					case 9: printf("V%d = exp(V%d);\n", iPos1, iPos2); break;
					case 10: printf("V%d = sqrt(V%d);\n", iPos1, iPos2); break;
					case 11: printf("if (V%d > V%d) goto a%d;\n", iPos1, iPos2, iPos3); break;
					case 12: printf("if (V%d >= V%d) goto a%d;\n", iPos1, iPos2, iPos3); break;
					case 13: printf("if (V%d < V%d) goto a%d;\n", iPos1, iPos2, iPos3); break;
					case 14: printf("if (V%d <= V%d) goto a%d;\n", iPos1, iPos2, iPos3); break;
					case 15: printf("if (V%d == V%d) goto a%d;\n", iPos1, iPos2, iPos3); break;
					case 16: printf("if (V%d != V%d) goto a%d;\n", iPos1, iPos2, iPos3); break;
				}
			}
			printf("//Fin del codigo\n");
			printf("float fDiferencia = fSalida[iCont]-V1;\n");
			printf("if (fDiferencia<0) fError -= fDiferencia;\n");
			printf("else fError += fDiferencia;\n");
			printf("}\n");
			printf("printf(\"Adaptacion: %cf\", fError);\n", 37);
			printf("}\n");
		}
		getchar();
}

bool bInterpretaOrganismo(unsigned int iOrgParticular, int iEntra)
{
	unsigned int iPos0, iPos1, iPos2, iPos3, iLinea, iEjecuta=0;
	unsigned int iMaximoInterpreta=0;

	//Inicializa los valores de variables
	for (unsigned int iCont=1; iCont<objInicializa.stDatVA.NUMVARIABLES; iCont++) fVarOrganismo[iOrgParticular][iCont]=0;
	fVarOrganismo[iOrgParticular][0]= (float)iEntra;

	while(true)
	{
		iLinea = iOrganismo[iOrgParticular][iEjecuta++];
		if (iLinea==0) break; //Termino el algoritmo correctamente
		if (iMaximoInterpreta++ > objInicializa.stDatVA.MAXIMOINTERPRETA)
			return false;
				
		iPos0 = ((iLinea >> 24) & 0xFF);
		iPos1 = ((iLinea >> 16) & 0xFF);
		iPos2 = ((iLinea >> 8) & 0xFF);

		//Si NO es una instrucci�n de salto
		if (iPos0<=10)
			iPos3 = (iLinea & 0xFF) % objInicializa.stDatVA.NUMVARIABLES;
		else
			iPos3 = (iLinea & 0xFF) % objInicializa.stDatVA.MAXINSTRUCCIONES;

		//Interpreta la l�nea de c�digo
		switch(iPos0)
		{
			case 0:	//Suma
					fVarOrganismo[iOrgParticular][iPos1] = fVarOrganismo[iOrgParticular][iPos2] + fVarOrganismo[iOrgParticular][iPos3];
					break;
			case 1:	//Resta
					fVarOrganismo[iOrgParticular][iPos1] = fVarOrganismo[iOrgParticular][iPos2] - fVarOrganismo[iOrgParticular][iPos3];
					break;
			case 2:	//Multiplica
					fVarOrganismo[iOrgParticular][iPos1] = fVarOrganismo[iOrgParticular][iPos2] * fVarOrganismo[iOrgParticular][iPos3];
					break;
			case 3: //Divide
					fVarOrganismo[iOrgParticular][iPos1] = fVarOrganismo[iOrgParticular][iPos2] / fVarOrganismo[iOrgParticular][iPos3];
					break;
			case 4: //Seno
					fVarOrganismo[iOrgParticular][iPos1] = (float) sin(fVarOrganismo[iOrgParticular][iPos2]);
					break;
			case 5: //Coseno
					fVarOrganismo[iOrgParticular][iPos1] = (float) cos(fVarOrganismo[iOrgParticular][iPos2]);
					break;
			case 6: //Tangente
					fVarOrganismo[iOrgParticular][iPos1] = (float) tan(fVarOrganismo[iOrgParticular][iPos2]);
					break;
			case 7: //Valor absoluto
					fVarOrganismo[iOrgParticular][iPos1] = (float) fabs(fVarOrganismo[iOrgParticular][iPos2]);
					break;
			case 8: //Logaritmo
					fVarOrganismo[iOrgParticular][iPos1] = (float) log(fVarOrganismo[iOrgParticular][iPos2]);
					break;
			case 9: //Exponencial
					fVarOrganismo[iOrgParticular][iPos1] = (float) exp(fVarOrganismo[iOrgParticular][iPos2]);
					break;
			case 10: //Raiz Cuadrada
					fVarOrganismo[iOrgParticular][iPos1] = (float) sqrt(fVarOrganismo[iOrgParticular][iPos2]);
					break;
			case 11: //Si [iPos1]>[iPos2] Goto iPos3
					if (fVarOrganismo[iOrgParticular][iPos1]>fVarOrganismo[iOrgParticular][iPos2]) iEjecuta = iPos3;
					break;
			case 12: //Si [iPos1]>=[iPos2] Goto iPos3
					if (fVarOrganismo[iOrgParticular][iPos1]>=fVarOrganismo[iOrgParticular][iPos2]) iEjecuta = iPos3;
					break;
			case 13: //Si [iPos1]<[iPos2] Goto iPos3
					if (fVarOrganismo[iOrgParticular][iPos1]<fVarOrganismo[iOrgParticular][iPos2]) iEjecuta = iPos3;
					break;
			case 14: //Si [iPos1]<=[iPos2] Goto iPos3
					if (fVarOrganismo[iOrgParticular][iPos1]<=fVarOrganismo[iOrgParticular][iPos2]) iEjecuta = iPos3;
					break;
			case 15: //Si [iPos1]==[iPos2] Goto iPos3
					if (fVarOrganismo[iOrgParticular][iPos1]==fVarOrganismo[iOrgParticular][iPos2]) iEjecuta = iPos3;
					break;
			case 16: //Si [iPos1]!=[iPos2] Goto iPos3
					if (fVarOrganismo[iOrgParticular][iPos1]!=fVarOrganismo[iOrgParticular][iPos2]) iEjecuta = iPos3;
					break;
		}

		//Limita el valor m�ximo que tendr� las variables y evitar el overflow de enteros
		if (fVarOrganismo[iOrgParticular][iPos1]>40000 || fVarOrganismo[iOrgParticular][iPos1]<-40000 ||
			fVarOrganismo[iOrgParticular][iPos2]>40000 || fVarOrganismo[iOrgParticular][iPos2]<-40000 ||
			fVarOrganismo[iOrgParticular][iPos3]>40000 || fVarOrganismo[iOrgParticular][iPos2]<-40000)
		{
			fVarOrganismo[iOrgParticular][1]=(float)objInicializa.stDatVA.MAXTOLERANCIA+5; //El algoritmo se pas� del l�mite de valor, luego es rechazado
			break;
		}
	}
	return true;
}


void vDeshaceIO(char *m_sSerieNum, int iEntraSale)
{
		char sAcum[30];
		unsigned int iProgreso=0, iCont;
		int iEntra=0, iSale=0;
		
		// Ahora deshace la expresion en un arreglo de numeros tipo float
		for(iCont=0; iCont<=strlen(m_sSerieNum); iCont++)
		{
			if(m_sSerieNum[iCont] != ',')
			{
				sAcum[iProgreso++] = m_sSerieNum[iCont];
				sAcum[iProgreso]='\0';
			}
			else
				if(strlen(sAcum)>0)
				{
				    switch(iEntraSale)
				    {
				        case 1:
					        fEntrada[iEntra++]=(float)atof(sAcum);
					        break;
					    case 2: 
					        fSalida[iSale++]=(float)atof(sAcum);
					        break;
					}
					iProgreso=0;
				}
		} // Fin For
}; // Fin DeshaceIO
