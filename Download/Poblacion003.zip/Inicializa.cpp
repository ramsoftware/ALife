/*
Autor:		Rafael Alberto Moreno Parra
URL:		http://darwin.50webs.com
Clase:		Inicializa.
Lenguaje:	C++

Prop�sito:
Inicializa las variables para la simulaci�n

*/

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "Inicializa.h"
#include "StringUtil.h"

//Abre y estudia el archivo de inicializaci�n
int Inicializa::iLeeArchivoIni()
{
	FILE *fpInicio;
	char sFrase[600], sVariable[200], sValor[200];
    unsigned int iCar;
	StringUtil StrUtil;

	fpInicio = fopen("Pobl03.ini", "r+t");
	if (fpInicio == NULL)
    {
		printf("Error al tratar de abrir archivo de inicializaci�n Pobl03.ini\n");
		return -1;
    }
	while(!feof(fpInicio))
	{
		fgets(sFrase, 298, fpInicio);
		StrUtil.vQuitaEspacios(sFrase);

		//Extrae variables y valores
		for (iCar=0; iCar<strlen(sFrase) && sFrase[iCar]!='='; iCar++);
		StrUtil.vLeft(sVariable, sFrase, iCar);
		StrUtil.vMid(sValor, sFrase, iCar+2,strlen(sFrase)-1);

		//Clasifica variables
		if(strcmp(sVariable, "NUMORGANISMOS")==0) stDatVA.NUMORGANISMOS = atoi(sValor);
		if(strcmp(sVariable, "PROBABLEBASICO")==0) stDatVA.PROBABLEBASICO = atoi(sValor);
		if(strcmp(sVariable, "PROBABLEFUNCION")==0) stDatVA.PROBABLEFUNCION = atoi(sValor);
		if(strcmp(sVariable, "NUMORGANISMOS")==0) stDatVA.NUMORGANISMOS = atoi(sValor);
		if(strcmp(sVariable, "MAXINSTRUCCIONES")==0) stDatVA.MAXINSTRUCCIONES = atoi(sValor);
		if(strcmp(sVariable, "NUMVARIABLES")==0) stDatVA.NUMVARIABLES = atoi(sValor);
		if(strcmp(sVariable, "TOTALSIMULACION")==0) stDatVA.TOTALSIMULACION = atoi(sValor);
		if(strcmp(sVariable, "MAXIMOINTERPRETA")==0) stDatVA.MAXIMOINTERPRETA = atoi(sValor);
		if(strcmp(sVariable, "ENTRADAS")==0) stDatVA.ENTRADAS = atoi(sValor);
		if(strcmp(sVariable, "MAXTOLERANCIA")==0) stDatVA.MAXTOLERANCIA = atoi(sValor);
		if(strcmp(sVariable, "sEntrada")==0) strcpy(stDatVA.sEntrada, sValor);
		if(strcmp(sVariable, "sSalidas")==0) strcpy(stDatVA.sSalidas, sValor);
	}
	fclose(fpInicio);
	return 0;
};