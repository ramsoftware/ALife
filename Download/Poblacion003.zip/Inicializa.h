/*
Autor:		Rafael Alberto Moreno Parra
URL:		http://www.geocities.com/krousky
Clase:		Inicializa.
Lenguaje:	C++

Prop�sito:
Inicializa las variables para la simulaci�n

M�todos:

*/
class Inicializa {
public:

	struct stDatosSimul
	{
		unsigned int NUMORGANISMOS; //Cuantos organismos tendr� el ambiente al tiempo
		unsigned int PROBABLEBASICO; //Probabilidad de operaciones b�sicas
		unsigned int PROBABLEFUNCION; //Probabilidad de funciones matem�ticas
		unsigned int MAXINSTRUCCIONES; //El maximo son 256 instrucciones
		unsigned int NUMVARIABLES; //Total variables que tendr� cada algoritmo gen�tico
		unsigned int TOTALSIMULACION; //Cuantos organismos va a generar
		unsigned int MAXIMOINTERPRETA; //Cuantas instrucciones del algoritmo genetico ejecutar�.
		unsigned int ENTRADAS;  //Numero de entradas/salidas que tendr� 
		unsigned int MAXTOLERANCIA; //Si la adaptac�n del organismo comparado con este valor es menor entonces es evaluado para selecci�n

		char sEntrada[200];
		char sSalidas[200];
	};  

	struct stDatosSimul stDatVA; //Datos Vida Artificial
    int iLeeArchivoIni(void);
};
