/*
[A-Life]: Investigaci�n sobre Vida Artificial. El Algoritmo Evolutivo.

Autor: Rafael Alberto Moreno Parra. enginelife@hotmail.com
URL:   http://www.geocities.com/krousky
Fecha: 22 de Enero de 2001

Simulaci�n:  AlgEvo001
Herramienta: Microsoft Visual C++ 6.0

Objetivo:
Dado un Universo, este esta lleno de ambientes, hay una serie de
elementos (materia) que reaccionan al estado del ambiente, una serie
de seres vivos comandados por el "algoritmo evolutivo", buscan conseguir
dichos elementos usando estrat�gias como desplazamiento, colecci�n de nuevos
elementos, etc...

*/
#include <stdlib.h>
#include <stdio.h>

#include "Universo.h"

//Constructor
Universo::Universo()
{
	time(&ltime1);
}


//Inicializa la semilla dependiendo del tiempo
void Universo::IniciaSemillaT()
{
	time_t ltime2;
	do
	{
		time(&ltime2);
	}while(ltime2==ltime1);
	srand( ltime2 );
	ltime1 = ltime2;
}

//Inicializa la semilla aleatoriamente
void Universo::IniciaSemillaR()
{
	srand(rand());
};


//Genera ambientes, tipos de materiales, materiales y organismos
unsigned int Universo::BigBang(void)
{
	unsigned int iCont, iCont1, iMaterial;

	//Trae los datos del archivo de configuracion
	objInicia.vPantallaIni();
	objInicia.vLeeArchivoIni();

	// Valores de inicializaci�n
	m_iTotalAmb = objInicia.stDatVA.iTotalAmb;
	m_iTotalTip = objInicia.stDatVA.iTotalTip;
	m_iTotalMat = objInicia.stDatVA.iTotalMat;
	m_iTotalOrg = objInicia.stDatVA.iTotalOrg;
	m_iXmin = objInicia.stDatVA.iXmin;
	m_iYmin = objInicia.stDatVA.iYmin;
	m_iXmax = objInicia.stDatVA.iXmax;
	m_iYmax	= objInicia.stDatVA.iYmax;

	// Reserva memoria
	objAmb = (Ambiente *) malloc ( sizeof(Ambiente) * m_iTotalAmb );
	if (objAmb == NULL) return ERRORMEMORIA;

	objTip = (TipoMat *) malloc ( sizeof(TipoMat) * m_iTotalTip );
	if (objTip == NULL) return ERRORMEMORIA;

	objMat = (Material *) malloc ( sizeof(Material) * m_iTotalMat );
	if (objMat == NULL) return ERRORMEMORIA;

	objOrg = (Organismo *) malloc ( sizeof(Organismo) * m_iTotalOrg );
	if (objOrg == NULL) return ERRORMEMORIA;

	//Inicia proceso aleatorio
	IniciaSemillaT();


	//Crea los ambientes
	for (iCont=0; iCont < m_iTotalAmb; iCont++)
		objAmb[iCont].iInicia(iCont, m_iXmin, m_iYmin, m_iXmax, m_iYmax,
								objInicia.stDatVA.iLongExprAmb,
								objInicia.stDatVA.iProbN,
								objInicia.stDatVA.iProbX,
								objInicia.stDatVA.iProbY,
								objInicia.stDatVA.iProbP);

	//Crea los tipos de materiales
	for (iCont=0; iCont < m_iTotalTip; iCont++)
		objTip[iCont].iInicia(iCont,
								objInicia.stDatVA.iLongExprTip,
								objInicia.stDatVA.iTipProbN,
								objInicia.stDatVA.iTipProbX,
								objInicia.stDatVA.iTipProbP);

	//Crea los materiales y los relaciona a un tipo de material
	for (iCont=0; iCont < m_iTotalMat; iCont++)
		objMat[iCont].vInicia(iCont, m_iXmin, m_iYmin, m_iXmax, m_iYmax, m_iTotalTip);

	//Crea los organismos (relaciones estables entre materiales)
	for (iCont=0; iCont < m_iTotalOrg; iCont++)
	{
		objOrg[iCont].vNace(objInicia.stDatVA.iEstabilidad, objInicia.stDatVA.iTolMin, objInicia.stDatVA.iTolMax, objInicia.stDatVA.iMaxMat);

		for (iCont1=0; iCont1 < objInicia.stDatVA.iMaxMat; iCont1++) 
		{
			do
			{
				iMaterial = rand()%m_iTotalMat; 
			}while (objMat[iMaterial].m_cUsado==MAT_OCUPADO);

			objOrg[iCont].m_iIDmaterial[iCont1] = objMat[iMaterial].m_iIDmat;
			objMat[iMaterial].m_cUsado=MAT_OCUPADO;
		}
	}
	return OPERACIONEXITOSA;
}

/* Dado un punto, que valor tiene este cubierto de 0 a N ambientes */
float Universo::fValPosXY(unsigned int iPosX, unsigned int iPosY)
{
	unsigned int iCont;
	float fValor=0;

	for (iCont=0; iCont < m_iTotalAmb; iCont++)
		fValor += objAmb[iCont].fValCoord(iPosX, iPosY);

	return fValor;
};

/* Ciclo de la vida */
void Universo::vCicloVida()
{
	unsigned int iCont, iContinua;

	for(;;) // Es un ciclo infinito hasta que todos mueran
	{
		iContinua=0;
		printf("\nSobreviven: ");
		for (iCont=0; iCont < m_iTotalOrg; iCont++)
		{
			if ( objOrg[iCont].m_cVivo == ORG_VIVO )
			{
				iContinua=1;
				printf("%d,", iCont);
			}
		}
		if (iContinua==0) break;
		vEvaluaOrganismo();
	}
	printf("\n");
}


/* Evalua el Organismo */
void Universo::vEvaluaOrganismo()
{
	unsigned int iCont, iCont1, iMaterial, iTipMaterial, iPosX, iPosY;
	signed int iEnergia;
	float fValor;

	/* Toma cada organismo que a�n viva */
	for (iCont=0; iCont < m_iTotalOrg; iCont++)
	{
		if ( objOrg[iCont].m_cVivo == ORG_VIVO )
		{
			// Se va por cada material de que este hecho el organismo
			for (iCont1=0; iCont1 < objInicia.stDatVA.iMaxMat; iCont1++)
			{
				// �De que material esta hecho?
				iMaterial = objOrg[iCont].m_iIDmaterial[iCont1];

				// �Donde esta ubicado ese material?
				iPosX = objMat[iMaterial].m_iPosX;
				iPosY = objMat[iMaterial].m_iPosY;

				// �Que tipo de material es?
				iTipMaterial = objMat[iMaterial].m_iTipMaterial;

				// �Que ambiente hay en esa ubicaci�n?
				fValor = fValPosXY(iPosX, iPosY);

				//�Como reacciona el material a ese ambiente?
				iEnergia = objTip[iTipMaterial].iEnergia(fValor);

				//�Como afecta esa reacci�n al organismo?
				objOrg[iCont].m_iEstabilidad += iEnergia;
			}

			// �Sobrevivir� el organismo?
			if ( objOrg[iCont].m_iEstabilidad > objOrg[iCont].m_iToleranciaMax ||
				 objOrg[iCont].m_iEstabilidad < objOrg[iCont].m_iToleranciaMin)
				objOrg[iCont].m_cVivo = ORG_MUERTO;
		}
	}
}
