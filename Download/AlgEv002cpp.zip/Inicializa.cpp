/*
[A-Life]: Investigaci�n sobre Vida Artificial. El Algoritmo Evolutivo.

Autor: Rafael Alberto Moreno Parra. enginelife@hotmail.com
URL:   http://www.geocities.com/krousky
Fecha: 23 de Enero de 2001

Simulaci�n:  AlgEvo001
Herramienta: Microsoft Visual C++ 6.0

Objetivo:
Dado un Universo, este esta lleno de ambientes, hay una serie de
elementos (materia) que reaccionan al estado del ambiente, una serie
de seres vivos comandados por el "algoritmo evolutivo", buscan conseguir
dichos elementos usando estrat�gias como desplazamiento, colecci�n de nuevos
elementos, etc...

*/

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>
#include "Inicializa.h"
#include "StringUtil.h"

void Inicializa::vPantallaIni()
{
	printf("Motor de Vida Artificial\n\n");
	printf("Algoritmo Evolutivo 002: Inicios\n\n");
	printf("Autor: Rafael Alberto Moreno Parra\n");
	printf("Fecha: 23 de Enero de 2001\n");
	printf("E-mail: enginelife@hotmail.com\n");
	printf("http://www.geocities.com/krousky\n");
};

//Abre y estudia el archivo de inicializaci�n
int Inicializa::vLeeArchivoIni()
{
	FILE *fpInicio;
	char sFrase[600], sVariable[200], sValor[200];
    unsigned int iCar;
	StringUtil StrUtil;

	fpInicio = fopen("AlgEv002.ini", "r+t");
	if (fpInicio == NULL)
    {
		printf("Error al tratar de abrir archivo de inicializaci�n AlgEv002.ini\n");
		return -1;
    }
	while(!feof(fpInicio))
	{
		fgets(sFrase, 298, fpInicio);
		StrUtil.vQuitaEspacios(sFrase);

		//Extrae variables y valores
		for (iCar=0; iCar<strlen(sFrase) && sFrase[iCar]!='='; iCar++);
		StrUtil.vLeft(sVariable, sFrase, iCar);
		StrUtil.vMid(sValor, sFrase, iCar+2,strlen(sFrase)-1);

		//Clasifica

		//Para universo
		if(strcmp(sVariable, "iTotalAmb")==0) stDatVA.iTotalAmb = atoi(sValor); //Total ambientes
		if(strcmp(sVariable, "iTotalTip")==0) stDatVA.iTotalTip = atoi(sValor); //Total tipos de materia
		if(strcmp(sVariable, "iTotalMat")==0) stDatVA.iTotalMat = atoi(sValor); //Total materiales
		if(strcmp(sVariable, "iTotalOrg")==0) stDatVA.iTotalOrg = atoi(sValor); //Total organismos
		if(strcmp(sVariable, "iXmin")==0) stDatVA.iXmin = atoi(sValor);
		if(strcmp(sVariable, "iYmin")==0) stDatVA.iYmin = atoi(sValor);
		if(strcmp(sVariable, "iXmax")==0) stDatVA.iXmax = atoi(sValor);
		if(strcmp(sVariable, "iYmax")==0) stDatVA.iYmax = atoi(sValor);

		//Para ambiente
		if(strcmp(sVariable, "iLongExprAmb")==0) stDatVA.iLongExprAmb = atoi(sValor); //Longitud de la expresi�n de ambiente
		if(strcmp(sVariable, "iProbN")==0) stDatVA.iProbN = atoi(sValor); // Probabilidad de Numero
		if(strcmp(sVariable, "iProbX")==0) stDatVA.iProbX = atoi(sValor); // Probabilidad de variable X
		if(strcmp(sVariable, "iProbY")==0) stDatVA.iProbY = atoi(sValor); // Probabilidad de variable Y
		if(strcmp(sVariable, "iProbP")==0) stDatVA.iProbP = atoi(sValor); // Probabilidad de parentesis

		//Para tipo de material
		if(strcmp(sVariable, "iLongExprTip")==0) stDatVA.iLongExprTip = atoi(sValor); //Longitud de la expresi�n de tipo de material
		if(strcmp(sVariable, "iTipProbN")==0) stDatVA.iTipProbN = atoi(sValor); // Probabilidad de Numero
		if(strcmp(sVariable, "iTipProbX")==0) stDatVA.iTipProbX = atoi(sValor); // Probabilidad de variable X
		if(strcmp(sVariable, "iTipProbP")==0) stDatVA.iTipProbP = atoi(sValor); // Probabilidad de parentesis

		//Para organismo
		if(strcmp(sVariable, "iEstabilidad")==0) stDatVA.iEstabilidad = atoi(sValor); //Longitud de la expresi�n de tipo de material
		if(strcmp(sVariable, "iTolMin")==0) stDatVA.iTolMin = atoi(sValor); // Probabilidad de Numero
		if(strcmp(sVariable, "iTolMax")==0) stDatVA.iTolMax = atoi(sValor); // Probabilidad de variable X
		if(strcmp(sVariable, "iMaxMat")==0) stDatVA.iMaxMat = atoi(sValor); // M�ximo n�mero de materiales que llega a enlazar
	}
	fclose(fpInicio);
	return 0;
};
