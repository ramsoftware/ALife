/*
[A-Life]: Investigaci�n sobre Vida Artificial. El Algoritmo Evolutivo.

Autor: Rafael Alberto Moreno Parra. enginelife@hotmail.com
URL:   http://www.geocities.com/krousky
Fecha: 23 de Enero de 2001

Simulaci�n:  AlgEvo001
Herramienta: Microsoft Visual C++ 6.0

Objetivo:
Dado un Universo, este esta lleno de ambientes, hay una serie de
elementos (materia) que reaccionan al estado del ambiente, una serie
de seres vivos comandados por el "algoritmo evolutivo", buscan conseguir
dichos elementos usando estrat�gias como desplazamiento, colecci�n de nuevos
elementos, etc...

*/

#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "Ambiente.h"
#include "Mutacion.h"


/* Inicializa los ambientes */
unsigned int Ambiente::iInicia(unsigned int iID,
								unsigned int iXmin, unsigned int iYmin, unsigned int iXmax, unsigned int iYmax,
								unsigned int iLongExpr,
								unsigned int iProbN, unsigned int iProbX, unsigned int iProbY, unsigned int iProbP)
{
	/* Valida MAXIMALONGEXPRESION */
	if (iLongExpr >= MAXIMALONGEXPRESION )
		return EXCEDIOLIMITES;

	/* Reserva memoria para la Ecuaci�n */
	m_sEcuacion = (char *) malloc ( sizeof(char) * iLongExpr + 10);
	if (m_sEcuacion == NULL) return ERRORMEMORIA;
	
	/* Identifica el ambiente con un c�digo */
	m_iIDambiente = iID;

	/* Inicializa los extremos del ambiente rect�ngular */
	m_iXini = 0;
	m_iXfin = 0;
	m_iYini = 0;
	m_iYfin = 0;

	/* Tama�o rectangular de cada ambiente */
	do{
		m_iXini = rand() % (iXmax - iXmin) + iXmin;
		m_iXfin = rand() % (iXmax - iXmin) + iXmin;
	}while ( m_iXini >= m_iXfin );

	do{
		m_iYini = rand() % (iYmax - iYmin) + iYmin;
		m_iYfin = rand() % (iYmax - iYmin) + iYmin;
	}while ( m_iYini >= m_iYfin );

	/* Ecuaci�n que define el ambiente en f(x,y) */
	Mutacion objMuta;

	objMuta.vIniLista(iProbN, iProbX, iProbY, iProbP);
	objMuta.vCreaExpresion(iProbN, iProbX, iProbY, iProbP, iLongExpr);
	strcpy(m_sEcuacion, objMuta.sExpresion);

	/* Evalua previamente la ecuaci�n para mayor velocidad */
	objEval.dCapturaEcuacion(m_sEcuacion, (float)0, (float)0);

	printf("Este es el ambiente [%d]\n", m_iIDambiente);
	printf("m_iXini=[%d] m_iYini=[%d]\n", m_iXini, m_iYini);
	printf("m_iXfin=[%d] m_iYfin=[%d]\n", m_iXfin, m_iYfin);
	printf("Expresi�n [%s]\n\n", m_sEcuacion);

	return OPERACIONEXITOSA;
};

/* Determina si un punto esta dentro del �rea */
unsigned int Ambiente::iDentro(unsigned int iPosX, unsigned int iPosY)
{
	if (iPosX >= m_iXini && iPosX <= m_iXfin && iPosY >= m_iYini && iPosY <= m_iYfin)
		return AMB_DENTRO;
	return AMB_FUERA;
};

/* Determina el valor interno del ambiente en un punto dado */
float Ambiente::fValCoord(unsigned int iPosX, unsigned int iPosY)
{
	if (iDentro(iPosX, iPosY)==AMB_DENTRO)
		return (float) objEval.dCicloEvalua( (float) iPosX, (float) iPosY);
	else
		return (float) 0;
};