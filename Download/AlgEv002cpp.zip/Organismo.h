/*
[A-Life]: Investigaci�n sobre Vida Artificial. El Algoritmo Evolutivo.

Autor: Rafael Alberto Moreno Parra. enginelife@hotmail.com
URL:   http://www.geocities.com/krousky
Fecha: 16 de Enero de 2001

Simulaci�n:  AlgEvo001
Herramienta: Microsoft Visual C++ 6.0

Objetivo:
Dado un Universo, este esta lleno de ambientes, hay una serie de
elementos (materia) que reaccionan al estado del ambiente, una serie
de seres vivos comandados por el "algoritmo evolutivo", buscan conseguir
dichos elementos usando estrat�gias como desplazamiento, colecci�n de nuevos
elementos, etc...

*/

#ifndef PARAMETRO
#include "Parametro.h"
#endif


class Organismo
{
public:

	//Indicador de si se mantiene con vida el organismo
	char m_cVivo;

	//Nivel de energia que tiene el organismo
	unsigned int m_iEstabilidad;

	//Tolerancia m�nima de energ�a
	unsigned int m_iToleranciaMin;

	//Tolerancia m�xima de energ�a
	unsigned int m_iToleranciaMax;

	//Materiales de que esta compuesto
	unsigned int *m_iIDmaterial;

	//Nace el organismo
	void vNace(unsigned int iEstabilidad, unsigned int iTolMin, unsigned int iTolMax, unsigned int iNumMaterial);
};