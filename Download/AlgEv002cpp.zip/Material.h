/*
[A-Life]: Investigaci�n sobre Vida Artificial. El Algoritmo Evolutivo.

Autor: Rafael Alberto Moreno Parra. enginelife@hotmail.com
URL:   http://www.geocities.com/krousky
Fecha: 16 de Enero de 2001

Simulaci�n:  AlgEvo001
Herramienta: Microsoft Visual C++ 6.0

Objetivo:
Dado un Universo, este esta lleno de ambientes, hay una serie de
elementos (materia) que reaccionan al estado del ambiente, una serie
de seres vivos comandados por el "algoritmo evolutivo", buscan conseguir
dichos elementos usando estrat�gias como desplazamiento, colecci�n de nuevos
elementos, etc...

*/

#ifndef PARAMETRO
#include "Parametro.h"
#endif


/* Esta clase representa la materia y energ�a del Universo */
class Material
{
public:
	/* Identificador de material */
	unsigned int m_iIDmat;

	/* Tipo de Material */
	unsigned int m_iTipMaterial;

	/* Es un material nodal */
	unsigned int m_iPosX, m_iPosY;

	/* Chequea si esta siendo usado por alg�n organismo */
	char m_cUsado;

	/* Inicializa */
	void vInicia(unsigned int iID, unsigned int iXmin, unsigned int iYmin, unsigned int iXmax, unsigned int iYmax, unsigned int iMaxTipMat);
};
