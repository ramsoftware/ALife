/*
[A-Life]: Investigaci�n sobre Vida Artificial. El Algoritmo Evolutivo.

Autor: Rafael Alberto Moreno Parra. enginelife@hotmail.com
URL:   http://www.geocities.com/krousky
Fecha: 23 de Enero de 2001

Simulaci�n:  AlgEvo001
Herramienta: Microsoft Visual C++ 6.0

Objetivo:
Dado un Universo, este esta lleno de ambientes, hay una serie de
elementos (materia) que reaccionan al estado del ambiente, una serie
de seres vivos comandados por el "algoritmo evolutivo", buscan conseguir
dichos elementos usando estrat�gias como desplazamiento, colecci�n de nuevos
elementos, etc...

*/


class Inicializa {
public:

	struct stDatosSimul
	{
   		//Probabilidades, estos datos se leen de un archivo de inicializaci�n

		//Universo
		unsigned int iTotalAmb; //Total ambientes
		unsigned int iTotalTip; //Total tipos de materia
		unsigned int iTotalMat; //Total materiales
		unsigned int iTotalOrg; //Total organismos
		unsigned int iXmin;
		unsigned int iYmin;
		unsigned int iXmax;
		unsigned int iYmax;
		
		//Ambientes
		unsigned int iLongExprAmb; //Longitud de la expresi�n de ambiente
		unsigned int iProbN; // Probabilidad de Numero
		unsigned int iProbX; // Probabilidad de variable X
		unsigned int iProbY; // Probabilidad de variable Y
		unsigned int iProbP; // Probabilidad de parentesis

		//Tipo de Material
		unsigned int iLongExprTip; //Longitud de la expresi�n de ambiente
		unsigned int iTipProbN; // Probabilidad de Numero
		unsigned int iTipProbX; // Probabilidad de variable X
		unsigned int iTipProbP; // Probabilidad de parentesis

		//Organismo
		unsigned int iEstabilidad; //Estabilidad Energ�tica
		unsigned int iTolMax; //Tolerancia m�xima
		unsigned int iTolMin; //Tolerancia m�nima
		unsigned int iMaxMat; //M�ximo Numero de Materiales
	};  

	struct stDatosSimul stDatVA; //Datos Vida Artificial
	void vPantallaIni(void);
    int vLeeArchivoIni(void);
};
