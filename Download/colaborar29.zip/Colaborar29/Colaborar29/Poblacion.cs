﻿/* Autor: Rafael Alberto Moreno Parra
 * Fecha: 11 de abril de 2024
 * 
 * En el anterior programa se desarrolló un software gráfico que compara un algoritmo evolutivo contra una red neuronal (perceptrón multicapa). A partir de allí hubo varios cambios:
 * 1. Se mejora el algoritmo evolutivo, en vez de una larga ecuación polinómica dentro de la operación trigonométrica seno, ahora es la sumatoria de varias operaciones trigonométricas seno y su posterior normalización. Además se retira el concepto de competencia y ahora es un conjunto de individuos que van mejorando su ajuste poco a poco.
 * 2. Se mejora la interfaz gráfica, haciéndola más sencilla de entender y controlar.
 * 3. Si se maximiza la ventana, el gráfico estadístico también se maximiza.
 * Modo de operación:
 *  1. El botón "Generar dataset" lo que hace es generar una serie de datos de entrenamiento y una serie de datos de validación. Esos datos nacen de una función generada al azar.
 *  2. El botón de "Procesar" lanza un hilo de ejecución que ejecuta la red neuronal y el algoritmo evolutivo. Una vez lanzado, es dejar pasar el tiempo, el programa va mostrando los ciclos. Entre más tiempo se deje ejecutar el programa mejor.
 *  3. El botón "Detener" lo que hace es finalizar el proceso inmediatamente.
 * Una vez se detiene el proceso, se muestra por pantalla las curvas obtenidas por ambos procedimientos. Se muestra la mejor red neuronal que se ajuste a los datos de validación, sucede lo mismo con el algoritmo evolutivo.
 * 
 *  Este nuevo programa ha generado una bifurcación en el desarrollo de esta investigación sobre colaboración. En una rama se seguirá desarrollando como herramienta de análisis de datos tanto el algoritmo evolutivo como la red neuronal (para una investigación que sigo en la universidad). La segunda rama, propiamente de vida artificial, se enfocará en el algoritmo evolutivo (se abandona la red neuronal) y los comportamientos cíclicos de los ambientes, algo que no estaba contemplado previamente. 
 */
namespace Colaborar29 {
    internal class Poblacion {
        //Para agilizar cálculos
        static private double Radian;

        //Los individuos
        private double[][] Individuos;
        private double[] Ajuste;
        public int MejorIndividuo;

        //¿Ya ha procesado?
        public bool Procesado;

        //Inicializa el individuo con los coeficientes al azar
        public Poblacion(Random Azar, int TamanoPoblacion) {
            Individuos = new double[TamanoPoblacion][];
            Ajuste = new double[TamanoPoblacion];

            Radian = Math.PI / 180;
            for (int Id = 0; Id < Individuos.Length; Id++) {
                Ajuste[Id] = double.MaxValue;
                Individuos[Id] = new double[30];
                for (int valor = 0; valor < 30; valor++) {
                    Individuos[Id][valor] = Azar.NextDouble() * 2 - 1;
                }
            }

            Procesado = false;
        }

        //Proceso evolutivo.
        public void Proceso(Random Azar, GeneradorDatos ConjuntoDatos) {

            //Todos los individuos son evaluados
            for (int Id = 0; Id < Individuos.Length; Id++) {

                //Guarda los valores anteriores
                int CualMuta = Azar.Next(30);
                double ValorAnterior = Individuos[Id][CualMuta];
                Individuos[Id][CualMuta] += Azar.NextDouble() * 2 - 1;

                //Deduce el ajuste
                double NuevoAjuste = 0;
                for (int Xval = 0; Xval < ConjuntoDatos.Entradas.Length; Xval++) {

                    //Deduce el valor Y del individuo con esa entrada X del ambiente
                    double Y = ValorIndividuo(Id, ConjuntoDatos.Entradas[Xval]);

                    //Diferencia entre la salida calculada y la esperada
                    NuevoAjuste += Math.Abs(Y - ConjuntoDatos.Salidas[Xval]);

                    //Si el nuevo ajuste supera al ajuste anterior, sale del ciclo
                    if (NuevoAjuste > Ajuste[Id]) break;
                }

                //Si el cambio mejora al individuo se conserva, caso contrario se restaura el valor anterior
                if (NuevoAjuste > Ajuste[Id])
                    Individuos[Id][CualMuta] = ValorAnterior;
                else
                    Ajuste[Id] = NuevoAjuste;
            }

            Procesado = true;
        }

        public void ObtenerMejorIndividuo(GeneradorDatos ConjuntoDatos) {
            //Prueba cada individuo con los valores de validación
            for (int Id = 0; Id < Individuos.Length; Id++) {
                Ajuste[Id] = 0;

                for (int Xval = 0; Xval < ConjuntoDatos.Entradas.Length; Xval++) {

                    //Deduce el valor Y del individuo con esa entrada X del ambiente
                    double Y = ValorIndividuo(Id, ConjuntoDatos.ValidaEntra[Xval]);

                    Ajuste[Id] += Math.Abs(Y - ConjuntoDatos.ValidaSale[Xval]);
                }
            }

            //Busca el mejor
            double MejorAjuste = double.MaxValue;
            for (int Id = 0; Id < Individuos.Length; Id++) {
                if (Ajuste[Id] < MejorAjuste) {
                    MejorAjuste = Ajuste[Id];
                    MejorIndividuo = Id;
                }
            }
        }

        public double ValorIndividuo(int Id, double valEntra) {
            double X = valEntra * 1000.0;
            return (Individuos[Id][0] * Math.Sin((Individuos[Id][1] * X + Individuos[Id][2]) * Radian) +
Individuos[Id][3] * Math.Sin((Individuos[Id][4] * X + Individuos[Id][5]) * Radian) +
Individuos[Id][6] * Math.Sin((Individuos[Id][7] * X + Individuos[Id][8]) * Radian) +
Individuos[Id][9] * Math.Sin((Individuos[Id][10] * X + Individuos[Id][11]) * Radian) +
Individuos[Id][12] * Math.Sin((Individuos[Id][13] * X + Individuos[Id][14]) * Radian) +
Individuos[Id][15] * Math.Sin((Individuos[Id][16] * X + Individuos[Id][17]) * Radian) +
Individuos[Id][18] * Math.Sin((Individuos[Id][19] * X + Individuos[Id][20]) * Radian) +
Individuos[Id][21] * Math.Sin((Individuos[Id][22] * X + Individuos[Id][23]) * Radian) +
Individuos[Id][24] * Math.Sin((Individuos[Id][25] * X + Individuos[Id][26]) * Radian) +
Individuos[Id][27] * Math.Sin((Individuos[Id][28] * X + Individuos[Id][29]) * Radian)) / 1000.0;
        }

    }
}
