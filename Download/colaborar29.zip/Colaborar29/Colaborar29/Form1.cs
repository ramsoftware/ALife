﻿/* Autor: Rafael Alberto Moreno Parra
 * Fecha: 11 de abril de 2024
 */
using System.ComponentModel;


namespace Colaborar29 {
    public partial class Form1 : Form {
        Random Azar;

        //Los datos generados para el dataset.
        GeneradorDatos ConjuntoDatos;

        //Para manejar las redes neuronales
        Redes RedesNeuronales;

        //Para manejar el algoritmo evolutivo
        Poblacion objPoblacion;

        //Para mantener el proceso en ejecución
        bool MantenerProceso;
        int CicloEjecutado;

        public Form1() {
            InitializeComponent();
            Azar = new Random();
        }

        private void LlenaGridChart() {
            //Llena el GridView con los datos del ambiente (entrada y salida esperadas)
            dgDatos.Rows.Clear();
            dgDatos.Refresh();

            //Alineación de los datos
            for (int Num = 0; Num <= 5; Num++)
                dgDatos.Columns[Num].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;

            //Entrada y salidas esperados
            for (int Num = 0; Num < ConjuntoDatos.Entradas.Length; Num++) {
                var nuevaFila = dgDatos.Rows.Add();
                dgDatos.Rows[nuevaFila].Cells[0].Value = ConjuntoDatos.Entradas[Num].ToString("0.000");
                dgDatos.Rows[nuevaFila].Cells[1].Value = ConjuntoDatos.Salidas[Num].ToString("0.000");
            }

            //GRÁFICO ESTADÍSTICO LINEAL

            //Inicializa las series de datos, algoritmo evolutivo y red neuronal
            for (int Num = 0; Num <= 2; Num++)
                chartDatos.Series[Num].Points.Clear();

            //Muestra los datos generados en el gráfico estadístico lineal
            chartDatos.ChartAreas[0].AxisX.MajorGrid.Enabled = false;
            chartDatos.ChartAreas[0].AxisY.MajorGrid.Enabled = false;
            chartDatos.ChartAreas[0].AxisY.Maximum = 1;

            chartDatos.ChartAreas[0].AxisX.Minimum = 0;
            chartDatos.ChartAreas[0].AxisX.Maximum = 1;
            chartDatos.ChartAreas[0].AxisX.Interval = 0.1;

            for (int Num = 0; Num < ConjuntoDatos.Entradas.Length; Num++)
                chartDatos.Series[0].Points.AddXY(ConjuntoDatos.Entradas[Num], ConjuntoDatos.Salidas[Num]);

            //Si los algoritmos han sido activados
            if (objPoblacion.Procesado) {

                RedesNeuronales.ObtenerMejorRedNeuronal(ConjuntoDatos);
                objPoblacion.ObtenerMejorIndividuo(ConjuntoDatos);

                for (int Num = 0; Num < ConjuntoDatos.Salidas.Length; Num++) {
                    //===================
                    //Algoritmo Evolutivo
                    //===================
                    double SalidaEvolutivo = objPoblacion.ValorIndividuo(objPoblacion.MejorIndividuo, ConjuntoDatos.Entradas[Num]);
                    dgDatos.Rows[Num].Cells[2].Value = SalidaEvolutivo.ToString("0.000");

                    //Pone la diferencia
                    dgDatos.Rows[Num].Cells[3].Value = Math.Abs(ConjuntoDatos.Salidas[Num] - SalidaEvolutivo).ToString("0.000");

                    //Pone en el chart
                    chartDatos.Series[2].Points.AddXY(ConjuntoDatos.Entradas[Num], SalidaEvolutivo);

                    //===================
                    //Red Neuronal
                    //===================
                    double SalidaRed = RedesNeuronales.MejorRed(ConjuntoDatos.Entradas[Num]);
                    dgDatos.Rows[Num].Cells[4].Value = SalidaRed.ToString("0.000");

                    //Pone la diferencia
                    dgDatos.Rows[Num].Cells[5].Value = Math.Abs(ConjuntoDatos.Salidas[Num] - SalidaRed).ToString("0.000");

                    //Pone en el chart
                    chartDatos.Series[1].Points.AddXY(ConjuntoDatos.Entradas[Num], SalidaRed);
                }
            }
        }

        private void btnGenera_Click(object sender, EventArgs e) {
            //Prepara el generador de datos
            ConjuntoDatos = new GeneradorDatos();

            //Genera el dataset en forma aleatoria
            ConjuntoDatos.GeneraEcuacion(Azar, Convert.ToDouble(numXini.Value), Convert.ToDouble(numXfin.Value), Convert.ToInt32(numRegistros.Value));

            //Configurando las redes neuronales
            RedesNeuronales = new(Azar, (int) numTotalRedes.Value, (int) numNeuronaCapaOculta1.Value, (int) numNeuronaCapaOculta2.Value);

            //Configurando la población del algoritmo evolutivo
            objPoblacion = new(Azar, (int)numIndividuos.Value);
            
            //Llena los datos en pantalla
            LlenaGridChart();

            //Habilita el proceso
            btnProceso.Enabled = true;
            txtCiclo.Text = "";
        }

        private void btnProceso_Click(object sender, EventArgs e) {
            btnGenera.Enabled = false;
            btnProceso.Enabled = false;
            btnDetener.Enabled = true;

            if (bgwProceso.IsBusy != true) {

                //Si el hilo no está trabajando
                bgwProceso.RunWorkerAsync();
            }
        }

        private void Proceso(object sender, DoWorkEventArgs e) {

            //Llama al algoritmo evolutivo y a la red neuronal
            MantenerProceso = true;
            CicloEjecutado = 0;
            while (MantenerProceso) {

                //===================
                //Algoritmo evolutivo
                //===================
                objPoblacion.Proceso(Azar, ConjuntoDatos);

                //===================                
                //Red neuronal
                //===================
                RedesNeuronales.Proceso(ConjuntoDatos);

                if (++CicloEjecutado % 100 == 0)
                    bgwProceso.ReportProgress(0);
            }
        }

        //Muestra el avance del proceso
        private void bgwProceso_ProgressChanged(object sender, ProgressChangedEventArgs e) {
            txtCiclo.Text = Convert.ToString(CicloEjecutado);
        }

        private void bgwProceso_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e) {
            //Llena el gridview y el chart
            LlenaGridChart();
        }

        private void btnDetener_Click(object sender, EventArgs e) {
            btnGenera.Enabled = true;
            btnDetener.Enabled = false;
            btnProceso.Enabled = false;
            MantenerProceso = false;
        }
    }
}
