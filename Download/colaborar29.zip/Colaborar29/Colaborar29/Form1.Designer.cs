﻿namespace Colaborar29 {
    partial class Form1 {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing) {
            if (disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent() {
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea1 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend1 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series1 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.Series series2 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.Series series3 = new System.Windows.Forms.DataVisualization.Charting.Series();
            tabPrincipal = new TabControl();
            tabGenerar = new TabPage();
            splitContainer1 = new SplitContainer();
            lblCiclos = new Label();
            txtCiclo = new TextBox();
            btnDetener = new Button();
            btnProceso = new Button();
            btnGenera = new Button();
            chartDatos = new System.Windows.Forms.DataVisualization.Charting.Chart();
            tabDatos = new TabPage();
            dgDatos = new DataGridView();
            dataGridViewTextBoxColumn5 = new DataGridViewTextBoxColumn();
            dataGridViewTextBoxColumn6 = new DataGridViewTextBoxColumn();
            colEvolutivo = new DataGridViewTextBoxColumn();
            colDifEvolutivo = new DataGridViewTextBoxColumn();
            colRed = new DataGridViewTextBoxColumn();
            colDifRed = new DataGridViewTextBoxColumn();
            tabConfiguracion = new TabPage();
            groupBox1 = new GroupBox();
            numRegistros = new NumericUpDown();
            lblNumRegistros = new Label();
            numXfin = new NumericUpDown();
            numXini = new NumericUpDown();
            lblXfin = new Label();
            lblXini = new Label();
            grbRed = new GroupBox();
            numTotalRedes = new NumericUpDown();
            lblRedes = new Label();
            numNeuronaCapaOculta2 = new NumericUpDown();
            numNeuronaCapaOculta1 = new NumericUpDown();
            lblCapa2 = new Label();
            lblCapa1 = new Label();
            grbEvolutivo = new GroupBox();
            numIndividuos = new NumericUpDown();
            lblIndividuos = new Label();
            bgwProceso = new System.ComponentModel.BackgroundWorker();
            tabPrincipal.SuspendLayout();
            tabGenerar.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)splitContainer1).BeginInit();
            splitContainer1.Panel1.SuspendLayout();
            splitContainer1.Panel2.SuspendLayout();
            splitContainer1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)chartDatos).BeginInit();
            tabDatos.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dgDatos).BeginInit();
            tabConfiguracion.SuspendLayout();
            groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)numRegistros).BeginInit();
            ((System.ComponentModel.ISupportInitialize)numXfin).BeginInit();
            ((System.ComponentModel.ISupportInitialize)numXini).BeginInit();
            grbRed.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)numTotalRedes).BeginInit();
            ((System.ComponentModel.ISupportInitialize)numNeuronaCapaOculta2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)numNeuronaCapaOculta1).BeginInit();
            grbEvolutivo.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)numIndividuos).BeginInit();
            SuspendLayout();
            // 
            // tabPrincipal
            // 
            tabPrincipal.Controls.Add(tabGenerar);
            tabPrincipal.Controls.Add(tabDatos);
            tabPrincipal.Controls.Add(tabConfiguracion);
            tabPrincipal.Dock = DockStyle.Fill;
            tabPrincipal.Location = new Point(0, 0);
            tabPrincipal.Margin = new Padding(4);
            tabPrincipal.Name = "tabPrincipal";
            tabPrincipal.SelectedIndex = 0;
            tabPrincipal.Size = new Size(1331, 624);
            tabPrincipal.TabIndex = 0;
            // 
            // tabGenerar
            // 
            tabGenerar.Controls.Add(splitContainer1);
            tabGenerar.Location = new Point(4, 25);
            tabGenerar.Name = "tabGenerar";
            tabGenerar.Padding = new Padding(3);
            tabGenerar.Size = new Size(1323, 595);
            tabGenerar.TabIndex = 3;
            tabGenerar.Text = "Generación y Proceso";
            tabGenerar.UseVisualStyleBackColor = true;
            // 
            // splitContainer1
            // 
            splitContainer1.Dock = DockStyle.Fill;
            splitContainer1.Location = new Point(3, 3);
            splitContainer1.Name = "splitContainer1";
            // 
            // splitContainer1.Panel1
            // 
            splitContainer1.Panel1.Controls.Add(lblCiclos);
            splitContainer1.Panel1.Controls.Add(txtCiclo);
            splitContainer1.Panel1.Controls.Add(btnDetener);
            splitContainer1.Panel1.Controls.Add(btnProceso);
            splitContainer1.Panel1.Controls.Add(btnGenera);
            // 
            // splitContainer1.Panel2
            // 
            splitContainer1.Panel2.Controls.Add(chartDatos);
            splitContainer1.Size = new Size(1317, 589);
            splitContainer1.SplitterDistance = 158;
            splitContainer1.TabIndex = 0;
            // 
            // lblCiclos
            // 
            lblCiclos.AutoSize = true;
            lblCiclos.Location = new Point(10, 164);
            lblCiclos.Name = "lblCiclos";
            lblCiclos.Size = new Size(45, 16);
            lblCiclos.TabIndex = 32;
            lblCiclos.Text = "Ciclos";
            // 
            // txtCiclo
            // 
            txtCiclo.Location = new Point(10, 183);
            txtCiclo.Name = "txtCiclo";
            txtCiclo.ReadOnly = true;
            txtCiclo.Size = new Size(137, 23);
            txtCiclo.TabIndex = 31;
            txtCiclo.TextAlign = HorizontalAlignment.Right;
            // 
            // btnDetener
            // 
            btnDetener.Enabled = false;
            btnDetener.Location = new Point(4, 297);
            btnDetener.Name = "btnDetener";
            btnDetener.Size = new Size(143, 36);
            btnDetener.TabIndex = 30;
            btnDetener.Text = "Detener";
            btnDetener.UseVisualStyleBackColor = true;
            btnDetener.Click += btnDetener_Click;
            // 
            // btnProceso
            // 
            btnProceso.Enabled = false;
            btnProceso.Location = new Point(4, 68);
            btnProceso.Name = "btnProceso";
            btnProceso.Size = new Size(144, 39);
            btnProceso.TabIndex = 29;
            btnProceso.Text = "Procesar";
            btnProceso.UseVisualStyleBackColor = true;
            btnProceso.Click += btnProceso_Click;
            // 
            // btnGenera
            // 
            btnGenera.Location = new Point(5, 13);
            btnGenera.Name = "btnGenera";
            btnGenera.Size = new Size(143, 39);
            btnGenera.TabIndex = 28;
            btnGenera.Text = "Generar dataset";
            btnGenera.UseVisualStyleBackColor = true;
            btnGenera.Click += btnGenera_Click;
            // 
            // chartDatos
            // 
            chartArea1.Name = "ChartArea1";
            chartDatos.ChartAreas.Add(chartArea1);
            chartDatos.Dock = DockStyle.Fill;
            legend1.Name = "Legend1";
            chartDatos.Legends.Add(legend1);
            chartDatos.Location = new Point(0, 0);
            chartDatos.Name = "chartDatos";
            series1.ChartArea = "ChartArea1";
            series1.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
            series1.Font = new Font("Verdana", 8.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            series1.Legend = "Legend1";
            series1.Name = "Datos";
            series1.XValueType = System.Windows.Forms.DataVisualization.Charting.ChartValueType.Single;
            series1.YValueType = System.Windows.Forms.DataVisualization.Charting.ChartValueType.Single;
            series2.ChartArea = "ChartArea1";
            series2.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
            series2.Legend = "Legend1";
            series2.Name = "Red Neuronal";
            series3.ChartArea = "ChartArea1";
            series3.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
            series3.Legend = "Legend1";
            series3.Name = "Evolutivo";
            chartDatos.Series.Add(series1);
            chartDatos.Series.Add(series2);
            chartDatos.Series.Add(series3);
            chartDatos.Size = new Size(1155, 589);
            chartDatos.TabIndex = 12;
            // 
            // tabDatos
            // 
            tabDatos.Controls.Add(dgDatos);
            tabDatos.Location = new Point(4, 24);
            tabDatos.Margin = new Padding(4);
            tabDatos.Name = "tabDatos";
            tabDatos.Padding = new Padding(4);
            tabDatos.Size = new Size(1323, 596);
            tabDatos.TabIndex = 1;
            tabDatos.Text = "Datos y Resultados";
            tabDatos.UseVisualStyleBackColor = true;
            // 
            // dgDatos
            // 
            dgDatos.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgDatos.Columns.AddRange(new DataGridViewColumn[] { dataGridViewTextBoxColumn5, dataGridViewTextBoxColumn6, colEvolutivo, colDifEvolutivo, colRed, colDifRed });
            dgDatos.Dock = DockStyle.Fill;
            dgDatos.Location = new Point(4, 4);
            dgDatos.Name = "dgDatos";
            dgDatos.ReadOnly = true;
            dgDatos.Size = new Size(1315, 588);
            dgDatos.TabIndex = 11;
            // 
            // dataGridViewTextBoxColumn5
            // 
            dataGridViewTextBoxColumn5.HeaderText = "Entrada X";
            dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            dataGridViewTextBoxColumn5.ReadOnly = true;
            dataGridViewTextBoxColumn5.Width = 200;
            // 
            // dataGridViewTextBoxColumn6
            // 
            dataGridViewTextBoxColumn6.HeaderText = "Salida Esperada Y";
            dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            dataGridViewTextBoxColumn6.ReadOnly = true;
            dataGridViewTextBoxColumn6.Width = 200;
            // 
            // colEvolutivo
            // 
            colEvolutivo.HeaderText = "Algoritmo Evolutivo";
            colEvolutivo.Name = "colEvolutivo";
            colEvolutivo.ReadOnly = true;
            colEvolutivo.Width = 200;
            // 
            // colDifEvolutivo
            // 
            colDifEvolutivo.HeaderText = "Diferencia";
            colDifEvolutivo.Name = "colDifEvolutivo";
            colDifEvolutivo.ReadOnly = true;
            colDifEvolutivo.Width = 200;
            // 
            // colRed
            // 
            colRed.HeaderText = "Red Neuronal";
            colRed.Name = "colRed";
            colRed.ReadOnly = true;
            colRed.Width = 200;
            // 
            // colDifRed
            // 
            colDifRed.HeaderText = "Diferencia";
            colDifRed.Name = "colDifRed";
            colDifRed.ReadOnly = true;
            colDifRed.Width = 200;
            // 
            // tabConfiguracion
            // 
            tabConfiguracion.Controls.Add(groupBox1);
            tabConfiguracion.Controls.Add(grbRed);
            tabConfiguracion.Controls.Add(grbEvolutivo);
            tabConfiguracion.Location = new Point(4, 25);
            tabConfiguracion.Name = "tabConfiguracion";
            tabConfiguracion.Padding = new Padding(3);
            tabConfiguracion.Size = new Size(1323, 595);
            tabConfiguracion.TabIndex = 2;
            tabConfiguracion.Text = "Configuración";
            tabConfiguracion.UseVisualStyleBackColor = true;
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(numRegistros);
            groupBox1.Controls.Add(lblNumRegistros);
            groupBox1.Controls.Add(numXfin);
            groupBox1.Controls.Add(numXini);
            groupBox1.Controls.Add(lblXfin);
            groupBox1.Controls.Add(lblXini);
            groupBox1.Location = new Point(27, 6);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(351, 143);
            groupBox1.TabIndex = 25;
            groupBox1.TabStop = false;
            groupBox1.Text = "Generador de datos";
            // 
            // numRegistros
            // 
            numRegistros.Location = new Point(225, 99);
            numRegistros.Maximum = new decimal(new int[] { 1000, 0, 0, 0 });
            numRegistros.Minimum = new decimal(new int[] { 100, 0, 0, 0 });
            numRegistros.Name = "numRegistros";
            numRegistros.Size = new Size(120, 23);
            numRegistros.TabIndex = 24;
            numRegistros.TextAlign = HorizontalAlignment.Right;
            numRegistros.Value = new decimal(new int[] { 120, 0, 0, 0 });
            // 
            // lblNumRegistros
            // 
            lblNumRegistros.AutoSize = true;
            lblNumRegistros.Location = new Point(6, 101);
            lblNumRegistros.Name = "lblNumRegistros";
            lblNumRegistros.Size = new Size(207, 16);
            lblNumRegistros.TabIndex = 23;
            lblNumRegistros.Text = "Número de registros a generar";
            // 
            // numXfin
            // 
            numXfin.Location = new Point(225, 64);
            numXfin.Maximum = new decimal(new int[] { 1000, 0, 0, 0 });
            numXfin.Minimum = new decimal(new int[] { 1000, 0, 0, int.MinValue });
            numXfin.Name = "numXfin";
            numXfin.Size = new Size(120, 23);
            numXfin.TabIndex = 22;
            numXfin.TextAlign = HorizontalAlignment.Right;
            numXfin.Value = new decimal(new int[] { 720, 0, 0, 0 });
            // 
            // numXini
            // 
            numXini.Location = new Point(225, 33);
            numXini.Maximum = new decimal(new int[] { 1000, 0, 0, 0 });
            numXini.Minimum = new decimal(new int[] { 1000, 0, 0, int.MinValue });
            numXini.Name = "numXini";
            numXini.Size = new Size(120, 23);
            numXini.TabIndex = 19;
            numXini.TextAlign = HorizontalAlignment.Right;
            numXini.Value = new decimal(new int[] { 720, 0, 0, int.MinValue });
            // 
            // lblXfin
            // 
            lblXfin.AutoSize = true;
            lblXfin.Location = new Point(6, 71);
            lblXfin.Name = "lblXfin";
            lblXfin.Size = new Size(127, 16);
            lblXfin.TabIndex = 18;
            lblXfin.Text = "Valor máximo de X";
            // 
            // lblXini
            // 
            lblXini.AutoSize = true;
            lblXini.Location = new Point(6, 35);
            lblXini.Name = "lblXini";
            lblXini.Size = new Size(123, 16);
            lblXini.TabIndex = 17;
            lblXini.Text = "Valor mínimo de X";
            // 
            // grbRed
            // 
            grbRed.Controls.Add(numTotalRedes);
            grbRed.Controls.Add(lblRedes);
            grbRed.Controls.Add(numNeuronaCapaOculta2);
            grbRed.Controls.Add(numNeuronaCapaOculta1);
            grbRed.Controls.Add(lblCapa2);
            grbRed.Controls.Add(lblCapa1);
            grbRed.Location = new Point(27, 261);
            grbRed.Name = "grbRed";
            grbRed.Size = new Size(351, 127);
            grbRed.TabIndex = 22;
            grbRed.TabStop = false;
            grbRed.Text = "Red Neuronal";
            // 
            // numTotalRedes
            // 
            numTotalRedes.Location = new Point(225, 27);
            numTotalRedes.Maximum = new decimal(new int[] { 2000, 0, 0, 0 });
            numTotalRedes.Minimum = new decimal(new int[] { 3, 0, 0, 0 });
            numTotalRedes.Name = "numTotalRedes";
            numTotalRedes.Size = new Size(120, 23);
            numTotalRedes.TabIndex = 16;
            numTotalRedes.TextAlign = HorizontalAlignment.Right;
            numTotalRedes.Value = new decimal(new int[] { 3, 0, 0, 0 });
            // 
            // lblRedes
            // 
            lblRedes.AutoSize = true;
            lblRedes.Location = new Point(6, 34);
            lblRedes.Name = "lblRedes";
            lblRedes.Size = new Size(87, 16);
            lblRedes.TabIndex = 16;
            lblRedes.Text = "Total redes:";
            // 
            // numNeuronaCapaOculta2
            // 
            numNeuronaCapaOculta2.Location = new Point(225, 87);
            numNeuronaCapaOculta2.Minimum = new decimal(new int[] { 1, 0, 0, 0 });
            numNeuronaCapaOculta2.Name = "numNeuronaCapaOculta2";
            numNeuronaCapaOculta2.Size = new Size(120, 23);
            numNeuronaCapaOculta2.TabIndex = 22;
            numNeuronaCapaOculta2.TextAlign = HorizontalAlignment.Right;
            numNeuronaCapaOculta2.Value = new decimal(new int[] { 5, 0, 0, 0 });
            // 
            // numNeuronaCapaOculta1
            // 
            numNeuronaCapaOculta1.Location = new Point(225, 58);
            numNeuronaCapaOculta1.Minimum = new decimal(new int[] { 1, 0, 0, 0 });
            numNeuronaCapaOculta1.Name = "numNeuronaCapaOculta1";
            numNeuronaCapaOculta1.Size = new Size(120, 23);
            numNeuronaCapaOculta1.TabIndex = 19;
            numNeuronaCapaOculta1.TextAlign = HorizontalAlignment.Right;
            numNeuronaCapaOculta1.Value = new decimal(new int[] { 5, 0, 0, 0 });
            // 
            // lblCapa2
            // 
            lblCapa2.AutoSize = true;
            lblCapa2.Location = new Point(6, 87);
            lblCapa2.Name = "lblCapa2";
            lblCapa2.Size = new Size(191, 16);
            lblCapa2.TabIndex = 18;
            lblCapa2.Text = "Neuronas en capa oculta 2:";
            // 
            // lblCapa1
            // 
            lblCapa1.AutoSize = true;
            lblCapa1.Location = new Point(6, 58);
            lblCapa1.Name = "lblCapa1";
            lblCapa1.Size = new Size(191, 16);
            lblCapa1.TabIndex = 17;
            lblCapa1.Text = "Neuronas en capa oculta 1:";
            // 
            // grbEvolutivo
            // 
            grbEvolutivo.Controls.Add(numIndividuos);
            grbEvolutivo.Controls.Add(lblIndividuos);
            grbEvolutivo.Location = new Point(27, 167);
            grbEvolutivo.Name = "grbEvolutivo";
            grbEvolutivo.Size = new Size(351, 71);
            grbEvolutivo.TabIndex = 21;
            grbEvolutivo.TabStop = false;
            grbEvolutivo.Text = "Algoritmo Evolutivo";
            // 
            // numIndividuos
            // 
            numIndividuos.Location = new Point(225, 26);
            numIndividuos.Maximum = new decimal(new int[] { 2000, 0, 0, 0 });
            numIndividuos.Minimum = new decimal(new int[] { 10, 0, 0, 0 });
            numIndividuos.Name = "numIndividuos";
            numIndividuos.Size = new Size(120, 23);
            numIndividuos.TabIndex = 15;
            numIndividuos.TextAlign = HorizontalAlignment.Right;
            numIndividuos.Value = new decimal(new int[] { 300, 0, 0, 0 });
            // 
            // lblIndividuos
            // 
            lblIndividuos.AutoSize = true;
            lblIndividuos.Location = new Point(6, 33);
            lblIndividuos.Name = "lblIndividuos";
            lblIndividuos.Size = new Size(115, 16);
            lblIndividuos.TabIndex = 14;
            lblIndividuos.Text = "Total individuos:";
            // 
            // bgwProceso
            // 
            bgwProceso.WorkerReportsProgress = true;
            bgwProceso.DoWork += Proceso;
            bgwProceso.ProgressChanged += bgwProceso_ProgressChanged;
            bgwProceso.RunWorkerCompleted += bgwProceso_RunWorkerCompleted;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 16F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1331, 624);
            Controls.Add(tabPrincipal);
            Font = new Font("Verdana", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            Margin = new Padding(4);
            Name = "Form1";
            Text = "Colaborar 29. Algoritmo Evolutivo vs Red Neuronal. Abril de 2024.";
            tabPrincipal.ResumeLayout(false);
            tabGenerar.ResumeLayout(false);
            splitContainer1.Panel1.ResumeLayout(false);
            splitContainer1.Panel1.PerformLayout();
            splitContainer1.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)splitContainer1).EndInit();
            splitContainer1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)chartDatos).EndInit();
            tabDatos.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)dgDatos).EndInit();
            tabConfiguracion.ResumeLayout(false);
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)numRegistros).EndInit();
            ((System.ComponentModel.ISupportInitialize)numXfin).EndInit();
            ((System.ComponentModel.ISupportInitialize)numXini).EndInit();
            grbRed.ResumeLayout(false);
            grbRed.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)numTotalRedes).EndInit();
            ((System.ComponentModel.ISupportInitialize)numNeuronaCapaOculta2).EndInit();
            ((System.ComponentModel.ISupportInitialize)numNeuronaCapaOculta1).EndInit();
            grbEvolutivo.ResumeLayout(false);
            grbEvolutivo.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)numIndividuos).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private System.Windows.Forms.TabControl tabPrincipal;
        private System.Windows.Forms.TabPage tabDatos;
        private System.Windows.Forms.DataGridView dgDatos;
        private System.Windows.Forms.TabPage tabConfiguracion;
        private System.Windows.Forms.GroupBox grbRed;
        private System.Windows.Forms.NumericUpDown numNeuronaCapaOculta2;
        private System.Windows.Forms.NumericUpDown numNeuronaCapaOculta1;
        private System.Windows.Forms.Label lblCapa2;
        private System.Windows.Forms.Label lblCapa1;
        private System.Windows.Forms.GroupBox grbEvolutivo;
        private System.Windows.Forms.NumericUpDown numIndividuos;
        private System.Windows.Forms.Label lblIndividuos;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.NumericUpDown numRegistros;
        private System.Windows.Forms.Label lblNumRegistros;
        private System.Windows.Forms.NumericUpDown numXfin;
        private System.Windows.Forms.NumericUpDown numXini;
        private System.Windows.Forms.Label lblXfin;
        private System.Windows.Forms.Label lblXini;
        private System.ComponentModel.BackgroundWorker bgwProceso;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private System.Windows.Forms.DataGridViewTextBoxColumn colEvolutivo;
        private System.Windows.Forms.DataGridViewTextBoxColumn colDifEvolutivo;
        private System.Windows.Forms.DataGridViewTextBoxColumn colRed;
        private System.Windows.Forms.DataGridViewTextBoxColumn colDifRed;
        private System.Windows.Forms.NumericUpDown numTotalRedes;
        private System.Windows.Forms.Label lblRedes;
        private System.Windows.Forms.TabPage tabGenerar;
        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.TextBox txtCiclo;
        private System.Windows.Forms.Button btnDetener;
        private System.Windows.Forms.Button btnProceso;
        private System.Windows.Forms.Button btnGenera;
        private System.Windows.Forms.DataVisualization.Charting.Chart chartDatos;
        private Label lblCiclos;
    }
}

