﻿/* Autor: Rafael Alberto Moreno Parra
 * Fecha: 11 de abril de 2024
 */
namespace Colaborar29 {
    internal class Redes {
        List<Perceptron> Perceptrones;
        double MejorRedAjuste;
        int MejorRedNeuronal;

        public Redes(Random Azar, int TotalPerceptrones, int NeuronasCapaOculta1, int NeuronasCapaOculta2) {
            Perceptrones = new List<Perceptron>();

            //Configurando los perceptrones
            int NumeroEntradas = 1; //Número de entradas
            int TotalNeuronasCapaOculta1 = NeuronasCapaOculta1;
            int TotalNeuronasCapaOculta2 = NeuronasCapaOculta2;
            int TotalNeuronasCapaSalida = 1; //Total neuronas en la capa de salida

            for (int Contador = 0; Contador < TotalPerceptrones; Contador++)
                Perceptrones.Add(new Perceptron(Azar, NumeroEntradas, TotalNeuronasCapaOculta1, TotalNeuronasCapaOculta2, TotalNeuronasCapaSalida));
        }

        public void Proceso(GeneradorDatos ConjuntoDatos){
            double[] EntradaRed = new double[1]; //Estas serán las entradas al perceptrón
            double[] SalidaRedEsperada = new double[1]; //Estas serán las salidas externas al perceptrón

            for (int Num = 0; Num < ConjuntoDatos.Salidas.Length; Num++) {
                //Entradas y salidas esperadas
                EntradaRed[0] = ConjuntoDatos.Entradas[Num];
                SalidaRedEsperada[0] = ConjuntoDatos.Salidas[Num];

                //Va de perceptrón en perceptrón
                for (int Contador = 0; Contador < Perceptrones.Count; Contador++) {

                    //Primero calcula la salida del perceptrón con esas entradas
                    Perceptrones[Contador].CalculaSalidaRed(EntradaRed);

                    //Luego entrena el perceptrón para ajustar los pesos y umbrales
                    Perceptrones[Contador].Entrena(EntradaRed, SalidaRedEsperada);
                }
            }
        }

        public void ObtenerMejorRedNeuronal(GeneradorDatos ConjuntoDatos) {
            //Se evalúa cada red neuronal con los datos de validación.
            //La que se acerque más a esos datos es la que se muestra.
            MejorRedAjuste = double.MaxValue;
            MejorRedNeuronal = -1;
            for (int Cont = 0; Cont < Perceptrones.Count; Cont++) {
                double AjusteRed = Perceptrones[Cont].Ajuste(ConjuntoDatos.ValidaEntra, ConjuntoDatos.ValidaSale);
                if (AjusteRed < MejorRedAjuste) {
                    MejorRedAjuste = AjusteRed;
                    MejorRedNeuronal = Cont;
                }
            }
        }

        public double MejorRed(double DatoEntra) {
            double[] Entradas = [DatoEntra];
            Perceptrones[MejorRedNeuronal].CalculaSalidaRed(Entradas);
            return Perceptrones[MejorRedNeuronal].Capas[2].Salidas[0];
        }
    }
}
