﻿/* Autor: Rafael Alberto Moreno Parra
 * Fecha: 11 de abril de 2024
 * 
 * En el anterior programa se desarrolló un software gráfico que compara un algoritmo evolutivo contra una red neuronal (perceptrón multicapa). A partir de allí hubo varios cambios:
 * 1. Se mejora el algoritmo evolutivo, en vez de una larga ecuación polinómica dentro de la operación trigonométrica seno, ahora es la sumatoria de varias operaciones trigonométricas seno y su posterior normalización. Además se retira el concepto de competencia y ahora es un conjunto de individuos que van mejorando su ajuste poco a poco.
 * 2. Se mejora la interfaz gráfica, haciéndola más sencilla de entender y controlar.
 * 3. Si se maximiza la ventana, el gráfico estadístico también se maximiza.
 * Modo de operación:
 *  1. El botón "Generar dataset" lo que hace es generar una serie de datos de entrenamiento y una serie de datos de validación. Esos datos nacen de una función generada al azar.
 *  2. El botón de "Procesar" lanza un hilo de ejecución que ejecuta la red neuronal y el algoritmo evolutivo. Una vez lanzado, es dejar pasar el tiempo, el programa va mostrando los ciclos. Entre más tiempo se deje ejecutar el programa mejor.
 *  3. El botón "Detener" lo que hace es finalizar el proceso inmediatamente.
 * Una vez se detiene el proceso, se muestra por pantalla las curvas obtenidas por ambos procedimientos. Se muestra la mejor red neuronal que se ajuste a los datos de validación, sucede lo mismo con el algoritmo evolutivo.
 * 
 *  Este nuevo programa ha generado una bifurcación en el desarrollo de esta investigación sobre colaboración. En una rama se seguirá desarrollando como herramienta de análisis de datos tanto el algoritmo evolutivo como la red neuronal (para una investigación que sigo en la universidad). La segunda rama, propiamente de vida artificial, se enfocará en el algoritmo evolutivo (se abandona la red neuronal) y los comportamientos cíclicos de los ambientes, algo que no estaba contemplado previamente. 
 */

namespace Colaborar29 {
    internal class GeneradorDatos {
        //Coeficientes de la ecuación generada
        public double[] Coef = new double[10 * 3];

        //Almacena los valores de la variable independiente (entrada)
        public double[] Entradas;

        //Almacena los valores de la variable dependiente (salida) 
        public double[] Salidas;

        //Para los valores de validación
        public double[] ValidaEntra;
        public double[] ValidaSale;

        //Genera la ecuación 
        public void GeneraEcuacion(Random Azar, double ValorXini, double ValorXfin, int NumRegistros) {
            Entradas = new double[NumRegistros];
            Salidas = new double[NumRegistros];
            ValidaEntra = new double[NumRegistros];
            ValidaSale = new double[NumRegistros];

            for (int Cont = 0; Cont < Coef.Length; Cont++)
                Coef[Cont] = Azar.NextDouble() * 2 - 1;

            double MinimoX = double.MaxValue;
            double MaximoX = double.MinValue;
            double MinimoY = double.MaxValue;
            double MaximoY = double.MinValue;

            for (int Contador = 0; Contador < NumRegistros; Contador++) {

                //Datos del entrenamiento
                double valX = (Azar.NextDouble() * (ValorXfin - ValorXini)) + ValorXini;
                double valY = Evaluar(valX);
                Entradas[Contador] = valX;
                Salidas[Contador] = valY;

                //Para normalizar
                if (valX < MinimoX) MinimoX = valX;
                if (valX > MaximoX) MaximoX = valX;
                if (valY < MinimoY) MinimoY = valY;
                if (valY > MaximoY) MaximoY = valY;

                //Datos para validación de sobre ajuste
                valX = (Azar.NextDouble() * (ValorXfin - ValorXini)) + ValorXini;
                valY = Evaluar(valX);
                ValidaEntra[Contador] = valX;
                ValidaSale[Contador] = valY;

                //Para normalizar
                if (valX < MinimoX) MinimoX = valX;
                if (valX > MaximoX) MaximoX = valX;
                if (valY < MinimoY) MinimoY = valY;
                if (valY > MaximoY) MaximoY = valY;
            }

            //Ordena los valores
            Ordenar(Entradas, Salidas);
            Ordenar(ValidaEntra, ValidaSale);

            //Normaliza los valores de entrenamiento y validación
            for (int Contador = 0; Contador < NumRegistros; Contador++) {
                Entradas[Contador] = (Entradas[Contador] - MinimoX) / (MaximoX - MinimoX);
                Salidas[Contador] = (Salidas[Contador] - MinimoY) / (MaximoY - MinimoY);

                ValidaEntra[Contador] = (ValidaEntra[Contador] - MinimoX) / (MaximoX - MinimoX);
                ValidaSale[Contador] = (ValidaSale[Contador] - MinimoY) / (MaximoY - MinimoY);
            }
        }

        //Genera los datos
        public double Evaluar(double X) {
            double Y = 0;
            for (int Cont = 0; Cont < Coef.Length; Cont += 3)
                Y += Coef[Cont] * Math.Sin((Coef[Cont + 1] * X + Coef[Cont + 2]) * Math.PI / 180);
            return Y;
        }

        //Ordenamiento por Shell
        static void Ordenar(double[] Entrada, double[] Salida) {
            int N = Entrada.Length;
            int incremento = N;
            do {
                incremento /= 2;
                for (int k = 0; k < incremento; k++) {
                    for (int i = incremento + k; i < N; i += incremento) {
                        int j = i;
                        while (j - incremento >= 0 && Entrada[j] < Entrada[j - incremento]) {
                            double tmp = Entrada[j];
                            Entrada[j] = Entrada[j - incremento];
                            Entrada[j - incremento] = tmp;

                            tmp = Salida[j];
                            Salida[j] = Salida[j - incremento];
                            Salida[j - incremento] = tmp;

                            j -= incremento;
                        }
                    }
                }
            } while (incremento > 1);
        }
    }
}
