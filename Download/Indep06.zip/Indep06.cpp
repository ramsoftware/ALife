/*

Autor:		Rafael Alberto Moreno Parra
URL:		http://www.geocities.com/krousky
Clase:		Independencia 06: Un nuevo generador de numeros aleatorios
Lenguaje:	C++
Fecha:		04 de Agosto de 2002

*/

#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <string.h>

#include "Inicializa.h"
#include "MedioAmbiente.h"
#include "Organismo.h"
#include "MasApto.h"

void main()
{
    unsigned int iAlgoritmo; //Contador de algoritmos a probar
	unsigned int iRefrescaSemilla=0; //Contador de las semillas 
	unsigned int iEvalAmbiente=0; // "Tama�o" del ambiente
	unsigned int iInstruccion; //Mantiene en que parte se esta evaluando el algoritmo gen�tico
	unsigned int iFuncion=0; //Que funcion ejecuta el organismo
	unsigned int iIniVar; //Para inicializar variables.
	unsigned int iCopia; 
	int iError;
	float fMargenError;
	char sbADN[7000];

    Inicializa objInicializa; //Lee el archivo de inicializaci�n
	MedioAmbiente objAmbiente; //El ambiente
	Organismo objOrg;  //El Algoritmo ("Organismo") a evaluar.
	MasApto objMasApto; //Algoritmo Mas Apto

	objInicializa.vPantallaIni(); //Pantalla de Inicio
	iError = objInicializa.vLeeArchivoIni(); //Archivo de Inicializaci�n
	if (iError == -1)
	{
		printf("Un error ocurri� al inicializar la simulaci�n\n");
		return;
	}

	objAmbiente.vDeshaceIO(objInicializa.stDatVA.sEntrada, 1); //Ambiente de Entrada
	objAmbiente.vDeshaceIO(objInicializa.stDatVA.sSalidas, 2); //Ambiente de Salida

	objOrg.vInicio(true,
		objInicializa.stDatVA.iNumInstMin,
		objInicializa.stDatVA.iNumInstMax,
		objInicializa.stDatVA.iTotalFun,
		objInicializa.stDatVA.iTotalVar,
		objInicializa.stDatVA.iNumCiclos,
		objInicializa.stDatVA.iProbabIF,
		objInicializa.stDatVA.iProbabFN,
		objInicializa.stDatVA.iProbaVar);

	objMasApto.fMargenError = (float) 9999999; //Inicializa el mas apto
	objInicializa.vArchResult(); //Encabezado archivo de resultados

	//============================================================
	//Primero: Algoritmos Gen�ticos al azar
	//============================================================
	for (iAlgoritmo = 1; iAlgoritmo < objInicializa.stDatVA.iTotalAzar; iAlgoritmo++)
	{
		//Crea el algoritmo genetico
		objOrg.vCreaADN();

		//Evalua el organismo en el ambiente
		fMargenError = 0;
		for (iEvalAmbiente=0; iEvalAmbiente<objAmbiente.m_iContEntra; iEvalAmbiente++)
		{
			//Inicializa el algoritmo genetico
			iInstruccion = 1;
			for (iIniVar=1; iIniVar<=objInicializa.stDatVA.iTotalVar*2; iIniVar++)
				objOrg.fVariable[iIniVar] = 0;
			
			//Coloca una variable como valor de entrada
			objOrg.fVariable[1] = (float) objAmbiente.m_iEntradas[iEvalAmbiente];
			if (objOrg.fEvalOrganismo(&iInstruccion, &iFuncion) == -1)
			{
				fMargenError = (float) 9999999;
				break;
			}
			fMargenError = fMargenError + fabs( (float) objAmbiente.m_iSalidas[iEvalAmbiente] - objOrg.fVariable[2]);
			if (fMargenError > 100000 ) break;
		}

		if (fMargenError < objMasApto.fMargenError)
		{
			objMasApto.fMargenError = fMargenError;

			for (iCopia=1; iCopia <= objOrg.m_iMaxGenOrg; iCopia++)
			{
				objMasApto.m_oTriplete[iCopia].bEjecuta = objOrg.m_oTriplete[iCopia].bEjecuta;
				objMasApto.m_oTriplete[iCopia].bEsVariable1 = objOrg.m_oTriplete[iCopia].bEsVariable1;
				objMasApto.m_oTriplete[iCopia].bEsVariable2 = objOrg.m_oTriplete[iCopia].bEsVariable2;
				objMasApto.m_oTriplete[iCopia].iGotoLabel = objOrg.m_oTriplete[iCopia].iGotoLabel;
				objMasApto.m_oTriplete[iCopia].iInstruccion = objOrg.m_oTriplete[iCopia].iInstruccion;
				objMasApto.m_oTriplete[iCopia].cOperador = objOrg.m_oTriplete[iCopia].cOperador;
				objMasApto.m_oTriplete[iCopia].iOperando1 = objOrg.m_oTriplete[iCopia].iOperando1;
				objMasApto.m_oTriplete[iCopia].iOperando2 = objOrg.m_oTriplete[iCopia].iOperando2;
				objMasApto.m_oTriplete[iCopia].iVariable = objOrg.m_oTriplete[iCopia].iVariable;
			}
			objMasApto.m_iMaxGenOrg = objOrg.m_iMaxGenOrg;
                    
			//Escribe el resultado a archivo
	        objOrg.sDisplayADN(sbADN);
			objInicializa.vGrabaAlgoritmos(iAlgoritmo, fMargenError, sbADN);
		}
	}

	//============================================================
	//Segundo: Mutaciones de Algoritmos Gen�ticos al azar
	//============================================================
	strcpy(sbADN, "====== Mutando el mejor Algoritmo Gen�tico ======");
	objInicializa.vGrabaLinea(sbADN);

	objOrg.m_iMaxGenOrg = objMasApto.m_iMaxGenOrg;
	for (iAlgoritmo = 1; iAlgoritmo < objInicializa.stDatVA.iTotalMutar; iAlgoritmo++)
	{
		
        //Restaura copia del mejor algoritmo gen�tico y lo muta
		for (iCopia=1; iCopia <= objOrg.m_iMaxGenOrg; iCopia++)
		{
			objOrg.m_oTriplete[iCopia].bEjecuta = objMasApto.m_oTriplete[iCopia].bEjecuta;
			objOrg.m_oTriplete[iCopia].bEsVariable1 = objMasApto.m_oTriplete[iCopia].bEsVariable1;
			objOrg.m_oTriplete[iCopia].bEsVariable2 = objMasApto.m_oTriplete[iCopia].bEsVariable2;
			objOrg.m_oTriplete[iCopia].iGotoLabel = objMasApto.m_oTriplete[iCopia].iGotoLabel;
			objOrg.m_oTriplete[iCopia].iInstruccion = objMasApto.m_oTriplete[iCopia].iInstruccion;
			objOrg.m_oTriplete[iCopia].cOperador = objMasApto.m_oTriplete[iCopia].cOperador;
			objOrg.m_oTriplete[iCopia].iOperando1 = objMasApto.m_oTriplete[iCopia].iOperando1;
			objOrg.m_oTriplete[iCopia].iOperando2 = objMasApto.m_oTriplete[iCopia].iOperando2;
			objOrg.m_oTriplete[iCopia].iVariable = objMasApto.m_oTriplete[iCopia].iVariable;
		}
		objOrg.vMutaGen();

		//Evalua el organismo en el ambiente
		fMargenError = 0;
		for (iEvalAmbiente=0; iEvalAmbiente<objAmbiente.m_iContEntra; iEvalAmbiente++)
		{
			//Inicializa el algoritmo genetico
			iInstruccion = 1;
			for (iIniVar=1; iIniVar<=objInicializa.stDatVA.iTotalVar*2; iIniVar++)
				objOrg.fVariable[iIniVar] = 0;
			
			//Coloca una variable como valor de entrada
			objOrg.fVariable[1] = (float) objAmbiente.m_iEntradas[iEvalAmbiente];
			if (objOrg.fEvalOrganismo(&iInstruccion, &iFuncion) == -1)
			{
				fMargenError = (float) 9999999;
				break;
			}
			fMargenError = fMargenError + fabs( (float) objAmbiente.m_iSalidas[iEvalAmbiente] - objOrg.fVariable[2]);
			if (fMargenError > 100000 ) break;
		}

		if (fMargenError < objMasApto.fMargenError)
		{
			objMasApto.fMargenError = fMargenError;

			for (iCopia=1; iCopia <= objOrg.m_iMaxGenOrg; iCopia++)
			{
				objMasApto.m_oTriplete[iCopia].bEjecuta = objOrg.m_oTriplete[iCopia].bEjecuta;
				objMasApto.m_oTriplete[iCopia].bEsVariable1 = objOrg.m_oTriplete[iCopia].bEsVariable1;
				objMasApto.m_oTriplete[iCopia].bEsVariable2 = objOrg.m_oTriplete[iCopia].bEsVariable2;
				objMasApto.m_oTriplete[iCopia].iGotoLabel = objOrg.m_oTriplete[iCopia].iGotoLabel;
				objMasApto.m_oTriplete[iCopia].iInstruccion = objOrg.m_oTriplete[iCopia].iInstruccion;
				objMasApto.m_oTriplete[iCopia].cOperador = objOrg.m_oTriplete[iCopia].cOperador;
				objMasApto.m_oTriplete[iCopia].iOperando1 = objOrg.m_oTriplete[iCopia].iOperando1;
				objMasApto.m_oTriplete[iCopia].iOperando2 = objOrg.m_oTriplete[iCopia].iOperando2;
				objMasApto.m_oTriplete[iCopia].iVariable = objOrg.m_oTriplete[iCopia].iVariable;
			}
			objMasApto.m_iMaxGenOrg = objOrg.m_iMaxGenOrg;
                    
			//Escribe el resultado a archivo
	        objOrg.sDisplayADN(sbADN);
			objInicializa.vGrabaAlgoritmos(iAlgoritmo, fMargenError, sbADN);
		}
	}
	objInicializa.vFinalSimulacion();
}
