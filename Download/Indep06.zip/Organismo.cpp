/* Clase Organismo

Exones: son las porciones de ADN con un c�digo funcional.
Se ha argumentado que los exones podr�an ser antiguos "minigenes"
que en un principio codificaban peque�as secuencias funcionales
de amino�cidos. Seg�n esta hip�tesis, las prote�nas modernas
habr�an surgido por agregaci�n de varias de estas secuencias
amino�cidos.

Intrones: En muchos organismos, una cantidad sorprendentemente grande
del ADN no parece intervenir activamente en la codificaci�n de
proteinas. Esta proporci�n var�a seg�n las especies: por ejemplo del 
9% al 27% en humanos, 75% en nematodos, 67% en moscas de la fruta,
99% en peces pulmonados. Parte de este ADN no codificador esta formado
por intrones.

Esta clase representar�a un exon o intron porque es en si una
instrucci�n completa del algoritmo gen�tico.

En el ADN de cualquier ser vivo se encuentra cuatro(4) tipos de bases
nitrogenadas que forman los nucle�tidos:
Adenina (A)
Timina (T)
Citosina (C)
Guanina (G)

Cada pelda�o de la escalera del ADN esta formado por la uni�n de dos
bases, la pareja es as�:
Adenina con Timina
Citosina con Guanina

Los nucle�tidos A, T, C, G son como las letras de un alfabeto gen�tico,
con el que se ha elaborado un lenguaje para la informaci�n gen�tica.
Este lenguaje esta formado exclusivamente por tres palabras de tres
letras: AAA, CGT, TCC, etc.. Esto es lo que se conoce como c�digo de
tripletes. En �ltimo t�rmino, cada uno de estos tripletes equivale,
en t�rminos de producci�n, a un amino�cido concreto. Los amino�cidos
son las unidades estructurales de las prote�nas; las prote�nas forman
el cuerpo de los organismos, y tambi�n son prote�nas las enzimas y
hormonas responsables de su funcionamiento.

Autor:		Rafael Alberto Moreno Parra
URL:		http://www.geocities.com/krousky
Clase:		Organismo
Lenguaje:	C++
Fecha:		01 de Julio de 2002

*/

#include "Organismo.h"
#include <string.h>
#include <stdio.h>
#include <math.h>


//Constructor
Organismo::Organismo()
{
	time_t ltime1;
	time(&ltime1);
	objAzar.sgenrand(ltime1);
}


//Inicializa la semilla dependiendo del tiempo
void Organismo::IniciaSemilla(unsigned long int iSemilla)
{
	if (iSemilla == 0)
	{
		time_t ltime1;	
		time(&ltime1);
		objAzar.sgenrand(ltime1);
	}
	else
		objAzar.sgenrand(iSemilla);
}


//Inicializa las variables del Organismo
void Organismo::vInicio (bool bGenRandom,
			  unsigned int iMinInstr,
			  unsigned int iMaxInstr,
                  unsigned int iTotalFuncion,
				  unsigned int iTotalVariables,
  				  unsigned int iMaxiCiclos,
				  unsigned int iProbabIF,
				  unsigned int iProbabFN,
				  unsigned int iProbaVar)
{
	m_bGenRandom = bGenRandom; //N�mero de Genes fijos o aleatorio
	m_iMinInstr = iMinInstr;
	m_iMaxInstr = iMaxInstr;
    m_iTotalFuncion = iTotalFuncion;
	m_iTotalVariables = iTotalVariables;
  	m_iMaxiCiclos = iMaxiCiclos;
	m_iProbabIF = iProbabIF;
	m_iProbabFN = iProbabFN;
	m_iProbaVar = iProbaVar;
}

// Crea el organismo, llamando la funci�n que hace sus genes
void Organismo::vCreaADN ()
{
    unsigned int iCont;

	if(m_bGenRandom)
		m_iMaxGenOrg = objAzar.genrand() % (m_iMaxInstr-m_iMinInstr) + m_iMinInstr + 1; //Crea organismos entre iMinInstr y iMaxInstr instrucciones
	else
		m_iMaxGenOrg = m_iMaxInstr;

    for (iCont=1; iCont<=m_iMaxGenOrg; iCont++)
		vHaceGen(iCont);

	for (iCont=1; iCont <= m_iTotalVariables*2; iCont++)
		fVariable[iCont] = 0;
};

// Crea la instrucci�n (que llam� triplete)
void Organismo::vHaceGen(unsigned int iLabel)
{
    unsigned int iAleatorio, iCondicIF;

	//Por defecto, nunca se ha ejecutado esta instruccion
    m_oTriplete[iLabel].bEjecuta = false;
       
    /* Asignacion = 0 
	IF MAYOR = 1
	IF MENOR = 2
	IF IGUAL = 3
	IF DIFER = 4
	Funcion = 5....n
	*/
	iAleatorio = objAzar.genrand() % 100;
	if (iAleatorio < m_iProbabIF)  // de 0 a ProbIF es un IF
	{
		m_oTriplete[iLabel].iInstruccion = objAzar.genrand() % 4 + 1; //Un IF
		iCondicIF = 1;
	}
	else if (iAleatorio < (m_iProbabIF+m_iProbabFN) ) //Una funcion
	{
		m_oTriplete[iLabel].iInstruccion = objAzar.genrand() % m_iTotalFuncion + 5;
		iCondicIF = 0;
	}
	else //Un SET o Asignaci�n
	{
		m_oTriplete[iLabel].iInstruccion = 0;
		iCondicIF = 0;
	}

	//Variable a asignar o comparar
	m_oTriplete[iLabel].iVariable = objAzar.genrand() % m_iTotalVariables + 1;

	//Operando 1 (se escoge entre una variable o un numero)
	iAleatorio = objAzar.genrand() % 100; //Entre 0 y 9
	if (iAleatorio < m_iProbaVar)
	{
		m_oTriplete[iLabel].bEsVariable1 = true;
		if (iCondicIF == 1)
		{
			do //Si hay un condicional, no se debe comparar consigo misma
			{
				m_oTriplete[iLabel].iOperando1 = objAzar.genrand() % m_iTotalVariables + 1;
			} while (m_oTriplete[iLabel].iOperando1 == m_oTriplete[iLabel].iVariable);
		}
		else
		{
			m_oTriplete[iLabel].iOperando1 = objAzar.genrand() % m_iTotalVariables + 1;
		}

	}
	else
	{
		m_oTriplete[iLabel].bEsVariable1 = false;
		m_oTriplete[iLabel].iOperando1 = objAzar.genrand() % 100 + 1;
	}

	//Operando 2 (se escoge entre una variable o un numero)
	iAleatorio = objAzar.genrand() % 100; //Entre 0 y 9
	if (iAleatorio < m_iProbaVar)
	{
		m_oTriplete[iLabel].bEsVariable2 = true;
		if (iCondicIF == 1)
		{
			do //Si hay un condicional, no se debe comparar consigo misma
			{
				m_oTriplete[iLabel].iOperando2 = objAzar.genrand() % m_iTotalVariables + 1;
			} while (m_oTriplete[iLabel].iOperando2 == m_oTriplete[iLabel].iVariable);
		}
		else
		{
			m_oTriplete[iLabel].iOperando2 = objAzar.genrand() % m_iTotalVariables + 1;
		}
	}
	else
	{
		m_oTriplete[iLabel].bEsVariable2 = false;
		m_oTriplete[iLabel].iOperando2 = objAzar.genrand() % 100 + 1;
	}

	//Operador
	iAleatorio = objAzar.genrand() % 5;
	switch(iAleatorio)
	{
		case 0: m_oTriplete[iLabel].cOperador = '+'; break;
		case 1: m_oTriplete[iLabel].cOperador = '-'; break;
		case 2: m_oTriplete[iLabel].cOperador = '*'; break;
		case 3: m_oTriplete[iLabel].cOperador = '/'; break;
		case 4: m_oTriplete[iLabel].cOperador = '%'; break;
	}

    //Decide hacia que label va (entre 1 y MaxGenes) o si es el FIN, el resultado siempre sera Y
    unsigned int iNumCiclo;
	do
	{
		iNumCiclo = objAzar.genrand() % (m_iMaxGenOrg+1);
	} while (iNumCiclo==iLabel); //Evita el goto hacia la misma instruccion
    m_oTriplete[iLabel].iGotoLabel = iNumCiclo; //Retorna 0 para FINalizar

};

//Muta solo una instrucci�n del Organismo
void Organismo::vMutaGen()
{
	unsigned int iAleatorio;
	iAleatorio = objAzar.genrand() % m_iMaxGenOrg + 1;
    vHaceGen(iAleatorio);
}

//Despliega el organismo como si fuera c�digo Java
void Organismo::sDisplayADN(char *sbADN)
{
	char sExprTemp1[250], sExprTemp2[250]="";
	char cEnter[4];
    cEnter[0]= '\n';
    cEnter[1]= '\0';

	strcpy(sbADN,"function Organismo.fSerVivo():real;");
	strcat(sbADN,cEnter);
	strcat(sbADN, "begin");
    strcat(sbADN,cEnter);

	for (unsigned int iCont=1; iCont<= m_iMaxGenOrg; iCont++)
    {
		sprintf(sExprTemp1, "%d: ", iCont);
		strcat(sbADN, sExprTemp1);

		if (m_oTriplete[iCont].iInstruccion >= 5 ) //Es una funcion
		{
			sprintf(sExprTemp1, "Funcion %d", m_oTriplete[iCont].iInstruccion);
			strcat(sbADN, sExprTemp1);
			strcat(sbADN, cEnter);
			continue;
		}
                 
        //Organiza los if y asignaciones
		if (m_oTriplete[iCont].iInstruccion >=1 && m_oTriplete[iCont].iInstruccion <= 4)
			strcat(sbADN, "IF ");

		sprintf(sExprTemp1, "V%d ", m_oTriplete[iCont].iVariable);
		strcat(sbADN, sExprTemp1);

		switch (m_oTriplete[iCont].iInstruccion)
		{
			case 0:	strcat(sbADN, "= ("); break;
			case 1:	strcat(sbADN, "> ("); break;
			case 2:	strcat(sbADN, "< ("); break;
			case 3:	strcat(sbADN, "== ("); break;
			case 4:	strcat(sbADN, "<> ("); break;
		}

		if (m_oTriplete[iCont].bEsVariable1 == true)
			sprintf(sExprTemp1, "V%d", m_oTriplete[iCont].iOperando1);
		else
			sprintf(sExprTemp1, "%d", m_oTriplete[iCont].iOperando1);

		strcat(sbADN, sExprTemp1);
		sprintf(sExprTemp1, " %c ", m_oTriplete[iCont].cOperador);
		strcat(sbADN, sExprTemp1);

		if (m_oTriplete[iCont].bEsVariable2 == true)
			sprintf(sExprTemp1, "V%d)", m_oTriplete[iCont].iOperando2);
		else
			sprintf(sExprTemp1, "%d)", m_oTriplete[iCont].iOperando2);
		strcat(sbADN, sExprTemp1);

		if (m_oTriplete[iCont].iInstruccion>=1 && m_oTriplete[iCont].iInstruccion <= 4)
		{
			sprintf(sExprTemp1, " Goto %d", m_oTriplete[iCont].iGotoLabel);
			strcat(sbADN, sExprTemp1);
		}

		strcat(sbADN, cEnter);
	}

	strcat(sbADN, "end;");
	strcat(sbADN, cEnter);
};

//Evaluar el Organismo en el ambiente
int Organismo::fEvalOrganismo (unsigned int *iOrgGenInst,
							   unsigned int *iFuncion)
{                   
	float fValor1, fValor2, fResultado=0;
	
	unsigned int iGenOrg; //# de Instrucci�n de inicio
    unsigned int iNumCiclos=0; //Contador de Ciclos
    	
	iGenOrg = *iOrgGenInst; //Continua por donde estaba
	while (iGenOrg!=0 && iGenOrg<=m_iMaxGenOrg)
    {
		//Coloca a TRUE la instruci�n porque se ejecuta
        m_oTriplete[iGenOrg].bEjecuta = true;
            
        //Aumenta el # de Ciclos
        iNumCiclos++;

		//M�ximo n�mero de ciclos que se evaluar�n del organismo, si el
        //organismo supera este n�mero de ciclos sin dar con un resultado
        //es desechado.
		if (iNumCiclos > m_iMaxiCiclos)
			return -1; //Se pas� del m�ximo de ciclos
            
		if (m_oTriplete[iGenOrg].iInstruccion >= 5) //Es una funcion
		{
			//Estas son las respuestas del organismo a las funciones
			*iFuncion = m_oTriplete[iGenOrg].iInstruccion;
			*iOrgGenInst = iGenOrg+1;
			return 1; //Ejecuta una funcion
		}

		//Determina si los valores son traidos por variables o son absolutos
		if (m_oTriplete[iGenOrg].bEsVariable1)
			fValor1 = fVariable[m_oTriplete[iGenOrg].iOperando1]; //Es una variable
		else
			fValor1 = (float) m_oTriplete[iGenOrg].iOperando1; //Un entero

		if (m_oTriplete[iGenOrg].bEsVariable2)
			fValor2 = fVariable[m_oTriplete[iGenOrg].iOperando2]; //Es una variable
		else
			fValor2 = (float) m_oTriplete[iGenOrg].iOperando2; //Un entero

		switch(m_oTriplete[iGenOrg].cOperador)
		{
			case '+': fResultado = fValor1 + fValor2; break;
			case '-': fResultado = fValor1 - fValor2; break;
			case '*': fResultado = fValor1 * fValor2; break;
			case '/': if (fabs(fValor2) < 0.00001) return -1;
					  fResultado = fValor1 / fValor2; break;
		}
		if (fabs(fResultado) > 100000000) return -1;

		/* Asignacion = 0 
			IF MAYOR = 1
			IF MENOR = 2
			IF IGUAL = 3
			IF DIFER = 4
			Funcion = 5....n
		*/
		switch(m_oTriplete[iGenOrg].iInstruccion)
		{
		case 0: //Una asignacion
			fVariable[m_oTriplete[iGenOrg].iVariable] = fResultado;
			iGenOrg++;
			break;
		case 1: //Un IF mayor
			if (fVariable[m_oTriplete[iGenOrg].iVariable] > fResultado)
	            iGenOrg=m_oTriplete[iGenOrg].iGotoLabel;
            else
	  	        iGenOrg++;
            break;
		case 2: //Un IF menor
			if (fVariable[m_oTriplete[iGenOrg].iVariable] < fResultado)
	            iGenOrg=m_oTriplete[iGenOrg].iGotoLabel;
            else
	  	        iGenOrg++;
            break;
		case 3: //Un IF igual
			if (fVariable[m_oTriplete[iGenOrg].iVariable] == fResultado)
	            iGenOrg=m_oTriplete[iGenOrg].iGotoLabel;
            else
	  	        iGenOrg++;
            break;
		case 4: //Un IF diferente
			if (fVariable[m_oTriplete[iGenOrg].iVariable] != fResultado)
	            iGenOrg=m_oTriplete[iGenOrg].iGotoLabel;
            else
	  	        iGenOrg++;
            break;
		}
	}//Fin de la evaluacion del ser vivo
	return 0; //Finalizo la ejecucion
};

int Organismo::_matherr(struct exception *a)
{
	printf("Hubo un error\n");
    return 1;
}
