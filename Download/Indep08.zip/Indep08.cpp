/*

Autor:		Rafael Alberto Moreno Parra
URL:		http://www.geocities.com/krousky
Clase:		Independencia 08: La competencia
Lenguaje:	C++
Fecha:		16 de Diciembre de 2002
Descripcion:
			Se generan N organismos los cuales competiran por cual es el
			mejor en el juego de 4 en l�nea.
			
			Partida:
			Se escogen al azar dos(2) contendores.
			Se suma a cada organismo el total de 4 en l�nea que hizo.

			Despu�s de M partidas, los que tengan mas puntos, pueden
			reproducirse (mutando) a costa de los que no tienen puntos,
			es decir, sobreescriben el organismo perdedor.
			Los hijos heredan el puntaje de los padres.

			Despu�s de K ciclos, se detiene el programa y se muestran
			los mejores.

			Vuelva a Partida:
*/

#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <string.h>

#include "Inicializa.h"
#include "Organismo.h"
#include "MasApto.h"

void main(void);
unsigned int Seleccion1(void);
unsigned int Seleccion2(void);
unsigned int Seleccion3(unsigned int iMutaciones, unsigned int iMinimo);
unsigned int Jugar(unsigned int iTotalUsarFuncion, unsigned int iMarca, unsigned int *iPuntInstr);

Aleatorio objAleatorio;
Organismo objOrg;  //El Algoritmo ("Organismo") a evaluar.
Inicializa objIni; //Lee el archivo de inicializaci�n
unsigned int iTablero[42][42];

void main(void)
{
	char sbCadena[250];
	unsigned int iOrganismo; //Para generar la poblaci�n completa.
	unsigned int iCopia; //Para copiar la parte interna del Organismo.
	unsigned int iCiclo; //Cuantos "mundiales" van a haber.
	unsigned int iJuegos; //Cuantos juegos por mundial.
	unsigned int iTurno; //Cuantos Turnos por juego.
	
	unsigned int iJugador1; //Jugador n�mero 1
	unsigned int iJugador2; //Jugador n�mero 2
	unsigned int iPuntInstr1, iPuntInstr2; //Por donde va evaluando los algoritmos gen�ticos
	unsigned int iTest; // [Seleccion Natural 1] Solo pasan los algoritmos que tengan la funcion 7 (colocar ficha)

	MasApto objMasApto[102]; //La poblaci�n a generar (m�ximo 100 organismos.. OJO!! sale un mensaje de error de STACK Overflow si tratode aumentar este n�mero)

	//Tablero de Juego
	unsigned int iAncho, iLargo;
	unsigned int iLinea1=0, iLinea2=0;
	unsigned int iPuntaje1=0, iPuntaje2=0;
	unsigned int iMasApto;
	unsigned int iVictima, iGenModifica;
	//======================================


    //============================================================
    //Inicializa la semilla de n�meros aleatorios
	//============================================================
	time_t ltime1;
	time(&ltime1);
	objAleatorio.sgenrand(ltime1);
	
	//============================================================
    //Inicializa la Simulaci�n
	//============================================================
	objIni.vPantallaIni(); //Pantalla de Inicio
	if (objIni.vLeeArchivoIni() == -1)
	{
		printf("Un error ocurri� al inicializar la simulaci�n\n");
		return;
	}
	objIni.vArchResult(); //Encabezado archivo de resultados


	objOrg.vInicio(true,
		objIni.stDatVA.iNumInstMin,
		objIni.stDatVA.iNumInstMax,
		objIni.stDatVA.iTotalFun,
		objIni.stDatVA.iTotalVar,
		objIni.stDatVA.iProbabIF,
		objIni.stDatVA.iProbabFN,
		objIni.stDatVA.iProbaVar,
		objIni.stDatVA.iTotalCPU);

	//============================================================
	//Se generan los N organismos.
	//============================================================

	for (iOrganismo=0; iOrganismo<objIni.stDatVA.iPoblacion; iOrganismo++)
	{
		iTest=0;
		do
		{
			objOrg.vCreaADN();		
			iTest = Seleccion1(); //Solo pasan los que tengan llamados a funciones
			if (iTest==1) iTest = Seleccion2(); //Solo pasan los que solos puedan llenar al menos una casilla
			if (iTest>=1) iTest = Seleccion3(1100, 4); //Muta hasta que pueda llenar N casillas.
		} while (iTest==0);
		sprintf(sbCadena, "(%d) Numero de casillas llenas: %d\n", iOrganismo, iTest);
		objIni.vGrabaLinea(sbCadena);
		printf("%s", sbCadena);

		for (iCopia=1; iCopia <= objOrg.m_iMaxGenOrg; iCopia++)
		{
			objMasApto[iOrganismo].m_oTriplete[iCopia].bEjecuta = objOrg.m_oTriplete[iCopia].bEjecuta;
			objMasApto[iOrganismo].m_oTriplete[iCopia].bEsVariable1 = objOrg.m_oTriplete[iCopia].bEsVariable1;
			objMasApto[iOrganismo].m_oTriplete[iCopia].bEsVariable2 = objOrg.m_oTriplete[iCopia].bEsVariable2;
			objMasApto[iOrganismo].m_oTriplete[iCopia].iGotoLabel = objOrg.m_oTriplete[iCopia].iGotoLabel;
			objMasApto[iOrganismo].m_oTriplete[iCopia].iInstruccion = objOrg.m_oTriplete[iCopia].iInstruccion;
			objMasApto[iOrganismo].m_oTriplete[iCopia].cOperador = objOrg.m_oTriplete[iCopia].cOperador;
			objMasApto[iOrganismo].m_oTriplete[iCopia].iOperando1 = objOrg.m_oTriplete[iCopia].iOperando1;
			objMasApto[iOrganismo].m_oTriplete[iCopia].iOperando2 = objOrg.m_oTriplete[iCopia].iOperando2;
			objMasApto[iOrganismo].m_oTriplete[iCopia].iVariable = objOrg.m_oTriplete[iCopia].iVariable;
		}
		objMasApto[iOrganismo].m_iMaxGenOrg = objOrg.m_iMaxGenOrg;
		objMasApto[iOrganismo].iPuntaje = 0;
	}


	for (iCiclo = 0; iCiclo < objIni.stDatVA.iTotalCiclos; iCiclo++)
	{
		for (iJuegos = 0; iJuegos < objIni.stDatVA.iTotalJuegos; iJuegos++)
		{
			//============================================================
			//Primero: Se escogen los contendores al azar
			//============================================================
			iJugador1 = objAleatorio.genrand() % objIni.stDatVA.iPoblacion;
			iJugador2 = objAleatorio.genrand() % objIni.stDatVA.iPoblacion;

			//Se limpia el tablero
			for (iAncho=0; iAncho < objIni.stDatVA.iAnchoTabl; iAncho++)
				for (iLargo=0; iLargo < objIni.stDatVA.iLargoTabl; iLargo++)
					iTablero[iAncho][iLargo] = 0;

			//============================================================
			//Segundo: Compiten entre ellos
			//============================================================
			//Jugador1 coloca '1' en las posiciones que marca
			//Jugador2 coloca '2' en las posiciones que marca
			//'0' son posiciones libres.
			iPuntInstr1 = 1;
			iPuntInstr2 = 1;
			for (iTurno = 0; iTurno < objIni.stDatVA.iTotalTurnos; iTurno++)
			{

				//Debe copiar el jugador1 escogido a objOrg y que Juegue
				for (iCopia=1; iCopia <= objMasApto[iJugador1].m_iMaxGenOrg; iCopia++)
				{
					objOrg.m_oTriplete[iCopia].bEjecuta = objMasApto[iJugador1].m_oTriplete[iCopia].bEjecuta;
					objOrg.m_oTriplete[iCopia].bEsVariable1 = objMasApto[iJugador1].m_oTriplete[iCopia].bEsVariable1;
					objOrg.m_oTriplete[iCopia].bEsVariable2 = objMasApto[iJugador1].m_oTriplete[iCopia].bEsVariable2;
					objOrg.m_oTriplete[iCopia].iGotoLabel = objMasApto[iJugador1].m_oTriplete[iCopia].iGotoLabel;
					objOrg.m_oTriplete[iCopia].iInstruccion = objMasApto[iJugador1].m_oTriplete[iCopia].iInstruccion;
					objOrg.m_oTriplete[iCopia].cOperador = objMasApto[iJugador1].m_oTriplete[iCopia].cOperador;
					objOrg.m_oTriplete[iCopia].iOperando1 = objMasApto[iJugador1].m_oTriplete[iCopia].iOperando1;
					objOrg.m_oTriplete[iCopia].iOperando2 = objMasApto[iJugador1].m_oTriplete[iCopia].iOperando2;
					objOrg.m_oTriplete[iCopia].iVariable = objMasApto[iJugador1].m_oTriplete[iCopia].iVariable;
				}
				objOrg.m_iMaxGenOrg = objMasApto[iJugador1].m_iMaxGenOrg;
				Jugar(objIni.stDatVA.iTotalUsarFuncion, 1, &iPuntInstr1);
				if (iPuntInstr1 >= objOrg.m_iMaxGenOrg) iPuntInstr1 = 1;

				//Debe copiar el jugador2 escogido a objOrg y que Juegue
				for (iCopia=1; iCopia <= objMasApto[iJugador1].m_iMaxGenOrg; iCopia++)
				{
					objOrg.m_oTriplete[iCopia].bEjecuta = objMasApto[iJugador2].m_oTriplete[iCopia].bEjecuta;
					objOrg.m_oTriplete[iCopia].bEsVariable1 = objMasApto[iJugador2].m_oTriplete[iCopia].bEsVariable1;
					objOrg.m_oTriplete[iCopia].bEsVariable2 = objMasApto[iJugador2].m_oTriplete[iCopia].bEsVariable2;
					objOrg.m_oTriplete[iCopia].iGotoLabel = objMasApto[iJugador2].m_oTriplete[iCopia].iGotoLabel;
					objOrg.m_oTriplete[iCopia].iInstruccion = objMasApto[iJugador2].m_oTriplete[iCopia].iInstruccion;
					objOrg.m_oTriplete[iCopia].cOperador = objMasApto[iJugador2].m_oTriplete[iCopia].cOperador;
					objOrg.m_oTriplete[iCopia].iOperando1 = objMasApto[iJugador2].m_oTriplete[iCopia].iOperando1;
					objOrg.m_oTriplete[iCopia].iOperando2 = objMasApto[iJugador2].m_oTriplete[iCopia].iOperando2;
					objOrg.m_oTriplete[iCopia].iVariable = objMasApto[iJugador2].m_oTriplete[iCopia].iVariable;
				}
				objOrg.m_iMaxGenOrg = objMasApto[iJugador2].m_iMaxGenOrg;
				Jugar(objIni.stDatVA.iTotalUsarFuncion, 2, &iPuntInstr2);
				if (iPuntInstr2 >= objOrg.m_iMaxGenOrg) iPuntInstr2 = 1;

			} //Fin de los Turnos

			//============================================================
			//Tercero: Resultado de la partida
			//============================================================
			//Jugadores �Cuantas Linea3 horizontal o vertical realiz�?
			iLinea1=0;
			iLinea2=0;
			iPuntaje1=0;
			iPuntaje2=0;
			for (iAncho=1; iAncho < objIni.stDatVA.iAnchoTabl; iAncho++)
				for (iLargo=1; iLargo < objIni.stDatVA.iLargoTabl; iLargo++)
				{
					if (iTablero[iAncho][iLargo]==1) { iLinea1++; iLinea2=0; }
					if (iTablero[iAncho][iLargo]==2) { iLinea2++; iLinea1=0; }
					if (iTablero[iAncho][iLargo]==0) { iLinea1=0; iLinea2=0; }
					if (iLinea1 >= 3) iPuntaje1++;
					if (iLinea2 >= 3) iPuntaje2++;
				}

			iLinea1=0;
			iLinea2=0;
			for (iLargo=1; iLargo < objIni.stDatVA.iLargoTabl; iLargo++)
				for (iAncho=1; iAncho < objIni.stDatVA.iAnchoTabl; iAncho++)
				{
					if (iTablero[iAncho][iLargo]==1) { iLinea1++; iLinea2=0; }
					if (iTablero[iAncho][iLargo]==2) { iLinea2++; iLinea1=0; }
					if (iTablero[iAncho][iLargo]==0) { iLinea1=0; iLinea2=0; }
					if (iLinea1 >= 2) iPuntaje1++;
					if (iLinea2 >= 2) iPuntaje2++;
				}
			
			objMasApto[iJugador1].iPuntaje += iPuntaje1;
			objMasApto[iJugador2].iPuntaje += iPuntaje2;
		} //Fin de los Juegos

		//Resultados de los Juegos
		for (iLargo=0; iLargo < objIni.stDatVA.iPoblacion; iLargo++)
		{
			sprintf(sbCadena, "Org: %d, Puntaje: %d\n", iLargo, objMasApto[iLargo].iPuntaje);
			objIni.vGrabaLinea(sbCadena);
			printf("%s", sbCadena);
		}

		//============================================================
		//Cuarto: Se reproducen
		//============================================================
		for (iMasApto=0; iMasApto < objIni.stDatVA.iPoblacion; iMasApto++)
		{
			//Si tiene puntaje, puede reproducirse...
			if (objMasApto[iMasApto].iPuntaje > 0)
			{
				//Tiene 5 intentos para buscar donde reproducirse
				for (iVictima=0; iVictima<5; iVictima++)
				{
					iJugador1 = objAleatorio.genrand() % objIni.stDatVA.iPoblacion;
					if (objMasApto[iMasApto].iPuntaje > objMasApto[iJugador1].iPuntaje)
					{
						for (iCopia=1; iCopia <= objMasApto[iMasApto].m_iMaxGenOrg; iCopia++)
						{
							objMasApto[iJugador1].m_oTriplete[iCopia].bEjecuta = objMasApto[iMasApto].m_oTriplete[iCopia].bEjecuta;
							objMasApto[iJugador1].m_oTriplete[iCopia].bEsVariable1 = objMasApto[iMasApto].m_oTriplete[iCopia].bEsVariable1;
							objMasApto[iJugador1].m_oTriplete[iCopia].bEsVariable2 = objMasApto[iMasApto].m_oTriplete[iCopia].bEsVariable2;
							objMasApto[iJugador1].m_oTriplete[iCopia].iGotoLabel = objMasApto[iMasApto].m_oTriplete[iCopia].iGotoLabel;
							objMasApto[iJugador1].m_oTriplete[iCopia].iInstruccion = objMasApto[iMasApto].m_oTriplete[iCopia].iInstruccion;
							objMasApto[iJugador1].m_oTriplete[iCopia].cOperador = objMasApto[iMasApto].m_oTriplete[iCopia].cOperador;
							objMasApto[iJugador1].m_oTriplete[iCopia].iOperando1 = objMasApto[iMasApto].m_oTriplete[iCopia].iOperando1;
							objMasApto[iJugador1].m_oTriplete[iCopia].iOperando2 = objMasApto[iMasApto].m_oTriplete[iCopia].iOperando2;
							objMasApto[iJugador1].m_oTriplete[iCopia].iVariable = objMasApto[iMasApto].m_oTriplete[iCopia].iVariable;
						}
						objMasApto[iJugador1].m_iMaxGenOrg = objMasApto[iMasApto].m_iMaxGenOrg;
						objMasApto[iJugador1].iPuntaje = objMasApto[iMasApto].iPuntaje - 1;

						//2: Modifica el algoritmo original
						iGenModifica = objAleatorio.genrand() % objMasApto[iMasApto].m_iMaxGenOrg + 1;
						objOrg.m_oTriplete[iGenModifica].bEjecuta = objMasApto[iMasApto].m_oTriplete[iGenModifica].bEjecuta;
						objOrg.m_oTriplete[iGenModifica].bEsVariable1 = objMasApto[iMasApto].m_oTriplete[iGenModifica].bEsVariable1;
						objOrg.m_oTriplete[iGenModifica].bEsVariable2 = objMasApto[iMasApto].m_oTriplete[iGenModifica].bEsVariable2;
						objOrg.m_oTriplete[iGenModifica].iGotoLabel = objMasApto[iMasApto].m_oTriplete[iGenModifica].iGotoLabel;
						objOrg.m_oTriplete[iGenModifica].iInstruccion = objMasApto[iMasApto].m_oTriplete[iGenModifica].iInstruccion;
						objOrg.m_oTriplete[iGenModifica].cOperador = objMasApto[iMasApto].m_oTriplete[iGenModifica].cOperador;
						objOrg.m_oTriplete[iGenModifica].iOperando1 = objMasApto[iMasApto].m_oTriplete[iGenModifica].iOperando1;
						objOrg.m_oTriplete[iGenModifica].iOperando2 = objMasApto[iMasApto].m_oTriplete[iGenModifica].iOperando2;
						objOrg.m_oTriplete[iGenModifica].iVariable = objMasApto[iMasApto].m_oTriplete[iGenModifica].iVariable;
						objOrg.vHaceGen(iGenModifica);

						objMasApto[iJugador1].m_oTriplete[iGenModifica].bEjecuta = objOrg.m_oTriplete[iGenModifica].bEjecuta;
						objMasApto[iJugador1].m_oTriplete[iGenModifica].bEsVariable1 = objOrg.m_oTriplete[iGenModifica].bEsVariable1;
						objMasApto[iJugador1].m_oTriplete[iGenModifica].bEsVariable2 = objOrg.m_oTriplete[iGenModifica].bEsVariable2;
						objMasApto[iJugador1].m_oTriplete[iGenModifica].iGotoLabel = objOrg.m_oTriplete[iGenModifica].iGotoLabel;
						objMasApto[iJugador1].m_oTriplete[iGenModifica].iInstruccion = objOrg.m_oTriplete[iGenModifica].iInstruccion;
						objMasApto[iJugador1].m_oTriplete[iGenModifica].cOperador = objOrg.m_oTriplete[iGenModifica].cOperador;
						objMasApto[iJugador1].m_oTriplete[iGenModifica].iOperando1 = objOrg.m_oTriplete[iGenModifica].iOperando1;
						objMasApto[iJugador1].m_oTriplete[iGenModifica].iOperando2 = objOrg.m_oTriplete[iGenModifica].iOperando2;
						objMasApto[iJugador1].m_oTriplete[iGenModifica].iVariable = objOrg.m_oTriplete[iGenModifica].iVariable;
						break;
					}
				}
			}
		}
	}
//	objIni.vFinalSimulacion();
}


//[Selecci�n Natural 1] Solo pasan los algoritmos que tienen la funcion 7 (colocar fichas)
unsigned int Seleccion1()
{
    unsigned int iGen, iFuncion1=0, iFuncion2=0, iFuncion3=0;

	for (iGen=1; iGen <= objOrg.m_iMaxGenOrg; iGen++)
	{
		if (objOrg.m_oTriplete[iGen].iInstruccion == 5 ) iFuncion1 = 1;
		if (objOrg.m_oTriplete[iGen].iInstruccion == 6 ) iFuncion2 = 1;
		if (objOrg.m_oTriplete[iGen].iInstruccion == 7 ) iFuncion3 = 1;
	}
	
	if (iFuncion1==1 && iFuncion2==1 && iFuncion3==1) return 1;
	return 0;
}
	
//[Selecci�n Natural 2] Solo pasan los algoritmos que colocan al menos cuatro fichas en el tablero
unsigned int Seleccion2()
{
	unsigned int iPuntInstr, iRetorna;

	iPuntInstr = 1;
	iRetorna = Jugar(objIni.stDatVA.iTotalFun, 1, &iPuntInstr);
	return iRetorna;
}

//[Selecci�n Natural 3] Muta hasta que pueda llenar las iMinimo casillas en iIntentos
unsigned int Seleccion3(unsigned int iMutaciones, unsigned int iMinimo)
{
	unsigned int iMutar, iPuntInstr, iGenModifica, iCopia, iAncho, iLargo, iCuadros, iCiclo=0;
	MasApto objCopia;

	for (iAncho=1; iAncho < objIni.stDatVA.iAnchoTabl; iAncho++)
		for (iLargo=1; iLargo < objIni.stDatVA.iLargoTabl; iLargo++)
			iTablero[iAncho][iLargo] = 0;

	objOrg.iPuntaje = 0;
	for (iMutar=0; iMutar<iMutaciones; iMutar++)
	{
		iCiclo++;

		//1: Copia el algoritmo original (para no perderlo)
		for (iCopia=1; iCopia <= objOrg.m_iMaxGenOrg; iCopia++)
		{
			objCopia.m_oTriplete[iCopia].bEjecuta = objOrg.m_oTriplete[iCopia].bEjecuta;
			objCopia.m_oTriplete[iCopia].bEsVariable1 = objOrg.m_oTriplete[iCopia].bEsVariable1;
			objCopia.m_oTriplete[iCopia].bEsVariable2 = objOrg.m_oTriplete[iCopia].bEsVariable2;
			objCopia.m_oTriplete[iCopia].iGotoLabel = objOrg.m_oTriplete[iCopia].iGotoLabel;
			objCopia.m_oTriplete[iCopia].iInstruccion = objOrg.m_oTriplete[iCopia].iInstruccion;
			objCopia.m_oTriplete[iCopia].cOperador = objOrg.m_oTriplete[iCopia].cOperador;
			objCopia.m_oTriplete[iCopia].iOperando1 = objOrg.m_oTriplete[iCopia].iOperando1;
			objCopia.m_oTriplete[iCopia].iOperando2 = objOrg.m_oTriplete[iCopia].iOperando2;
			objCopia.m_oTriplete[iCopia].iVariable = objOrg.m_oTriplete[iCopia].iVariable;
		}
		objCopia.m_iMaxGenOrg = objOrg.m_iMaxGenOrg;
		objCopia.iPuntaje = objOrg.iPuntaje;

		//2: Modifica el algoritmo original
		iGenModifica = objAleatorio.genrand() % objOrg.m_iMaxGenOrg + 1;
		objOrg.vHaceGen(iGenModifica);

		//3: El algoritmo modificado juega N(turnos) veces y luego se computa cuantas casillas llen�
		iPuntInstr = 1;
		for (unsigned int iJugar=0; iJugar <= objIni.stDatVA.iTotalTurnos/2; iJugar++)
			Jugar(objIni.stDatVA.iTotalUsarFuncion, iCiclo, &iPuntInstr);

		//4: Si comput� mejor, entonces sobreescribe al original. Volver a 1:
		iCuadros = 0;
		for (iAncho=1; iAncho < objIni.stDatVA.iAnchoTabl; iAncho++)
			for (iLargo=1; iLargo < objIni.stDatVA.iLargoTabl; iLargo++)
				if (iTablero[iAncho][iLargo] == iCiclo) iCuadros++;
			
		if (iCuadros > objOrg.iPuntaje)
		{
			for (iCopia=1; iCopia <= objCopia.m_iMaxGenOrg; iCopia++)
			{
				objOrg.m_oTriplete[iCopia].bEjecuta = objCopia.m_oTriplete[iCopia].bEjecuta;
				objOrg.m_oTriplete[iCopia].bEsVariable1 = objCopia.m_oTriplete[iCopia].bEsVariable1;
				objOrg.m_oTriplete[iCopia].bEsVariable2 = objCopia.m_oTriplete[iCopia].bEsVariable2;
				objOrg.m_oTriplete[iCopia].iGotoLabel = objCopia.m_oTriplete[iCopia].iGotoLabel;
				objOrg.m_oTriplete[iCopia].iInstruccion = objCopia.m_oTriplete[iCopia].iInstruccion;
				objOrg.m_oTriplete[iCopia].cOperador = objCopia.m_oTriplete[iCopia].cOperador;
				objOrg.m_oTriplete[iCopia].iOperando1 = objCopia.m_oTriplete[iCopia].iOperando1;
				objOrg.m_oTriplete[iCopia].iOperando2 = objCopia.m_oTriplete[iCopia].iOperando2;
				objOrg.m_oTriplete[iCopia].iVariable = objCopia.m_oTriplete[iCopia].iVariable;
			}
			objOrg.m_iMaxGenOrg = objCopia.m_iMaxGenOrg;
			objOrg.iPuntaje = iCuadros;
		}
	}
	if (objOrg.iPuntaje>=iMinimo) return objOrg.iPuntaje;
	return 0;
}

//Aqui los organismos juegan a llenar el tablero
unsigned int Jugar(unsigned int iTotalUsarFuncion, unsigned int iMarca, unsigned int *iPuntInstr)
{
	unsigned int iContUsarFuncion = 0;
	unsigned int iAccion = 0;
	unsigned int iCont1, iCont2;
	unsigned int iFuncion=0;
	unsigned int iRetorna=0; //Si coloco al menos una ficha se retorna 1 caso contrario, cero


	//Cuando coloque una ficha, debe darle turno al otro jugador
	do
	{
		iContUsarFuncion++;
		iAccion = objOrg.iEvalOrganismo( iPuntInstr, &iFuncion);

		if (iAccion==-1) 
		{
			*iPuntInstr=1;
			return 0;
		}
		
		if (iAccion==0) 
		{
			*iPuntInstr=1;
			return iRetorna;
		}

		if (iAccion==1) //Llamando una funcion
		{
			switch(iFuncion)
			{
				case 1: //Retorna el contenido de la celda
					iCont1 = objOrg.iVariable[0];
					iCont2 = objOrg.iVariable[1];
					if (iCont1<objIni.stDatVA.iAnchoTabl && iCont1>=1 && iCont2<objIni.stDatVA.iLargoTabl && iCont2>=1)
						objOrg.iVariable[2] = iTablero[iCont1][iCont2];
					else
						objOrg.iVariable[2] = -1; //esta preguntando por una posici�n invalida.
					break;
				case 2: //Retorna tama�o del tablero
						objOrg.iVariable[0] = 1;
						objOrg.iVariable[1] = 1;
						objOrg.iVariable[2] = objIni.stDatVA.iAnchoTabl;
						objOrg.iVariable[3] = objIni.stDatVA.iLargoTabl;
						break;
				case 3: //Colocar una ficha
					iCont1 = objOrg.iVariable[0];
					iCont2 = objOrg.iVariable[1];
					if (iCont1<objIni.stDatVA.iAnchoTabl && iCont1>=1 && iCont2<objIni.stDatVA.iLargoTabl && iCont2>=1)
					{
						iRetorna = 1;
						if (iTablero[iCont1][iCont2]==0)
						{
							iTablero[iCont1][iCont2]=iMarca;
							objOrg.iVariable[2]=1;
						}
						else
							objOrg.iVariable[2] = -1; //esta colocandolo en una posici�n invalida.
					}
					return iRetorna;
			} //Fin de Switch
		} //Fin do
	} while(iContUsarFuncion <= iTotalUsarFuncion);
	return iRetorna;
}