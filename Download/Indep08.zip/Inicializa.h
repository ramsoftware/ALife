/*
Autor:		Rafael Alberto Moreno Parra
URL:		http://www.geocities.com/krousky
Clase:		Inicializa.
Lenguaje:	C++

Prop�sito:
Inicializa las variables para la simulaci�n

M�todos:

*/
class Inicializa {
public:

	struct stDatosSimul
	{
   		//Probabilidades, estos datos se leen de un archivo de inicializaci�n
		unsigned int iTotalCiclos; //Ciclos de juego (Cuantos "mundiales" se van a jugar)
		unsigned int iTotalJuegos; //N�mero de juegos por ciclo (cuantas partidas se van a jugar)
		unsigned int iTotalTurnos; //N�mero de turnos que tendran ambos jugadores
		unsigned int iTotalUsarFuncion; //M�ximo n�mero de veces que se puede usar funciones del ambiente
		unsigned int iPoblacion; //Poblaci�n a generar.
		unsigned int iNumInstMin; //Numero de instrucciones(tripletes) m�nimo generado
		unsigned int iNumInstMax; //Numero de instrucciones(tripletes) m�ximo generado
		unsigned int iTotalFun; //Total Funciones
		unsigned int iProbabIF; //Probabilidad de IF
		unsigned int iProbabFN; //Probabilidad de Funcion
		unsigned int iTotalVar; //Total Variables
		unsigned int iProbaVar; //Probabilidad de usar variables en la expresi�n derecha
		unsigned int iTotalCPU; //Cuantos ciclos de CPU consume cada algoritmo gen�tico.
		unsigned int iAnchoTabl; //Ancho del tablero de Juego
		unsigned int iLargoTabl; //Largo del tablero de Juego
		char sArchResult[30]; //Archivo donde se guarda el resultado
	};  

	struct stDatosSimul stDatVA; //Datos Vida Artificial
	void vPantallaIni(void);
    int vLeeArchivoIni(void);
	void vArchResult(void);
	void vGrabaLinea(char *sMensaje);
	void vGrabaAlgoritmos(unsigned int iIntento, float fMargenError, char *sMensaje);
	void vFinalSimulacion(void);
};
