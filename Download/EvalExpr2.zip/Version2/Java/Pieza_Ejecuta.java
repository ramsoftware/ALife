/*  Autor: Rafael Alberto Moreno Parra
  Sitio Web:  http://darwin.50webs.com
  Correo:  enginelife@hotmail.com

  Evaluador de expresiones algebraicas por ejemplo, 57+1.87/84.89-(6.8*e+b+8769-4*b/8+b^2*4^e/f)+5.4-(d/9.6+0.2) con las siguientes funcionalidades:
  1. Ilimitado número de paréntesis
  2. Más rápido y más sencillo que el evaluador escrito para el primer libro: "Desarrollo de un evaluador de expresiones algebraicas"
  3. Manejo de 26 variables
  4. Manejo de 12 funciones
  5. Manejo de operadores +, -, *, /, ^ (potencia)
  6. Manejo del menos unario: lo reemplaza con (0-1)# donde # es la operación con mayor relevancia y equivale a la multiplicación

  Versión: 2.00 [Genera el libro "Desarrollo de un evaluador de expresiones algebraicas. Versión 2.0"]
  Fecha: Enero de 2013
  Licencia: LGPL

  Algoritmo:

  Se toma una expresión como 7*x+sen(12.8/y+9)-5*cos(9-(8.3/5.11^3-4.7)*7.12)+0.445
  Se agregan paréntesis de inicio y fin  (7*x+sen(12.8/y+9)-5*cos(9-(8.3/5.11^3-4.7)*7.12)+0.445)
  Se divide en piezas simples   | ( | 7 | * | x | + | sen( | 12.8 | / | y | + | 9 | ) | - | 5 | * | cos( | 9 | - | ( | 8.3 | / | 5.11 | ^ | 3 | - | 4.7 | ) | * | 7.12 | ) | + | 0.445 | ) |
  Esas piezas están clasificadas:
   Paréntesis que abre (
   Paréntesis que cierra )
   Números  7   12.8  9   5
   Variables  x  y
   Operadores + - * / ^
   Funciones  sen(  cos(
  Luego se convierte esa expresión larga en expresiones cortas de ejecución del tipo
  Acumula = operando(número/variable/acumula)  operador(+, -, *, /, ^)   operando(número/variable/acumula)
    [0]  5.11 ^ 3
    [1]  8.3  / [0]
    [2]  [1] - 4.7
    [3]  [2] + 0
    [4]  [3] * 7,12
    [5]  9   - [4]
    [6]  cos([5])
    [7]  12,8 / y
    [8]  [7] +  9
    [9]  sen([8])
    [10] 7 * x
    [11] 5 * [6]
    [12] [10] + [9]
    [13] [12] - [11]
    [14] [13] + 0.445
    [15] [14] + 0
  La expresión ya está analizada y lista para evaluar.
  Se evalúa yendo de [0] a [15], en [15] está el valor final.
*/

public class Pieza_Ejecuta
{
  private double valorPieza;

  private int funcion;

  private int tipo_operandoA;
  private double numeroA;
  private int variableA;
  private int acumulaA;

  private char operador;

  private int tipo_operandoB;
  private double numeroB;
  private int variableB;
  private int acumulaB;

  public final double getValorPieza() { return this.valorPieza; }
  public final void setValorPieza(double valor) { this.valorPieza = valor; }
  public final int getFuncion() { return this.funcion; }
  public final int getTipoOperA() { return this.tipo_operandoA; }
  public final double getNumeroA() { return this.numeroA; }
  public final int getVariableA() { return this.variableA; }
  public final int getAcumulaA() { return this.acumulaA; }
  public final char getOperador() { return this.operador; }
  public final int getTipoOperB() { return this.tipo_operandoB; }
  public final double getNumeroB() { return this.numeroB; }
  public final int getVariableB() { return this.variableB; }
  public final int getAcumulaB() { return this.acumulaB; }

  public Pieza_Ejecuta(int funcion, int tipo_operandoA, double numeroA, int variableA, int acumulaA, char operador, int tipo_operandoB, double numeroB, int variableB, int acumulaB)
  {
    this.valorPieza = 0;

    this.funcion = funcion;

    this.tipo_operandoA = tipo_operandoA;
    this.numeroA = numeroA;
    this.variableA = variableA;
    this.acumulaA = acumulaA;

    this.operador = operador;

    this.tipo_operandoB = tipo_operandoB;
    this.numeroB = numeroB;
    this.variableB = variableB;
    this.acumulaB = acumulaB;
  }
}

