﻿'Autor: Rafael Alberto Moreno Parra
'Sitio Web:  http://darwin.50webs.com
'Correo:  enginelife@hotmail.com

'Evaluador de expresiones algebraicas por ejemplo, 57+1.87/84.89-(6.8*e+b+8769-4*b/8+b^2*4^e/f)+5.4-(d/9.6+0.2) con las siguientes funcionalidades:
'1. Ilimitado número de paréntesis
'2. Más rápido y más sencillo que el evaluador escrito para el primer libro: "Desarrollo de un evaluador de expresiones algebraicas"
'3. Manejo de 26 variables
'4. Manejo de 12 funciones
'5. Manejo de operadores +, -, *, /, ^ (potencia)
'6. Manejo del menos unario: lo reemplaza con (0-1)# donde # es la operación con mayor relevancia y equivale a la multiplicación

'Versión: 2.00 [Genera el libro "Desarrollo de un evaluador de expresiones algebraicas. Versión 2.0"]
'Fecha: Enero de 2013
'Licencia: LGPL

'Algoritmo:

'Se toma una expresión como 7*x+sen(12.8/y+9)-5*cos(9-(8.3/5.11^3-4.7)*7.12)+0.445
'Se agregan paréntesis de inicio y fin  (7*x+sen(12.8/y+9)-5*cos(9-(8.3/5.11^3-4.7)*7.12)+0.445)
'Se divide en piezas simples   | ( | 7 | * | x | + | sen( | 12.8 | / | y | + | 9 | ) | - | 5 | * | cos( | 9 | - | ( | 8.3 | / | 5.11 | ^ | 3 | - | 4.7 | ) | * | 7.12 | ) | + | 0.445 | ) |
'Esas piezas están clasificadas:
' Paréntesis que abre (
' Paréntesis que cierra )
' Números  7   12.8  9   5
' Variables  x  y
' Operadores + - * / ^
' Funciones  sen(  cos(
'Luego se convierte esa expresión larga en expresiones cortas de ejecución del tipo
'Acumula = operando(número/variable/acumula)  operador(+, -, *, /, ^)   operando(número/variable/acumula)
'  [0]  5.11 ^ 3
'  [1]  8.3  / [0]
'  [2]  [1] - 4.7
'  [3]  [2] + 0
'  [4]  [3] * 7,12
'  [5]  9   - [4]
'  [6]  cos([5])
'  [7]  12,8 / y
'  [8]  [7] +  9
'  [9]  sen([8])
'  [10] 7 * x
'  [11] 5 * [6]
'  [12] [10] + [9]
'  [13] [12] - [11]
'  [14] [13] + 0.445
'  [15] [14] + 0
'La expresión ya está analizada y lista para evaluar.
'Se evalúa yendo de [0] a [15], en [15] está el valor final.

Public Class Evaluar
    ' Esta constante sirve para que se reste al carácter y se obtenga el número.  Ejemplo:  '7' - ASCIINUMERO =  7 
    Private Shared ASCIINUMERO As Integer = 48

    ' Esta constante sirve para que se reste al carácter y se obtenga el número de la letra. Ejemplo:  'b' - ASCIILETRA =  1 
    Private Shared ASCIILETRA As Integer = 97

    ' Las funciones que soporta este evaluador 
    Private Shared TAMANOFUNCION As Integer = 39
    Private Shared listaFunciones As [String] = "sinsencostanabsasnacsatnlogceiexpsqrrcb"

    ' Constantes de los diferentes tipos de datos que tendrán las piezas 
    Private Shared ESFUNCION As Integer = 1
    Private Shared ESPARABRE As Integer = 2
    Private Shared ESPARCIERRA As Integer = 3
    Private Shared ESOPERADOR As Integer = 4
    Private Shared ESNUMERO As Integer = 5
    Private Shared ESVARIABLE As Integer = 6

    'Listado de Piezas de análisis
    Private PiezaSimple As New List(Of Pieza_Simple)()

    'Listado de Piezas de ejecución
    Private PiezaEjecuta As New List(Of Pieza_Ejecuta)()
    Private Contador_Acumula As Integer = 0

    'Almacena los valores de las 26 diferentes variables que puede tener la expresión algebraica
    Private VariableAlgebra As Double() = New Double(25) {}

    'Valida la expresión algebraica
    Public Function EvaluaSintaxis(expresion As [String]) As Integer
        'Hace 25 pruebas de sintaxis
        If DobleTripleOperadorSeguido(expresion) Then
            Return 1
        End If
        If OperadorParentesisCierra(expresion) Then
            Return 2
        End If
        If ParentesisAbreOperador(expresion) Then
            Return 3
        End If
        If ParentesisDesbalanceados(expresion) Then
            Return 4
        End If
        If ParentesisVacio(expresion) Then
            Return 5
        End If
        If ParentesisBalanceIncorrecto(expresion) Then
            Return 6
        End If
        If ParentesisCierraNumero(expresion) Then
            Return 7
        End If
        If NumeroParentesisAbre(expresion) Then
            Return 8
        End If
        If DoblePuntoNumero(expresion) Then
            Return 9
        End If
        If ParentesisCierraVariable(expresion) Then
            Return 10
        End If
        If VariableluegoPunto(expresion) Then
            Return 11
        End If
        If PuntoluegoVariable(expresion) Then
            Return 12
        End If
        If NumeroAntesVariable(expresion) Then
            Return 13
        End If
        If VariableDespuesNumero(expresion) Then
            Return 14
        End If
        If Chequea4letras(expresion) Then
            Return 15
        End If
        If FuncionInvalida(expresion) Then
            Return 16
        End If
        If VariableInvalida(expresion) Then
            Return 17
        End If
        If VariableParentesisAbre(expresion) Then
            Return 18
        End If
        If ParCierraParAbre(expresion) Then
            Return 19
        End If
        If OperadorPunto(expresion) Then
            Return 20
        End If
        If ParAbrePunto(expresion) Then
            Return 21
        End If
        If PuntoParAbre(expresion) Then
            Return 22
        End If
        If ParCierraPunto(expresion) Then
            Return 23
        End If
        If PuntoOperador(expresion) Then
            Return 24
        End If
        If PuntoParCierra(expresion) Then
            Return 25
        End If

        Return 0
        'No se detectó error de sintaxis
    End Function

    'Muestra mensaje de error sintáctico
    Public Function MensajeSintaxis(CodigoError As Integer) As [String]
        Select Case CodigoError
            Case 0
                Return "No se detectó error sintáctico en las 21 pruebas que se hicieron."
            Case 1
                Return "1. Dos o más operadores estén seguidos. Ejemplo: 2++4, 5-*3"
            Case 2
                Return "2. Un operador seguido de un paréntesis que cierra. Ejemplo: 2-(4+)-7"
            Case 3
                Return "3. Un paréntesis que abre seguido de un operador. Ejemplo: 2-(*3)"
            Case 4
                Return "4. Que los paréntesis estén desbalanceados. Ejemplo: 3-(2*4))"
            Case 5
                Return "5. Que haya paréntesis vacío. Ejemplo: 2-()*3"
            Case 6
                Return "6. Paréntesis que abre no corresponde con el que cierra. Ejemplo: 2+3)-2*(4"
            Case 7
                Return "7. Un paréntesis que cierra y sigue un número. Ejemplo: (3-5)7-(1+2)"
            Case 8
                Return "8. Un número seguido de un paréntesis que abre. Ejemplo: 7-2(5-6)"
            Case 9
                Return "9. Doble punto en un número de tipo real. Ejemplo: 3-2..4+1  7-6.46.1+2"
            Case 10
                Return "10. Un paréntesis que cierra seguido de una variable. Ejemplo: (12-4)y-1"
            Case 11
                Return "11. Una variable seguida de un punto. Ejemplo: 4-z.1+3"
            Case 12
                Return "12. Un punto seguido de una variable. Ejemplo: 7-2.p+1"
            Case 13
                Return "13. Un número antes de una variable. Ejemplo: 3x+1"
            Case 14
                Return "14. Un número después de una variable. Ejemplo: x21+4"
            Case 15
                Return "15. Hay 4 o más letras seguidas. Ejemplo: 12+ramp+8.9"
            Case 16
                Return "16. Función inexistente. Ejemplo: 5*alo(78)"
            Case 17
                Return "17. Variable inválida (solo pueden tener una letra). Ejemplo: 5+tr-xc+5"
            Case 18
                Return "18. Variable seguida de paréntesis que abre. Ejemplo: 5-a(7+3)"
            Case 19
                Return "19. Después de paréntesis que cierra sigue paréntesis que abre. Ejemplo: (4-5)(2*x)"
            Case 20
                Return "20. Después de operador sigue un punto. Ejemplo: -.3+7"
            Case 21
                Return "21. Después de paréntesis que abre sigue un punto. Ejemplo: 3*(.5+4)"
            Case 22
                Return "22. Un punto seguido de un paréntesis que abre. Ejemplo: 7+3.(2+6)"
            Case 23
                Return "23. Paréntesis cierra y sigue punto. Ejemplo: (4+5).7-2"
            Case 24
                Return "24. Punto seguido de operador. Ejemplo: 5.*9+1"
            Case Else
                Return "25. Punto seguido de paréntesis que cierra. Ejemplo: (3+2.)*5"
        End Select
    End Function

    'Retira caracteres inválidos. Pone la expresión entre paréntesis.
    Public Function TransformaExpresion(expr As [String]) As [String]
        If expr Is Nothing Then
            Return ""
        End If
        Dim validos As [String] = "abcdefghijklmnopqrstuvwxyz0123456789.+-*/^()"
        Dim nuevaExpr As New Text.StringBuilder()
        Dim expr2 As [String] = expr.ToLower()

        nuevaExpr.Append("(")
        For pos As Integer = 0 To expr2.Length - 1
            Dim letra As Char = expr2(pos)
            For valida As Integer = 0 To validos.Length - 1
                If letra = validos(valida) Then
                    nuevaExpr.Append(letra)
                    Exit For
                End If
            Next
        Next
        nuevaExpr.Append(")")
        Return nuevaExpr.ToString()
    End Function

    '1. Dos o más operadores estén seguidos. Ejemplo: 2++4, 5-*3
    Private Shared Function DobleTripleOperadorSeguido(expr As [String]) As [Boolean]
        For pos As Integer = 0 To expr.Length - 2
            Dim car1 As Char = expr(pos)
            'Extrae un carácter
            Dim car2 As Char = expr(pos + 1)
            'Extrae el siguiente carácter
            'Compara si el carácter y el siguiente son operadores, dado el caso retorna true
            If car1 = "+" OrElse car1 = "-" OrElse car1 = "*" OrElse car1 = "/" OrElse car1 = "^" Then
                If car2 = "+" OrElse car2 = "*" OrElse car2 = "/" OrElse car2 = "^" Then
                    Return True
                End If
            End If
        Next

        For pos As Integer = 0 To expr.Length - 3
            Dim car1 As Char = expr(pos)
            'Extrae un carácter
            Dim car2 As Char = expr(pos + 1)
            'Extrae el siguiente carácter
            Dim car3 As Char = expr(pos + 2)
            'Extrae el siguiente carácter

            'Compara si el carácter y el siguiente son operadores, dado el caso retorna true
            If car1 = "+" OrElse car1 = "-" OrElse car1 = "*" OrElse car1 = "/" OrElse car1 = "^" Then
                If car2 = "+" OrElse car2 = "-" OrElse car2 = "*" OrElse car2 = "/" OrElse car2 = "^" Then
                    If car3 = "+" OrElse car3 = "-" OrElse car3 = "*" OrElse car3 = "/" OrElse car3 = "^" Then
                        Return True
                    End If
                End If
            End If
        Next

        Return False
        'No encontró doble/triple operador seguido
    End Function

    '2. Un operador seguido de un paréntesis que cierra. Ejemplo: 2-(4+)-7
    Private Shared Function OperadorParentesisCierra(expr As [String]) As [Boolean]
        For pos As Integer = 0 To expr.Length - 2
            Dim car1 As Char = expr(pos)
            'Extrae un carácter
            'Compara si el primer carácter es operador y el siguiente es paréntesis que cierra
            If car1 = "+" OrElse car1 = "-" OrElse car1 = "*" OrElse car1 = "/" OrElse car1 = "^" Then
                If expr(pos + 1) = ")" Then
                    Return True
                End If
            End If
        Next
        Return False
        'No encontró operador seguido de un paréntesis que cierra
    End Function

    '3. Un paréntesis que abre seguido de un operador. Ejemplo: 2-(*3)
    Private Shared Function ParentesisAbreOperador(expr As [String]) As [Boolean]
        For pos As Integer = 0 To expr.Length - 2
            Dim car2 As Char = expr(pos + 1)
            'Extrae el siguiente carácter
            'Compara si el primer carácter es paréntesis que abre y el siguiente es operador
            If expr(pos) = "(" Then
                If car2 = "+" OrElse car2 = "*" OrElse car2 = "/" OrElse car2 = "^" Then
                    Return True
                End If
            End If
        Next
        Return False
        'No encontró paréntesis que abre seguido de un operador
    End Function

    '4. Que los paréntesis estén desbalanceados. Ejemplo: 3-(2*4))
    Private Shared Function ParentesisDesbalanceados(expr As [String]) As [Boolean]
        Dim parabre As Integer = 0, parcierra As Integer = 0
        For pos As Integer = 0 To expr.Length - 1
            Dim car1 As Char = expr(pos)
            If car1 = "(" Then
                parabre += 1
            End If
            If car1 = ")" Then
                parcierra += 1
            End If
        Next
        Return parabre <> parcierra
    End Function

    '5. Que haya paréntesis vacío. Ejemplo: 2-()*3
    Private Shared Function ParentesisVacio(expr As [String]) As [Boolean]
        'Compara si el primer carácter es paréntesis que abre y el siguiente es paréntesis que cierra
        For pos As Integer = 0 To expr.Length - 2
            If expr(pos) = "(" AndAlso expr(pos + 1) = ")" Then
                Return True
            End If
        Next
        Return False
    End Function

    '6. Así estén balanceados los paréntesis no corresponde el que abre con el que cierra. Ejemplo: 2+3)-2*(4
    Private Shared Function ParentesisBalanceIncorrecto(expr As [String]) As [Boolean]
        Dim balance As Integer = 0
        For pos As Integer = 0 To expr.Length - 1
            Dim car1 As Char = expr(pos)
            'Extrae un carácter
            If car1 = "(" Then
                balance += 1
            End If
            If car1 = ")" Then
                balance -= 1
            End If
            If balance < 0 Then
                Return True
                'Si cae por debajo de cero es que el balance es erróneo
            End If
        Next
        Return False
    End Function

    '7. Un paréntesis que cierra y sigue un número o paréntesis que abre. Ejemplo: (3-5)7-(1+2)(3/6)
    Private Shared Function ParentesisCierraNumero(expr As [String]) As [Boolean]
        For pos As Integer = 0 To expr.Length - 2
            Dim car2 As Char = expr(pos + 1)
            'Extrae el siguiente carácter
            'Compara si el primer carácter es paréntesis que cierra y el siguiente es número
            If expr(pos) = ")" Then
                If car2 >= "0" AndAlso car2 <= "9" Then
                    Return True
                End If
            End If
        Next
        Return False
    End Function

    '8. Un número seguido de un paréntesis que abre. Ejemplo: 7-2(5-6)
    Private Shared Function NumeroParentesisAbre(expr As [String]) As [Boolean]
        For pos As Integer = 0 To expr.Length - 2
            Dim car1 As Char = expr(pos)
            'Extrae un carácter
            'Compara si el primer carácter es número y el siguiente es paréntesis que abre
            If car1 >= "0" AndAlso car1 <= "9" Then
                If expr(pos + 1) = "(" Then
                    Return True
                End If
            End If
        Next
        Return False
    End Function

    '9. Doble punto en un número de tipo real. Ejemplo: 3-2..4+1  7-6.46.1+2
    Private Shared Function DoblePuntoNumero(expr As [String]) As [Boolean]
        Dim totalpuntos As Integer = 0
        For pos As Integer = 0 To expr.Length - 1
            Dim car1 As Char = expr(pos)
            'Extrae un carácter
            If (car1 < "0" OrElse car1 > "9") AndAlso car1 <> "." Then
                totalpuntos = 0
            End If
            If car1 = "." Then
                totalpuntos += 1
            End If
            If totalpuntos > 1 Then
                Return True
            End If
        Next
        Return False
    End Function

    '10. Un paréntesis que cierra seguido de una variable. Ejemplo: (12-4)y-1
    Private Shared Function ParentesisCierraVariable(expr As [String]) As [Boolean]
        For pos As Integer = 0 To expr.Length - 2
            If expr(pos) = ")" Then
                'Compara si el primer carácter es paréntesis que cierra y el siguiente es letra
                If expr(pos + 1) >= "a" AndAlso expr(pos + 1) <= "z" Then
                    Return True
                End If
            End If
        Next
        Return False
    End Function

    '11. Una variable seguida de un punto. Ejemplo: 4-z.1+3
    Private Shared Function VariableluegoPunto(expr As [String]) As [Boolean]
        For pos As Integer = 0 To expr.Length - 2
            If expr(pos) >= "a" AndAlso expr(pos) <= "z" Then
                If expr(pos + 1) = "." Then
                    Return True
                End If
            End If
        Next
        Return False
    End Function

    '12. Un punto seguido de una variable. Ejemplo: 7-2.p+1
    Private Shared Function PuntoluegoVariable(expr As [String]) As [Boolean]
        For pos As Integer = 0 To expr.Length - 2
            If expr(pos) = "." Then
                If expr(pos + 1) >= "a" AndAlso expr(pos + 1) <= "z" Then
                    Return True
                End If
            End If
        Next
        Return False
    End Function

    '13. Un número antes de una variable. Ejemplo: 3x+1
    'Nota: Algebraicamente es aceptable 3x+1 pero entonces vuelve más complejo un evaluador porque debe saber que 3x+1 es en realidad 3*x+1
    Private Shared Function NumeroAntesVariable(expr As [String]) As [Boolean]
        For pos As Integer = 0 To expr.Length - 2
            If expr(pos) >= "0" AndAlso expr(pos) <= "9" Then
                If expr(pos + 1) >= "a" AndAlso expr(pos + 1) <= "z" Then
                    Return True
                End If
            End If
        Next
        Return False
    End Function

    '14. Un número después de una variable. Ejemplo: x21+4
    Private Shared Function VariableDespuesNumero(expr As [String]) As [Boolean]
        For pos As Integer = 0 To expr.Length - 2
            If expr(pos) >= "a" AndAlso expr(pos) <= "z" Then
                If expr(pos + 1) >= "0" AndAlso expr(pos + 1) <= "9" Then
                    Return True
                End If
            End If
        Next
        Return False
    End Function

    '15. Chequea si hay 4 o más letras seguidas
    Private Shared Function Chequea4letras(expr As [String]) As [Boolean]
        For pos As Integer = 0 To expr.Length - 4
            Dim car1 As Char = expr(pos)
            Dim car2 As Char = expr(pos + 1)
            Dim car3 As Char = expr(pos + 2)
            Dim car4 As Char = expr(pos + 3)

            If car1 >= "a" AndAlso car1 <= "z" AndAlso car2 >= "a" AndAlso car2 <= "z" AndAlso car3 >= "a" AndAlso car3 <= "z" AndAlso car4 >= "a" AndAlso car4 <= "z" Then
                Return True
            End If
        Next
        Return False
    End Function

    '16. Si detecta tres letras seguidas y luego un paréntesis que abre, entonces verifica si es función o no
    Private Function FuncionInvalida(expr As [String]) As [Boolean]
        For pos As Integer = 0 To expr.Length - 3
            Dim car1 As Char = expr(pos)
            Dim car2 As Char = expr(pos + 1)
            Dim car3 As Char = expr(pos + 2)

            'Si encuentra tres letras seguidas
            If car1 >= "a" AndAlso car1 <= "z" AndAlso car2 >= "a" AndAlso car2 <= "z" AndAlso car3 >= "a" AndAlso car3 <= "z" Then
                If pos >= expr.Length - 4 Then
                    Return True
                End If
                'Hay un error porque no sigue paréntesis
                If expr(pos + 3) <> "(" Then
                    Return True
                End If
                'Hay un error porque no hay paréntesis
                If FuncionInvalida(car1, car2, car3) Then
                    Return True
                End If
            End If
        Next
        Return False
    End Function

    'Chequea si las tres letras enviadas son una función
    Private Shared Function FuncionInvalida(car1 As Char, car2 As Char, car3 As Char) As [Boolean]
        Dim listafunciones As [String] = "sinsencostanabsasnacsatnlogceiexpsqrrcb"
        For pos As Integer = 0 To listafunciones.Length - 3 Step 3
            Dim listfunc1 As Char = listafunciones(pos)
            Dim listfunc2 As Char = listafunciones(pos + 1)
            Dim listfunc3 As Char = listafunciones(pos + 2)
            If car1 = listfunc1 AndAlso car2 = listfunc2 AndAlso car3 = listfunc3 Then
                Return False
            End If
        Next
        Return True
    End Function

    '17. Si detecta sólo dos letras seguidas es un error
    Private Shared Function VariableInvalida(expr As [String]) As [Boolean]
        Dim cuentaletras As Integer = 0
        For pos As Integer = 0 To expr.Length - 1
            If expr(pos) >= "a" AndAlso expr(pos) <= "z" Then
                cuentaletras += 1
            Else
                If cuentaletras = 2 Then
                    Return True
                End If
                cuentaletras = 0
            End If
        Next
        Return cuentaletras = 2
    End Function

    '18. Antes de paréntesis que abre hay una letra
    Private Shared Function VariableParentesisAbre(expr As [String]) As [Boolean]
        Dim cuentaletras As Integer = 0
        For pos As Integer = 0 To expr.Length - 1
            Dim car1 As Char = expr(pos)
            If car1 >= "a" AndAlso car1 <= "z" Then
                cuentaletras += 1
            ElseIf car1 = "(" AndAlso cuentaletras = 1 Then
                Return True
            Else
                cuentaletras = 0
            End If
        Next
        Return False
    End Function


    '19. Después de paréntesis que cierra sigue paréntesis que abre. Ejemplo: (4-5)(2*x)
    Private Shared Function ParCierraParAbre(expr As [String]) As [Boolean]
        For pos As Integer = 0 To expr.Length - 2
            If expr(pos) = ")" AndAlso expr(pos + 1) = "(" Then
                Return True
            End If
        Next
        Return False
    End Function

    '20. Después de operador sigue un punto. Ejemplo: -.3+7
    Private Shared Function OperadorPunto(expr As [String]) As [Boolean]
        For pos As Integer = 0 To expr.Length - 2
            If expr(pos) = "+" OrElse expr(pos) = "-" OrElse expr(pos) = "*" OrElse expr(pos) = "/" OrElse expr(pos) = "^" Then
                If expr(pos + 1) = "." Then
                    Return True
                End If
            End If
        Next
        Return False
    End Function

    '21. Después de paréntesis que abre sigue un punto. Ejemplo: 3*(.5+4)
    Private Shared Function ParAbrePunto(expr As [String]) As [Boolean]
        For pos As Integer = 0 To expr.Length - 2
            If expr(pos) = "(" AndAlso expr(pos + 1) = "." Then
                Return True
            End If
        Next
        Return False
    End Function

    '22. Un punto seguido de un paréntesis que abre. Ejemplo: 7+3.(2+6)
    Private Shared Function PuntoParAbre(expr As [String]) As [Boolean]
        For pos As Integer = 0 To expr.Length - 2
            If expr(pos) = "." AndAlso expr(pos + 1) = "(" Then
                Return True
            End If
        Next
        Return False
    End Function

    '23. Paréntesis cierra y sigue punto. Ejemplo: (4+5).7-2
    Private Shared Function ParCierraPunto(expr As [String]) As [Boolean]
        For pos As Integer = 0 To expr.Length - 2
            If expr(pos) = ")" AndAlso expr(pos + 1) = "." Then
                Return True
            End If
        Next
        Return False
    End Function

    '24. Punto seguido de operador. Ejemplo: 5.*9+1 
    Private Shared Function PuntoOperador(expr As [String]) As [Boolean]
        For pos As Integer = 0 To expr.Length - 2
            If expr(pos) = "." Then
                If expr(pos + 1) = "+" OrElse expr(pos + 1) = "-" OrElse expr(pos + 1) = "*" OrElse expr(pos + 1) = "/" OrElse expr(pos + 1) = "^" Then
                    Return True
                End If
            End If
        Next
        Return False
    End Function

    '25. Punto y sigue paréntesis que cierra. Ejemplo: (3+2.)*5
    Private Shared Function PuntoParCierra(expr As [String]) As [Boolean]
        For pos As Integer = 0 To expr.Length - 2
            If expr(pos) = "." AndAlso expr(pos + 1) = ")" Then
                Return True
            End If
        Next
        Return False
    End Function

    ' Convierte una expresión con el menos unario en una expresión valida para el evaluador de expresiones:
    '   * 1. Si encuentra un - al inicio le agrega un cero
    '   * 2. Si detecta un paréntesis que abre y un - entonces pone el 0 adelante
    '   * 3. Si detecta un operador y luego un menos, entonces agrega un "(0-1)#" entre esos dos
    '   

    Public Function ArreglaNegativos(expresion As [String]) As [String]
        Dim NuevaExpresion As New Text.StringBuilder()
        Dim NuevaExpresion2 As New Text.StringBuilder()

        'Si detecta un operador y luego un menos, entonces reemplaza el menos con un "(0-1)#"
        For pos As Integer = 0 To expresion.Length - 1
            Dim letra1 As Char = expresion(pos)
            If letra1 = "+" OrElse letra1 = "-" OrElse letra1 = "*" OrElse letra1 = "/" OrElse letra1 = "^" Then
                If expresion(pos + 1) = "-" Then
                    NuevaExpresion.Append(letra1).Append("(0-1)#")
                    pos += 1
                    Continue For
                End If
            End If
            NuevaExpresion.Append(letra1)
        Next

        'Si detecta un paréntesis que abre y luego un menos, entonces reemplaza el menos con un "(0-1)#"
        For pos As Integer = 0 To NuevaExpresion.Length - 1
            Dim letra1 As Char = NuevaExpresion(pos)
            If letra1 = "(" Then
                If NuevaExpresion(pos + 1) = "-" Then
                    NuevaExpresion2.Append(letra1).Append("(0-1)#")
                    pos += 1
                    Continue For
                End If
            End If
            NuevaExpresion2.Append(letra1)
        Next

        Return NuevaExpresion2.ToString()
    End Function

    'Inicializa las listas, convierte la expresión en piezas simples y luego en piezas de ejecución
    Public Sub Analizar(expresion As [String])
        PiezaSimple.Clear()
        PiezaEjecuta.Clear()
        Generar_Piezas_Simples(expresion)
        Generar_Piezas_Ejecucion()
    End Sub

    'Convierte la expresión en piezas simples: números # paréntesis # variables # operadores # funciones
    Private Sub Generar_Piezas_Simples(expresion As [String])
        Dim longExpresion As Integer = expresion.Length

        'Variables requeridas para armar un número
        Dim parteentera As Double = 0
        Dim partedecimal As Double = 0
        Dim divide As Double = 1
        Dim entero As Boolean = True
        Dim armanumero As Boolean = False

        For cont As Integer = 0 To longExpresion - 1
            'Va de letra en letra de la expresión
            Dim letra As Char = expresion(cont)
            If letra = "." Then
                'Si letra es . entonces el resto de digitos leídos son la parte decimal del número
                entero = False
            ElseIf letra >= "0" AndAlso letra <= "9" Then
                'Si es un número, entonces lo va armando
                armanumero = True
                If entero Then
                    parteentera = parteentera * 10 + Asc(letra) - ASCIINUMERO
                Else
                    'La parte entera del número 
                    divide *= 10
                    'La parte decimal del número
                    partedecimal = partedecimal * 10 + Asc(letra) - ASCIINUMERO
                End If
            Else
                If armanumero Then
                    'Si tenía armado un número, entonces crea la pieza ESNUMERO
                    PiezaSimple.Add(New Pieza_Simple(ESNUMERO, 0, "0", parteentera + partedecimal / divide, 0, 0))
                    parteentera = 0
                    partedecimal = 0
                    divide = 1
                    entero = True
                    armanumero = False
                End If

                If letra = "+" OrElse letra = "-" OrElse letra = "*" OrElse letra = "/" OrElse letra = "^" OrElse letra = "#" Then
                    PiezaSimple.Add(New Pieza_Simple(ESOPERADOR, 0, letra, 0, 0, 0))
                ElseIf letra = "(" Then
                    PiezaSimple.Add(New Pieza_Simple(ESPARABRE, 0, "0", 0, 0, 0))
                    '¿Es paréntesis que abre?
                ElseIf letra = ")" Then
                    PiezaSimple.Add(New Pieza_Simple(ESPARCIERRA, 0, "0", 0, 0, 0))
                    '¿Es paréntesis que cierra?
                ElseIf letra >= "a" AndAlso letra <= "z" Then
                    '¿Es variable o función?
                    ' Detecta si es una función porque tiene dos letras seguidas 

                    If cont < longExpresion - 1 Then
                        Dim letra2 As Char = expresion(cont + 1)
                        ' Chequea si el siguiente carácter es una letra, dado el caso es una función 
                        If letra2 >= "a" AndAlso letra2 <= "z" Then
                            Dim letra3 As Char = expresion(cont + 2)
                            Dim funcionDetectada As Integer = 1
                            ' Identifica la función 
                            For funcion As Integer = 0 To TAMANOFUNCION Step 3
                                If letra = listaFunciones(funcion) AndAlso letra2 = listaFunciones(funcion + 1) AndAlso letra3 = listaFunciones(funcion + 2) Then
                                    Exit For
                                End If
                                funcionDetectada += 1
                            Next
                            PiezaSimple.Add(New Pieza_Simple(ESFUNCION, funcionDetectada, "0", 0, 0, 0))
                            'Adiciona función a la lista
                            ' Mueve tres caracteres  sin(  [s][i][n][(] 
                            cont += 3
                        Else
                            ' Es una variable, no una función 
                            PiezaSimple.Add(New Pieza_Simple(ESVARIABLE, 0, "0", 0, Asc(letra) - ASCIILETRA, 0))
                        End If
                    Else
                        ' Es una variable, no una función 
                        PiezaSimple.Add(New Pieza_Simple(ESVARIABLE, 0, "0", 0, Asc(letra) - ASCIILETRA, 0))
                    End If
                End If
            End If
        Next
        If armanumero Then
            PiezaSimple.Add(New Pieza_Simple(ESNUMERO, 0, "0", parteentera + partedecimal / divide, 0, 0))
        End If
    End Sub

    'Toma las piezas simples y las convierte en piezas de ejecución de funciones
    'Acumula = función (operando(número/variable/acumula))
    Private Sub Generar_Piezas_Ejecucion()
        Dim cont As Integer = PiezaSimple.Count() - 1
        Contador_Acumula = 0
        Do
            If PiezaSimple(cont).getTipo() = ESPARABRE OrElse PiezaSimple(cont).getTipo() = ESFUNCION Then
                Generar_Piezas_Operador("#", "#", cont)
                'Primero evalúa los menos unarios
                Generar_Piezas_Operador("^", "^", cont)
                'Luego evalúa las potencias
                Generar_Piezas_Operador("*", "/", cont)
                'Luego evalúa multiplicar y dividir
                Generar_Piezas_Operador("+", "-", cont)
                'Finalmente evalúa sumar y restar
                'Crea pieza de ejecución
                PiezaEjecuta.Add(New Pieza_Ejecuta(PiezaSimple(cont).getFuncion(), PiezaSimple(cont + 1).getTipo(), PiezaSimple(cont + 1).getNumero(), PiezaSimple(cont + 1).getVariable(), PiezaSimple(cont + 1).getAcumula(), "+", _
                  ESNUMERO, 0, 0, 0))

                'La pieza pasa a ser de tipo Acumulador
                PiezaSimple(cont + 1).setAcumula(Contador_Acumula)
                Contador_Acumula = Contador_Acumula + 1

                'Quita el paréntesis/función que abre y el que cierra, dejando el centro
                PiezaSimple.RemoveAt(cont)
                PiezaSimple.RemoveAt(cont + 1)
            End If
            cont -= 1
        Loop While cont >= 0
    End Sub

    'Toma las piezas simples y las convierte en piezas de ejecución
    'Acumula = operando(número/variable/acumula)  operador(+, -, *, /, ^)   operando(número/variable/acumula)
    Private Sub Generar_Piezas_Operador(operA As Char, operB As Char, inicio As Integer)
        Dim cont As Integer = inicio + 1
        Do
            If PiezaSimple(cont).getTipo() = ESOPERADOR AndAlso (PiezaSimple(cont).getOperador() = operA OrElse PiezaSimple(cont).getOperador() = operB) Then
                'Crea pieza de ejecución
                PiezaEjecuta.Add(New Pieza_Ejecuta(0, PiezaSimple(cont - 1).getTipo(), PiezaSimple(cont - 1).getNumero(), PiezaSimple(cont - 1).getVariable(), PiezaSimple(cont - 1).getAcumula(), PiezaSimple(cont).getOperador(), _
                  PiezaSimple(cont + 1).getTipo(), PiezaSimple(cont + 1).getNumero(), PiezaSimple(cont + 1).getVariable(), PiezaSimple(cont + 1).getAcumula()))

                'Elimina la pieza del operador y la siguiente
                PiezaSimple.RemoveAt(cont)
                PiezaSimple.RemoveAt(cont)

                'Retorna el contador en uno para tomar la siguiente operación
                cont -= 1

                'Cambia la pieza anterior por pieza acumula
                PiezaSimple(cont).setAcumula(Contador_Acumula)
                Contador_Acumula = Contador_Acumula + 1
            End If
            cont += 1
        Loop While cont < PiezaSimple.Count() AndAlso PiezaSimple(cont).getTipo() <> ESPARCIERRA
    End Sub

    'Calcula la expresión convertida en piezas de ejecución
    Public Function Calcular() As Double
        Dim valorA As Double = 0, valorB As Double = 0
        Dim totalPiezaEjecuta As Integer = PiezaEjecuta.Count()

        For cont As Integer = 0 To totalPiezaEjecuta - 1
            Select Case PiezaEjecuta(cont).getTipoOperA()
                Case 5
                    valorA = PiezaEjecuta(cont).getNumeroA()
                    Exit Select
                    '¿Es un número?
                Case 6
                    valorA = VariableAlgebra(PiezaEjecuta(cont).getVariableA())
                    Exit Select
                    '¿Es una variable?
                Case 7
                    valorA = PiezaEjecuta(PiezaEjecuta(cont).getAcumulaA()).getValorPieza()
                    Exit Select
                    '¿Es una expresión anterior?
            End Select
            If [Double].IsNaN(valorA) OrElse [Double].IsInfinity(valorA) Then
                Return valorA
            End If

            Select Case PiezaEjecuta(cont).getFuncion()
                Case 0
                    Select Case PiezaEjecuta(cont).getTipoOperB()
                        Case 5
                            valorB = PiezaEjecuta(cont).getNumeroB()
                            Exit Select
                            '¿Es un número?
                        Case 6
                            valorB = VariableAlgebra(PiezaEjecuta(cont).getVariableB())
                            Exit Select
                            '¿Es una variable?
                        Case 7
                            valorB = PiezaEjecuta(PiezaEjecuta(cont).getAcumulaB()).getValorPieza()
                            Exit Select
                            '¿Es una expresión anterior?
                    End Select
                    If [Double].IsNaN(valorB) OrElse [Double].IsInfinity(valorB) Then
                        Return valorB
                    End If

                    Select Case PiezaEjecuta(cont).getOperador()
                        Case "#"
                            PiezaEjecuta(cont).setValorPieza(valorA * valorB)
                            Exit Select
                        Case "+"
                            PiezaEjecuta(cont).setValorPieza(valorA + valorB)
                            Exit Select
                        Case "-"
                            PiezaEjecuta(cont).setValorPieza(valorA - valorB)
                            Exit Select
                        Case "*"
                            PiezaEjecuta(cont).setValorPieza(valorA * valorB)
                            Exit Select
                        Case "/"
                            PiezaEjecuta(cont).setValorPieza(valorA / valorB)
                            Exit Select
                        Case "^"
                            PiezaEjecuta(cont).setValorPieza(Math.Pow(valorA, valorB))
                            Exit Select
                    End Select
                    Exit Select
                Case 1, 2
                    PiezaEjecuta(cont).setValorPieza(Math.Sin(valorA))
                    Exit Select
                Case 3
                    PiezaEjecuta(cont).setValorPieza(Math.Cos(valorA))
                    Exit Select
                Case 4
                    PiezaEjecuta(cont).setValorPieza(Math.Tan(valorA))
                    Exit Select
                Case 5
                    PiezaEjecuta(cont).setValorPieza(Math.Abs(valorA))
                    Exit Select
                Case 6
                    PiezaEjecuta(cont).setValorPieza(Math.Asin(valorA))
                    Exit Select
                Case 7
                    PiezaEjecuta(cont).setValorPieza(Math.Acos(valorA))
                    Exit Select
                Case 8
                    PiezaEjecuta(cont).setValorPieza(Math.Atan(valorA))
                    Exit Select
                Case 9
                    PiezaEjecuta(cont).setValorPieza(Math.Log(valorA))
                    Exit Select
                Case 10
                    PiezaEjecuta(cont).setValorPieza(Math.Ceiling(valorA))
                    Exit Select
                Case 11
                    PiezaEjecuta(cont).setValorPieza(Math.Exp(valorA))
                    Exit Select
                Case 12
                    PiezaEjecuta(cont).setValorPieza(Math.Sqrt(valorA))
                    Exit Select
                Case 13
                    PiezaEjecuta(cont).setValorPieza(Math.Pow(valorA, 0.333333333333))
                    Exit Select
            End Select
        Next
        Return PiezaEjecuta(totalPiezaEjecuta - 1).getValorPieza()
    End Function

    ' Da valor a las variables que tendrá la expresión algebraica
    Public Sub ValorVariable(variableAlg As Char, valor As Double)
        VariableAlgebra(Asc(variableAlg) - ASCIILETRA) = valor
    End Sub
End Class
