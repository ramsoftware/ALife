﻿'Autor: Rafael Alberto Moreno Parra
'Sitio Web:  http://darwin.50webs.com
'Correo:  enginelife@hotmail.com

'Evaluador de expresiones algebraicas por ejemplo, 57+1.87/84.89-(6.8*e+b+8769-4*b/8+b^2*4^e/f)+5.4-(d/9.6+0.2) con las siguientes funcionalidades:
'1. Ilimitado número de paréntesis
'2. Más rápido y más sencillo que el evaluador escrito para el primer libro: "Desarrollo de un evaluador de expresiones algebraicas"
'3. Manejo de 26 variables
'4. Manejo de 12 funciones
'5. Manejo de operadores +, -, *, /, ^ (potencia)
'6. Manejo del menos unario: lo reemplaza con (0-1)# donde # es la operación con mayor relevancia y equivale a la multiplicación

'Versión: 2.00 [Genera el libro "Desarrollo de un evaluador de expresiones algebraicas. Versión 2.0"]
'Fecha: Enero de 2013
'Licencia: LGPL

'Algoritmo:

'Se toma una expresión como 7*x+sen(12.8/y+9)-5*cos(9-(8.3/5.11^3-4.7)*7.12)+0.445
'Se agregan paréntesis de inicio y fin  (7*x+sen(12.8/y+9)-5*cos(9-(8.3/5.11^3-4.7)*7.12)+0.445)
'Se divide en piezas simples   | ( | 7 | * | x | + | sen( | 12.8 | / | y | + | 9 | ) | - | 5 | * | cos( | 9 | - | ( | 8.3 | / | 5.11 | ^ | 3 | - | 4.7 | ) | * | 7.12 | ) | + | 0.445 | ) |
'Esas piezas están clasificadas:
' Paréntesis que abre (
' Paréntesis que cierra )
' Números  7   12.8  9   5
' Variables  x  y
' Operadores + - * / ^
' Funciones  sen(  cos(
'Luego se convierte esa expresión larga en expresiones cortas de ejecución del tipo
'Acumula = operando(número/variable/acumula)  operador(+, -, *, /, ^)   operando(número/variable/acumula)
'  [0]  5.11 ^ 3
'  [1]  8.3  / [0]
'  [2]  [1] - 4.7
'  [3]  [2] + 0
'  [4]  [3] * 7,12
'  [5]  9   - [4]
'  [6]  cos([5])
'  [7]  12,8 / y
'  [8]  [7] +  9
'  [9]  sen([8])
'  [10] 7 * x
'  [11] 5 * [6]
'  [12] [10] + [9]
'  [13] [12] - [11]
'  [14] [13] + 0.445
'  [15] [14] + 0
'La expresión ya está analizada y lista para evaluar.
'Se evalúa yendo de [0] a [15], en [15] está el valor final.

Public Class Pieza_Ejecuta
    'Almacena el calculo de la operación. Es Acumula
    Private valorPieza As Double

    ' ¿Es una función? 0 no lo es. 1 es seno, 3 es coseno, ....
    Private funcion As Integer

    'Que tipo de operando es: ¿Un número, una variable o una acumulación anterior?
    Private tipo_operandoA As Integer
    Private numeroA As Double
    Private variableA As Integer
    Private acumulaA As Integer

    ' +, -, *, /, ^
    Private operador As Char

    'Que tipo de operando es: ¿Un número, una variable o una acumulación anterior?
    Private tipo_operandoB As Integer
    Private numeroB As Double
    Private variableB As Integer
    Private acumulaB As Integer

    Public Function getValorPieza() As Double
        Return Me.valorPieza
    End Function
    Public Sub setValorPieza(valor As Double)
        Me.valorPieza = valor
    End Sub
    Public Function getFuncion() As Integer
        Return Me.funcion
    End Function
    Public Function getTipoOperA() As Integer
        Return Me.tipo_operandoA
    End Function
    Public Function getNumeroA() As Double
        Return Me.numeroA
    End Function
    Public Function getVariableA() As Integer
        Return Me.variableA
    End Function
    Public Function getAcumulaA() As Integer
        Return Me.acumulaA
    End Function
    Public Function getOperador() As Char
        Return Me.operador
    End Function
    Public Function getTipoOperB() As Integer
        Return Me.tipo_operandoB
    End Function
    Public Function getNumeroB() As Double
        Return Me.numeroB
    End Function
    Public Function getVariableB() As Integer
        Return Me.variableB
    End Function
    Public Function getAcumulaB() As Integer
        Return Me.acumulaB
    End Function

    Public Sub New(funcion As Integer, tipo_operandoA As Integer, numeroA As Double, variableA As Integer, acumulaA As Integer, operador As Char, _
        tipo_operandoB As Integer, numeroB As Double, variableB As Integer, acumulaB As Integer)
        Me.valorPieza = 0

        Me.funcion = funcion

        Me.tipo_operandoA = tipo_operandoA
        Me.numeroA = numeroA
        Me.variableA = variableA
        Me.acumulaA = acumulaA

        Me.operador = operador

        Me.tipo_operandoB = tipo_operandoB
        Me.numeroB = numeroB
        Me.variableB = variableB
        Me.acumulaB = acumulaB
    End Sub
End Class
