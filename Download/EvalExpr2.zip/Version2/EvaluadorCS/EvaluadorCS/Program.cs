﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EvaluadorCS
{
  class Program
  {
    static void Main(string[] args)
    {
      Evaluar evaluadorExpresiones = new Evaluar();
      int NumPruebas = 51;

      //En este arreglo de strings guarda las diversas expresiones
      String[] exprAlgebraica = new String[NumPruebas];

      //Aquí se ponen los resultados probados con Excel o WolframAlpha para chequear que el evaluador funciona correctamente
      double[] resultado = new double[NumPruebas];
      
      //Estas expresiones presentan fallas sintácticas. Sirve para probar el chequeador de sintaxis
      exprAlgebraica[0] =  " (7*8*--3/5)/4  ";
      exprAlgebraica[1] =  " 5.31-(4.6*)+3 ";
      exprAlgebraica[2] =  " 7+3.4- ";
      exprAlgebraica[3] =  "  5-(*9.4/2)+1 ";
      exprAlgebraica[4] =  "  /5.67*12-6+4 ";
      exprAlgebraica[5] =  "  3-(2*4) ) ";
      exprAlgebraica[6] =  "  7+((4-3) ";
      exprAlgebraica[7] =  "  7- 90.87 * (   ) +9.01";
      exprAlgebraica[8] =  "  2+3)-2)*3+((4";
      exprAlgebraica[9] =  " (3-5)7-(1+2)";
      exprAlgebraica[10] =  " 7-2(5-6) + 8";
      exprAlgebraica[11] =  "  3-2..4+1 ";
      exprAlgebraica[12] =  "  2.5+78.23.1-4 ";
      exprAlgebraica[13] =  "  (12-4)y-1 ";
      exprAlgebraica[14] =  "  4-z.1+3 ";
      exprAlgebraica[15] =  " 7-2.p+1 ";
      exprAlgebraica[16] =  "  3x+1";
      exprAlgebraica[17] =  "  x21+4 ";
      exprAlgebraica[18] =  "  7+abrg-8";
      exprAlgebraica[19] =  "  5*alo(78) ";
      exprAlgebraica[20] =  "  5+tr-xc+5  ";
      exprAlgebraica[21] = "  5-a(7+3)";
      exprAlgebraica[22] = "  (4-5)(2*x) ";
      exprAlgebraica[23] = " -.3+7  ";
      exprAlgebraica[24] = " 3*(.5+4) ";
      exprAlgebraica[25] = " 7+3.(2+6) ";
      exprAlgebraica[26] = "  (4+5).7-2 ";
      exprAlgebraica[27] = " 5.*9+1  ";
      exprAlgebraica[28] = " (3+2.)*5 ";
       
      //Estas expresiones son correctas sintácticamente
      exprAlgebraica[29] = " --5 "; resultado[29] = 5;
      exprAlgebraica[30] = " -(-(-(-(-(-(-1^(-(-(-(-1))))))))))"; resultado[30] = -1;
      exprAlgebraica[31] = "  --(--(--(--(--(--(--1^(--(--(--(--1))))))))))"; resultado[31] = 1;
      exprAlgebraica[32] = " --1*-2*-3*(--4*-2/-4/-2)/-3^-1 "; resultado[32] = 18;
      exprAlgebraica[33] = " -1-(-2-(-3)) "; resultado[33] = -2;
      exprAlgebraica[34] = " -1^2-(-2^2-(-3^2)) "; resultado[34] = 6;
      exprAlgebraica[35] = " -1^-2-(-2^-2-(-3^-2)) "; resultado[35] = 0.861111111111111;
      exprAlgebraica[36] = " -1^-3-(-2^-3-(-3^-3)) "; resultado[36] = -0.912037037037037;
      exprAlgebraica[37] = " (--1) "; resultado[37] = 1;
      exprAlgebraica[38] = " --1 "; resultado[38] = 1;
      exprAlgebraica[39] = " --3--2--4--5--6 "; resultado[39] = 20;
      exprAlgebraica[40] = " --3^-2--2^-2--4^-2--5^-2--6^-2 "; resultado[40] = -0.269166666666667;
      exprAlgebraica[41] = " ((((-1)*-1)*-1)*-1) "; resultado[41] = 1;
      exprAlgebraica[42] = " 0/2/3/4/5/6/-7 "; resultado[42] = 0;
      exprAlgebraica[43] = " 0/-1 "; resultado[43] = 0;
      exprAlgebraica[44] = " --2 "; resultado[44] = 2;
      exprAlgebraica[45] = " --2^2 "; resultado[45] = 4;
      exprAlgebraica[46] = " -(-2^3) "; resultado[46] = 8;
      exprAlgebraica[47] = "  -(-2^-3)"; resultado[47] = 0.125;
      exprAlgebraica[48] = " X-(Y-(Z-(-1*X)*y)*z) "; resultado[48] = 2084;
      exprAlgebraica[49] = " ASN(-0.67)+ACS(-0.3*-0.11)+ATN(-4.5/-2.3)+EXP(-2)-SQR(9.7315)-RCB(7)+LOG(7.223) + CEI(10.1) "; resultado[49] = 9.98202019592338;
      exprAlgebraica[50] = " -SEN(-12.78)+COS(-SEN(7.1)+ABS(-4.09))+ TAN(-3.4*-5.7)+ LOG(9.12-5.89) "; resultado[50] = 0.994984132031446;


      for (int cont=0; cont < exprAlgebraica.Length; cont++)
      {
        Console.WriteLine("\n<" + cont + "> Expresion inicial es: [" + exprAlgebraica[cont] + "]");

        //Quita espacios, tabuladores, encierra en paréntesis, vuelve a minúsculas 
        String Transformado = evaluadorExpresiones.TransformaExpresion(exprAlgebraica[cont]);
        Console.WriteLine("Transformada : [" + Transformado + "]");

        //Chequea la sintaxis de la expresión
        int chequeoSintaxis = evaluadorExpresiones.EvaluaSintaxis(Transformado);
        if (chequeoSintaxis == 0)  //Si la sintaxis es correcta
        {
          //Transforma la expresión para aceptar los menos unarios agregando (0-1)#
          String ExprNegativos = evaluadorExpresiones.ArreglaNegativos(Transformado);
          Console.WriteLine("Negativos unarios: [" + ExprNegativos + "]");
          
          //Analiza la expresión
          evaluadorExpresiones.Analizar(ExprNegativos);
          
          //Da valor a las variables
          evaluadorExpresiones.ValorVariable('x', 7);
          evaluadorExpresiones.ValorVariable('y',  13);
          evaluadorExpresiones.ValorVariable('z', 19);

          //Evalúa la expresión para retornar un valor
          double valor = evaluadorExpresiones.Calcular();
          
          //Compara el valor retornado con el esperado. Si falla el evaluador, este condicional avisa
          if (Math.Abs(valor - resultado[cont])>0.01)
            Console.WriteLine("FALLA EN [" + ExprNegativos + "] Calculado: " + valor + " Esperado: " + resultado[cont]);

          //Si hay un fallo matemático se captura con este si condicional
          if (Double.IsNaN(valor) || Double.IsInfinity(valor))
            Console.WriteLine("Error matemático");
          else //No hay fallo matemático, se muestra el valor
            Console.WriteLine("Resultado es: " + valor);
        }
        else
          Console.WriteLine("La validación es: " + evaluadorExpresiones.MensajeSintaxis(chequeoSintaxis));
      }
      Console.ReadKey();
    }
  }
}
