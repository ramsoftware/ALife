﻿/*  Autor: Rafael Alberto Moreno Parra
  Sitio Web:  http://darwin.50webs.com
  Correo:  enginelife@hotmail.com

  Evaluador de expresiones algebraicas por ejemplo, 57+1.87/84.89-(6.8*e+b+8769-4*b/8+b^2*4^e/f)+5.4-(d/9.6+0.2) con las siguientes funcionalidades:
  1. Ilimitado número de paréntesis
  2. Más rápido y más sencillo que el evaluador escrito para el primer libro: "Desarrollo de un evaluador de expresiones algebraicas"
  3. Manejo de 26 variables
  4. Manejo de 12 funciones
  5. Manejo de operadores +, -, *, /, ^ (potencia)
  6. Manejo del menos unario: lo reemplaza con (0-1)# donde # es la operación con mayor relevancia y equivale a la multiplicación

  Versión: 2.00 [Genera el libro "Desarrollo de un evaluador de expresiones algebraicas. Versión 2.0"]
  Fecha: Enero de 2013
  Licencia: LGPL

  Algoritmo:

  Se toma una expresión como 7*x+sen(12.8/y+9)-5*cos(9-(8.3/5.11^3-4.7)*7.12)+0.445
  Se agregan paréntesis de inicio y fin  (7*x+sen(12.8/y+9)-5*cos(9-(8.3/5.11^3-4.7)*7.12)+0.445)
  Se divide en piezas simples   | ( | 7 | * | x | + | sen( | 12.8 | / | y | + | 9 | ) | - | 5 | * | cos( | 9 | - | ( | 8.3 | / | 5.11 | ^ | 3 | - | 4.7 | ) | * | 7.12 | ) | + | 0.445 | ) |
  Esas piezas están clasificadas:
   Paréntesis que abre (
   Paréntesis que cierra )
   Números  7   12.8  9   5
   Variables  x  y
   Operadores + - * / ^
   Funciones  sen(  cos(
  Luego se convierte esa expresión larga en expresiones cortas de ejecución del tipo
  Acumula = operando(número/variable/acumula)  operador(+, -, *, /, ^)   operando(número/variable/acumula)
    [0]  5.11 ^ 3
    [1]  8.3  / [0]
    [2]  [1] - 4.7
    [3]  [2] + 0
    [4]  [3] * 7,12
    [5]  9   - [4]
    [6]  cos([5])
    [7]  12,8 / y
    [8]  [7] +  9
    [9]  sen([8])
    [10] 7 * x
    [11] 5 * [6]
    [12] [10] + [9]
    [13] [12] - [11]
    [14] [13] + 0.445
    [15] [14] + 0
  La expresión ya está analizada y lista para evaluar.
  Se evalúa yendo de [0] a [15], en [15] está el valor final.
*/


using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EvaluadorCS
{
  class Evaluar
  {
  /* Esta constante sirve para que se reste al carácter y se obtenga el número.  Ejemplo:  '7' - ASCIINUMERO =  7 */
  private static int ASCIINUMERO = 48;

  /* Esta constante sirve para que se reste al carácter y se obtenga el número de la letra. Ejemplo:  'b' - ASCIILETRA =  1 */
  private static int ASCIILETRA = 97;

  /* Las funciones que soporta este evaluador */
  private static int TAMANOFUNCION = 39;
  private static String listaFunciones = "sinsencostanabsasnacsatnlogceiexpsqrrcb";

  /* Constantes de los diferentes tipos de datos que tendrán las piezas */
  private static int ESFUNCION = 1;
  private static int ESPARABRE = 2;
  private static int ESPARCIERRA = 3;
  private static int ESOPERADOR = 4;
  private static int ESNUMERO = 5;
  private static int ESVARIABLE = 6;

  //Listado de Piezas de análisis
  private List<Pieza_Simple> PiezaSimple = new List<Pieza_Simple>();

  //Listado de Piezas de ejecución
  private List<Pieza_Ejecuta> PiezaEjecuta = new List<Pieza_Ejecuta>();
  int Contador_Acumula = 0;

  //Almacena los valores de las 26 diferentes variables que puede tener la expresión algebraica
  private double[] VariableAlgebra = new double[26];

  //Valida la expresión algebraica
  public int EvaluaSintaxis(String expresion)
  {
    //Hace 25 pruebas de sintaxis
    if (DobleTripleOperadorSeguido(expresion)) return 1;
    if (OperadorParentesisCierra(expresion)) return 2;
    if (ParentesisAbreOperador(expresion)) return 3;
    if (ParentesisDesbalanceados(expresion)) return 4;
    if (ParentesisVacio(expresion)) return 5;
    if (ParentesisBalanceIncorrecto(expresion)) return 6;
    if (ParentesisCierraNumero(expresion)) return 7;
    if (NumeroParentesisAbre(expresion)) return 8;
    if (DoblePuntoNumero(expresion)) return 9;
    if (ParentesisCierraVariable(expresion)) return 10;
    if (VariableluegoPunto(expresion)) return 11;
    if (PuntoluegoVariable(expresion)) return 12;
    if (NumeroAntesVariable(expresion)) return 13;
    if (VariableDespuesNumero(expresion)) return 14;
    if (Chequea4letras(expresion)) return 15;
    if (FuncionInvalida(expresion)) return 16;
    if (VariableInvalida(expresion)) return 17;
    if (VariableParentesisAbre(expresion)) return 18;
    if (ParCierraParAbre(expresion)) return 19;
    if (OperadorPunto(expresion)) return 20;
    if (ParAbrePunto(expresion)) return 21;
    if (PuntoParAbre(expresion)) return 22;
    if (ParCierraPunto(expresion)) return 23;
    if (PuntoOperador(expresion)) return 24;
    if (PuntoParCierra(expresion)) return 25;

    return 0; //No se detectó error de sintaxis
  }

  //Muestra mensaje de error sintáctico
  public String MensajeSintaxis(int CodigoError)
  {
    switch(CodigoError)
    {
      case 0:  return "No se detectó error sintáctico en las 21 pruebas que se hicieron.";
      case 1:  return "1. Dos o más operadores estén seguidos. Ejemplo: 2++4, 5-*3"; 
      case 2:  return "2. Un operador seguido de un paréntesis que cierra. Ejemplo: 2-(4+)-7"; 
      case 3:  return "3. Un paréntesis que abre seguido de un operador. Ejemplo: 2-(*3)"; 
      case 4:  return "4. Que los paréntesis estén desbalanceados. Ejemplo: 3-(2*4))"; 
      case 5:  return "5. Que haya paréntesis vacío. Ejemplo: 2-()*3"; 
      case 6:  return "6. Paréntesis que abre no corresponde con el que cierra. Ejemplo: 2+3)-2*(4"; 
      case 7: return "7. Un paréntesis que cierra y sigue un número. Ejemplo: (3-5)7-(1+2)"; 
      case 8: return "8. Un número seguido de un paréntesis que abre. Ejemplo: 7-2(5-6)"; 
      case 9: return "9. Doble punto en un número de tipo real. Ejemplo: 3-2..4+1  7-6.46.1+2"; 
      case 10: return "10. Un paréntesis que cierra seguido de una variable. Ejemplo: (12-4)y-1"; 
      case 11: return "11. Una variable seguida de un punto. Ejemplo: 4-z.1+3"; 
      case 12: return "12. Un punto seguido de una variable. Ejemplo: 7-2.p+1"; 
      case 13: return "13. Un número antes de una variable. Ejemplo: 3x+1"; 
      case 14: return "14. Un número después de una variable. Ejemplo: x21+4"; 
      case 15: return "15. Hay 4 o más letras seguidas. Ejemplo: 12+ramp+8.9"; 
      case 16: return "16. Función inexistente. Ejemplo: 5*alo(78)"; 
      case 17: return "17. Variable inválida (solo pueden tener una letra). Ejemplo: 5+tr-xc+5"; 
      case 18: return "18. Variable seguida de paréntesis que abre. Ejemplo: 5-a(7+3)";
      case 19: return "19. Después de paréntesis que cierra sigue paréntesis que abre. Ejemplo: (4-5)(2*x)";
      case 20: return "20. Después de operador sigue un punto. Ejemplo: -.3+7";
      case 21: return "21. Después de paréntesis que abre sigue un punto. Ejemplo: 3*(.5+4)";
      case 22: return "22. Un punto seguido de un paréntesis que abre. Ejemplo: 7+3.(2+6)";
      case 23: return "23. Paréntesis cierra y sigue punto. Ejemplo: (4+5).7-2";
      case 24: return "24. Punto seguido de operador. Ejemplo: 5.*9+1";   
      default: return "25. Punto seguido de paréntesis que cierra. Ejemplo: (3+2.)*5";
    }
  }
  
  //Retira caracteres inválidos. Pone la expresión entre paréntesis.
  public String TransformaExpresion(String expr)
  {
    if (expr == null) return "";
    String validos = "abcdefghijklmnopqrstuvwxyz0123456789.+-*/^()";
    StringBuilder nuevaExpr = new StringBuilder();
    String expr2 = expr.ToLower();
    nuevaExpr.Append('(');
    for(int pos = 0; pos < expr2.Length; pos++)
    {
      char letra = expr2[pos];
      for(int valida = 0; valida < validos.Length; valida++)
        if (letra == validos[valida])
        {
          nuevaExpr.Append(letra);
          break;
        }
    }
    nuevaExpr.Append(')');
    return nuevaExpr.ToString();
  }  

  //1. Dos o más operadores estén seguidos. Ejemplo: 2++4, 5-*3
  private static Boolean DobleTripleOperadorSeguido(String expr)
  {
    for(int pos = 0; pos < expr.Length - 1; pos++)
    {
      char car1 = expr[pos];   //Extrae un carácter
      char car2 = expr[pos + 1]; //Extrae el siguiente carácter

      //Compara si el carácter y el siguiente son operadores, dado el caso retorna true
      if (car1 == '+' || car1 == '-' || car1 == '*' || car1 == '/' || car1 == '^')
        if (car2 == '+' || car2 == '*' || car2 == '/' || car2 == '^')
          return true;
    }

    for (int pos = 0; pos < expr.Length - 2; pos++)
    {
      char car1 = expr[pos];   //Extrae un carácter
      char car2 = expr[pos + 1]; //Extrae el siguiente carácter
      char car3 = expr[pos + 2]; //Extrae el siguiente carácter


      //Compara si el carácter y el siguiente son operadores, dado el caso retorna true
      if (car1 == '+' || car1 == '-' || car1 == '*' || car1 == '/' || car1 == '^')
        if (car2 == '+' || car2 == '-' || car2 == '*' || car2 == '/' || car2 == '^')
          if (car3 == '+' || car3 == '-' || car3 == '*' || car3 == '/' || car3 == '^')
            return true;
    }

    return false;  //No encontró doble/triple operador seguido
  }

  //2. Un operador seguido de un paréntesis que cierra. Ejemplo: 2-(4+)-7
  private static Boolean OperadorParentesisCierra(String expr)
  {
    for(int pos = 0; pos < expr.Length - 1; pos++)
    {
      char car1 = expr[pos];   //Extrae un carácter

      //Compara si el primer carácter es operador y el siguiente es paréntesis que cierra
      if (car1 == '+' || car1 == '-' || car1 == '*' || car1 == '/' || car1 == '^')
        if (expr[pos + 1] == ')') return true;
    }
    return false; //No encontró operador seguido de un paréntesis que cierra
  }

  //3. Un paréntesis que abre seguido de un operador. Ejemplo: 2-(*3)
  private static Boolean ParentesisAbreOperador(String expr)
  {
    for(int pos = 0; pos < expr.Length - 1; pos++)
    {
      char car2 = expr[pos + 1]; //Extrae el siguiente carácter

      //Compara si el primer carácter es paréntesis que abre y el siguiente es operador
      if (expr[pos] == '(')
        if (car2 == '+' || car2 == '*' || car2 == '/' || car2 == '^') return true;
    }
    return false;  //No encontró paréntesis que abre seguido de un operador
  }

  //4. Que los paréntesis estén desbalanceados. Ejemplo: 3-(2*4))
  private static Boolean ParentesisDesbalanceados(String expr)
  {
    int parabre = 0, parcierra = 0;
    for(int pos = 0; pos < expr.Length; pos++)
    {
      char car1 = expr[pos];
      if (car1 == '(') parabre++;
      if (car1 == ')') parcierra++;
    }
    return parabre != parcierra;
  }

  //5. Que haya paréntesis vacío. Ejemplo: 2-()*3
  private static Boolean ParentesisVacio(String expr)
  {
    //Compara si el primer carácter es paréntesis que abre y el siguiente es paréntesis que cierra
    for(int pos = 0; pos < expr.Length - 1; pos++)
      if (expr[pos] == '(' && expr[pos + 1] == ')') return true;
    return false;
  }

  //6. Así estén balanceados los paréntesis no corresponde el que abre con el que cierra. Ejemplo: 2+3)-2*(4
  private static Boolean ParentesisBalanceIncorrecto(String expr)
  {
    int balance = 0;
    for(int pos = 0; pos < expr.Length; pos++)
    {
      char car1 = expr[pos];   //Extrae un carácter
      if (car1 == '(') balance++;
      if (car1 == ')') balance--;
      if (balance < 0) return true; //Si cae por debajo de cero es que el balance es erróneo
    }
    return false;
  }

  //7. Un paréntesis que cierra y sigue un número o paréntesis que abre. Ejemplo: (3-5)7-(1+2)(3/6)
  private static Boolean ParentesisCierraNumero(String expr)
  {
    for(int pos = 0; pos < expr.Length - 1; pos++)
    {
      char car2 = expr[pos + 1]; //Extrae el siguiente carácter

      //Compara si el primer carácter es paréntesis que cierra y el siguiente es número
      if (expr[pos] == ')')
        if (car2 >= '0' && car2 <= '9') return true;
    }
    return false;
  }

  //8. Un número seguido de un paréntesis que abre. Ejemplo: 7-2(5-6)
  private static Boolean NumeroParentesisAbre(String expr)
  {
    for(int pos = 0; pos < expr.Length - 1; pos++)
    {
      char car1 = expr[pos];   //Extrae un carácter

      //Compara si el primer carácter es número y el siguiente es paréntesis que abre
      if (car1 >= '0' && car1 <= '9')
        if (expr[pos + 1] == '(') return true;
    }
    return false;
  }

  //9. Doble punto en un número de tipo real. Ejemplo: 3-2..4+1  7-6.46.1+2
  private static Boolean DoblePuntoNumero(String expr)
  {
    int totalpuntos = 0;
    for(int pos = 0; pos < expr.Length; pos++)
    {
      char car1 = expr[pos];   //Extrae un carácter
      if ((car1 < '0' || car1 > '9') && car1 != '.') totalpuntos = 0;
      if (car1 == '.') totalpuntos++;
      if (totalpuntos > 1) return true;
    }
    return false;
  }

  //10. Un paréntesis que cierra seguido de una variable. Ejemplo: (12-4)y-1
  private static Boolean ParentesisCierraVariable(String expr)
  {
    for(int pos = 0; pos < expr.Length - 1; pos++)
      if (expr[pos] == ')') //Compara si el primer carácter es paréntesis que cierra y el siguiente es letra
        if (expr[pos + 1] >= 'a' && expr[pos + 1] <= 'z')
          return true;
    return false;
  }

  //11. Una variable seguida de un punto. Ejemplo: 4-z.1+3
  private static Boolean VariableluegoPunto(String expr)
  {
    for(int pos = 0; pos < expr.Length - 1; pos++)
      if (expr[pos] >= 'a' && expr[pos] <= 'z')
        if (expr[pos + 1] == '.') return true;
    return false;
  }

  //12. Un punto seguido de una variable. Ejemplo: 7-2.p+1
  private static Boolean PuntoluegoVariable(String expr)
  {
    for(int pos = 0; pos < expr.Length - 1; pos++)
      if (expr[pos] == '.')
        if (expr[pos + 1] >= 'a' && expr[pos + 1] <= 'z')
          return true;
    return false;
  }

  //13. Un número antes de una variable. Ejemplo: 3x+1
  //Nota: Algebraicamente es aceptable 3x+1 pero entonces vuelve más complejo un evaluador porque debe saber que 3x+1 es en realidad 3*x+1
  private static Boolean NumeroAntesVariable(String expr)
  {
    for(int pos = 0; pos < expr.Length - 1; pos++)
      if (expr[pos] >= '0' && expr[pos] <= '9')
        if (expr[pos + 1] >= 'a' && expr[pos + 1] <= 'z')
          return true;
    return false;
  }

  //14. Un número después de una variable. Ejemplo: x21+4
  private static Boolean VariableDespuesNumero(String expr)
  {
    for(int pos = 0; pos < expr.Length - 1; pos++)
      if (expr[pos] >= 'a' && expr[pos] <= 'z')
        if (expr[pos + 1] >= '0' && expr[pos + 1] <= '9')
          return true;
    return false;
  }

  //15. Chequea si hay 4 o más letras seguidas
  private static Boolean Chequea4letras(String expr)
  {
    for(int pos = 0; pos < expr.Length - 3; pos++)
    {
      char car1 = expr[pos];
      char car2 = expr[pos + 1];
      char car3 = expr[pos + 2];
      char car4 = expr[pos + 3];

      if (car1 >= 'a' && car1 <= 'z' && car2 >= 'a' && car2 <= 'z' && car3 >= 'a' && car3 <= 'z' && car4 >= 'a' && car4 <= 'z')
        return true;
    }
    return false;
  }

  //16. Si detecta tres letras seguidas y luego un paréntesis que abre, entonces verifica si es función o no
  private Boolean FuncionInvalida(String expr)
  {
    for(int pos = 0; pos < expr.Length - 2; pos++)
    {
      char car1 = expr[pos];
      char car2 = expr[pos + 1];
      char car3 = expr[pos + 2];

      //Si encuentra tres letras seguidas
      if (car1 >= 'a' && car1 <= 'z' && car2 >= 'a' && car2 <= 'z' && car3 >= 'a' && car3 <= 'z')
      {
        if (pos >= expr.Length - 4) return true; //Hay un error porque no sigue paréntesis
        if (expr[pos + 3] != '(') return true; //Hay un error porque no hay paréntesis
        if (FuncionInvalida(car1, car2, car3)) return true;
      }
    }
    return false;
  }

  //Chequea si las tres letras enviadas son una función
  private static Boolean FuncionInvalida(char car1, char car2, char car3)
  {
    String listafunciones = "sinsencostanabsasnacsatnlogceiexpsqrrcb";
    for(int pos = 0; pos <= listafunciones.Length - 3; pos+=3)
    {
      char listfunc1 = listafunciones[pos];
      char listfunc2 = listafunciones[pos + 1];
      char listfunc3 = listafunciones[pos + 2];
      if (car1 == listfunc1 && car2 == listfunc2 && car3 == listfunc3) return false;
    }
    return true;
  }

  //17. Si detecta sólo dos letras seguidas es un error
  private static Boolean VariableInvalida(String expr)
  {
    int cuentaletras = 0;
    for(int pos = 0; pos < expr.Length; pos++)
    {
      if (expr[pos] >= 'a' && expr[pos] <= 'z')
        cuentaletras++;
      else
      {
        if (cuentaletras == 2) return true;
        cuentaletras = 0;
      }
    }
    return cuentaletras == 2;
  }

  //18. Antes de paréntesis que abre hay una letra
  private static Boolean VariableParentesisAbre(String expr)
  {
    int cuentaletras = 0;
    for(int pos = 0; pos < expr.Length; pos++)
    {
      char car1 = expr[pos];
      if (car1 >= 'a' && car1 <= 'z')
        cuentaletras++;
      else if (car1 == '(' && cuentaletras == 1)
        return true;
      else
        cuentaletras = 0;
    }
    return false;
  }
  
          
  //19. Después de paréntesis que cierra sigue paréntesis que abre. Ejemplo: (4-5)(2*x)
  private static Boolean ParCierraParAbre(String expr)
  {
      for (int pos = 0; pos < expr.Length-1; pos++)
          if (expr[pos]==')' && expr[pos+1]=='(')
              return true;
      return false;
  }
  
  //20. Después de operador sigue un punto. Ejemplo: -.3+7
  private static Boolean OperadorPunto(String expr)
  {
      for (int pos = 0; pos < expr.Length-1; pos++)
          if (expr[pos]=='+' || expr[pos]=='-' || expr[pos]=='*' || expr[pos]=='/' || expr[pos]=='^')
                  if (expr[pos+1]=='.')
                    return true;
      return false;
  }
  
  //21. Después de paréntesis que abre sigue un punto. Ejemplo: 3*(.5+4)
  private static Boolean ParAbrePunto(String expr)
  {
      for (int pos = 0; pos < expr.Length-1; pos++)
          if (expr[pos]=='(' && expr[pos+1]=='.')
              return true;
      return false;
  }  
  
  //22. Un punto seguido de un paréntesis que abre. Ejemplo: 7+3.(2+6)
  private static Boolean PuntoParAbre(String expr)
  {
      for (int pos = 0; pos < expr.Length-1; pos++)
          if (expr[pos]=='.' && expr[pos+1]=='(')
              return true;
      return false;
  }  
  
  //23. Paréntesis cierra y sigue punto. Ejemplo: (4+5).7-2
  private static Boolean ParCierraPunto(String expr)
  {
      for (int pos = 0; pos < expr.Length-1; pos++)
          if (expr[pos]==')' && expr[pos+1]=='.')
              return true;
      return false;
  }  
  
  //24. Punto seguido de operador. Ejemplo: 5.*9+1 
  private static Boolean PuntoOperador(String expr)
  {
      for (int pos = 0; pos < expr.Length-1; pos++)
          if (expr[pos]=='.')
            if (expr[pos+1]=='+' || expr[pos+1]=='-' || expr[pos+1]=='*' || expr[pos+1]=='/' || expr[pos+1]=='^')
                    return true;
      return false;
  }
  
  //25. Punto y sigue paréntesis que cierra. Ejemplo: (3+2.)*5
  private static Boolean PuntoParCierra(String expr)
  {
      for (int pos = 0; pos < expr.Length-1; pos++)
          if (expr[pos]=='.' && expr[pos+1]==')')
              return true;
      return false;
  }   

  /* Convierte una expresión con el menos unario en una expresión valida para el evaluador de expresiones:
   * 1. Si encuentra un - al inicio le agrega un cero
   * 2. Si detecta un paréntesis que abre y un - entonces pone el 0 adelante
   * 3. Si detecta un operador y luego un menos, entonces agrega un "(0-1)#" entre esos dos
   */
  public String ArreglaNegativos(String expresion)
  {
    StringBuilder NuevaExpresion = new StringBuilder();
    StringBuilder NuevaExpresion2 = new StringBuilder();

    //Si detecta un operador y luego un menos, entonces reemplaza el menos con un "(0-1)#"
    for (int pos=0; pos<expresion.Length; pos++)
    {
      char letra1 = expresion[pos];
      if (letra1=='+' || letra1=='-' || letra1=='*' || letra1=='/' || letra1=='^')
        if (expresion[pos+1]=='-')
        {
          NuevaExpresion.Append(letra1).Append("(0-1)#");
          pos++;
          continue;
        }
      NuevaExpresion.Append(letra1);
    }
    
    //Si detecta un paréntesis que abre y luego un menos, entonces reemplaza el menos con un "(0-1)#"
    for (int pos=0; pos<NuevaExpresion.Length; pos++)
    {
      char letra1 = NuevaExpresion[pos];
      if (letra1=='(')
        if (NuevaExpresion[pos+1]=='-')
        {
          NuevaExpresion2.Append(letra1).Append("(0-1)#");
          pos++;
          continue;
        }
      NuevaExpresion2.Append(letra1);
    }    
    
    return NuevaExpresion2.ToString();
  }


  //Inicializa las listas, convierte la expresión en piezas simples y luego en piezas de ejecución
  public void Analizar(String expresion)
  {
    PiezaSimple.Clear();
    PiezaEjecuta.Clear();
    Generar_Piezas_Simples(expresion);
    Generar_Piezas_Ejecucion();
  }

  //Convierte la expresión en piezas simples: números # paréntesis # variables # operadores # funciones
  private void Generar_Piezas_Simples(String expresion)
  {
    int longExpresion = expresion.Length;

    //Variables requeridas para armar un número
    double parteentera = 0;
    double partedecimal = 0;
    double divide = 1;
    bool entero = true;
    bool armanumero = false;

    for (int cont = 0; cont < longExpresion; cont++) //Va de letra en letra de la expresión
    {
      char letra = expresion[cont];
      if (letra == '.')  //Si letra es . entonces el resto de digitos leídos son la parte decimal del número
        entero = false;
      else if (letra >= '0' && letra <= '9')  //Si es un número, entonces lo va armando
      {
        armanumero = true;
        if (entero)
          parteentera = parteentera * 10 + letra - ASCIINUMERO; //La parte entera del número 
        else
        {
          divide *= 10;
          partedecimal = partedecimal * 10 + letra - ASCIINUMERO; //La parte decimal del número
        }
      }
      else
      {
        if (armanumero) //Si tenía armado un número, entonces crea la pieza ESNUMERO
        {
          PiezaSimple.Add(new Pieza_Simple(ESNUMERO, 0, '0', parteentera+partedecimal/divide, 0, 0));
          parteentera = 0;
          partedecimal = 0;      
          divide = 1;
          entero = true;
          armanumero = false;
        }
      
        if (letra == '+' || letra == '-' || letra == '*' || letra == '/' || letra == '^' || letra == '#') PiezaSimple.Add(new Pieza_Simple(ESOPERADOR, 0, letra, 0, 0, 0));
        else if (letra == '(') PiezaSimple.Add(new Pieza_Simple(ESPARABRE, 0, '0', 0, 0, 0)); //¿Es paréntesis que abre?
        else if (letra == ')') PiezaSimple.Add(new Pieza_Simple(ESPARCIERRA, 0, '0', 0, 0, 0));//¿Es paréntesis que cierra?
        else if (letra >= 'a' && letra <= 'z') //¿Es variable o función?
        {
          /* Detecta si es una función porque tiene dos letras seguidas */
          if (cont < longExpresion - 1)
          {
            char letra2 = expresion[cont + 1]; /* Chequea si el siguiente carácter es una letra, dado el caso es una función */
            if (letra2 >= 'a' && letra2 <= 'z')
            {
              char letra3 = expresion[cont + 2];
              int funcionDetectada = 1;  /* Identifica la función */
              for (int funcion = 0; funcion <= TAMANOFUNCION; funcion += 3)
              {
                if (letra == listaFunciones[funcion]
                   && letra2 == listaFunciones[funcion + 1]
                   && letra3 == listaFunciones[funcion + 2])
                   break;
                funcionDetectada++;
              }
              PiezaSimple.Add(new Pieza_Simple(ESFUNCION, funcionDetectada, '0', 0, 0, 0));  //Adiciona función a la lista
              cont += 3; /* Mueve tres caracteres  sin(  [s][i][n][(] */
            }
            else /* Es una variable, no una función */
               PiezaSimple.Add(new Pieza_Simple(ESVARIABLE, 0, '0', 0, letra - ASCIILETRA, 0));
          }
          else /* Es una variable, no una función */
            PiezaSimple.Add(new Pieza_Simple(ESVARIABLE, 0, '0', 0, letra - ASCIILETRA, 0));
        }
      }
    }
    if (armanumero) PiezaSimple.Add(new Pieza_Simple(ESNUMERO, 0, '0', parteentera+partedecimal/divide, 0, 0));
  }

  //Toma las piezas simples y las convierte en piezas de ejecución de funciones
  //Acumula = función (operando(número/variable/acumula))
  private void Generar_Piezas_Ejecucion()
  {
    int cont = PiezaSimple.Count()-1;
    Contador_Acumula = 0;
    do
    {
      if (PiezaSimple[cont].getTipo() == ESPARABRE || PiezaSimple[cont].getTipo() == ESFUNCION)
      {
        Generar_Piezas_Operador('#', '#', cont);  //Primero evalúa los menos unarios
        Generar_Piezas_Operador('^', '^', cont);  //Luego evalúa las potencias
        Generar_Piezas_Operador('*', '/', cont);  //Luego evalúa multiplicar y dividir
        Generar_Piezas_Operador('+', '-', cont);  //Finalmente evalúa sumar y restar

        //Crea pieza de ejecución
        PiezaEjecuta.Add(new Pieza_Ejecuta(PiezaSimple[cont].getFuncion(),
           PiezaSimple[cont + 1].getTipo(), PiezaSimple[cont + 1].getNumero(), PiezaSimple[cont + 1].getVariable(), PiezaSimple[cont + 1].getAcumula(),
           '+', ESNUMERO, 0, 0, 0));

        //La pieza pasa a ser de tipo Acumulador
        PiezaSimple[cont + 1].setAcumula(Contador_Acumula++);

        //Quita el paréntesis/función que abre y el que cierra, dejando el centro
        PiezaSimple.RemoveAt(cont);
        PiezaSimple.RemoveAt(cont + 1);
      }
      cont--;
    }while (cont>=0);
  }

  //Toma las piezas simples y las convierte en piezas de ejecución
  //Acumula = operando(número/variable/acumula)  operador(+, -, *, /, ^)   operando(número/variable/acumula)
  private void Generar_Piezas_Operador(char operA, char operB, int inicio)
  {
    int cont = inicio + 1;
    do
    {
      if (PiezaSimple[cont].getTipo() == ESOPERADOR && (PiezaSimple[cont].getOperador() == operA || PiezaSimple[cont].getOperador() == operB))
      {
        //Crea pieza de ejecución
        PiezaEjecuta.Add(new Pieza_Ejecuta(0,
           PiezaSimple[cont - 1].getTipo(),
           PiezaSimple[cont - 1].getNumero(), PiezaSimple[cont - 1].getVariable(), PiezaSimple[cont - 1].getAcumula(),
           PiezaSimple[cont].getOperador(),
           PiezaSimple[cont + 1].getTipo(),
           PiezaSimple[cont + 1].getNumero(), PiezaSimple[cont + 1].getVariable(), PiezaSimple[cont + 1].getAcumula()));

        //Elimina la pieza del operador y la siguiente
        PiezaSimple.RemoveAt(cont);
        PiezaSimple.RemoveAt(cont);

        //Retorna el contador en uno para tomar la siguiente operación
        cont--;

        //Cambia la pieza anterior por pieza acumula
        PiezaSimple[cont].setAcumula(Contador_Acumula++);
      }
      cont++;
    } while (cont < PiezaSimple.Count() && PiezaSimple[cont].getTipo() != ESPARCIERRA);
  }

  //Calcula la expresión convertida en piezas de ejecución
  public double Calcular()
  {
    double valorA=0, valorB=0;
    int totalPiezaEjecuta = PiezaEjecuta.Count();

    for (int cont = 0; cont < totalPiezaEjecuta; cont++)
    {
      switch (PiezaEjecuta[cont].getTipoOperA())
      {
        case 5: valorA = PiezaEjecuta[cont].getNumeroA(); break; //¿Es un número?
        case 6: valorA = VariableAlgebra[PiezaEjecuta[cont].getVariableA()]; break;  //¿Es una variable?
        case 7: valorA = PiezaEjecuta[PiezaEjecuta[cont].getAcumulaA()].getValorPieza(); break; //¿Es una expresión anterior?
      }
      if (Double.IsNaN(valorA) || Double.IsInfinity(valorA)) return valorA;

      switch (PiezaEjecuta[cont].getFuncion())
      {
        case 0:
          switch (PiezaEjecuta[cont].getTipoOperB())
          {
            case 5: valorB = PiezaEjecuta[cont].getNumeroB(); break; //¿Es un número?
            case 6: valorB = VariableAlgebra[PiezaEjecuta[cont].getVariableB()]; break;  //¿Es una variable?
            case 7: valorB = PiezaEjecuta[PiezaEjecuta[cont].getAcumulaB()].getValorPieza(); break; //¿Es una expresión anterior?
          }
          if (Double.IsNaN(valorB) || Double.IsInfinity(valorB)) return valorB;

          switch (PiezaEjecuta[cont].getOperador())
          {
            case '#': PiezaEjecuta[cont].setValorPieza(valorA * valorB); break;
            case '+': PiezaEjecuta[cont].setValorPieza(valorA + valorB); break;
            case '-': PiezaEjecuta[cont].setValorPieza(valorA - valorB); break;
            case '*': PiezaEjecuta[cont].setValorPieza(valorA * valorB); break;
            case '/': PiezaEjecuta[cont].setValorPieza(valorA / valorB); break;
            case '^': PiezaEjecuta[cont].setValorPieza(Math.Pow(valorA, valorB)); break;
          }
        break;
        case 1:
        case 2: PiezaEjecuta[cont].setValorPieza(Math.Sin(valorA)); break;
        case 3: PiezaEjecuta[cont].setValorPieza(Math.Cos(valorA)); break;
        case 4: PiezaEjecuta[cont].setValorPieza(Math.Tan(valorA)); break;
        case 5: PiezaEjecuta[cont].setValorPieza(Math.Abs(valorA)); break;
        case 6: PiezaEjecuta[cont].setValorPieza(Math.Asin(valorA)); break;
        case 7: PiezaEjecuta[cont].setValorPieza(Math.Acos(valorA)); break;
        case 8: PiezaEjecuta[cont].setValorPieza(Math.Atan(valorA)); break;       
        case 9: PiezaEjecuta[cont].setValorPieza(Math.Log(valorA)); break;
        case 10: PiezaEjecuta[cont].setValorPieza(Math.Ceiling(valorA)); break;
        case 11: PiezaEjecuta[cont].setValorPieza(Math.Exp(valorA)); break;
        case 12: PiezaEjecuta[cont].setValorPieza(Math.Sqrt(valorA)); break;
        case 13: PiezaEjecuta[cont].setValorPieza(Math.Pow(valorA, 0.333333333333)); break;
      }
    }
    return PiezaEjecuta[totalPiezaEjecuta - 1].getValorPieza();
  }

  // Da valor a las variables que tendrá la expresión algebraica
  public void ValorVariable(char variableAlg, double valor)
  {
     VariableAlgebra[variableAlg - ASCIILETRA] = valor;
  }
 }
}
