#include <stdio.h>
#include <string.h>
#include <math.h>
#include "Evaluar.h"

int main(void);

int main()
{
      Evaluar evaluadorExpresiones;

      //En este arreglo de strings guarda las diversas expresiones
      char exprAlgebraica[51][200];
      
      //Aqu� se ponen los resultados probados con Excel o WolframAlpha para chequear que el evaluador funciona correctamente
      double resultado[51];

      //Estas expresiones presentan fallas sint�cticas. Sirve para probar el chequeador de sintaxis
      strcpy(exprAlgebraica[0], " (7*8*--3/5)/4  ");
      strcpy(exprAlgebraica[1], " 5.31-(4.6*)+3 ");
      strcpy(exprAlgebraica[2], " 7+3.4- ");
      strcpy(exprAlgebraica[3], "  5-(*9.4/2)+1 ");
      strcpy(exprAlgebraica[4],  "  /5.67*12-6+4 ");
      strcpy(exprAlgebraica[5],  "  3-(2*4) ) ");
      strcpy(exprAlgebraica[6],  "  7+((4-3) ");
      strcpy(exprAlgebraica[7],  "  7- 90.87 * (   ) +9.01");
      strcpy(exprAlgebraica[8],  "  2+3)-2)*3+((4");
      strcpy(exprAlgebraica[9],  " (3-5)7-(1+2)");
      strcpy(exprAlgebraica[10],  " 7-2(5-6) + 8");
      strcpy(exprAlgebraica[11],  "  3-2..4+1 ");
      strcpy(exprAlgebraica[12],  "  2.5+78.23.1-4 ");
      strcpy(exprAlgebraica[13],  "  (12-4)y-1 ");
      strcpy(exprAlgebraica[14],  "  4-z.1+3 ");
      strcpy(exprAlgebraica[15],  " 7-2.p+1 ");
      strcpy(exprAlgebraica[16],  "  3x+1");
      strcpy(exprAlgebraica[17],  "  x21+4 ");
      strcpy(exprAlgebraica[18],  "  7+abrg-8");
      strcpy(exprAlgebraica[19],  "  5*alo(78) ");
      strcpy(exprAlgebraica[20],  "  5+tr-xc+5  ");
      strcpy(exprAlgebraica[21], "  5-a(7+3)");
      strcpy(exprAlgebraica[22], "  (4-5)(2*x) ");
      strcpy(exprAlgebraica[23], " -.3+7  ");
      strcpy(exprAlgebraica[24], " 3*(.5+4) ");
      strcpy(exprAlgebraica[25], " 7+3.(2+6) ");
      strcpy(exprAlgebraica[26], "  (4+5).7-2 ");
      strcpy(exprAlgebraica[27], " 5.*9+1  ");
      strcpy(exprAlgebraica[28], " (3+2.)*5 ");

      //Estas expresiones son correctas sint�cticamente
      strcpy(exprAlgebraica[29], " --5 "); resultado[29] = 5;
      strcpy(exprAlgebraica[30], " -(-(-(-(-(-(-1^(-(-(-(-1))))))))))"); resultado[30] = -1;
      strcpy(exprAlgebraica[31], "  --(--(--(--(--(--(--1^(--(--(--(--1))))))))))"); resultado[31] = 1;
      strcpy(exprAlgebraica[32], " --1*-2*-3*(--4*-2/-4/-2)/-3^-1 "); resultado[32] = 18;
      strcpy(exprAlgebraica[33], " -1-(-2-(-3)) "); resultado[33] = -2;
      strcpy(exprAlgebraica[34], " -1^2-(-2^2-(-3^2)) "); resultado[34] = 6;
      strcpy(exprAlgebraica[35], " -1^-2-(-2^-2-(-3^-2)) "); resultado[35] = 0.861111111111111;
      strcpy(exprAlgebraica[36], " -1^-3-(-2^-3-(-3^-3)) "); resultado[36] = -0.912037037037037;
      strcpy(exprAlgebraica[37], " (--1) "); resultado[37] = 1;
      strcpy(exprAlgebraica[38], " --1 "); resultado[38] = 1;
      strcpy(exprAlgebraica[39], " --3--2--4--5--6 "); resultado[39] = 20;
      strcpy(exprAlgebraica[40], " --3^-2--2^-2--4^-2--5^-2--6^-2 "); resultado[40] = -0.269166666666667;
      strcpy(exprAlgebraica[41], " ((((-1)*-1)*-1)*-1) "); resultado[41] = 1;
      strcpy(exprAlgebraica[42], " 0/2/3/4/5/6/-7 "); resultado[42] = 0;
      strcpy(exprAlgebraica[43], " 0/-1 "); resultado[43] = 0;
      strcpy(exprAlgebraica[44], " --2 "); resultado[44] = 2;
      strcpy(exprAlgebraica[45], " --2^2 "); resultado[45] = 4;
      strcpy(exprAlgebraica[46], " -(-2^3) "); resultado[46] = 8;
      strcpy(exprAlgebraica[47], "  -(-2^-3)"); resultado[47] = 0.125;
      strcpy(exprAlgebraica[48], " X-(Y-(Z-(-1*X)*y)*z) "); resultado[48] = 2084;
      strcpy(exprAlgebraica[49], " ASN(-0.67)+ACS(-0.3*-0.11)+ATN(-4.5/-2.3)+EXP(-2)-SQR(9.7315)-RCB(7)+LOG(7.223) + CEI(10.1) "); resultado[49] = 9.98202019592338;
      strcpy(exprAlgebraica[50], " -SEN(-12.78)+COS(-SEN(7.1)+ABS(-4.09))+ TAN(-3.4*-5.7)+ LOG(9.12-5.89) "); resultado[50] = 0.994984132031446;

      char Transformado[200], ExprNegativos[200], Mensaje[200];

      for (int cont=0; cont < 51; cont++)
      {
        for (int inicializa=0; inicializa<200; inicializa++) { Transformado[inicializa] = '\0'; ExprNegativos[inicializa] = '\0'; Mensaje[inicializa] = '\0'; }

        printf("\n<%d>Expresi�n inicial es : [%s]\n", cont, exprAlgebraica[cont]);
        
        //Quita espacios, tabuladores, encierra en par�ntesis, vuelve a min�sculas 
        evaluadorExpresiones.TransformaExpresion(Transformado, exprAlgebraica[cont]);
        printf("Transformada: [%s]\n", Transformado);
        
        //Chequea la sintaxis de la expresi�n
        int chequeoSintaxis = evaluadorExpresiones.EvaluaSintaxis(Transformado);
        if (chequeoSintaxis == 0) //Si la sintaxis es correcta
        {
          //Transforma la expresi�n para aceptar los menos unarios agregando (0-1)#
          if (evaluadorExpresiones.ArreglaNegativos(ExprNegativos, Transformado) == -1)
          {
            printf("Fallo en reserva de memoria para convertir negativos\n");
            exit(0);
          }
          printf("Negativos unarios: [%s]\n", ExprNegativos);
          
          //Analiza la expresi�n
          evaluadorExpresiones.Analizar(ExprNegativos);
          
          //Da valor a las variables
          evaluadorExpresiones.ValorVariable('x', 7);
          evaluadorExpresiones.ValorVariable('y', 13);
          evaluadorExpresiones.ValorVariable('z', 19);

          //Eval�a la expresi�n para retornar un valor
          double valor = evaluadorExpresiones.Calcular();
          
          //Compara el valor retornado con el esperado. Si falla el evaluador, este si condicional avisa
          if (abs(valor - resultado[cont])>0.01)
            printf("FALLA EN [%s] Calculado: %f Esperado: %f\n", ExprNegativos, valor, resultado[cont]);
            
          //Si hay un fallo matem�tico se captura con este si condicional
          if (_isnan(valor) || !_finite(valor))
            printf("Error matem�tico\n");
          else //No hay fallo matem�tico, se muestra el valor
            printf("Resultado es: %f\n", valor);
        }
        else
        {
          evaluadorExpresiones.MensajeSintaxis(chequeoSintaxis, Mensaje);
          printf("La validaci�n es: %s\n", Mensaje);
        }
      }
  getchar();
  return 0;
}