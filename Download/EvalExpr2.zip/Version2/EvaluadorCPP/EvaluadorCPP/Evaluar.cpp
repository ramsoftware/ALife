/*  Autor: Rafael Alberto Moreno Parra
  Sitio Web:  http://darwin.50webs.com
  Correo:  enginelife@hotmail.com

  Evaluador de expresiones algebraicas por ejemplo, 57+1.87/84.89-(6.8*e+b+8769-4*b/8+b^2*4^e/f)+5.4-(d/9.6+0.2) con las siguientes funcionalidades:
  1. Ilimitado n�mero de par�ntesis
  2. M�s r�pido y m�s sencillo que el evaluador escrito para el primer libro: "Desarrollo de un evaluador de expresiones algebraicas"
  3. Manejo de 26 variables
  4. Manejo de 12 funciones
  5. Manejo de operadores +, -, *, /, ^ (potencia)
  6. Manejo del menos unario: lo reemplaza con (0-1)# donde # es la operaci�n con mayor relevancia y equivale a la multiplicaci�n

  Versi�n: 2.00 [Genera el libro "Desarrollo de un evaluador de expresiones algebraicas. Versi�n 2.0"]
  Fecha: Enero de 2013
  Licencia: LGPL

  Algoritmo:

  Se toma una expresi�n como 7*x+sen(12.8/y+9)-5*cos(9-(8.3/5.11^3-4.7)*7.12)+0.445
  Se agregan par�ntesis de inicio y fin  (7*x+sen(12.8/y+9)-5*cos(9-(8.3/5.11^3-4.7)*7.12)+0.445)
  Se divide en piezas simples   | ( | 7 | * | x | + | sen( | 12.8 | / | y | + | 9 | ) | - | 5 | * | cos( | 9 | - | ( | 8.3 | / | 5.11 | ^ | 3 | - | 4.7 | ) | * | 7.12 | ) | + | 0.445 | ) |
  Esas piezas est�n clasificadas:
   Par�ntesis que abre (
   Par�ntesis que cierra )
   N�meros  7   12.8  9   5
   Variables  x  y
   Operadores + - * / ^
   Funciones  sen(  cos(
  Luego se convierte esa expresi�n larga en expresiones cortas de ejecuci�n del tipo
  Acumula = operando(n�mero/variable/acumula)  operador(+, -, *, /, ^)   operando(n�mero/variable/acumula)
    [0]  5.11 ^ 3
    [1]  8.3  / [0]
    [2]  [1] - 4.7
    [3]  [2] + 0
    [4]  [3] * 7,12
    [5]  9   - [4]
    [6]  cos([5])
    [7]  12,8 / y
    [8]  [7] +  9
    [9]  sen([8])
    [10] 7 * x
    [11] 5 * [6]
    [12] [10] + [9]
    [13] [12] - [11]
    [14] [13] + 0.445
    [15] [14] + 0
  La expresi�n ya est� analizada y lista para evaluar.
  Se eval�a yendo de [0] a [15], en [15] est� el valor final.
*/
#include "Evaluar.h"
#include <string.h>
#include <math.h>

const char *Evaluar::listaFunciones = "sinsencostanabsasnacsatnlogceiexpsqrrcb";

//Valida la expresi�n algebraica 
int Evaluar::EvaluaSintaxis(char *expresion)
{
    //Hace 25 pruebas de sintaxis
    if (DobleTripleOperadorSeguido(expresion)) return 1; 
    if (OperadorParentesisCierra(expresion)) return 2; 
    if (ParentesisAbreOperador(expresion)) return 3; 
    if (ParentesisDesbalanceados(expresion)) return 4; 
    if (ParentesisVacio(expresion)) return 5; 
    if (ParentesisBalanceIncorrecto(expresion)) return 6; 
    if (ParentesisCierraNumero(expresion)) return 7; 
    if (NumeroParentesisAbre(expresion)) return 8; 
    if (DoblePuntoNumero(expresion)) return 9; 
    if (ParentesisCierraVariable(expresion)) return 10; 
    if (VariableluegoPunto(expresion)) return 11; 
    if (PuntoluegoVariable(expresion)) return 12; 
    if (NumeroAntesVariable(expresion)) return 13; 
    if (VariableDespuesNumero(expresion)) return 14; 
    if (Chequea4letras(expresion)) return 15; 
    if (FuncionInvalida(expresion)) return 16; 
    if (VariableInvalida(expresion)) return 17; 
    if (VariableParentesisAbre(expresion)) return 18;
    if (ParCierraParAbre(expresion)) return 19;
    if (OperadorPunto(expresion)) return 20;
    if (ParAbrePunto(expresion)) return 21;
    if (PuntoParAbre(expresion)) return 22;
    if (ParCierraPunto(expresion)) return 23;
    if (PuntoOperador(expresion)) return 24;
    if (PuntoParCierra(expresion)) return 25;

    //No se detect� error de sintaxis
    return 0;
}

//Muestra mensaje de error sint�ctico
void Evaluar::MensajeSintaxis(int CodigoError, char *mensaje)
{
    switch(CodigoError)
    {
      case 0:  strcpy(mensaje, "No se detect� error sint�ctico en las 25 pruebas que se hicieron."); break;
      case 1:  strcpy(mensaje, "1. Dos o m�s operadores est�n seguidos. Ejemplo: 2++4, 5-*3"); break; 
      case 2:  strcpy(mensaje, "2. Un operador seguido de un par�ntesis que cierra. Ejemplo: 2-(4+)-7"); break; 
      case 3:  strcpy(mensaje, "3. Un par�ntesis que abre seguido de un operador. Ejemplo: 2-(*3)"); break; 
      case 4:  strcpy(mensaje, "4. Que los par�ntesis est�n desbalanceados. Ejemplo: 3-(2*4))"); break; 
      case 5:  strcpy(mensaje, "5. Que haya par�ntesis vac�o. Ejemplo: 2-()*3"); break; 
      case 6:  strcpy(mensaje, "6. Par�ntesis que abre no corresponde con el que cierra. Ejemplo: 2+3)-2*(4"); break; 
      case 7: strcpy(mensaje, "7. Un par�ntesis que cierra y sigue un n�mero. Ejemplo: (3-5)7-(1+2)"); break; 
      case 8: strcpy(mensaje, "8. Un n�mero seguido de un par�ntesis que abre. Ejemplo: 7-2(5-6)"); break; 
      case 9: strcpy(mensaje, "9. Doble punto en un n�mero de tipo real. Ejemplo: 3-2..4+1  7-6.46.1+2"); break; 
      case 10: strcpy(mensaje, "10. Un par�ntesis que cierra seguido de una variable. Ejemplo: (12-4)y-1"); break; 
      case 11: strcpy(mensaje, "11. Una variable seguida de un punto. Ejemplo: 4-z.1+3"); break; 
      case 12: strcpy(mensaje, "12. Un punto seguido de una variable. Ejemplo: 7-2.p+1"); break; 
      case 13: strcpy(mensaje, "13. Un n�mero antes de una variable. Ejemplo: 3x+1"); break; 
      case 14: strcpy(mensaje, "14. Un n�mero despu�s de una variable. Ejemplo: x21+4"); break; 
      case 15: strcpy(mensaje, "15. Hay 4 o m�s letras seguidas. Ejemplo: 12+ramp+8.9"); break; 
      case 16: strcpy(mensaje, "16. Funci�n inexistente. Ejemplo: 5*alo(78)"); break; 
      case 17: strcpy(mensaje, "17. Variable inv�lida (solo pueden tener una letra). Ejemplo: 5+tr-xc+5"); break; 
      case 18: strcpy(mensaje, "18. Variable seguida de par�ntesis que abre. Ejemplo: 5-a(7+3)"); break;
      case 19: strcpy(mensaje, "19. Despu�s de par�ntesis que cierra sigue par�ntesis que abre. Ejemplo: (4-5)(2*x)"); break;
      case 20: strcpy(mensaje, "20. Despu�s de operador sigue un punto. Ejemplo: -.3+7"); break;
      case 21: strcpy(mensaje, "21. Despu�s de par�ntesis que abre sigue un punto. Ejemplo: 3*(.5+4)"); break;
      case 22: strcpy(mensaje, "22. Un punto seguido de un par�ntesis que abre. Ejemplo: 7+3.(2+6)"); break;
      case 23: strcpy(mensaje, "23. Par�ntesis cierra y sigue punto. Ejemplo: (4+5).7-2"); break;
      case 24: strcpy(mensaje, "24. Punto seguido de operador. Ejemplo: 5.*9+1"); break;   
      default: strcpy(mensaje, "25. Punto seguido de par�ntesis que cierra. Ejemplo: (3+2.)*5"); break;
    }
}

//Retira caracteres inv�lidos. Pone la expresi�n entre par�ntesis.
void Evaluar::TransformaExpresion(char *nuevaExpr, char *expr)
{
  char validos[50];
  strcpy(validos, "abcdefghijklmnopqrstuvwxyz0123456789.+-*/^()");

  //Convierte a min�sculas
  for (int cont=0; cont<strlen(expr); cont++)
     if (expr[cont] >= 'A' && expr[cont] <= 'Z')
         expr[cont] = expr[cont] - 'A' + 'a';
  strcpy(nuevaExpr, "(");
  int posnuevaExpr = 1;
  for(int pos = 0; *(expr+pos); pos++)
  {
    char letra = expr[pos];
    for(int valida = 0; *(validos+valida); valida++)
      if (letra == validos[valida])
      {
        nuevaExpr[posnuevaExpr++] = letra;
        break;
      }
  }
  nuevaExpr[posnuevaExpr]=')';
  nuevaExpr[posnuevaExpr+1]='\0';
}


//1. Dos o m�s operadores est�n seguidos. Ejemplo: 2++4, 5-*3
bool Evaluar::DobleTripleOperadorSeguido(char *expr)
{
    for (int pos=0; *(expr+pos+1); pos++)
    {
        char car1 = expr[pos];  //Extrae un car�cter
        char car2 = expr[pos+1]; //Extrae el siguiente car�cter

        //Compara si el car�cter y el siguiente son operadores, dado el caso retorna true
        if (car1 == '+' || car1 == '-' || car1 == '*' || car1 == '/' || car1 == '^')
            if (car2 == '+' || car2 == '*' || car2 == '/' || car2 == '^')
                return true;
    }

    for (int pos=0; *(expr+pos+2); pos++)
    {
        char car1 = expr[pos];  //Extrae un car�cter
        char car2 = expr[pos+1]; //Extrae el siguiente car�cter
        char car3 = expr[pos+2]; //Extrae el siguiente car�cter

        //Compara si el car�cter y el siguiente son operadores, dado el caso retorna true
        if (car1 == '+' || car1 == '-' || car1 == '*' || car1 == '/' || car1 == '^')
            if (car2 == '+' || car2 == '-' || car2 == '*' || car2 == '/' || car2 == '^')
                if (car3 == '+' || car3 == '-' || car3 == '*' || car3 == '/' || car3 == '^')
                    return true;
    }
    return false; //No encontr� doble/triple operador seguido
}

//2. Un operador seguido de un par�ntesis que cierra. Ejemplo: 2-(4+)-7
bool Evaluar::OperadorParentesisCierra(char *expr)
{
    for(int pos = 0; *(expr+pos+1); pos++)
    {
        char car1 = expr[pos];   //Extrae un car�cter

        //Compara si el primer car�cter es operador y el siguiente es par�ntesis que cierra
        if (car1 == '+' || car1 == '-' || car1 == '*' || car1 == '/' || car1 == '^')
            if (expr[pos+1] == ')') return true;
    }
    return false; //No encontr� operador seguido de un par�ntesis que cierra
}

//3. Un par�ntesis que abre seguido de un operador. Ejemplo: 2-(*3)
bool Evaluar::ParentesisAbreOperador(char *expr)
{
    for(int pos = 0; *(expr+pos+1); pos++)
    {
        char car2 = expr[pos+1]; //Extrae el siguiente car�cter

        //Compara si el primer car�cter es par�ntesis que abre y el siguiente es operador
        if (expr[pos] == '(')
            if (car2 == '+' || car2 == '*' || car2 == '/' || car2 == '^') return true;
    }
    return false; //No encontr� par�ntesis que abre seguido de un operador
}

//4. Que los par�ntesis est�n desbalanceados. Ejemplo: 3-(2*4))
bool Evaluar::ParentesisDesbalanceados(char *expr)
{
    int parabre = 0, parcierra = 0;
    for(int pos = 0; *(expr+pos); pos++)
    {
        char car1 = expr[pos];
        if (car1 == '(') parabre++;
        if (car1 == ')') parcierra++;
    }
    return (parabre != parcierra);
}

//5. Que haya par�ntesis vac�o. Ejemplo: 2-()*3
bool Evaluar::ParentesisVacio(char *expr)
{
    for(int pos = 0; *(expr+pos+1); pos++)
        if (expr[pos] == '(' && expr[pos+1] == ')') return true;
    return false;
}

//6. As� est�n balanceados los par�ntesis no corresponde el que abre con el que cierra. Ejemplo: 2+3)-2*(4
bool Evaluar::ParentesisBalanceIncorrecto(char *expr)
{
    int balance = 0;
    for(int pos = 0; *(expr+pos); pos++)
    {
        char car1 = expr[pos];   //Extrae un car�cter
        if (car1 == '(') balance++;
        if (car1 == ')') balance--;
        if (balance < 0) return true; //Si cae por debajo de cero es que el balance es err�neo
    }
    return false;
}

//7. Un par�ntesis que cierra y sigue un n�mero o par�ntesis que abre. Ejemplo: (3-5)7-(1+2)(3/6)
bool Evaluar::ParentesisCierraNumero(char *expr)
{
    for(int pos = 0; *(expr+pos+1); pos++)
    {
        char car2 = expr[pos+1]; //Extrae el siguiente car�cter

        //Compara si el primer car�cter es par�ntesis que abre y el siguiente es par�ntesis que cierra
        if (expr[pos] == ')')
            if (car2 >= '0' && car2 <= '9') return true;
    }
    return false;
}

//8. Un n�mero seguido de un par�ntesis que abre. Ejemplo: 7-2(5-6)
bool Evaluar::NumeroParentesisAbre(char *expr)
{
    for(int pos = 0; *(expr+pos+1); pos++)
    {
        char car1 = expr[pos];   //Extrae un car�cter

        //Compara si el primer car�cter es n�mero y el siguiente es par�ntesis que abre
        if (car1 >= '0' && car1 <= '9')
            if (expr[pos+1] == '(') return true;
    }
    return false;
}

//9. Doble punto en un n�mero de tipo real. Ejemplo: 3-2..4+1  7-6.46.1+2
bool Evaluar::DoblePuntoNumero(char *expr)
{
    int totalpuntos = 0;
    for(int pos = 0; *(expr+pos); pos++)
    {
        char car1 = expr[pos];   //Extrae un car�cter
        if ((car1 < '0' || car1 > '9') && car1 != '.') totalpuntos = 0;
        if (car1 == '.') totalpuntos++;
        if (totalpuntos > 1) return true;
    }
    return false;
}

//10. Un par�ntesis que cierra seguido de una variable. Ejemplo: (12-4)y-1
bool Evaluar::ParentesisCierraVariable(char *expr)
{
    for(int pos = 0; *(expr+pos+1); pos++)
        if (expr[pos] == ')') //Compara si el primer car�cter es par�ntesis que cierra y el siguiente es letra
            if (expr[pos+1] >= 'a' && expr[pos+1] <= 'z') return true;
    return false;
}

//11. Una variable seguida de un punto. Ejemplo: 4-z.1+3
bool Evaluar::VariableluegoPunto(char *expr)
{
    for(int pos = 0; *(expr+pos+1); pos++)
        if (expr[pos] >= 'a' && expr[pos] <= 'z')
            if (expr[pos+1] == '.') return true;
    return false;
}

//12. Un punto seguido de una variable. Ejemplo: 7-2.p+1
bool Evaluar::PuntoluegoVariable(char *expr)
{
    for(int pos = 0; *(expr+pos+1); pos++)
        if (expr[pos] == '.')
            if (expr[pos+1] >= 'a' && expr[pos+1] <= 'z')
                return true;
    return false;
}

//13. Un n�mero antes de una variable. Ejemplo: 3x+1
//Nota: Algebraicamente es aceptable 3x+1 pero entonces vuelve m�s complejo un evaluador porque debe saber que 3x+1 es en realidad 3*x+1
bool Evaluar::NumeroAntesVariable(char *expr)
{
    for(int pos = 0; *(expr+pos+1); pos++)
        if (expr[pos] >= '0' && expr[pos] <= '9')
            if (expr[pos+1] >= 'a' && expr[pos+1] <= 'z') return true;
    return false;
}

//14. Un n�mero despu�s de una variable. Ejemplo: x21+4
bool Evaluar::VariableDespuesNumero(char *expr)
{
    for(int pos = 0; *(expr+pos+1); pos++)
        if (expr[pos] >= 'a' && expr[pos] <= 'z')
            if (expr[pos+1] >= '0' && expr[pos+1] <= '9')
                return true;
    return false;
}

//15. Chequea si hay 4 o m�s letras seguidas
bool Evaluar::Chequea4letras(char *expr)
{
    for(int pos = 0; *(expr+pos+3); pos++)
    {
        char car1 = expr[pos];
        char car2 = expr[pos+1];
        char car3 = expr[pos+2];
        char car4 = expr[pos+3];

        if (car1 >= 'a' && car1 <= 'z' && car2 >= 'a' && car2 <= 'z' && car3 >= 'a' && car3 <= 'z' && car4 >= 'a' && car4 <= 'z')
            return true;
    }
    return false;
}

//16. Si detecta tres letras seguidas y luego un par�ntesis que abre, entonces verifica si es funci�n o no
bool Evaluar::FuncionInvalida(char *expr)
{
    for(int pos = 0; *(expr+pos+2); pos++)
    {
        char car1 = expr[pos];
        char car2 = expr[pos+1];
        char car3 = expr[pos+2];

        //Si encuentra tres letras seguidas
        if (car1 >= 'a' && car1 <= 'z' && car2 >= 'a' && car2 <= 'z' && car3 >= 'a' && car3 <= 'z')
        {
            if (pos >= strlen(expr) - 4) return true; //Hay un error porque no sigue par�ntesis
            if (*(expr+pos+3) != '(') return true; //Hay un error porque no hay par�ntesis
            if (EsFuncionInvalida(car1, car2, car3)) return true;
        }
    }
    return false;
}

//Chequea si las tres letras enviadas son una funci�n  
bool Evaluar::EsFuncionInvalida(char car1, char car2, char car3)
{
    char *listafunciones = "sinsencostanabsasnacsatnlogceiexpsqrrcb";
    for(int pos = 0; *(listafunciones+pos+2); pos+=3)
    {
        char listfunc1 = listafunciones[pos];
        char listfunc2 = listafunciones[pos + 1];
        char listfunc3 = listafunciones[pos + 2];
        if (car1 == listfunc1 && car2 == listfunc2 && car3 == listfunc3) return false;
    }
    return true;
}

//17. Si detecta s�lo dos letras seguidas es un error
bool Evaluar::VariableInvalida(char *expr)
{
    int cuentaletras = 0;
    for(int pos = 0; *(expr+pos); pos++)
    {
      char car1 = expr[pos];
      if (car1 >= 'a' && car1 <= 'z')
        cuentaletras++;
      else
      {
        if (cuentaletras == 2) return true;
        cuentaletras = 0;
      }
    }
    return cuentaletras == 2;
}

//18. Antes de par�ntesis que abre hay una letra
bool Evaluar::VariableParentesisAbre(char *expr)
{
    int cuentaletras = 0;
    for(int pos = 0; *(expr+pos); pos++)
    {
        char car1 = expr[pos];
        if (car1 >= 'a' && car1 <= 'z')
           cuentaletras++;
        else if (car1 == '(' && cuentaletras == 1)
           return true;
        else
           cuentaletras = 0;
    }
    return false;
}

//19. Despu�s de par�ntesis que cierra sigue par�ntesis que abre. Ejemplo: (4-5)(2*x)
bool Evaluar::ParCierraParAbre(char *expr)
{
      for (int pos = 0; pos < *(expr+pos)-1; pos++)
          if (expr[pos]==')' && expr[pos+1]=='(')
              return true;
      return false;
}
  
//20. Despu�s de operador sigue un punto. Ejemplo: -.3+7
bool Evaluar::OperadorPunto(char *expr)
{
      for (int pos = 0; pos < *(expr+pos)-1; pos++)
          if (expr[pos]=='+' || expr[pos]=='-' || expr[pos]=='*' || expr[pos]=='/' || expr[pos]=='^')
                  if (expr[pos+1]=='.')
                    return true;
      return false;
}
  
//21. Despu�s de par�ntesis que abre sigue un punto. Ejemplo: 3*(.5+4)
bool Evaluar::ParAbrePunto(char *expr)
{
      for (int pos = 0; pos < *(expr+pos)-1; pos++)
          if (expr[pos]=='(' && expr[pos+1]=='.')
              return true;
      return false;
}  
  
//22. Un punto seguido de un par�ntesis que abre. Ejemplo: 7+3.(2+6)
bool Evaluar::PuntoParAbre(char *expr)
{
      for (int pos = 0; pos < *(expr+pos)-1; pos++)
          if (expr[pos]=='.' && expr[pos+1]=='(')
              return true;
      return false;
}  
  
//23. Par�ntesis cierra y sigue punto. Ejemplo: (4+5).7-2
bool Evaluar::ParCierraPunto(char *expr)
{
      for (int pos = 0; pos < *(expr+pos)-1; pos++)
          if (expr[pos]==')' && expr[pos+1]=='.')
              return true;
      return false;
}  
  
//24. Punto seguido de operador. Ejemplo: 5.*9+1 
bool Evaluar::PuntoOperador(char *expr)
{
      for (int pos = 0; pos < *(expr+pos)-1; pos++)
          if (expr[pos]=='.')
            if (expr[pos+1]=='+' || expr[pos+1]=='-' || expr[pos+1]=='*' || expr[pos+1]=='/' || expr[pos+1]=='^')
                    return true;
      return false;
}
  
//25. Punto y sigue par�ntesis que cierra. Ejemplo: (3+2.)*5
bool Evaluar::PuntoParCierra(char *expr)
{
      for (int pos = 0; pos < *(expr+pos)-1; pos++)
          if (expr[pos]=='.' && expr[pos+1]==')')
              return true;
      return false;
}   

/* Convierte una expresi�n con el menos unario en una expresi�n valida para el evaluador de expresiones */
int Evaluar::ArreglaNegativos(char *NuevaExpresion2, char *expresion)
{
  char *NuevaExpresion = (char *) malloc((strlen(expresion)+100)*7);
  if (NuevaExpresion == NULL) return -1;
  NuevaExpresion[0] = '\0';
  int posNuevaExpr = 0;
  int posNuevaExpr2 = 0;

  //Si detecta un operador y luego un menos, entonces agrega un "(0-1)#" entre esos dos
  for (int pos=0; pos<strlen(expresion); pos++)
  {
    char letra1 = expresion[pos];
    if (letra1=='+' || letra1=='-' || letra1=='*' || letra1=='/' || letra1=='^')
      if (expresion[pos+1]=='-')
      {
        NuevaExpresion[posNuevaExpr++] = letra1;
        NuevaExpresion[posNuevaExpr++] = '(';
        NuevaExpresion[posNuevaExpr++] = '0';
        NuevaExpresion[posNuevaExpr++] = '-';
        NuevaExpresion[posNuevaExpr++] = '1';
        NuevaExpresion[posNuevaExpr++] = ')';
        NuevaExpresion[posNuevaExpr++] = '#';
        pos++;
        continue;
      }
      NuevaExpresion[posNuevaExpr++] =  letra1;
  }
  NuevaExpresion[posNuevaExpr++] = '\0';

  //Si detecta un par�ntesis que abre y luego un menos, entonces reemplaza el menos con un "(0-1)#"
  for (int pos=0; pos<strlen(NuevaExpresion); pos++)
  {
    char letra1 = NuevaExpresion[pos];
    if (letra1=='(')
      if (NuevaExpresion[pos+1]=='-')
      {
        NuevaExpresion2[posNuevaExpr2++] = letra1;
        NuevaExpresion2[posNuevaExpr2++] = '(';
        NuevaExpresion2[posNuevaExpr2++] = '0';
        NuevaExpresion2[posNuevaExpr2++] = '-';
        NuevaExpresion2[posNuevaExpr2++] = '1';
        NuevaExpresion2[posNuevaExpr2++] = ')';
        NuevaExpresion2[posNuevaExpr2++] = '#';
        pos++;
        continue;
      }
      NuevaExpresion2[posNuevaExpr2++] =  letra1;
  }
  NuevaExpresion2[posNuevaExpr2++] = '\0';

  free(NuevaExpresion);
  return 0;
}

//Inicializa las listas, convierte la expresi�n en piezas simples y luego en piezas de ejecuci�n
void Evaluar::Analizar(char *expresion)
{
  PiezaSimple.clear();
  PiezaEjecuta.clear();
  Generar_Piezas_Simples(expresion);
  Generar_Piezas_Ejecucion();
}

//Convierte la expresi�n en piezas simples: n�meros # par�ntesis # variables # operadores # funciones
void Evaluar::Generar_Piezas_Simples(char *expresion)
{
  int longExpresion = strlen(expresion);

  //Variables requeridas para armar un n�mero
  double parteentera = 0;
  double partedecimal = 0;
  double divide = 1;
  bool entero = true;
  bool armanumero = false;

  for (int cont = 0; cont < longExpresion; cont++) //Va de letra en letra de la expresi�n
  {
    char letra = expresion[cont];
    if (letra == '.')  //Si letra es . entonces el resto de digitos le�dos son la parte decimal del n�mero
      entero = false;
    else if (letra >= '0' && letra <= '9')  //Si es un n�mero, entonces lo va armando
    {
      armanumero = true;
      if (entero)
        parteentera = parteentera * 10 + letra - ASCIINUMERO; //La parte entera del n�mero 
      else
      {
        divide *= 10;
        partedecimal = partedecimal * 10 + letra - ASCIINUMERO; //La parte decimal del n�mero
      }
    }
    else
    {
      if (armanumero) //Si ten�a armado un n�mero, entonces crea la pieza ESNUMERO
      {
        Pieza_Simple objeto(ESNUMERO, 0, '0', parteentera+partedecimal/divide, 0);
        PiezaSimple.push_back(objeto);
        parteentera = 0;
        partedecimal = 0;                        
        divide = 1;
        entero = true;
        armanumero = false;
      }
                    
      if (letra == '+' || letra == '-' || letra == '*' || letra == '/' || letra == '^' || letra == '#'){ Pieza_Simple objeto(ESOPERADOR, 0, letra, 0, 0); PiezaSimple.push_back(objeto); }
      else if (letra == '('){ Pieza_Simple objeto(ESPARABRE, 0, '0', 0, 0); PiezaSimple.push_back(objeto); }//�Es par�ntesis que abre?
      else if (letra == ')'){ Pieza_Simple objeto(ESPARCIERRA, 0, '0', 0, 0); PiezaSimple.push_back(objeto); }//�Es par�ntesis que cierra?
      else if (letra >= 'a' && letra <= 'z') //�Es variable o funci�n?
      {
        /* Detecta si es una funci�n porque tiene dos letras seguidas */
        if (cont < longExpresion - 1)
        {
          char letra2 = expresion[cont + 1]; /* Chequea si el siguiente car�cter es una letra, dado el caso es una funci�n */
          if (letra2 >= 'a' && letra2 <= 'z')
          {
            char letra3 = expresion[cont + 2];
            int funcionDetectada = 1;  /* Identifica la funci�n */
            for (int funcion = 0; funcion <= TAMANOFUNCION; funcion += 3)
            {
              if (letra == listaFunciones[funcion]
                && letra2 == listaFunciones[funcion + 1]
                && letra3 == listaFunciones[funcion + 2])
                break;
              funcionDetectada++;
            }
            Pieza_Simple objeto(ESFUNCION, funcionDetectada, '0', 0, 0);
            PiezaSimple.push_back(objeto);  //Adiciona funci�n a la lista
            cont += 3; /* Mueve tres caracteres  sin(  [s][i][n][(] */
          }
          else /* Es una variable, no una funci�n */
          {
            Pieza_Simple objeto(ESVARIABLE, 0, '0', 0, letra - ASCIILETRA);
            PiezaSimple.push_back(objeto);
          }
        }
        else /* Es una variable, no una funci�n */
        {
          Pieza_Simple objeto(ESVARIABLE, 0, '0', 0, letra - ASCIILETRA);
          PiezaSimple.push_back(objeto);
        }
      }
    }
  }
  if (armanumero) { Pieza_Simple objeto(ESNUMERO, 0, '0', parteentera+partedecimal/divide, 0); PiezaSimple.push_back(objeto);  }
}


//Toma las piezas simples y las convierte en piezas de ejecuci�n de funciones
//Acumula = funci�n (operando(n�mero/variable/acumula))
void Evaluar::Generar_Piezas_Ejecucion()
{
  int cont = PiezaSimple.size()-1;
  Contador_Acumula = 0;
  do
  {
    if (PiezaSimple[cont].getTipo() == ESPARABRE || PiezaSimple[cont].getTipo() == ESFUNCION)
    {
      Generar_Piezas_Operador('#', '#', cont);  //Primero eval�a los menos unarios
      Generar_Piezas_Operador('^', '^', cont);  //Luego las potencias
      Generar_Piezas_Operador('*', '/', cont);  //Luego eval�a multiplicar y dividir
      Generar_Piezas_Operador('+', '-', cont);  //Finalmente eval�a sumar y restar

      //Crea pieza de ejecuci�n
      Pieza_Ejecuta objeto(PiezaSimple[cont].getFuncion(),
                            PiezaSimple[cont + 1].getTipo(), PiezaSimple[cont + 1].getNumero(), PiezaSimple[cont + 1].getVariable(), PiezaSimple[cont + 1].getAcumula(),
                            '+', ESNUMERO, 0, 0, 0);
      PiezaEjecuta.push_back(objeto);

      //La pieza pasa a ser de tipo Acumulador
      PiezaSimple[cont + 1].setAcumula(Contador_Acumula++);

      //Quita el par�ntesis/funci�n que abre y el que cierra, dejando el centro
      PiezaSimple.erase(PiezaSimple.begin() + cont);
      PiezaSimple.erase(PiezaSimple.begin() + cont + 1);
    }
    cont--;
  }while (cont>=0);
}

//Toma las piezas simples y las convierte en piezas de ejecuci�n
//Acumula = operando(n�mero/variable/acumula)  operador(+, -, *, /, ^)   operando(n�mero/variable/acumula)
void Evaluar::Generar_Piezas_Operador(char operA, char operB, int inicio)
{
  int cont = inicio + 1;
  do
  {
    if (PiezaSimple[cont].getTipo() == ESOPERADOR && (PiezaSimple[cont].getOperador() == operA || PiezaSimple[cont].getOperador() == operB))
    {
      //Crea pieza de ejecuci�n
      Pieza_Ejecuta objeto(0,
                PiezaSimple[cont - 1].getTipo(),
                PiezaSimple[cont - 1].getNumero(), PiezaSimple[cont - 1].getVariable(), PiezaSimple[cont - 1].getAcumula(),
                PiezaSimple[cont].getOperador(),
                PiezaSimple[cont + 1].getTipo(),
                PiezaSimple[cont + 1].getNumero(), PiezaSimple[cont + 1].getVariable(), PiezaSimple[cont + 1].getAcumula());
      PiezaEjecuta.push_back(objeto);

      //Elimina la pieza del operador y la siguiente
      PiezaSimple.erase(PiezaSimple.begin() + cont);
      PiezaSimple.erase(PiezaSimple.begin() + cont);

      //Retorna el contador en uno para tomar la siguiente operaci�n
      cont--;

      //Cambia la pieza anterior por pieza acumula
      PiezaSimple[cont].setAcumula(Contador_Acumula++);
    }
    cont++;
  } while (cont < PiezaSimple.size() && PiezaSimple[cont].getTipo() != ESPARCIERRA);
}

//Calcula la expresi�n convertida en piezas de ejecuci�n
double Evaluar::Calcular()
{
  double valorA=0, valorB=0;
  int totalPiezaEjecuta = PiezaEjecuta.size();

  for (int cont = 0; cont < totalPiezaEjecuta; cont++)
  {
    switch (PiezaEjecuta[cont].getTipoOperA())
    {
      case 5: valorA = PiezaEjecuta[cont].getNumeroA(); break; //�Es un n�mero?
      case 6: valorA = VariableAlgebra[PiezaEjecuta[cont].getVariableA()]; break;  //�Es una variable?
      case 7: valorA = PiezaEjecuta[PiezaEjecuta[cont].getAcumulaA()].getValorPieza(); break; //�Es una expresi�n anterior?
    }
    if (_isnan(valorA) || !_finite(valorA)) return valorA;

    switch (PiezaEjecuta[cont].getFuncion())
    {
      case 0:
        switch (PiezaEjecuta[cont].getTipoOperB())
        {
          case 5: valorB = PiezaEjecuta[cont].getNumeroB(); break; //�Es un n�mero?
          case 6: valorB = VariableAlgebra[PiezaEjecuta[cont].getVariableB()]; break;  //�Es una variable?
          case 7: valorB = PiezaEjecuta[PiezaEjecuta[cont].getAcumulaB()].getValorPieza(); break; //�Es una expresi�n anterior?
        }
        if (_isnan(valorB) || !_finite(valorB)) return valorB;

        switch (PiezaEjecuta[cont].getOperador())
        {
          case '#': PiezaEjecuta[cont].setValorPieza(valorA * valorB); break;
          case '+': PiezaEjecuta[cont].setValorPieza(valorA + valorB); break;
          case '-': PiezaEjecuta[cont].setValorPieza(valorA - valorB); break;
          case '*': PiezaEjecuta[cont].setValorPieza(valorA * valorB); break;
          case '/': PiezaEjecuta[cont].setValorPieza(valorA / valorB); break;
          case '^': PiezaEjecuta[cont].setValorPieza(pow(valorA, valorB)); break;
        }
        break;
      case 1:
      case 2: PiezaEjecuta[cont].setValorPieza(sin(valorA)); break;
      case 3: PiezaEjecuta[cont].setValorPieza(cos(valorA)); break;
      case 4: PiezaEjecuta[cont].setValorPieza(tan(valorA)); break;
      case 5: PiezaEjecuta[cont].setValorPieza(abs(valorA)); break;
      case 6: PiezaEjecuta[cont].setValorPieza(asin(valorA)); break;
      case 7: PiezaEjecuta[cont].setValorPieza(acos(valorA)); break;
      case 8: PiezaEjecuta[cont].setValorPieza(atan(valorA)); break;                       
      case 9: PiezaEjecuta[cont].setValorPieza(log(valorA)); break;
      case 10: PiezaEjecuta[cont].setValorPieza(ceil(valorA)); break;
      case 11: PiezaEjecuta[cont].setValorPieza(exp(valorA)); break;
      case 12: PiezaEjecuta[cont].setValorPieza(sqrt(valorA)); break;
      case 13: PiezaEjecuta[cont].setValorPieza(pow(valorA, 0.333333333333)); break;
    }
  }
  return PiezaEjecuta[totalPiezaEjecuta - 1].getValorPieza();
}

// Da valor a las variables que tendr� la expresi�n algebraica
void Evaluar::ValorVariable(char variableAlg, double valor)
{
  VariableAlgebra[variableAlg - ASCIILETRA] = valor;
}




