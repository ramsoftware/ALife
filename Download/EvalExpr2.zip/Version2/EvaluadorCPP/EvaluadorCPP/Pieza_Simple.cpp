/*  Autor: Rafael Alberto Moreno Parra
  Sitio Web:  http://darwin.50webs.com
  Correo:  enginelife@hotmail.com

  Evaluador de expresiones algebraicas por ejemplo, 57+1.87/84.89-(6.8*e+b+8769-4*b/8+b^2*4^e/f)+5.4-(d/9.6+0.2) con las siguientes funcionalidades:
  1. Ilimitado n�mero de par�ntesis
  2. M�s r�pido y m�s sencillo que el evaluador escrito para el primer libro: "Desarrollo de un evaluador de expresiones algebraicas"
  3. Manejo de 26 variables
  4. Manejo de 12 funciones
  5. Manejo de operadores +, -, *, /, ^ (potencia)
  6. Manejo del menos unario: lo reemplaza con (0-1)# donde # es la operaci�n con mayor relevancia y equivale a la multiplicaci�n

  Versi�n: 2.00 [Genera el libro "Desarrollo de un evaluador de expresiones algebraicas. Versi�n 2.0"]
  Fecha: Enero de 2013
  Licencia: LGPL

  Algoritmo:

  Se toma una expresi�n como 7*x+sen(12.8/y+9)-5*cos(9-(8.3/5.11^3-4.7)*7.12)+0.445
  Se agregan par�ntesis de inicio y fin  (7*x+sen(12.8/y+9)-5*cos(9-(8.3/5.11^3-4.7)*7.12)+0.445)
  Se divide en piezas simples   | ( | 7 | * | x | + | sen( | 12.8 | / | y | + | 9 | ) | - | 5 | * | cos( | 9 | - | ( | 8.3 | / | 5.11 | ^ | 3 | - | 4.7 | ) | * | 7.12 | ) | + | 0.445 | ) |
  Esas piezas est�n clasificadas:
   Par�ntesis que abre (
   Par�ntesis que cierra )
   N�meros  7   12.8  9   5
   Variables  x  y
   Operadores + - * / ^
   Funciones  sen(  cos(
  Luego se convierte esa expresi�n larga en expresiones cortas de ejecuci�n del tipo
  Acumula = operando(n�mero/variable/acumula)  operador(+, -, *, /, ^)   operando(n�mero/variable/acumula)
    [0]  5.11 ^ 3
    [1]  8.3  / [0]
    [2]  [1] - 4.7
    [3]  [2] + 0
    [4]  [3] * 7,12
    [5]  9   - [4]
    [6]  cos([5])
    [7]  12,8 / y
    [8]  [7] +  9
    [9]  sen([8])
    [10] 7 * x
    [11] 5 * [6]
    [12] [10] + [9]
    [13] [12] - [11]
    [14] [13] + 0.445
    [15] [14] + 0
  La expresi�n ya est� analizada y lista para evaluar.
  Se eval�a yendo de [0] a [15], en [15] est� el valor final.
*/
#include "Pieza_Simple.h"

Pieza_Simple::Pieza_Simple(int tipo, int funcion, char operador, double numero, int variable)
{
  this->tipo = tipo;
  this->funcion = funcion;
  this->operador = operador;
  this->variableAlgebra = variable;
  this->acumula = acumula;
  this->numero = numero;
}

int Pieza_Simple::getTipo() {  return this->tipo;  }
int Pieza_Simple::getFuncion() { return this->funcion; }
char Pieza_Simple::getOperador() { return this->operador; }
double Pieza_Simple::getNumero() { return this->numero; }
int Pieza_Simple::getVariable() { return this->variableAlgebra; }
int Pieza_Simple::getAcumula() { return this->acumula; }
void Pieza_Simple::setAcumula(int acumula) { this->tipo = 7; this->acumula = acumula; }       
