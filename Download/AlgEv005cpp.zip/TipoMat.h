/*
[A-Life]: Investigaci�n sobre Vida Artificial. El Algoritmo Evolutivo.

Autor: Rafael Alberto Moreno Parra. enginelife@hotmail.com
URL:   http://www.geocities.com/krousky
Fecha: 01 de Septiembre de 2001

Simulaci�n:  AlgEvo005
Herramienta: Microsoft Visual C++ 6.0

Objetivo:
Hay un Universo
Universo tiene ambientes
Universo tiene tipos de materiales
Hay materiales de cada tipo dispersos por todo el Universo
El ser vivo es la cooperaci�n entre materiales
Hay tipos de seres vivos (el concepto de especie).
*/

#ifndef PARAMETRO
#include "Parametro.h"
#endif


#ifndef EVALUADOREXPRESIONES
#include "EvalExpr.h"
#endif


#define TIPOMATERIAL 1

//Tipo de Material
class TipoMat
{
private:
	/* Como se comporta en el ambiente donde se encuentra en f(z) */
	char m_sEcuacion[200];

	/* Evalua previamente la ecuaci�n para dar mayor velocidad */
	EvalExpr objEval;

public:

	TipoMat(void);

	/* Identificador de Tipo */
	unsigned int m_iIDtipo;

	/* Inicia el comportamiento del material */
	unsigned int iInicia(unsigned int iID,
		         unsigned int iLongExprTip,
				 unsigned int iProbN, unsigned int iProbX, unsigned int iProbP,
				 unsigned int iTipMat);

	/* Suma o resta energ�a dependiendo de como es el ambiente */
	signed int iEnergia(float fValAmbiente);

	/* Procesa el cambio de tipo de material dependiendo del ambiente */
	void vCambio(float fValAmbiente, signed int *iNuevoTipoMat);

	/* Calcula la estabilidad del tipo de material */
	signed int m_iToleranciaMinima;
	signed int m_iToleranciaMaxima;

	/* En que se convierte el material cuando se rebasan los l�mites */
	unsigned int m_iNuevoMatTolMin;
	unsigned int m_iNuevoMatTolMax;
};
