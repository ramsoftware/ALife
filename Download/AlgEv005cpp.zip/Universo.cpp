/*
[A-Life]: Investigaci�n sobre Vida Artificial. El Algoritmo Evolutivo.

Autor: Rafael Alberto Moreno Parra. enginelife@hotmail.com
URL:   http://www.geocities.com/krousky
Fecha: 01 de Septiembre de 2001

Simulaci�n:  AlgEvo005
Herramienta: Microsoft Visual C++ 6.0

Objetivo:
Hay un Universo
Universo tiene ambientes
Universo tiene tipos de materiales
Hay materiales de cada tipo dispersos por todo el Universo
El ser vivo es la cooperaci�n entre materiales
Hay tipos de seres vivos (el concepto de especie).

*/
#include <stdlib.h>
#include <stdio.h>

#include "Universo.h"

//Constructor
Universo::Universo()
{
	time(&ltime1);
}


//Inicializa la semilla dependiendo del tiempo
void Universo::IniciaSemilla(unsigned int iForma)
{
	switch(iForma)
	{
		case 1:
			time_t ltime2;
			do { time(&ltime2); }while(ltime2==ltime1);
			srand( ltime2 );
			ltime1 = ltime2;
		case 2:
			srand(rand());
	}
}

//Genera ambientes, tipos de materiales, materiales, especies y organismos
unsigned int Universo::BigBang(void)
{
	unsigned int iCont, iCont1, iCont2, iDentro, iEspecie;
	signed int iNacio;

	//Trae los datos del archivo de configuracion
	objInicia.vPantallaIni();
	objInicia.vLeeArchivoIni();

	// Valores de inicializaci�n
	m_iTotalAmb = objInicia.stDatVA.iTotalAmb;
	m_iTotalTip = objInicia.stDatVA.iTotalTip;
	m_iTotalMat = objInicia.stDatVA.iTotalMat;
	m_iTotalEsp = objInicia.stDatVA.iTotalEsp;
	m_iTotalOrg = objInicia.stDatVA.iTotalOrg;
	m_iTotalTipMatEsp = objInicia.stDatVA.iTipMatEsp;
	m_iTotalMaterialporTipo = objInicia.stDatVA.iMaxMatTip;
	m_iXmin = objInicia.stDatVA.iXmin;
	m_iYmin = objInicia.stDatVA.iYmin;
	m_iXmax = objInicia.stDatVA.iXmax;
	m_iYmax	= objInicia.stDatVA.iYmax;

	// Reserva memoria
	objAmb = new Ambiente[m_iTotalAmb];
	if (objAmb == NULL) return ERRORMEMORIA;

	objTip = new TipoMat[m_iTotalTip];
	if (objTip == NULL) return ERRORMEMORIA;

	objMat = new Material[m_iTotalMat];
	if (objMat == NULL) return ERRORMEMORIA;

	objEsp = new TipoOrg[m_iTotalEsp];
	if (objEsp == NULL) return ERRORMEMORIA;

	objOrg = new Organismo[m_iTotalOrg];
	if (objOrg == NULL) return ERRORMEMORIA;

	//Inicia proceso aleatorio
	IniciaSemilla(1);

	//Crea los ambientes
	for (iCont=0; iCont < m_iTotalAmb; iCont++)
		objAmb[iCont].iInicia(iCont, m_iXmin, m_iYmin, m_iXmax, m_iYmax,
								objInicia.stDatVA.iLongExprAmb,
								objInicia.stDatVA.iProbN,
								objInicia.stDatVA.iProbX,
								objInicia.stDatVA.iProbY,
								objInicia.stDatVA.iProbP);

	//Crea los tipos de materiales
	for (iCont=0; iCont < m_iTotalTip; iCont++)
		objTip[iCont].iInicia(iCont,
								objInicia.stDatVA.iLongExprTip,
								objInicia.stDatVA.iTipProbN,
								objInicia.stDatVA.iTipProbX,
								objInicia.stDatVA.iTipProbP,
								objInicia.stDatVA.iTotalTip);

	//Crea los materiales y los relaciona a un tipo de material
	for (iCont=0; iCont < m_iTotalMat; iCont++)
		objMat[iCont].vInicia(iCont, m_iXmin, m_iYmin, m_iXmax, m_iYmax, m_iTotalTip);

	//Crea los tipos de organismos (especies)
	//Debe haber un m�nimo n�mero de tipos y materiales en si para una especie
	for (iCont=0; iCont < m_iTotalEsp; iCont++)
	{
		//Codigo de la especie
		objEsp[iCont].m_iIdTipOrg = iCont;

		//Tolerancia de la especie (al azar)
		do
		{
			objEsp[iCont].m_iToleranciaMin = objInicia.stDatVA.iTolVivoMin + rand()%(objInicia.stDatVA.iTolVivoMax - objInicia.stDatVA.iTolVivoMin);
			objEsp[iCont].m_iToleranciaMax = objInicia.stDatVA.iTolVivoMax - rand()%(objInicia.stDatVA.iTolVivoMax - objInicia.stDatVA.iTolVivoMin);
		}while (objEsp[iCont].m_iToleranciaMin > objEsp[iCont].m_iToleranciaMax);
		
		//Tipos de material y cantidad que tendr� cada especie
		for (iCont1=0; iCont1 < m_iTotalTipMatEsp; iCont1++) 
		{
			do
			{
				objEsp[iCont].m_iIdTipMat[iCont1] = rand()%m_iTotalTip; //Escoge al azar el tipo de material
				
				//Evita que el tipo de material se repita dentro de una misma especie
				iDentro=0;	
				for (iCont2=0; iCont2<iCont1; iCont2++)
					if (objEsp[iCont].m_iIdTipMat[iCont2] == objEsp[iCont].m_iIdTipMat[iCont1])
						iDentro=1;
			}while(iDentro==1);
			
			 // �Cuantos materiales por tipo?
			objEsp[iCont].iNumMaterialporTipo[iCont1] = rand()%m_iTotalMaterialporTipo + 1;
		}
	}
	
	//Imprime los resultados en consola
	for (iCont=0; iCont < m_iTotalEsp; iCont++)
	{
		printf("\n\nEspecie = %d  ", objEsp[iCont].m_iIdTipOrg);
		printf("Compuesta de:\n");
		for (iCont1=0; iCont1 < m_iTotalTipMatEsp; iCont1++) 
			printf("[%d,%d] ", objEsp[iCont].m_iIdTipMat[iCont1], objEsp[iCont].iNumMaterialporTipo[iCont1]);
	}

	//Crea Organismos por especie
	for (iCont=0; iCont < m_iTotalOrg; iCont++)
	{
		iEspecie = rand() % m_iTotalEsp;
		iNacio = iNaceOrg(iCont, iEspecie);
	}
	
	//Imprime los resultados en consola
	for (iCont=0; iCont < m_iTotalOrg; iCont++)
	{
		printf("\n\nOrganismo = %d\n", iCont);
		printf("Vive? = %d\n", objOrg[iCont].m_cVivo);

		if (objOrg[iCont].m_cVivo == ORG_VIVO)
		{
			printf("Especie = %d\n", objOrg[iCont].iEspecie);
			printf("Estabilidad = %d\n", objOrg[iCont].m_iEstabilidad);
			printf("Numero Materiales = %d\n", objOrg[iCont].iTotalMaterial);
			printf("Compuesta de:\n");
			for (iCont1=0; iCont1 < objOrg[iCont].iTotalMaterial; iCont1++) 
				printf("%d,", objOrg[iCont].m_iIDmaterial[iCont1]);
		}
	}

	return OPERACIONEXITOSA;
}

/* Procedimiento para que un organismo nazca */
int Universo::iNaceOrg(unsigned int iOrganismo, unsigned int iEspecie)
{
	unsigned int iCont, iTipoMaterial, iCantidad, iMater, iAcumula=0;

	/* Por defecto el ser vivo esta muerto */
    objOrg[iOrganismo].m_cVivo = ORG_MUERTO;

	/* Especie del Organismo */
	objOrg[iOrganismo].iEspecie = iEspecie;

	/* Inicia la energia (en la mitad de estabilidad m�nima y m�xima) */
	objOrg[iOrganismo].m_iEstabilidad = objEsp[iEspecie].m_iToleranciaMin + (objEsp[iEspecie].m_iToleranciaMax - objEsp[iEspecie].m_iToleranciaMin)/2;
	
	/* Determina si hay materiales libres para esa especie */
	for (iCont=0; iCont < m_iTotalTipMatEsp; iCont++)
	{
		/* Datos de la especie */
		iTipoMaterial = objEsp[iEspecie].m_iIdTipMat[iCont];
		iCantidad = objEsp[iEspecie].iNumMaterialporTipo[iCont];
		if (iCantidad==0) continue;

		/* Chequea toda la materia del Universo */
		for (iMater=0; iMater < m_iTotalMat; iMater++)
		{
			if (objMat[iMater].m_iTipMaterial == iTipoMaterial)
				if (objMat[iMater].m_cUsado == MAT_NOOCUPADO)
					iCantidad--;

			if (iCantidad==0)
				break;
		}

		if (iCantidad>0)
			return -1;  /* No hay suficiente cantidad */
	}

	/* Crea el ser vivo */
	objOrg[iOrganismo].m_cVivo = ORG_VIVO;

	/* Reserva el material para el organismo */
	for (iCont=0; iCont < m_iTotalTipMatEsp; iCont++)
	{
		/* Datos de la especie */
		iTipoMaterial = objEsp[iEspecie].m_iIdTipMat[iCont];
		iCantidad = objEsp[iEspecie].iNumMaterialporTipo[iCont];
		if (iCantidad==0) continue;

		/* Chequea la materia del Universo */
		for (iMater=0; iMater < m_iTotalMat; iMater++)
		{
			if (objMat[iMater].m_iTipMaterial == iTipoMaterial)
				if (objMat[iMater].m_cUsado == MAT_NOOCUPADO)
				{
					objMat[iMater].m_cUsado = MAT_OCUPADO;
					objOrg[iOrganismo].m_iIDmaterial[iAcumula++] = objMat[iMater].m_iIDmat;
					objOrg[iOrganismo].iTotalMaterial = iAcumula;
					iCantidad--;
				}

			if (iCantidad==0)
				break;
		}
	}
	return 1;
};


/* Procedimiento para que un organismo muera */
void Universo::iMuereOrg(unsigned int iOrganismo)
{
	unsigned int iCont, iIDmaterial;

	objOrg[iOrganismo].m_cVivo = ORG_MUERTO;
	
	/* Libera el material del organismo */
	for (iCont=0; iCont < objOrg[iOrganismo].iTotalMaterial; iCont++)
	{
		iIDmaterial = objOrg[iOrganismo].m_iIDmaterial[iCont];
		objMat[iIDmaterial].m_cUsado = MAT_NOOCUPADO;
	}
};


/* Dado un punto, que valor tiene este cubierto de 0 a N ambientes */
float Universo::fValPosXY(unsigned int iPosX, unsigned int iPosY)
{
	unsigned int iCont;
	float fValor=0;

	for (iCont=0; iCont < m_iTotalAmb; iCont++)
		fValor += objAmb[iCont].fValCoord(iPosX, iPosY);

	return fValor;
};


/* Ciclo de la vida */
void Universo::vCicloVida()
{
	unsigned int iCont, iCont1, iContinua, iEspecie, iMatOrg; 
	unsigned int iMaterial, iMatEsp, iPosX, iPosY, iTipMaterial;
	unsigned int *iNuevosOrg;
	float fValor;
	signed int iNacio, iNuevoTipoMat;

    iNuevosOrg = (unsigned int *) malloc(m_iTotalEsp * sizeof(int));
	if (iNuevosOrg==NULL) return;

	for (iCont=0; iCont<m_iTotalEsp; iCont++)
		iNuevosOrg[iCont] = 0;

	//Es un ciclo de vida, los que sobreviven a cada ciclo tienen la oportunidad de 
	//reproducirse.
	for(;;)
	{
		iContinua=0;
		printf("\n\nSobreviven:\n");
		for (iCont=0; iCont < m_iTotalOrg; iCont++)
		{
			if ( objOrg[iCont].m_cVivo == ORG_VIVO )
			{
				iContinua=1;
				iEspecie = objOrg[iCont].iEspecie;

				//Busca algun c�digo que no est� usado
				for (iCont1=0; iCont1<m_iTotalOrg; iCont1++)
				{
					if ( objOrg[iCont1].m_cVivo == ORG_MUERTO)
						break;
				}

				//Reproduce un nuevo organismo
				if (iCont1 < m_iTotalOrg)
				{
					/* Cuenta organismos nacientes */
					iNacio = iNaceOrg(iCont1, iEspecie);
					if (iNacio==1)
					{
						objOrg[iCont1].m_cVivo = ORG_RECIEN;
						iNuevosOrg[iEspecie]++;
						printf("Organismo nuevo. Id:%d Especie:%d Cantidad:%d\n", iCont1, iEspecie, iNuevosOrg[iEspecie]);
					}
				}
			}
		}

		//Muestra como progresa la vida de un organismo
		for (iCont=0; iCont < m_iTotalOrg; iCont++)
			if ( objOrg[iCont].m_cVivo == ORG_VIVO || objOrg[iCont].m_cVivo == ORG_RECIEN)
			{
				objOrg[iCont].m_cVivo = ORG_VIVO;

				printf("\n\n[Identificacion=%d, Especie=%d, Estado=%d]\n", iCont, objOrg[iCont].iEspecie, objOrg[iCont].m_iEstabilidad);
				
				//Tipo de Material que tiene la especie del organismo
				printf("Tipo Material Especie Original:[Tipo,Cantidad]\n");
				iEspecie = objOrg[iCont].iEspecie;
				for (iMatEsp=0; iMatEsp < m_iTotalTipMatEsp; iMatEsp++)
					printf("[%d,%d]",objEsp[iEspecie].m_iIdTipMat[iMatEsp], objEsp[iEspecie].iNumMaterialporTipo[iMatEsp]);
				
				printf("\nMateriales que hay en el organismo (tipos): \n");
				for (iMatOrg=0; iMatOrg < objOrg[iCont].iTotalMaterial; iMatOrg++)
				{
					// �De que material esta hecho?
					iMaterial = objOrg[iCont].m_iIDmaterial[iMatOrg];

					// �Que tipo de material es?
					printf("%d,", objMat[iMaterial].m_iTipMaterial);
				}
			}

		if (iContinua==0) break;
		vEvaluaOrganismo();

		/* Chequea la materia del Universo (cambios debido al ambiente) */
		for (iMaterial=0; iMaterial < m_iTotalMat; iMaterial++)
		{
				// �Que ambiente hay en esa ubicaci�n?
				iPosX = objMat[iMaterial].m_iPosX;
				iPosY = objMat[iMaterial].m_iPosY;
				fValor = fValPosXY(iPosX, iPosY);

				// �Como reacciona el material a ese ambiente? �Cambia?
				iTipMaterial = objMat[iMaterial].m_iTipMaterial;
				objTip[iTipMaterial].vCambio(fValor, &iNuevoTipoMat);
				if (iNuevoTipoMat!= -1)
					objMat[iMaterial].m_iTipMaterial = iNuevoTipoMat;
		}
	}
	printf("\n");
}


/* Evalua el Organismo */
void Universo::vEvaluaOrganismo()
{
	unsigned int iCont, iCont1, iMaterial, iTipMaterial, iPosX, iPosY, iEspecie;
	signed int iEnergia;
	float fValor;

	/* Toma cada organismo que a�n viva */
	for (iCont=0; iCont < m_iTotalOrg; iCont++)
	{
		if ( objOrg[iCont].m_cVivo == ORG_VIVO )
		{
			iEspecie = objOrg[iCont].iEspecie;

			// Se va por cada material de que este hecho el organismo
			for (iCont1=0; iCont1 < objOrg[iCont].iTotalMaterial; iCont1++)
			{
				// �De que material esta hecho?
				iMaterial = objOrg[iCont].m_iIDmaterial[iCont1];

				// �Donde esta ubicado ese material?
				iPosX = objMat[iMaterial].m_iPosX;
				iPosY = objMat[iMaterial].m_iPosY;

				// �Que tipo de material es?
				iTipMaterial = objMat[iMaterial].m_iTipMaterial;

				// �Que ambiente hay en esa ubicaci�n?
				fValor = fValPosXY(iPosX, iPosY);

				// Energia traida por ese material
				iEnergia = objTip[iTipMaterial].iEnergia(fValor);
				
				// �Como afecta esa reacci�n al organismo?
				objOrg[iCont].m_iEstabilidad += iEnergia;
			}

			// �Sobrevivir� el organismo?
			if ( objOrg[iCont].m_iEstabilidad > objEsp[iEspecie].m_iToleranciaMax ||
				 objOrg[iCont].m_iEstabilidad < objEsp[iEspecie].m_iToleranciaMin)
				 iMuereOrg(iCont);
		}
	}
}
