/*
[A-Life]: Investigaci�n sobre Vida Artificial. El Algoritmo Evolutivo.

Autor: Rafael Alberto Moreno Parra. enginelife@hotmail.com
URL:   http://www.geocities.com/krousky
Fecha: 01 de Septiembre de 2001

Simulaci�n:  AlgEvo005
Herramienta: Microsoft Visual C++ 6.0

Objetivo:
Hay un Universo
Universo tiene ambientes
Universo tiene tipos de materiales
Hay materiales de cada tipo dispersos por todo el Universo
El ser vivo es la cooperaci�n entre materiales
Hay tipos de seres vivos (el concepto de especie).

*/
#include <time.h>

#include "Ambiente.h"
#include "TipoMat.h"
#include "Material.h"
#include "TipoOrg.h"
#include "Organismo.h"
#include "Inicializa.h"


/* Universo: Contenedor de los diferentes ambientes, materiales, energ�a y organismos
   Controla la generaci�n aleatoria (caos) */
class Universo
{
public:
	/* Datos de inicializaci�n */
	Inicializa objInicia;

	/* Se definen UNI_NUMAMBIENTE ambientes primarios */
	unsigned int m_iTotalAmb;
	Ambiente *objAmb;

	/* Se definen UNI_NUMTIPOMAT tipos de materiales */
	unsigned int m_iTotalTip;
	TipoMat *objTip;

	/* Se definen UNI_NUMMATERIAL materiales */
	unsigned int m_iTotalMat;
	Material *objMat;

	/* Se definen UNI_NUMTIPORG tipos de organismos, es decir, especies */
	unsigned int m_iTotalEsp;
	TipoOrg *objEsp;
	
	/* Se define la cantidad m�xima de tipos de material por especie */
	unsigned int m_iTotalTipMatEsp;
	
	/* Se define la cantidad m�xima de materiales por tipo de material por especie */
	unsigned int m_iTotalMaterialporTipo;

	/* Se definen UNI_NUMORG organismos */
	unsigned int m_iTotalOrg;
	Organismo *objOrg;

	/* Extremos del Universo rectangular */
	unsigned int m_iXmin, m_iYmin, m_iXmax, m_iYmax;

	//Inicia la semilla de los n�meros aleatorios
    time_t ltime1;
	void IniciaSemilla(unsigned int iForma);

	/* Constructor */
	Universo(void);

	/* Crea ambientes, materiales y organismos al azar */
	unsigned int BigBang(void);
		
	/* Dado un punto, que valor tiene este cubierto de 0 a N ambientes */
	float fValPosXY (unsigned int iPosX, unsigned int iPosY);

	/* Ciclo de vida. Que organismo al final resiste */
	void vCicloVida(void);

	/* Evalua el Organismo */
	void vEvaluaOrganismo(void);

	/* Nacimiento de un Organismo */
	int iNaceOrg(unsigned int iOrganismo, unsigned int iEspecie);

	/* Procedimiento para que un organismo muera */
	void iMuereOrg(unsigned int iOrganismo);

};
