/*
[A-Life]: Investigaci�n sobre Vida Artificial. El Algoritmo Evolutivo.

Autor: Rafael Alberto Moreno Parra. enginelife@hotmail.com
URL:   http://www.geocities.com/krousky
Fecha: 01 de Septiembre de 2001

Simulaci�n:  AlgEvo005
Herramienta: Microsoft Visual C++ 6.0

Objetivo:
Hay un Universo
Universo tiene ambientes
Universo tiene tipos de materiales
Hay materiales de cada tipo dispersos por todo el Universo
El ser vivo es la cooperaci�n entre materiales
Hay tipos de seres vivos (el concepto de especie).

*/

#ifndef PARAMETRO
#include "Parametro.h"
#endif


/* Esta clase representa la materia y energ�a del Universo */
class Material
{
public:
	/* Identificador de material */
	unsigned int m_iIDmat;

	/* Tipo de Material */
	unsigned int m_iTipMaterial;

	/* Es un material nodal */
	unsigned int m_iPosX, m_iPosY;

	/* Chequea si esta siendo usado por alg�n organismo */
	char m_cUsado;

	/* Inicializa */
	void vInicia(unsigned int iID, unsigned int iXmin, unsigned int iYmin, unsigned int iXmax, unsigned int iYmax, unsigned int iMaxTipMat);
};
