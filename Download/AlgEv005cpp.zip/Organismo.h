/*
[A-Life]: Investigaci�n sobre Vida Artificial. El Algoritmo Evolutivo.

Autor: Rafael Alberto Moreno Parra. enginelife@hotmail.com
URL:   http://www.geocities.com/krousky
Fecha: 01 de Septiembre de 2001

Simulaci�n:  AlgEvo005
Herramienta: Microsoft Visual C++ 6.0

Objetivo:
Hay un Universo
Universo tiene ambientes
Universo tiene tipos de materiales
Hay materiales de cada tipo dispersos por todo el Universo
El ser vivo es la cooperaci�n entre materiales
Hay tipos de seres vivos (el concepto de especie).
*/

#ifndef PARAMETRO
#include "Parametro.h"
#endif

class Organismo
{
public:
	//Constructor
	Organismo(void);

	//Tipo de ser vivo
	unsigned int iEspecie;

	//Indicador de si se mantiene con vida el organismo
	char m_cVivo;

	//Nivel de estabilidad que tiene el organismo
	signed int m_iEstabilidad;

	//Lista de materiales
	unsigned int m_iIDmaterial[40];
	unsigned int iTotalMaterial;

	//Nace el organismo
	void vNace(unsigned int iEstabilidad, unsigned int iTolMin, unsigned int iTolMax, unsigned int iNumMaterial);
};