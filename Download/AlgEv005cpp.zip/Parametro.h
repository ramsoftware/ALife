/*
[A-Life]: Investigaci�n sobre Vida Artificial. El Algoritmo Evolutivo.

Autor: Rafael Alberto Moreno Parra. enginelife@hotmail.com
URL:   http://www.geocities.com/krousky
Fecha: 01 de Septiembre de 2001

Simulaci�n:  AlgEvo005
Herramienta: Microsoft Visual C++ 6.0

Objetivo:
Hay un Universo
Universo tiene ambientes
Universo tiene tipos de materiales
Hay materiales de cada tipo dispersos por todo el Universo
El ser vivo es la cooperaci�n entre materiales
Hay tipos de seres vivos (el concepto de especie).

*/

#define PARAMETROS 1

// Condiciones de error y exito
#define ERRORMEMORIA 10
#define EXCEDIOLIMITES 11
#define OPERACIONEXITOSA 1
#define MAXIMALONGEXPRESION 50 //Limitante del evaluador de expresiones


// Constantes de Ambiente
#define AMB_DENTRO 1
#define AMB_FUERA 0

// Mutacion
#define MUT_LONGEXPR 60
#define MUT_TAMANOPILALISTA 101 //Representa el 100%

// Material
#define MAT_OCUPADO 1
#define MAT_NOOCUPADO 0

//Organismo
#define ORG_VIVO 1
#define ORG_MUERTO 0
#define ORG_RECIEN 2  //Recien nace


