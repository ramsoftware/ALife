/*
Autor:		Rafael Alberto Moreno Parra
URL:		http://www.geocities.com/krousky
Clase:		Mutacion
Lenguaje:	C++

Prop�sito:
Clase de generaci�n/modificaci�n de expresiones matem�ticas en forma
aleatoria.

M�todos:
vIniLista_DosVar: Optimiza la generaci�n/modificaci�n de expresiones
vCrearExpresion_DosVar: Genera expresi�n

*/

#include "Parametro.h"

class Mutacion {
public:
    int vIniLista(unsigned int iProbN, unsigned int iProbX, unsigned int iProbY, unsigned int iProbP);
	void vCreaExpresion(unsigned int iProbN, unsigned int iProbX, unsigned int iProbY, unsigned int iProbP, unsigned int iLongExpr);
    char sExpresion[MUT_LONGEXPR]; //La expresion que se genera

private:
    unsigned char sOperNumPar[MUT_TAMANOPILALISTA]; //Por velocidad: Almacena un listado de Numeros, Operadores, Variables X, Parentesis
                               //para cuando se construyan las expresiones sea muy rapido.
};