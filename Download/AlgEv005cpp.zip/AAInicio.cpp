/*
[A-Life]: Investigaci�n sobre Vida Artificial. El Algoritmo Evolutivo.

Autor: Rafael Alberto Moreno Parra. enginelife@hotmail.com
URL:   http://www.geocities.com/krousky
Fecha: 01 de Septiembre de 2001

Simulaci�n:  AlgEvo005
Herramienta: Microsoft Visual C++ 6.0

Objetivo:
Hay un Universo
Universo tiene ambientes
Universo tiene tipos de materiales
Hay materiales de cada tipo dispersos por todo el Universo
El ser vivo es la cooperaci�n entre materiales
*/

#include <stdio.h>

#include "Universo.h"


void main()
{
	Universo objUniv;
	objUniv.BigBang();
	objUniv.vCicloVida();
}
