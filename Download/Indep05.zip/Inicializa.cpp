/*
Autor:		Rafael Alberto Moreno Parra
URL:		http://www.geocities.com/krousky
Clase:		Inicializa.
Lenguaje:	C++

Prop�sito:
Inicializa las variables para la simulaci�n

*/

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>
#include "Inicializa.h"
#include "StringUtil.h"

void Inicializa::vPantallaIni()
{
	printf("Independencia 05: Algoritmos mas veloces y con menor consumo de memoria\n\n");
	printf("Autor: Rafael Alberto Moreno Parra\n");
	printf("Fecha: 21 de Julio de 2002\n");
	printf("E-mail: enginelife@hotmail.com\n");
	printf("http://www.geocities.com/krousky\n\n");
};

//Abre y estudia el archivo de inicializaci�n
int Inicializa::vLeeArchivoIni()
{
	FILE *fpInicio;
	char sFrase[600], sVariable[200], sValor[200];
    unsigned int iCar;
	StringUtil StrUtil;

	//Inicializa la estructura
	stDatVA.iNumInstMin = 0;
	stDatVA.iNumInstMax = 0;
	stDatVA.iNumCiclos = 0;
	stDatVA.iTotalAzar = 0;
	stDatVA.iTotalMutar = 0;
	stDatVA.iTotalVar = 0;
	stDatVA.iTotalFun = 0;
	strcpy(stDatVA.sArchResult, "Motor05p1.txt");
	
	fpInicio = fopen("Indep05.ini", "r+t");
	if (fpInicio == NULL)
    {
		printf("Error al tratar de abrir archivo de inicializaci�n Indep05.ini\n");
		return -1;
    }
	while(!feof(fpInicio))
	{
		fgets(sFrase, 298, fpInicio);
		StrUtil.vQuitaEspacios(sFrase);

		//Extrae variables y valores
		for (iCar=0; iCar<strlen(sFrase) && sFrase[iCar]!='='; iCar++);
		StrUtil.vLeft(sVariable, sFrase, iCar);
		StrUtil.vMid(sValor, sFrase, iCar+2,strlen(sFrase)-1);

		//Clasifica variables
		if(strcmp(sVariable, "iNumInstMin")==0) stDatVA.iNumInstMin = atoi(sValor);
		if(strcmp(sVariable, "iNumInstMax")==0) stDatVA.iNumInstMax = atoi(sValor);
		if(strcmp(sVariable, "iNumCiclos")==0) stDatVA.iNumCiclos= atoi(sValor);
		if(strcmp(sVariable, "iAlgoritmosAzar")==0) stDatVA.iTotalAzar = atoi(sValor);
		if(strcmp(sVariable, "iAlgoritmosMuta")==0) stDatVA.iTotalMutar = atoi(sValor);
		if(strcmp(sVariable, "iTotalVar")==0) stDatVA.iTotalVar = atoi(sValor);
		if(strcmp(sVariable, "iTotalFun")==0) stDatVA.iTotalFun = atoi(sValor);
		if(strcmp(sVariable, "sEntrada")==0) strcpy(stDatVA.sEntrada, sValor);
		if(strcmp(sVariable, "sSalidas")==0) strcpy(stDatVA.sSalidas, sValor);

		if(strcmp(sVariable, "sArchResult")==0)
		{
			if (strlen(sValor) > 15 || strlen(sValor) < 3)
			{
				printf("Mal Nombre de archivo de resultado. sArchResult M�nimo: 3 M�ximo: 15 caracteres\n");
				return -1;
			}
			strcpy(stDatVA.sArchResult, sValor);
		}
	}
	

    //Valida los valores de entrada
	if (stDatVA.iNumInstMax > 2000 || stDatVA.iNumInstMax < 8)
	{
		printf("Mal n�mero de instrucciones (iNumInstMax min 8 max 2000)\n");
		return -1;
	}

	if (stDatVA.iTotalVar < 2 )
	{
		printf("Mal n�mero de Variables (iTotalVar min 2 max 30)\n");
		return -1;
	}

	fclose(fpInicio);
	return 0;
};

//Hace el encabezado del archivo de resultados
void Inicializa::vArchResult()
{
    //Leidos de una vez los par�metros de simulaci�n, comienza a simular
	FILE *fpSimular;
    unlink(stDatVA.sArchResult);
	fpSimular = fopen(stDatVA.sArchResult, "a+t");
	fprintf(fpSimular,"Independencia 05: Instrucciones mas r�pidas\n");
	fprintf(fpSimular,"Serie Entrada: [%s]\n", stDatVA.sEntrada);
	fprintf(fpSimular,"Serie Salida: [%s]\n", stDatVA.sSalidas);
	fprintf(fpSimular,"\nPosibilidades:\n");
	fprintf(fpSimular,"N�mero de Instrucciones m�nimas para cada Algoritmo: %d\n", stDatVA.iNumInstMin);
	fprintf(fpSimular,"N�mero de Instrucciones m�ximas para cada Algoritmo: %d\n", stDatVA.iNumInstMax);
	fprintf(fpSimular,"Numero de Algoritmos Gen�ticos generados al azar: %d\n", stDatVA.iTotalAzar);
	fprintf(fpSimular,"Numero de veces que se muta el mejor Algoritmo Gen�tico: %d\n", stDatVA.iTotalMutar);
	fprintf(fpSimular,"N�mero m�ximo de ciclos para evaluar cada Algoritmo: %d\n", stDatVA.iNumCiclos);
	
	time_t ltime;
    time( &ltime );
    fprintf(fpSimular,"\nSimulaci�n inicia en: %s\n", ctime( &ltime ) );
	fclose(fpSimular);
};


//Graba una l�nea al archivo
void Inicializa::vGrabaLinea(char *sMensaje)
{
	FILE *fpSimular;

	fpSimular = fopen(stDatVA.sArchResult, "a+t");
	fprintf(fpSimular,"\n\n%s\n\n", sMensaje);
	fclose(fpSimular);
};

//Graba a archivo el algoritmo gen�tico
void Inicializa::vGrabaAlgoritmos(unsigned int iIntento, float fMargenError, char *sMensaje)
{
	FILE *fpSimular;

	fpSimular = fopen(stDatVA.sArchResult, "a+t");
	fprintf(fpSimular,"Intento: [%d], Margen de Error (menor es mejor): [%f]\n", iIntento, fMargenError);
	fprintf(fpSimular,"%s\n", sMensaje);
	fclose(fpSimular);
};

//Este es el pie de p�gina del archivo de resultado
void Inicializa::vFinalSimulacion()
{
	FILE *fpSimular;
	time_t ltime;

	fpSimular = fopen(stDatVA.sArchResult, "a+t");
	time( &ltime );
	fprintf(fpSimular,"Finaliza en: %s\n", ctime( &ltime ) );
	fclose(fpSimular);
};