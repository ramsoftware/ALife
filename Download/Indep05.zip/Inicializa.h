/*
Autor:		Rafael Alberto Moreno Parra
URL:		http://www.geocities.com/krousky
Clase:		Inicializa.
Lenguaje:	C++

Prop�sito:
Inicializa las variables para la simulaci�n

M�todos:

*/
class Inicializa {
public:

	struct stDatosSimul
	{
   		//Probabilidades, estos datos se leen de un archivo de inicializaci�n
		unsigned int iNumInstMin; //Numero de instrucciones(tripletes) m�nimo generado
		unsigned int iNumInstMax; //Numero de instrucciones(tripletes) m�ximo generado
		unsigned int iTotalFun; //Total Funciones
		unsigned int iTotalVar; //Total Variables
		unsigned int iNumCiclos; //Maximos Ciclos de Evaluaci�n
		unsigned int iTotalAzar; //Total Algoritmos geneticos al azar
		unsigned int iTotalMutar; //Total Mutaciones al mejor algoritmo
		char sEntrada[200];
		char sSalidas[200];
		char sArchResult[50]; //Archivo donde se guarda el resultado
	};  

	struct stDatosSimul stDatVA; //Datos Vida Artificial
	void vPantallaIni(void);
    int vLeeArchivoIni(void);
	void vArchResult(void);
	void vGrabaLinea(char *sMensaje);
	void vGrabaAlgoritmos(unsigned int iIntento, float fMargenError, char *sMensaje);
	void vFinalSimulacion(void);
};
