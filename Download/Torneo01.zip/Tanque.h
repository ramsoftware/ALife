/* Este es el Macro Organismo */

class Tanque
{
public:
	unsigned int iCodigo;
	unsigned int iPosX;
	unsigned int iPosY;
	signed int iVida; /* Vida = 0 el organismo esta muerto */
	unsigned int iRadar; /* Posici�n del radar 1 a 8 */
	unsigned int iDireccion; /* Posici�n del tanque de 1 a 8 */
	bool bEstadoBala; /* True es que la bala fue disparada */
	unsigned int iPosBalaX;
	unsigned int iPosBalaY;
	unsigned int iDirBala; /* 1 a 8 */
};


