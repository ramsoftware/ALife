/* Torneo de Organismos
   Inspirado en el programa Robocode de IBM, esta simulaci�n consiste en generar N tanques
   en un tablero (un plano), cada tanque puede girar, desplazarse hacia adelante o hacia atr�s,
   tiene un radar y disparar. Mientras dura el torneo, en cada ciclo, el tanque va perdiendo
   un punto de vida, pierde tres puntos de vida si es impactado por un proyectil de otro tanque
   y gana tres puntos de vida si al disparar acierta a otro tanque.

   El tanque tiene cuatro(4) eventos que se activan cuando:
   1. Es alcanzado por un disparo.
   2. Acierta su disparo en otro tanque.
   3. Choca contra otro tanque.
   4. Detecta otro tanque con el radar.

   Cada evento dispara una serie de instrucciones que han sido previamente generadas al azar.

   En esas instrucciones, t�picas de un lenguaje muy simple de programaci�n se manejan:
   1. Diez(10) variables.
   2. Las instrucciones IF y SET (asignaci�n)
   3. Ocho(8) funciones:
			a: Avanzar_Tanque();
			b: Retroceder_Tanque();
			c: Girar_Tanque(1-8);
			d: Girar_Radar(1-8);
			e: Disparar();  disminuye vida en un punto
			f: GetPosX();
			g: GetPosY();
			h: GetVida();
 

  Observaciones:  Este programa se crea como base de desarrollos futuros para probar conceptos
    sobre la evoluci�n: macroorganismos, reproducci�n, sensores, emociones, etc..
    Fue dise�ado para ser lo m�s r�pido posible.
    

  Versi�n: 1.0
  Fecha: 27 de Diciembre de 2003
  
  Autor: Rafael Alberto Moreno Parra
  E-mail: enginelife@hotmail.com
  WebPage: http://www.geocities.com/krousky


*/

#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <string.h>

#include "Tanque.h"
#include "Instruccion.h"

#define NUMTANQUES 70
#define NUMEVENTOS 5
#define NUMINSTRUC 50
#define TABLEROX 20 /* Tama�o del tablero */
#define TABLEROY 20
#define CONSTVIDA 100 /* Con cuanta vida empieza un tanque */
#define MAXCICLOS 60


Tanque objTanque[NUMTANQUES];
Instruccion objInst[NUMINSTRUC];
int objRelacion[NUMTANQUES][NUMEVENTOS];


void vGeneraTanques(void);
void vCreaTanque(unsigned int);
void vGeneraInstrucciones(void);
void vCreaInstruccion(unsigned int);
bool bChequeaColision(unsigned int);

bool bImpactado(unsigned int);
bool bAciertaDisparo(unsigned int);
bool bChequeaColision(unsigned int);
bool bDetectaRadar(unsigned int);

void vEjecutaInstrucciones(unsigned int, unsigned int);
void vAvance(unsigned int, signed int *, signed int *);
void vInforme(unsigned int);
void vMuestraInstrucciones(unsigned int);



void main()
{
	signed int iBalaX, iBalaY; /* Para mover la bala disparada por el tanque */
	unsigned int iTanque; /* Para ir de tanque en tanque */
	unsigned int iTanquesVivos = NUMTANQUES; /* Que tanques estan vivitos y coleando */
	
	/* Coloca los tanques en posiciones, radar, direcci�n al azar con determinada energ�a */
	vGeneraTanques();

	/* Crea las instrucciones */
	vGeneraInstrucciones();

	/* Crea la relaci�n Tanque + Evento + Instruccion */
	for( iTanque=0; iTanque < NUMTANQUES; iTanque++)
		for ( unsigned int iEvento=0; iEvento < NUMEVENTOS; iEvento++)
			objRelacion[iTanque][iEvento] = abs(rand()%NUMINSTRUC);

	/* Ciclo de vida de los Tanques */
	iTanque = 0;
	while (iTanquesVivos > 1) /* Si solo queda un tanque vivo termina la simulaci�n */
	{
		/* Chequea cuantos tanques vivos quedaron */
		iTanquesVivos = 0;
		for (unsigned int iCont=0; iCont < NUMTANQUES; iCont++)
			if (objTanque[iCont].iVida > 0) iTanquesVivos++;

		if (objTanque[iTanque].iVida <= 0)
		{
			iTanque++;
			if (iTanque >= NUMTANQUES) iTanque = 0;
			continue;
		}
		
		/* Imprime el estado del tanque */
	//	printf("iTanque: %d, iPosX: %d, iPosY: %d, iVida: %d\n", iTanque, objTanque[iTanque].iPosX, objTanque[iTanque].iPosY, objTanque[iTanque].iVida);
		
		/* �Lo impactaron? quita un punto de vida */
		if (bImpactado(iTanque))
		{
			objTanque[iTanque].iVida-=3;

			//Ejecuta las instrucciones
			vEjecutaInstrucciones(iTanque, 0);
		}

		/* Instrucciones que hace el tanque sin necesidad de emociones */
		{		
			if (objTanque[iTanque].bEstadoBala)
			{
				vAvance(objTanque[iTanque].iDirBala, &iBalaX, &iBalaY);
				objTanque[iTanque].iPosBalaX += iBalaX;
				objTanque[iTanque].iPosBalaY += iBalaY;
			}	

			if (objTanque[iTanque].iPosBalaX < 0 || objTanque[iTanque].iPosBalaX >= TABLEROX) objTanque[iTanque].bEstadoBala = false;
			if (objTanque[iTanque].iPosBalaY < 0 || objTanque[iTanque].iPosBalaY >= TABLEROY) objTanque[iTanque].bEstadoBala = false;

			//Ejecuta instrucciones del Tanque
			vEjecutaInstrucciones(iTanque, 4);

			//Va perdiendo vida por el simple hecho de vivir
			objTanque[iTanque].iVida--;
		}

		
		/* �La bala disparada impact� a un tanque enemigo? da tres puntos de vida */
		if (bAciertaDisparo(iTanque))
		{
			objTanque[iTanque].iVida+=3;

			//Ejecuta las instrucciones
			vEjecutaInstrucciones(iTanque, 1);
		}

		/* �Choc� con otro tanque? */
		if (bChequeaColision(iTanque))
		{
			//Ejecuta las instrucciones
			vEjecutaInstrucciones(iTanque, 2);
		}

		/* �Detect� otro tanque con el radar? */
		if (bDetectaRadar(iTanque))
		{
			//Ejecuta las instrucciones
			vEjecutaInstrucciones(iTanque, 3);
		}


		/* Un ciclo cerrado para evaluar cada tanque */
		iTanque++;
		if (iTanque >= NUMTANQUES) iTanque = 0;
	}

	/* Escribe el tanque que sobrevivi� */
	printf("Sobrevivio: \n");
	for (iTanque=0; iTanque < NUMTANQUES; iTanque++)
		if (objTanque[iTanque].iVida > 0) break;
    vInforme(iTanque);
}

/* Genera todos los tanques */
void vGeneraTanques()
{
	for (unsigned int iCont = 0; iCont < NUMTANQUES; iCont++)
		vCreaTanque(iCont);
}

/* Genera un tanque en particular */
void vCreaTanque(unsigned int iTanque)
{
	objTanque[iTanque].iCodigo = iTanque;

	do
	{
		objTanque[iTanque].iPosX = abs(rand() % TABLEROX);
		objTanque[iTanque].iPosY = abs(rand() % TABLEROY);
	} while (bChequeaColision(iTanque));

	objTanque[iTanque].iDireccion = abs(rand() % 8);
	objTanque[iTanque].iRadar = abs(rand() % 8 );
	objTanque[iTanque].bEstadoBala = false;
	objTanque[iTanque].iVida = CONSTVIDA;

}

/* Genera todos los juegos de instrucciones */
void vGeneraInstrucciones()
{
	for (unsigned int iCont = 0; iCont < NUMINSTRUC; iCont++)
		vCreaInstruccion(iCont);
}

/* Genera un juego de instrucciones en particular */
void vCreaInstruccion(unsigned int iInstr)
{
	for (unsigned int iCont=0; iCont < TRIPLETES; iCont++)
	{
		objInst[iInstr].m_oTriplete[iCont].bEjecuta = false;
		
		/* 
			0:  IF >
			1:  IF <
			2:  IF =
			3:  IF <>
			4:  SET
			5:  Avanzar_Tanque();
			6:  Retroceder_Tanque();
			7:  Girar_Tanque(1-8);
			8:  Girar_Radar(1-8);
			9:  Disparar();  disminuye vida en un punto
			10: GetPosX();
			11: GetPosY();
			12: GetVida();
        */
		objInst[iInstr].m_oTriplete[iCont].iInstruccion = abs(rand()%13);
		
		/* Variable que recibe el resultado de la funci�n */
		objInst[iInstr].m_oTriplete[iCont].iRecibe = abs(rand()%VARIABLES);

		/* Chequea si el primer operando es variable o un n�mero */
		if (abs(rand()%2) == 0 )
			objInst[iInstr].m_oTriplete[iCont].bEsNumero1 = true;
		else
			objInst[iInstr].m_oTriplete[iCont].bEsNumero1 = false;

		/* Chequea si el segundo operando es variable o un n�mero */
		if (abs(rand()%2) == 0 )
			objInst[iInstr].m_oTriplete[iCont].bEsNumero2 = true;
		else
			objInst[iInstr].m_oTriplete[iCont].bEsNumero2 = false;

		/* Variable o n�mero... decide cual, si es un n�mero va de 0 a 9 */
		objInst[iInstr].m_oTriplete[iCont].iVariable1 = abs(rand()%VARIABLES);
		objInst[iInstr].m_oTriplete[iCont].iVariable2 = abs(rand()%VARIABLES);

		/* Decide operador */
		switch (abs(rand()%4))
		{
		case 0: objInst[iInstr].m_oTriplete[iCont].cOperador = '+'; break;
		case 1: objInst[iInstr].m_oTriplete[iCont].cOperador = '-'; break;
		case 2: objInst[iInstr].m_oTriplete[iCont].cOperador = '*'; break;
		case 3: objInst[iInstr].m_oTriplete[iCont].cOperador = '/'; break;
		}
		
		/* Salta a si hay una condicion IF */
		objInst[iInstr].m_oTriplete[iCont].iGotoLabel = abs(rand()%TRIPLETES);
	}
}


/* ************************************************************************************ */
/*                            SECCION DE EVENTOS O EMOCIONES                            */ 
/* ************************************************************************************ */

/* Chequea si al tanque lo impactaron */
bool bImpactado (unsigned int iTanque)
{
	for (unsigned int iCont = 0; iCont < NUMTANQUES; iCont++)
	{
		if (iCont != iTanque && objTanque[iCont].iVida > 0 && objTanque[iCont].bEstadoBala == true )
			if ( objTanque[iTanque].iPosX == objTanque[iCont].iPosBalaX &&
				 objTanque[iTanque].iPosY == objTanque[iCont].iPosBalaY )
			{
				objTanque[iCont].bEstadoBala = false; /* Puede disparar de nuevo el tanque que le acert� primero */
				return true;
			}
	}

	return false;
}

/* Chequea si la bala disparada acert� en un tanque enemigo */
bool bAciertaDisparo (unsigned int iTanque)
{
	if (objTanque[iTanque].bEstadoBala == false) return false;

	for (unsigned int iCont = 0; iCont < NUMTANQUES; iCont++)
	{
		if (iCont != iTanque && objTanque[iCont].iVida > 0)
			if ( objTanque[iTanque].iPosBalaX == objTanque[iCont].iPosX &&
				 objTanque[iTanque].iPosBalaY == objTanque[iCont].iPosY )
					return true;
	}

	return false;
}

/* Chequea si el tanque esta colisionando con otro tanque vivo */
bool bChequeaColision (unsigned int iTanque)
{
	for (unsigned int iCont = 0; iCont < NUMTANQUES; iCont++)
	{
		if (iCont != iTanque && objTanque[iCont].iVida > 0 )
			if ( objTanque[iTanque].iPosX == objTanque[iCont].iPosX &&
				 objTanque[iTanque].iPosY == objTanque[iCont].iPosY )
					return true;
	}

	return false;
}
		
/* �Detect� otro tanque con el radar? */
bool bDetectaRadar (unsigned int iTanque)
{
	signed int iRastreoX, iRastreoY;
	unsigned int iPosRadarX, iPosRadarY;

	/* Depende de la posici�n que tiene el radar */
	vAvance(objTanque[iTanque].iRadar, &iRastreoX, &iRastreoY);

	/* Desde la posici�n del tanque hasta los l�mites del tablero */
	iPosRadarX = objTanque[iTanque].iPosX;
	iPosRadarY = objTanque[iTanque].iPosY;

	while (iPosRadarX >= 0 && iPosRadarX < TABLEROX && iPosRadarY >= 0 && iPosRadarY < TABLEROY)
	{
		iPosRadarX += iRastreoX;
		iPosRadarY += iRastreoY;
		
		for (unsigned int iCont = 0; iCont < NUMTANQUES; iCont++)
		{
			if (iCont != iTanque && objTanque[iCont].iVida > 0 )
				if ( objTanque[iCont].iPosX == iPosRadarX &&
					 objTanque[iCont].iPosY == iPosRadarY )
						return true;
		}
	}
    return false;
}

/* ***************************************************************************************** */
/* EJECUTAR INSTRUCCIONES DEL TANQUE 
/* ***************************************************************************************** */
void vEjecutaInstrucciones(unsigned int iTanque, unsigned int iEvento)
{
	unsigned int iInstr, iCont=0, iVarRecibe, iCiclo=0;
	signed int iIncX, iIncY, iValor1, iValor2, iValorT;
	bool bCiclo = true;

	iInstr = objRelacion[iTanque][iEvento]; //Trae las instrucciones para este tanque y evento (cruce)

	while(iCont<TRIPLETES && bCiclo)
	{
		/* Evita que se quede en un ciclo infinito */
		iCiclo++;
		if (iCiclo > MAXCICLOS) bCiclo = false;

		/* La instrucci�n ha sido ejecutada */
		objInst[iInstr].m_oTriplete[iCont].bEjecuta = true;

		/* Variable que recibe el resultado de la funci�n */
		iVarRecibe = objInst[iInstr].m_oTriplete[iCont].iRecibe;

		/* Las intrucciones IF se interpretan as�:
			IF varRecibe > var1  + var2 THEN Goto Etiqueta 
			IF varRecibe > 6557  - var2 THEN Goto Etiqueta
	    */
	    if (objInst[iInstr].m_oTriplete[iCont].bEsNumero1)
			iValor1 = objInst[iInstr].m_oTriplete[iCont].iVariable1;
		else
			iValor1 = objInst[iInstr].iVariable[objInst[iInstr].m_oTriplete[iCont].iVariable1];
			
		if (objInst[iInstr].m_oTriplete[iCont].bEsNumero2)
			iValor2 = objInst[iInstr].m_oTriplete[iCont].iVariable2;
		else
			iValor2 = objInst[iInstr].iVariable[objInst[iInstr].m_oTriplete[iCont].iVariable2];

		switch (objInst[iInstr].m_oTriplete[iCont].cOperador)
		{
			 case '+': iValorT = iValor1 + iValor2; break;
			 case '-': iValorT = iValor1 - iValor2; break;
			 case '*': iValorT = iValor1 * iValor2; break;
			 case '/': if (iValor2!=0)
						   iValorT = iValor1 / iValor2;
					   else
						   iValorT = 0;
					   break;
		}

		switch (objInst[iInstr].m_oTriplete[iCont].iInstruccion)
		{
		case 0:  //printf("IF > \n");
				 if (objInst[iInstr].iVariable[objInst[iInstr].m_oTriplete[iCont].iVariable1] > iValorT)
					 iCont = objInst[iInstr].m_oTriplete[iCont].iGotoLabel;
				 break; /* IF > */

		case 1:  //printf("IF < \n");
				 if (objInst[iInstr].iVariable[objInst[iInstr].m_oTriplete[iCont].iVariable1] < iValorT)
					 iCont = objInst[iInstr].m_oTriplete[iCont].iGotoLabel;
				 break; /* IF < */

		case 2:  //printf("IF ==  \n");
				 if (objInst[iInstr].iVariable[objInst[iInstr].m_oTriplete[iCont].iVariable1] == iValorT)
					 iCont = objInst[iInstr].m_oTriplete[iCont].iGotoLabel;
				 break; /* IF == */

		case 3:  //printf("IF <>  \n");
				 if (objInst[iInstr].iVariable[objInst[iInstr].m_oTriplete[iCont].iVariable1] != iValorT)
					 iCont = objInst[iInstr].m_oTriplete[iCont].iGotoLabel;
				 break; /* IF <> */

		case 4:  //printf("SET  \n");
				 objInst[iInstr].iVariable[iVarRecibe] = iValorT;
				 break; /* SET */

		case 5:  //printf("Avanzar Tanque \n");
				 vAvance(objTanque[iTanque].iDireccion, &iIncX, &iIncY);
				 objTanque[iTanque].iPosX += iIncX;
				 objTanque[iTanque].iPosY += iIncY;
				 if (objTanque[iTanque].iPosX < 0) objTanque[iTanque].iPosX = 0;
				 if (objTanque[iTanque].iPosX >= TABLEROX) objTanque[iTanque].iPosX = TABLEROX - 1;
				 if (objTanque[iTanque].iPosY < 0) objTanque[iTanque].iPosY = 0;
				 if (objTanque[iTanque].iPosY >= TABLEROY) objTanque[iTanque].iPosY = TABLEROY - 1;
				 break; /* Avanzar_Tanque */

		case 6:  //printf("Retroceder Tanque \n");
				 vAvance(objTanque[iTanque].iDireccion, &iIncX, &iIncY);
				 objTanque[iTanque].iPosX -= iIncX;
				 objTanque[iTanque].iPosY -= iIncY;
				 if (objTanque[iTanque].iPosX < 0) objTanque[iTanque].iPosX = 0;
				 if (objTanque[iTanque].iPosX >= TABLEROX) objTanque[iTanque].iPosX = TABLEROX - 1;
				 if (objTanque[iTanque].iPosY < 0) objTanque[iTanque].iPosY = 0;
				 if (objTanque[iTanque].iPosY >= TABLEROY) objTanque[iTanque].iPosY = TABLEROY - 1;
				 break; /* Retroceder Tanque */

		case 7:  //printf("Girar Tanque \n");
			     objTanque[iTanque].iDireccion = objInst[iInstr].iVariable[iVarRecibe];
				 break; /* Girar_Tanque(variable_recibe) */

		case 8:  //printf("Girar Radar \n");
				 objTanque[iTanque].iRadar = objInst[iInstr].iVariable[iVarRecibe];
				 break; /* Girar_Radar(variable_recibe) */

		case 9:	 //printf("Disparar \n");
			     if (objTanque[iTanque].bEstadoBala == false)
				 {
					objTanque[iTanque].bEstadoBala = true;
					objTanque[iTanque].iPosBalaX = objTanque[iTanque].iPosX;
					objTanque[iTanque].iPosBalaY = objTanque[iTanque].iPosY;
					objTanque[iTanque].iDirBala  = objTanque[iTanque].iDireccion;
					objTanque[iTanque].iVida--; /* Penaliza con un punto el disparar */
				 } 
				 break; /* Disparar */

		case 10: //printf("GetPosX \n");
			     objInst[iInstr].iVariable[iVarRecibe] = objTanque[iTanque].iPosX;
			     break; /* GetPosX */

		case 11: //printf("GetPosY \n");
			     objInst[iInstr].iVariable[iVarRecibe] = objTanque[iTanque].iPosY;
			     break; /* GetPosY */

		case 12: //printf("GetVida \n");
				 objInst[iInstr].iVariable[iVarRecibe] = objTanque[iTanque].iVida;
			     break; /* GetVida */
		}
		iCont++;
	}

}


/* Retorna que valores debe adicionar en X y Y para avanzar en la Matriz */
void vAvance(unsigned int iDireccion, signed int *iIncX, signed int *iIncY)
{
	switch(iDireccion)
	{
	case 0: *iIncX =  0; *iIncY = -1; break; /* Vertical hacia arriba */
	case 1: *iIncX =  1; *iIncY = -1; break; /* Diagonal derecha hacia arriba */
	case 2: *iIncX =  1; *iIncY =  0; break; /* Horizontal derecha */
	case 3: *iIncX =  1; *iIncY =  1; break; /* Diagonal derecha hacia abajo */
	case 4: *iIncX =  0; *iIncY =  1; break; /* Vertical hacia abajo */
	case 5: *iIncX = -1; *iIncY =  1; break; /* Diagonal izquierda hacia abajo */
	case 6: *iIncX = -1; *iIncY =  0; break; /* Horizontal izquierda */
	default: *iIncX = -1; *iIncY = -1; break; /* Diagonal izquierda hacia arriba */
	}
}


/* Informe sobre energ�a e instrucciones del Tanque */
void vInforme(unsigned int iTanque)
{
	printf("iTanque: %d, iPosX: %d, iPosY: %d, iVida: %d\n", iTanque, objTanque[iTanque].iPosX, objTanque[iTanque].iPosY, objTanque[iTanque].iVida);
	
	printf("\nFue Impactado: %d\n", objRelacion[iTanque][0]);
	vMuestraInstrucciones(objRelacion[iTanque][0]);

	printf("\nLe acerto a otro tanque: %d\n", objRelacion[iTanque][1]);
	vMuestraInstrucciones(objRelacion[iTanque][1]);

	printf("\nChoco con un tanque: %d\n", objRelacion[iTanque][2]);
	vMuestraInstrucciones(objRelacion[iTanque][2]);

	printf("\nDetecto el Radar: %d\n", objRelacion[iTanque][3]);
	vMuestraInstrucciones(objRelacion[iTanque][3]);

	printf("\nVida Normal: %d\n", objRelacion[iTanque][4]);
	vMuestraInstrucciones(objRelacion[iTanque][4]);
}

/* Muestra las instrucciones formateadas (creadas al azar) */
void vMuestraInstrucciones(unsigned int iInstr)
{
	char sbADN[1000], sExprTemp1[250], sExprTemp2[250]="";
	char cEnter[4];
    cEnter[0]= '\n';
    cEnter[1]= '\0';

	strcpy(sbADN,"#include <stdio.h>");
	strcat(sbADN,cEnter);
	strcat(sbADN,"void main()");
	strcat(sbADN,cEnter);
	strcat(sbADN,"{");
	strcat(sbADN,cEnter);
	strcat(sbADN,"  int V0=0, V1=0, V2=0, V3=0, V4=0, V5=0, V6=0, V7=0, V8=0, V9=0;");
	strcat(sbADN,cEnter);

	for (unsigned int iCont=1; iCont < TRIPLETES; iCont++)
    {
		sprintf(sExprTemp1, "  L%d: ", iCont);
		strcat(sbADN, sExprTemp1);

		if (objInst[iInstr].m_oTriplete[iCont].iInstruccion >= 5 ) //Es una funcion
		{
			switch(objInst[iInstr].m_oTriplete[iCont].iInstruccion)
			{
			case 5: sprintf(sExprTemp1, "Avanzar_Tanque();" ); break;
			case 6: sprintf(sExprTemp1, "Retroceder_Tanque();" ); break;
			case 7: sprintf(sExprTemp1, "Girar_Tanque(V%d);", objInst[iInstr].m_oTriplete[iCont].iRecibe ); break;
			case 8: sprintf(sExprTemp1, "Girar_Radar(V%d);", objInst[iInstr].m_oTriplete[iCont].iRecibe ); break;
			case 9: sprintf(sExprTemp1, "Disparar();" ); break;
			case 10: sprintf(sExprTemp1, "V%d = GetPosX();", objInst[iInstr].m_oTriplete[iCont].iRecibe); break;
			case 11: sprintf(sExprTemp1, "V%d = GetPosY();", objInst[iInstr].m_oTriplete[iCont].iRecibe); break;
			case 12: sprintf(sExprTemp1, "V%d = GetVida();", objInst[iInstr].m_oTriplete[iCont].iRecibe); break;
			}
		
			strcat(sbADN, sExprTemp1);
			strcat(sbADN, cEnter);
			continue;
		}
                 
        //Organiza los if y asignaciones
		if (objInst[iInstr].m_oTriplete[iCont].iInstruccion >=0 && objInst[iInstr].m_oTriplete[iCont].iInstruccion <= 3)
			strcat(sbADN, "if (");

		sprintf(sExprTemp1, "V%d ", objInst[iInstr].m_oTriplete[iCont].iRecibe);
		strcat(sbADN, sExprTemp1);

		switch (objInst[iInstr].m_oTriplete[iCont].iInstruccion)
		{
			case 0:	strcat(sbADN, "> ("); break;
			case 1:	strcat(sbADN, "< ("); break;
			case 2:	strcat(sbADN, "== ("); break;
			case 3:	strcat(sbADN, "!= ("); break;
			case 4:	strcat(sbADN, "= ("); break;
		}

		if (objInst[iInstr].m_oTriplete[iCont].bEsNumero1 == false)
			sprintf(sExprTemp1, "V%d", objInst[iInstr].m_oTriplete[iCont].iVariable1);
		else
			sprintf(sExprTemp1,  "%d", objInst[iInstr].m_oTriplete[iCont].iVariable1);

		strcat(sbADN, sExprTemp1);
		sprintf(sExprTemp1, " %c ", objInst[iInstr].m_oTriplete[iCont].cOperador);
		strcat(sbADN, sExprTemp1);

		if (objInst[iInstr].m_oTriplete[iCont].bEsNumero2 == false)
			sprintf(sExprTemp1, "V%d)", objInst[iInstr].m_oTriplete[iCont].iVariable2);
		else
			sprintf(sExprTemp1,  "%d)", objInst[iInstr].m_oTriplete[iCont].iVariable2);
		strcat(sbADN, sExprTemp1);

		if (objInst[iInstr].m_oTriplete[iCont].iInstruccion>=0 && objInst[iInstr].m_oTriplete[iCont].iInstruccion <= 3)
		{
			sprintf(sExprTemp1, ") goto L%d;", objInst[iInstr].m_oTriplete[iCont].iGotoLabel);
			strcat(sbADN, sExprTemp1);
		}
		else
			strcat(sbADN, ";");

		strcat(sbADN, cEnter);
	}
	strcat(sbADN, "  L0: ");
	strcat(sbADN, cEnter);
	strcat(sbADN, "}");
	strcat(sbADN, cEnter);
	printf(sbADN);
}
