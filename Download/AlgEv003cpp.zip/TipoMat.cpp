/*
[A-Life]: Investigaci�n sobre Vida Artificial. El Algoritmo Evolutivo.

Autor: Rafael Alberto Moreno Parra. enginelife@hotmail.com
URL:   http://www.geocities.com/krousky
Fecha: 24 de Marzo de 2001

Simulaci�n:  AlgEvo001
Herramienta: Microsoft Visual C++ 6.0

Objetivo:
Hay un Universo
Universo tiene ambientes
Universo tiene tipos de materiales
Hay materiales de cada tipo dispersos por todo el Universo
El ser vivo es la cooperaci�n entre materiales

*/
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "TipoMat.h"
#include "Mutacion.h"


unsigned int TipoMat::iInicia(unsigned int iID,
					unsigned int iLongExprTip,
					unsigned int iProbN, unsigned int iProbX, unsigned int iProbP)
{
	/* Valida MAXIMALONGEXPRESION */
	if (iLongExprTip >= MAXIMALONGEXPRESION )
		return EXCEDIOLIMITES;

	/* Reserva memoria para la Ecuaci�n */
	m_sEcuacion = (char *) malloc ( sizeof(char) * iLongExprTip + 10 );
	if (m_sEcuacion == NULL) return ERRORMEMORIA;

	/* ID del tipo de material */
	m_iIDtipo = iID;
	
	/* Ecuaci�n que define el comportamiento del tipo de material f(x) */
	Mutacion objMuta;

	objMuta.vIniLista(iProbN,iProbX,0,iProbP);
	objMuta.vCreaExpresion(iProbN,iProbX,0,iProbP,iLongExprTip);
	strcpy(m_sEcuacion, objMuta.sExpresion);

	/* Evalua la expresi�n previamente para mayor velocidad */
	objEval.dCapturaEcuacion(m_sEcuacion, (float) 0, (float) 0);

	return OPERACIONEXITOSA;

};

/* Suma o resta energ�a dependiendo de como es el ambiente */
signed int TipoMat::iEnergia(float fValAmbiente)
{
	float fResult = objEval.dCicloEvalua(fValAmbiente, (float) 0);

	if (fResult <= 0 )
		return -1;
	else
		return 1;
};