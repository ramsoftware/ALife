/*
[A-Life]: Investigaci�n sobre Vida Artificial. El Algoritmo Evolutivo.

Autor: Rafael Alberto Moreno Parra. enginelife@hotmail.com
URL:   http://www.geocities.com/krousky
Fecha: 24 de Marzo de 2001

Simulaci�n:  AlgEvo003
Herramienta: Microsoft Visual C++ 6.0

Objetivo:
Hay un Universo
Universo tiene ambientes
Universo tiene tipos de materiales
Hay materiales de cada tipo dispersos por todo el Universo
El ser vivo es la cooperaci�n entre materiales
Hay tipos de seres vivos (el concepto de especie).
*/


class Inicializa {
public:

	struct stDatosSimul
	{
   		//Probabilidades, estos datos se leen de un archivo de inicializaci�n

		//Universo
		unsigned int iXmin; // Coordenadas de ocupaci�n del Universo
		unsigned int iYmin;
		unsigned int iXmax;
		unsigned int iYmax;

		unsigned int iTotalAmb; //Total ambientes
		unsigned int iTotalTip; //Total tipos de materia
		unsigned int iTotalMat; //Total materiales
		unsigned int iTotalEsp; //Total especies
		unsigned int iTotalOrg; //Total organismos

		//Ambientes
		unsigned int iLongExprAmb; //Longitud de la expresi�n de ambiente
		unsigned int iProbN; // Probabilidad de Numero
		unsigned int iProbX; // Probabilidad de variable X
		unsigned int iProbY; // Probabilidad de variable Y
		unsigned int iProbP; // Probabilidad de parentesis

		//Tipo de Material
		unsigned int iLongExprTip; //Longitud de la expresi�n de ambiente
		unsigned int iTipProbN; // Probabilidad de Numero
		unsigned int iTipProbX; // Probabilidad de variable X
		unsigned int iTipProbP; // Probabilidad de parentesis

		//Especies
		unsigned int iTipMatEsp; //M�ximo n�mero de tipos de material que tendr� cada especie
		unsigned int iMaxMatTip; //M�ximos materiales por tipo de material que tendr� cada especie
		signed int iTolVivoMin; //Tolerancia m�nima de los seres vivos (por ejemplo temperatura)
		signed int iTolVivoMax; //Tolerancia m�xima de los seres vivos
	};  

	struct stDatosSimul stDatVA; //Datos Vida Artificial
	void vPantallaIni(void);
    int vLeeArchivoIni(void);
};
