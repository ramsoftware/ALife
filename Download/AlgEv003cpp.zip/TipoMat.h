/*
[A-Life]: Investigaci�n sobre Vida Artificial. El Algoritmo Evolutivo.

Autor: Rafael Alberto Moreno Parra. enginelife@hotmail.com
URL:   http://www.geocities.com/krousky
Fecha: 24 de Marzo de 2001

Simulaci�n:  AlgEvo003
Herramienta: Microsoft Visual C++ 6.0

Objetivo:
Hay un Universo
Universo tiene ambientes
Universo tiene tipos de materiales
Hay materiales de cada tipo dispersos por todo el Universo
El ser vivo es la cooperaci�n entre materiales
Hay tipos de seres vivos (el concepto de especie).
*/

#ifndef PARAMETRO
#include "Parametro.h"
#endif


#ifndef EVALUADOREXPRESIONES
#include "EvalExpr.h"
#endif


#define TIPOMATERIAL 1

//Tipo de Material
class TipoMat
{
private:
	/* Como se comporta en el ambiente donde se encuentra en f(z) */
	char *m_sEcuacion;

	/* Evalua previamente la ecuaci�n para dar mayor velocidad */
	EvalExpr objEval;

public:
	/* Identificador de Tipo */
	unsigned int m_iIDtipo;

	/* Inicia el comportamiento del material */
	unsigned int iInicia(unsigned int iID,
		         unsigned int iLongExprTip,
				 unsigned int iProbN, unsigned int iProbX, unsigned int iProbP);

	/* Suma o resta energ�a dependiendo de como es el ambiente */
	signed int iEnergia(float fValAmbiente);
};
