/*
[A-Life]: Investigaci�n sobre Vida Artificial. El Algoritmo Evolutivo.

Autor: Rafael Alberto Moreno Parra. enginelife@hotmail.com
URL:   http://www.geocities.com/krousky
Fecha: 24 de Marzo de 2001

Simulaci�n:  AlgEvo003
Herramienta: Microsoft Visual C++ 6.0

Objetivo:
Hay un Universo
Universo tiene ambientes
Universo tiene tipos de materiales
Hay materiales de cada tipo dispersos por todo el Universo
El ser vivo es la cooperaci�n entre materiales

*/
#include <stdlib.h>

#include "Organismo.h"

void Organismo::vNace(unsigned int iEstabilidad, unsigned int iTolMin, unsigned int iTolMax, unsigned int iNumMaterial)
{
	m_iEstabilidad = iEstabilidad;
	m_cVivo = ORG_VIVO;

//	m_iIDmaterial = (unsigned int *) malloc (sizeof(unsigned int) * iNumMaterial + 6);
}